# KarstBlast Hackathon — Phase 1 Plan
## Focus: Kuz-Ram vs Wipfrag Comparison & Reporting Improvement

> Status: DRAFT — awaiting user review before Phase 2 implementation begins.
> Revised: user selected Kuz-Ram vs Wipfrag comparison and reporting as the improvement focus.

---

## A. PROJECT AND ARCHITECTURE ASSESSMENT

### What KarstBlast Is
KarstBlast Analytics & Optimizer is a **browser-based, single-page application** for limestone-quarry blast fragmentation analysis. It is written in plain JavaScript (no module bundler), served from a local HTTP server, and relies on three vendor libraries: Plotly 2.35.2, PapaParse, SheetJS 0.18.5.

The application runs entirely client-side. All data is stored in `localStorage`. There is no server back-end, no database, and no network-dependent functionality except loading vendor scripts from `vendor/`.

### Current Technical Architecture

```
index.html          — Markup, CSP meta, script/style load order (critical)
css/style.css       — 24 cascade-ordered blocks; BLOCK 24 = accessibility
js/lab-data.js      — Embedded lab sample dataset (window.KB_EMBEDDED_LAB_SOURCE)
js/app.js           — Single IIFE (~8,000 lines); all state and logic
js/patches.js       — Post-init DOM patches, try/catch-isolated
js/a11y.js          — Tab navigation, roving tabindex, skip link
vendor/             — Plotly, PapaParse, SheetJS (locally hosted)
qa/                 — Playwright spec (unenforced), Python runners (unavailable), JSON results
```

**APP_STATE.kuzram** contains:
- `mode` — 'excel' | 'corrected'
- `source` — 'actual' | 'ash' | 'konya' | 'mae' | null
- `manual` / `manualSrc` — manual parameter overrides
- `geo` — global geometry override (applies to ALL blast rows)
- `wipBy` — per-blast Wipfrag data, keyed as `groupKey + '|' + rowNo`
- `simSrc` — 'kuzram' | 'wipfrag' (which distribution drives animation)

---

## B. VERIFIED FEATURE INVENTORY (Focus Area)

### Kuz-Ram Engine (VERIFIED WORKING)
- `kzCompute(input, mode)` — pure function, returns X50, X80, n, Xc, passFn, oversize, undersize, passing@target
- `kzCurve(result, pts)` — PSD curve points (60 pts default)
- `kzParticles(result, N, seed)` — 220 mass-weighted particles for simulation
- EXCEL mode matches BB-6 spreadsheet exactly; documented X50 = 31.3 cm for example data
- CORRECTION mode available for comparison; `kzRender()` shows Δn, ΔX80 between modes

### Wipfrag Integration (VERIFIED WORKING)
- `kzEnsureWipBox()` — dynamically creates the Wipfrag panel (paste textarea, buttons)
- `kzActiveWip()` — returns Wipfrag rows for the currently active blast
- `kzWipId()` — returns `{ key, label }` for the active blast's wipBy key
- `kzWipCurve(rows)` — converts raw rows to interpolatable curve `{p, x}` array
- `kzWipSize(curve, u)` / `kzWipPass(curve, x)` — interpolation functions
- `kzParseWip(text, mode)` — robust parser (handles %, fraction, koma, 4-col rejection)
- Single-level undo via `#kzWipUndo` (REQ-10, qa/CHANGELOG.md v4)
- JSON export/import with validation and conflict detection

### Current Comparison View (VERIFIED WORKING, but limited)
- `kzRenderCmp(res, wc)` — renders a small 6-row comparison table inside `#kzCmp`:
  - Columns: "Perbandingan | Kuz-Ram | Wipfrag"
  - Rows: X50, X80, Passing@F22, Oversize, Within range, Undersize
  - Wipfrag column shows `—` if no data for active blast
- `kzDrawChart()` — SVG chart overlaying Kuz-Ram (blue) and Wipfrag (orange) PSD curves
- `kzRenderTbls(rows)` — side-by-side raw data tables: Kuz-Ram (50mm classes) and Wipfrag (raw paste)

### Report Tab (VERIFIED WORKING, but incomplete for Wipfrag)
- `refreshReport()` — called on Report tab open; fills `#rKzModel`, `#rKzParams`, `#rKzResult`
- `kzReportLines()` — builds model/params/result text; includes Wipfrag X50/X80 if available for active blast
- `renderKzReport()` — writes kzReportLines() to Report tab DOM elements
- The Report tab currently shows only text entries; no visual comparison chart for Kuz-Ram vs Wipfrag
- `kzReportHtml()` — builds HTML for the executive report export; includes Kuz-Ram section but no Wipfrag comparison chart

### Wipfrag Entry Storage (VERIFIED — important for snapshot approach)
`put()` at line 5440 currently stores each wipBy entry as `{rows, label, t}`:
- `rows` — array of `[fraction, sizeMm]` pairs
- `label` — blast label string
- `t` — timestamp (Date.now())

`kzSanitize()` at line 104 only passes through `rows`, `label`, `t` — it drops any unrecognized fields during migration. `kzPersistable()` at line 5591 also only serializes `rows`, `label`, `t` per entry.

### Critical Gap (VERIFIED)
- The comparison between predicted (Kuz-Ram) and measured (Wipfrag) exists only:
  1. As a 6-row table in `#kzCmp` on the Simulator tab — visible only when looking at that panel
  2. As two text lines in the Report tab (`rKzResult` mentions Wipfrag X50/X80 if present)
- **There is no summary showing how many blasts have Wipfrag data, what the prediction error was, or how the model accuracy has evolved across blasts**
- **wipBy entries store no Kuz-Ram snapshot** — if blast geometry is edited after Wipfrag was pasted, any comparison would use the new geometry, not the original.

---

## C. KEY PROBLEMS AND IMPROVEMENT OPPORTUNITIES

### Problem 1 — Wipfrag Data Is Per-Blast but Has No Cross-Blast Summary (VERIFIED)
`APP_STATE.kuzram.wipBy` stores Wipfrag rows for every blast that has been measured. As of the embedded example data, the `wipBy` object can contain many entries. But there is no view that shows:
- How many blasts have Wipfrag data
- The prediction error (Kuz-Ram X50 − Wipfrag X50) per blast
- Which blast had the biggest discrepancy
- Whether the model consistently over- or under-predicts fragmentation

**Code evidence**: `kzWipId()` (line 5421) and `kzActiveWip()` (line 5422) only operate on the currently active blast. `APP_STATE.kuzram.wipBy` (line 88, sanitized at line 101–104) is a keyed object where each entry is `{rows, label, t}` — all the data needed for cross-blast comparison is already there.

### Problem 2 — Report Tab Lacks Wipfrag Comparison Section (VERIFIED)
`refreshReport()` (line 5098) fills `#rKzResult` with a text line that includes Wipfrag X50/X80 if present. But:
- No visual: the SVG chart showing Kuz-Ram vs Wipfrag exists only in the Simulator tab, not in the Report tab
- No comparison table: the 6-row `#kzCmp` table is in the Simulator tab, not the Report tab
- No accuracy metric: Δ(predicted − measured) for X50 and X80 is not calculated or shown anywhere
- `kzReportHtml()` (line 5596) — used for the exported executive report — does not include a Wipfrag comparison section at all

**Code evidence**: `kzReportHtml()` returns a table with just Model/Input/Result text rows. There is no call to any Wipfrag rendering in the HTML export path.

### Problem 3 — Kuz-Ram vs Wipfrag Comparison Has No Measurement of Model Error (VERIFIED)
The comparison table in `kzRenderCmp()` shows both values side-by-side but never computes the difference (ΔX50, ΔX80, percentage error). An engineer must subtract the numbers mentally. No signal whether the discrepancy is small (within engineering tolerance) or large (requiring model recalibration).

### Problem 4 — The Wipfrag Textarea Is the Only Comparison Entry Point (UX limitation, VERIFIED)
`kzEnsureWipBox()` creates the Wipfrag panel dynamically in the Simulator tab. The comparison view lives inside this panel. An engineer looking at the Report tab cannot see the Kuz-Ram vs Wipfrag comparison without switching to the Simulator tab.

---

## D. RECOMMENDED ENHANCEMENT — KUZ-RAM VS WIPFRAG COMPARISON PANEL & REPORTING

### Selected Improvement
**Add a "Predicted vs Measured Fragmentation" panel** that:

1. **Cross-blast accuracy table**: for every blast in `wipBy`, compute Kuz-Ram results using the stored blast geometry, then show: Blast label | X50 Kuz-Ram | X50 Wipfrag | ΔX50 | X80 Kuz-Ram | X80 Wipfrag | ΔX80 | % Error X50.
2. **Delta computation**: `kzRenderCmp()` extended to show ΔX50 = Kuz-Ram − Wipfrag and % error = (Kuz-Ram − Wipfrag) / Wipfrag × 100.
3. **Report tab integration**: add the comparison table and the PSD overlay chart to the Report tab so an engineer can see predicted vs measured without switching to the Simulator tab.
4. **Report export inclusion**: `kzReportHtml()` extended to include the Wipfrag comparison section with ΔX50, ΔX80 values.
5. **Summary statistics on comparison panel**: when ≥2 blasts have Wipfrag data, show mean absolute error (MAE) for X50 and X80, and a note indicating model bias direction (consistently over- or under-predicting).

### What This Does NOT Require
- No new Kuz-Ram formula or algorithm changes.
- No new data model changes (wipBy already stores everything needed).
- No new import pathway.
- No new tab or major layout restructuring.
- No changes to existing Wipfrag paste/apply/undo workflow.
- No changes to existing persistence keys.

### Components and Files Affected

| File | Change |
|---|---|
| `js/app.js` | (1) Extend `kzRenderCmp()` to include ΔX50, ΔX80, % error rows. (2) Add `renderWipComparisonPanel()` — iterates wipBy, computes kzCompute per blast, builds cross-blast accuracy table. (3) Extend `refreshReport()` to call Wipfrag comparison render into Report tab. (4) Extend `kzReportHtml()` to include Wipfrag comparison section. (5) Add ≥4 new assertions to test suite. |
| `index.html` | Add a `<div id="kzWipCompareSummary">` placeholder inside the Simulator tab's Kuz-Ram panel (after `#kzCmp`). Add a `<div id="rKzWipCompare">` section inside the Report tab. |
| `css/style.css` | Add styling for the accuracy table: delta cells with color coding (green ≤10% error, amber ≤20%, red >20%). Append after BLOCK 24. |
| `proposal/` | 8 new proposal markdown documents. |

### User Benefit and Technical Differentiation

**Before**: Engineer pastes Wipfrag data for blast J-13. They can see "X50 Kuz-Ram = 31.3 cm, X50 Wipfrag = 28.0 cm" in a small table. They do not know if the 3.3 cm difference is 10% error or 12% error. If they do the same for blast BB-6, they must remember both results. There is no aggregated view.

**After**: Engineer opens the "Predicted vs Measured" summary. It shows all blasts where Wipfrag data exists alongside Kuz-Ram predictions. ΔX50 = +3.3 cm (+11.8%) for J-13. ΔX50 = +1.8 cm (+6.1%) for BB-6. Mean absolute error = 9.0%. Model consistently over-predicts fragmentation size (positive bias). The Report tab shows this same comparison, and the exported executive report includes it.

**Differentiation**: This turns the Wipfrag paste feature — currently a manual one-blast comparison — into a **model calibration feedback tool**. Engineers can see whether the Kuz-Ram model is systematically biased and by how much, enabling better planning decisions. This is the most direct path from "data entry" to "engineering insight."

### Implementation Approach

**Snapshot design decision (confirmed by user)**: Store a Kuz-Ram result snapshot (`kzX50`, `kzX80`, `kzN`) into the wipBy entry at paste time. This ensures the comparison always reflects the geometry that was in effect when Wipfrag was recorded, not current geometry.

**Consequence**: Three functions need updating: `put()` (stores snapshot), `kzSanitize()` (passes through new fields), `kzPersistable()` (serializes new fields). Both `kzSanitize()` and `kzPersistable()` changes are minimal — 3 additional finite-number fields.

#### Step 0 — Extend wipBy Entry Format (Snapshot)
- **`put(rows, det, extraMsg)`** (line 5440): after building `{rows, label, t}`, capture the current Kuz-Ram result via `kzBuild()` and add `kzX50`, `kzX80`, `kzN` (all numbers, cm/cm/dimensionless). If Kuz-Ram is currently blocked (no result), these fields are `null`.
- **`kzSanitize()`** (line 104): after parsing `rows`, `label`, `t`, also pass through `kzX50`, `kzX80`, `kzN` if they are finite numbers in a reasonable range (0–10000 for cm values, 0–10 for n).
- **`kzPersistable()`** (line 5591): include `kzX50`, `kzX80`, `kzN` in the per-entry serialization alongside `rows`, `label`, `t`.

#### Step 1 — Extend `kzRenderCmp()` (Active Blast Delta)
Currently (line 5483–5487): renders table with 6 rows, Kuz-Ram col | Wipfrag col.
Add two new rows: "ΔX50 (predicted − measured)" and "ΔX80 (predicted − measured)", showing signed value in cm and percent. Use `wc` (Wipfrag curve) for measured values (same as today), and `res.r.x50cm` / `res.r.x80*100` for predicted values.

#### Step 2 — Add `renderWipComparisonPanel()` (Cross-Blast Summary)
New function. Iterates `Object.entries(APP_STATE.kuzram.wipBy)`, for each entry:
- Read **snapshot** fields `kzX50`, `kzX80` (from the wipBy entry itself — no BLAST_SHEET_ROWS lookup needed)
- Compute measured X50, X80 from `kzWipCurve(entry.rows)` + `kzWipSize()` at 0.5 and 0.8
- Compute ΔX50 = kzX50 − measuredX50, % error = ΔX50/measuredX50 × 100
- Build table row (label | kzX50 | measX50 | ΔX50 | % err | kzX80 | measX80 | ΔX80)
- For entries where `kzX50` is null (snapshot missing — legacy entry or Kuz-Ram was blocked), show `—` in predicted columns with a note
At the bottom: MAE for X50, MAE for X80, mean signed error (bias direction), for entries where both are available.
Render into the target element ID passed as argument.

**No BLAST_SHEET_ROWS lookup required**: geometry is not used here — only the snapshot values and Wipfrag rows. This eliminates the risk of stale geometry contaminating the comparison.

#### Step 3 — Report Tab Integration
Extend `refreshReport()` to call `renderWipComparisonPanel('rKzWipCompare')` after existing report rendering.
This makes the comparison visible on the Report tab without any extra user action.

#### Step 4 — Report HTML Export
Extend `kzReportHtml()` to include a "Kuz-Ram vs Wipfrag Model Accuracy" section with the cross-blast comparison table and MAE summary, if any wipBy data exists.

#### Step 5 — New Test Assertions
Add `runTahap2WipCompareTests(pass)` with ≥5 assertions:
- Snapshot stored at paste: after `put()`, wipBy entry has `kzX50` field (numeric or null)
- `kzSanitize()` preserves `kzX50`, `kzX80`, `kzN` when they are valid finite numbers
- Delta computation: given wipBy entry with kzX50=31.3 cm, measuredX50=28.0 cm → ΔX50 = 3.3 ± 0.1 cm, % error ≈ 11.8%
- Cross-blast panel renders rows equal to count of valid wipBy entries (including legacy entries with `kzX50=null`)
- MAE summary row present when ≥2 valid-snapshot wipBy entries exist
- `refreshReport()` populates `#rKzWipCompare` when wipBy has ≥1 entry

---

## E. CURRENT VS PROPOSED ARCHITECTURE

### Current Architecture (Kuz-Ram vs Wipfrag)

```
Simulator Tab
│
├── kzDrawChart()       → SVG: Kuz-Ram curve (blue) + Wipfrag curve (orange)
├── kzRenderTbls()      → side-by-side raw data tables
└── kzRenderCmp()       → 6-row table: X50/X80/passing/oversize/within/undersize
                           Kuz-Ram col | Wipfrag col (NO delta, NO % error)

Report Tab
└── renderKzReport()    → text only: model | params | result (incl. Wipfrag X50/X80 if present)
                           NO chart, NO comparison table, NO delta

Executive Report Export
└── kzReportHtml()      → text table only
                           NO Wipfrag section
```

### Proposed Architecture (After Enhancement)

```
Simulator Tab
│
├── kzDrawChart()       → unchanged SVG chart
├── kzRenderTbls()      → unchanged raw data tables
├── kzRenderCmp()       → 6-row table + 2 NEW rows: ΔX50 cm | ΔX50 %
│                          ΔX80 cm | ΔX80 %
│                          Color-coded: green ≤10% / amber ≤20% / red >20%
└── renderWipComparisonPanel()  → NEW: cross-blast summary table
    (in #kzWipCompareSummary)      columns: Blast | X50_pred | X50_meas | ΔX50 | X80_pred | X80_meas | ΔX80 | %Err
                                   footer: MAE X50 | MAE X80 | Bias direction

Report Tab
├── renderKzReport()    → unchanged
└── renderWipComparisonPanel()  → NEW: same cross-blast table rendered into #rKzWipCompare
    (in #rKzWipCompare)

Executive Report Export
└── kzReportHtml()      → extended: includes Wipfrag comparison HTML table section
```

---

## F. ACCEPTANCE CRITERIA

1. `kzRenderCmp()` shows ΔX50 and ΔX80 rows with correct signed values when Wipfrag data exists for the active blast.
2. Delta values are color-coded (green/amber/red) based on percentage error thresholds (10% / 20%).
3. `renderWipComparisonPanel()` renders one row per valid wipBy entry; each row shows: blast label, predicted X50/X80, measured X50/X80, ΔX50, % error.
4. When no wipBy data exists, panel shows a helpful message (not blank or crash).
5. When ≥2 wipBy entries exist, a summary row shows MAE for X50 and X80, and states bias direction.
6. Report tab shows the cross-blast comparison table whenever `refreshReport()` is called.
7. `kzReportHtml()` includes the Wipfrag accuracy section in the exported HTML.
8. All existing 322 assertions continue to pass.
9. ≥4 new assertions pass (delta calculation, panel row count, empty state, MAE summary).
10. `node --check js/app.js` passes after all changes.

---

## G. BASELINE VS TARGET KPIs

| Metric | Baseline (VERIFIED) | Target After Implementation |
|---|---|---|
| Kuz-Ram vs Wipfrag delta shown automatically | 0 (no delta computed) | ΔX50, ΔX80, % error shown per active blast |
| Cross-blast accuracy summary | Not available | Table of all blasts with wipBy data |
| MAE across blasts | Not computed | Shown when ≥2 blasts have Wipfrag data |
| Report tab includes comparison | Text only (no delta) | Full comparison table + Wipfrag section |
| Exported report includes Wipfrag | No section | HTML table with ΔX50, ΔX80 per blast |
| Test assertions passing | 322/322 PASS | ≥326/326 PASS |
| Formula results for BB-6 EXCEL mode | X50 = 31.3 cm (documented) | Unchanged |

---

## H. IBM BOB UTILIZATION PLAN

### Already Done (Phase 1)
| Activity | Evidence |
|---|---|
| Repository analysis | 12 source files read; kzRenderCmp, kzReportHtml, refreshReport, wipBy structure all inspected |
| Gap identification | Confirmed no delta row in kzRenderCmp (line 5483–5487); no Wipfrag section in kzReportHtml (line 5596); no cross-blast loop over wipBy anywhere |
| Test audit | Corrected 322 vs 332 discrepancy; traced to different harness version |
| Plan authoring | This structured plan with file-level scope, acceptance criteria, and KPI targets |

### Phase 2 (Implementation)
| Activity | Input | Output |
|---|---|---|
| Implement delta in kzRenderCmp | Lines 5483–5487 of app.js | Extended comparison table with ΔX50/ΔX80 rows |
| Implement renderWipComparisonPanel | wipBy structure, kzCompute, kzWipCurve/Size | Cross-blast accuracy table |
| Extend refreshReport | Lines 5098–5121 of app.js | Report tab includes Wipfrag comparison |
| Extend kzReportHtml | Line 5596 of app.js | Export includes Wipfrag accuracy section |
| Add new assertions | Existing test harness pattern | ≥4 new PASS assertions |
| Run node --check | app.js after changes | Syntax valid |
| Update README + docs | This plan | Proposal documents in proposal/ |

---

## I. SEVEN-SLIDE PROPOSAL OUTLINE

### Slide 1 — Executive Summary & Solution Overview
**Headline**: KarstBlast: Closing the Loop Between Predicted and Measured Fragmentation

**Bullets**:
- KarstBlast is a browser-based engineering tool for blast fragmentation analysis in limestone quarrying.
- Target users: blast engineers and quarry production teams who plan, execute, and evaluate blast events.
- Core problem: Kuz-Ram predictions and Wipfrag measurements are stored per-blast but never compared systematically — model accuracy is invisible.
- Solution: surface the prediction error (ΔX50, ΔX80, % error) per blast and across all blasts, and include this in the Report tab and export.
- Key differentiator: all data already exists in the application — the enhancement is computation and surfacing, not new data collection.
- Expected outcome: engineers can see whether the Kuz-Ram model is systematically biased and by how much, enabling evidence-based planning decisions.

**Visual**: Side-by-side screenshot: current comparison table (no delta) vs proposed comparison table (with ΔX50=+3.3cm / +11.8% / green/amber/red coding).

---

### Slide 2 — Problem Identification
**Headline**: Blast Engineers Have Measurements and Predictions but No Way to Compare Them Systematically

**Bullets**:
- Wipfrag data is stored per-blast in `wipBy` (verified in `js/app.js` line 88) but there is no cross-blast view.
- `kzRenderCmp()` shows "Kuz-Ram: 31.3 cm | Wipfrag: 28.0 cm" side-by-side — the engineer must mentally subtract.
- No percentage error, no color signal, no indication whether 3.3 cm difference is acceptable or not.
- The Report tab shows Wipfrag X50/X80 as text but no comparison — engineers who generate reports lack the comparison section.
- The exported executive report (`kzReportHtml()`) has no Wipfrag section at all.

**Visual**: Code excerpt showing `kzRenderCmp()` building the table without any delta row; Report tab screenshot showing text-only Kuz-Ram section.

---

### Slide 3 — Business Opportunity
**Headline**: Model Accuracy Feedback Enables Better Blast Planning Decisions

**Bullets**:
- Blast engineers who can see model bias (e.g., "Kuz-Ram consistently over-predicts X50 by 10%") can adjust blast parameters proactively.
- Without a comparison view, Wipfrag data entry is a data collection exercise that produces no actionable insight on the Report tab.
- Quarry operations benefit when blast engineers can answer: "Did our last 5 blasts match predictions? By how much?"
- KarstBlast already has the correct algorithms (Kuz-Ram EXCEL mode matches BB-6 spreadsheet) and per-blast Wipfrag storage — the gap is display and reporting.
- Engineering reports with measured vs predicted comparison have higher traceability value for quality and safety audits.

**Note**: Market size and revenue figures are not claimed. This opportunity is grounded in the operational gap confirmed by code review.

---

### Slide 4 — Product Strategy & Roadmap
**Headline**: Phase 2 Closes the Predicted-vs-Measured Gap; Phase 3 Extends to Pattern Optimization

**Bullets**:
- **Phase 1 (completed)**: Control hardening, CSV/XLSX import modal, calibration restoration, security hardening, 322 PASS test suite.
- **Phase 2 (this hackathon)**: Add ΔX50/ΔX80/% error to active-blast comparison; add cross-blast accuracy table; integrate into Report tab; extend export.
- **Phase 3 (future)**: Use model accuracy history to suggest blast parameter adjustments; batch Kuz-Ram across all blasts; trend chart of model accuracy over time.
- Principle: preserve all existing calculation semantics; only compute and surface existing data.

**Visual**: Roadmap timeline: Phase 1 → Phase 2 → Phase 3 with feature bullets under each.

---

### Slide 5 — Architecture Vision
**Headline**: Extend Existing Functions, Not New Algorithms

**Bullets**:
- No new algorithms or dependencies needed.
- `kzRenderCmp()` extended by 2 rows (ΔX50, ΔX80); `kzReportHtml()` extended by 1 section.
- New `renderWipComparisonPanel()`: iterates wipBy, calls existing `kzCompute()` + `kzWipCurve()` + `kzWipSize()`, builds table.
- Total new code: ~100–130 lines JS, ~20 lines HTML, ~10 lines CSS.
- CSS color-coding (green/amber/red) uses existing signal color tokens from `css/style.css`.

**Visual**: Architecture diagram (see Section E above).

---

### Slide 6 — IBM Bob Utilization
**Headline**: Bob Provided Evidence-Based Analysis, Not Just Code Generation

**Bullets**:
- **Analysis**: Bob read `js/app.js` lines 5483–5596 directly; confirmed no delta row in `kzRenderCmp()`, no Wipfrag section in `kzReportHtml()`.
- **Test audit**: Bob identified the 322 vs 332 discrepancy; traced it to a different harness version and corrected the count.
- **Planning**: Bob authored this structured plan with file-level change scope, acceptance criteria, and baseline KPI measurements from actual code.
- **Implementation (Phase 2)**: Bob will implement all changes, run `node --check`, add assertions, verify 322 existing tests still pass.
- **Documentation**: Bob will produce all 8 proposal markdown documents.

**Visual**: Table of Bob activities with input → output → artifact → verification per row.

---

### Slide 7 — Expected Improvements (Theme 1)
**Headline**: Measurable Gains in Model Traceability and Reporting Quality

**Bullets**:
- **Delta visibility**: 0 blasts with automatic % error display → 100% of blasts with Wipfrag data show ΔX50, ΔX80, % error.
- **Cross-blast accuracy**: Not available → summary table of all blasts with Wipfrag data (0 to N entries).
- **Report completeness**: Wipfrag absent from Report tab comparison → full comparison table on Report tab.
- **Export quality**: No Wipfrag in HTML export → Wipfrag comparison section in all exported reports.
- **Test coverage**: 322 assertions → ≥ 326 assertions (4+ new covering delta calculation, panel behavior, report integration).

**Validation method**: Run built-in test suite (`#btnRunTests`) → count pass; load example Wipfrag data for BB-6 blast → confirm ΔX50 matches manual calculation; open Report tab → confirm comparison table appears; export executive report → confirm Wipfrag section present.

**Note**: Theme 1 interpretation = "Modernization & Enhancement" per hackathon prompt. Confirm against official judging criteria before submission.

---

## J. IMPLEMENTATION PLAN: SUB-TASKS AND FILES

### Sub-Task 1 — Extend `kzRenderCmp()` with Delta Rows
**Intent**: After the existing 6 comparison rows in `kzRenderCmp()` (lines 5483–5487 in `js/app.js`), add ΔX50 and ΔX80 rows showing signed difference (Kuz-Ram − Wipfrag) in cm and as % of Wipfrag measurement. Apply color class (green/amber/red) based on absolute % error thresholds of 10% and 20%.

**Expected Outcome**: When Wipfrag data is present for the active blast, the comparison table shows 8 rows instead of 6, with the last 2 being deltas with visual color coding.

**Files**: `js/app.js`, `css/style.css`

**Status**: [ ] pending

---

### Sub-Task 2 — Add `renderWipComparisonPanel()` in `js/app.js`
**Intent**: New function that iterates `APP_STATE.kuzram.wipBy`, for each valid entry:
- Reconstructs blast geometry by looking up BLAST_SHEET_ROWS via the key
- Calls `kzBuild()` / `kzCompute()` with that geometry
- Computes Wipfrag X50 and X80 using `kzWipCurve()` + `kzWipSize()`
- Computes ΔX50, ΔX80, % error for X50
- Builds an HTML table row for the summary
Appends a footer row with MAE for X50 and X80 when ≥2 entries exist.
Renders into the target element (either `#kzWipCompareSummary` or `#rKzWipCompare` depending on caller).

**Key constraint**: Use same wipBy key structure as `kzWipId()` — `groupKey + '|' + rowNo`. If the blast row is not found in BLAST_SHEET_ROWS (deleted), skip that entry with a note.

**Expected Outcome**: A table showing all blasts with Wipfrag data, their prediction accuracy, and a MAE summary.

**Files**: `js/app.js`

**Status**: [ ] pending

---

### Sub-Task 3 — Add HTML Placeholders in `index.html`
**Intent**: Add `<div id="kzWipCompareSummary">` inside the Kuz-Ram panel on the Simulator tab, after `#kzCmp`. Add `<div id="rKzWipCompare">` inside the Report tab section, after `#rKzResult`.

**Expected Outcome**: Target elements exist in DOM for `renderWipComparisonPanel()` to write to.

**Files**: `index.html`

**Status**: [ ] pending

---

### Sub-Task 4 — Wire `renderWipComparisonPanel()` to Render Events
**Intent**: Call `renderWipComparisonPanel('kzWipCompareSummary')` from within `kzRender()` (so it updates when a blast changes or Wipfrag is pasted). Call `renderWipComparisonPanel('rKzWipCompare')` from within `refreshReport()` (so Report tab shows the table whenever opened).

**Files**: `js/app.js`

**Status**: [ ] pending

---

### Sub-Task 5 — Extend `kzReportHtml()` for Wipfrag Section
**Intent**: After the existing Kuz-Ram result table in `kzReportHtml()`, add a Wipfrag comparison section with: a heading "Kuz-Ram vs Wipfrag Model Accuracy", the cross-blast comparison table (same data as `renderWipComparisonPanel()`), and a note that this is predicted vs field-measured fragmentation.

**Files**: `js/app.js`

**Status**: [ ] pending

---

### Sub-Task 6 — Add New Test Assertions
**Intent**: Add `runTahap2WipCompareTests(pass)` function in the built-in test suite with ≥4 assertions:
1. Delta computation: given synthetic Kuz-Ram X50=31.3 cm, Wipfrag X50=28.0 cm → ΔX50 = 3.3 ± 0.1 cm, % error ≈ 11.8%
2. `renderWipComparisonPanel()` called with a wipBy containing N entries renders N rows (not N+1, not N-1)
3. Empty wipBy produces placeholder message, not empty div or crash
4. MAE summary row present when wipBy has ≥2 valid entries
5. `refreshReport()` populates `#rKzWipCompare` when wipBy has ≥1 entry

**Files**: `js/app.js`

**Status**: [ ] pending

---

### Sub-Task 7 — Write Proposal Documents
**Intent**: Create all 8 proposal markdown files in `proposal/` directory.

**Files**: `proposal/01_PROJECT_OVERVIEW.md` through `proposal/08_DEMO_AND_VALIDATION.md`

**Status**: [ ] pending

---

## K. CONSTRAINTS AND RISKS

| Risk | Likelihood | Mitigation |
|---|---|---|
| `kzBuild()` called N times in `renderWipComparisonPanel()` requires blast row switching — this may mutate APP_STATE | Medium | Call `kzCompute()` directly with geometry derived from wipBy key + BLAST_SHEET_ROWS lookup instead of switching the active blast. Do not call `kzBuild()` for non-active blasts. |
| wipBy key parsing (groupKey + '\|' + rowNo) may fail for manually renamed groups with '\|' in the name | Low | Keys are set by `kzWipId()` using `a.groupKey+'|'+a.row.no`; the rowNo is always a bare number, so the split on last '\|' is safe. |
| CSS color coding for delta cells must not conflict with existing signal colors | Low | Use new CSS classes `.kz-delta-good`, `.kz-delta-warn`, `.kz-delta-bad`; append after BLOCK 24 to avoid cascade conflicts. |
| New assertions must not require active blast to be set (they can run in clean state) | Medium | Design tests with synthetic wipBy data injected and cleaned up in finally block, same pattern as existing test isolation. |
| Official Theme 1 definition unknown | Unknown | Interpreted as "Modernization & Enhancement" per prompt. Confirm against hackathon docs if available. |
