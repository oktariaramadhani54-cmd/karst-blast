# HANDOFF KarstBlast V11 — status jujur (parsial)

Uji dijalankan dengan Chromium headless (Playwright) di sandbox tanpa internet. Skrip ada di `tests/` (ganti `__PROJECT_DIR__` dengan path proyek). Endpoint Google dipalsukan (mock), BUKAN Google nyata.

## Tabel hasil uji
| Fitur | Tes | Hasil aktual | Status |
|---|---|---|---|
| Muat halaman | 4 resolusi, pageerror | 0 pageerror (console error font Google = tidak ada internet di sandbox) | PASS |
| Overflow horizontal | 5 tab × 390/768/1366/1920 px | tidak ada | PASS |
| Sidebar desktop | screenshot 1366 & 1920 | brand utuh, ikon, grup, status nyata | PASS |
| Nav HP/tablet | 390 & 768 px, 1 screenshot HP | bar horizontal, tanpa overflow | PASS (visual hanya tab Sim di 390) |
| Navigasi 5 tab | klik, cek tab terlihat | hanya tab aktif tampil | PASS |
| Run Screening | klik, cek `#screening*` | timestamp & hasil berubah | PASS (data demo); input kosong/tidak valid BELUM diuji |
| Kuz-Ram `#kzBtnRun` | hash piksel canvas | berubah antar frame | PASS |
| Detonate `#detonateBtn` | SVG + screenshot | cincin, serpihan, plume; status RUNNING | PASS |
| Status simulasi | READY→RUNNING→PAUSED→COMPLETED | sesuai kondisi | PASS |
| Pause | waktu & FX 3,5 dtk (> durasi run) | t=beku, FX tidak dibersihkan | PASS |
| Play / Replay / Reset | klik berurutan | lanjut / ulang / kembali READY, FX kosong | PASS |
| Parameter → simulasi | – | – | NOT TESTED |
| Sheets: validasi URL/token lokal | mock | ditolak dengan pesan jelas | PASS (mock) |
| Sheets: token salah, endpoint 404 | mock | pesan error jelas | PASS (mock) |
| Sheets: tes koneksi, simpan+verifikasi, muat | mock | sukses; state & UI berubah; backup lokal dibuat | PASS (mock) |
| Sheets: Google nyata + Code.gs di Apps Script | – | butuh akun/deploy pengguna | BLOCKED |
| Import data, ekspor laporan, analisis PSD foto, hapus data | – | – | NOT TESTED |
| Vercel deploy / URL langsung / refresh | – | – | NOT TESTED |
| Formula audit (`app.js` rumus) | – | tidak ditinjau | NOT TESTED |

## Temuan yang belum ditangani
- CSS ≥7 generasi aturan `.kb-tabs/.kb-tab` ber-`!important` (baris ±508, 1109, 1185, 1275, 1374, 1625, 1888, 2142) — masih ada; perlu konsolidasi.
- Sync Sheets memakai JSONP: **token ikut di query string URL** (bisa tercatat di log). Token juga di localStorage browser. Untuk data rahasia gunakan proxy serverless Vercel + env var, atau autentikasi Google nyata.
- `script-src ... script.google.com` diperlukan oleh JSONP (jangan dihapus). CSP sudah konsisten dengan JSONP + form POST.
- Panel Google Sheets memakan ruang besar di atas tab Desain; pertimbangkan dipindah ke drawer.
- Foto PSD, kalibrasi, canvas, dataset fragmen tidak ikut snapshot (batasan sudah tertulis di UI).
- Keluhan "efek ledakan tidak terlihat" tidak bisa direproduksi di sandbox (animasi tampil); tolong konfirmasi di browser Anda.

## Cara jalankan / deploy
1. Ekstrak ZIP; buka `index.html` (atau `npx serve .`). Hard refresh (Ctrl+Shift+R).
2. Vercel: unggah folder ini ke repo, framework "Other", tanpa build. `vercel.json` sudah ada. Font Google & Apps Script butuh internet.
3. Google Sheets: ikuti `README_GOOGLE_SHEETS.md`, tempel `google-apps-script/Code.gs`, deploy Web App, isi URL `/exec` + token, lalu TES KONEKSI → SIMPAN → refresh → MUAT.

## PROMPT LANJUTAN
Lanjutkan KarstBlast dari ZIP ini; baca HANDOFF_V11.md. Jangan ubah rumus. Sisa: (1) uji Run Screening dengan field kosong/tidak valid (tidak boleh meloloskan) dan perubahan parameter→simulasi; (2) uji import CSV/XLSX, ekspor laporan, analisis PSD foto, hapus data; (3) konsolidasi CSS nav lama tanpa regresi; (4) screenshot visual tablet & semua tab di HP; (5) audit rumus di js/app.js (dokumentasikan, jangan ubah diam-diam); (6) opsi proxy aman untuk token; (7) finalisasi vercel.json/README. Laporkan PASS/FAIL/NOT TESTED/BLOCKED berdasarkan bukti.
