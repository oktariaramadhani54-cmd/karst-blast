# V9 — Formal presentation and Vercel preparation

- Switched the presentation layer to a restrained light theme with a slate navigation rail, neutral cards, readable tables, and safety-orange primary actions.
- Removed the decorative animated blast from the page header to make the opening screen more suitable for a formal technical presentation. The simulator's own animations were not changed.
- Corrected the desktop sidebar's excessive reserved right padding.
- Reduced headline size, cleaned card headings/spacing, and normalized controls and chart labels.
- Localized the document title, meta description, header copy and navigation labels to Indonesian.
- Updated the static formation status fallback to GAMPING HG.
- Added `defer` to external classic scripts while preserving document order, reducing parser-blocking downloads of the large local vendor libraries.
- Added `vercel.json`, `README_DEPLOY_VERCEL.md`, and `AUDIT_V9_REPORT.md`.
- Calculation JavaScript and engineering formulas were not modified in this release.

## Validation

Static QA: 694 unique IDs, no missing local asset references, no inline script blocks, balanced CSS braces, valid Vercel JSON, and JavaScript syntax checks passed for all four application JS files. Headless Chromium did not complete even against `about:blank` in the build environment, so no claim of fresh browser interaction certification is made.
