# KarstBlast V10 — deployment notes

## Deploy as a static website

1. Extract this ZIP. `index.html` must be at the project root; do not deploy the ZIP file itself.
2. In Vercel, choose **Add New → Project → Import** a Git repository containing these files, or use the Vercel CLI from this directory with `vercel`.
3. Framework preset: **Other**. Build Command: leave empty. Output Directory: `.`. Install Command: leave empty.
4. Deploy the preview URL first. Check every tab, upload/import controls, geometry calculations, screening, photo workflow, reports and downloads before promoting it to Production.
5. Copy the final Production URL into a QR-code generator. Scan the QR with a phone that is not logged into the Vercel owner account, and test on mobile data.

No build step is required for the static website; local JavaScript and vendor libraries are included. The optional Google Spreadsheet synchronization does require the separate Google Apps Script setup described in `README_GOOGLE_SHEETS.md`.

## Data and limitations

- Project inputs and some results are stored in the current browser's `localStorage`. They are **not uploaded to a database**, do not automatically synchronize across devices, and are not included just by sharing the URL/QR code.
- The site has no login/authorization. Anyone with the public URL can open the app and inspect the client-side code. Do not embed secrets, access tokens, confidential mine plans, or sensitive personal/company data.
- `localStorage` depends on the browser and origin. Changing from a Vercel preview URL to a Production domain can make earlier browser-saved data appear missing. Export/backup important work before changing domains or clearing browser data.
- This is an engineering decision-support and presentation tool, not an autonomous blast-design authority. Verify assumptions, units, material class, source records, formulas, and outputs with a qualified engineer.
- Multi-blast weighted-average/batch calculation is not implemented. Photo PSD remains a draft that can require ROI selection and manual boundary correction; the project log reports that automatic segmentation does not match manually outlined WipFrag results reliably.

## Included hardening

`vercel.json` adds response headers for MIME sniffing, referrer policy and browser permissions. The Content Security Policy is in `index.html`; this version allows the additional Google Apps Script domains needed by the optional Sheets backup panel.


## Google Spreadsheet Sync (opsional)

Versi ini menambahkan panel Google Spreadsheet. Sebelum menggunakannya, ikuti seluruh langkah pada [`README_GOOGLE_SHEETS.md`](README_GOOGLE_SHEETS.md) dan pasang kode [`google-apps-script/Code.gs`](google-apps-script/Code.gs) pada spreadsheet milikmu. Sinkronisasi tidak aktif otomatis tanpa URL `/exec` dan sync key.
