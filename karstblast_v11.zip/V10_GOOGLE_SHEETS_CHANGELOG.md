# V10 — Google Spreadsheet Sync

- Added a configurable Google Apps Script web app endpoint and local sync-key field.
- Added connection test, save snapshot, and restore latest snapshot controls.
- Added Apps Script source that writes `Log_Penyimpanan`, `Ringkasan_Blast`, and chunked `Arsip_Workspace` tabs.
- Added restore confirmation and format validation before local working-copy replacement.
- Exposed a minimal `KarstBlastForcePersist()` hook so the current app state is serialized before backup.
- Documented security and persistence limits, especially photo PSD session data not being part of the existing persisted state.
- Existing formulas and analysis calculations were not intentionally changed.
