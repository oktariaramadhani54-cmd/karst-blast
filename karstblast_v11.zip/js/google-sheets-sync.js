/* KarstBlast Google Sheets sync. Uses a bound Apps Script web app; no Google token is embedded in source. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const STORAGE_KEY = 'karstblast_working_copy_v9';
  const CONFIG_KEY = 'karstblast_google_sheets_config_v1';
  const MAX_RETRIES = 7;
  let activeSaveId = null;

  const status = (message, kind = 'info') => {
    const box = $('gsSyncStatus');
    if (!box) return;
    box.textContent = message;
    box.dataset.status = kind;
    box.setAttribute('role', kind === 'error' ? 'alert' : 'status');
    const badge = $('gsSummaryStatus');
    if (badge) {
      const configured = !!(String($('gsEndpoint')?.value || '').trim() && String($('gsToken')?.value || '').trim());
      const lowerMessage = String(message || '').toLowerCase();
      badge.textContent = kind === 'error' ? 'PERLU DIPERIKSA' : kind === 'success' ? (lowerMessage.includes('terhubung') ? 'TERHUBUNG' : lowerMessage.includes('terverifikasi') ? 'TERSIMPAN' : 'KONFIGURASI OK') : configured ? 'SIAP DIUJI' : 'BELUM DIKONFIGURASI';
      badge.classList.toggle('warn', kind === 'error' || !configured);
      badge.classList.toggle('ok', kind === 'success');
    }
  };
  const readConfig = () => {
    const endpoint = String($('gsEndpoint')?.value || '').trim();
    const token = String($('gsToken')?.value || '').trim();
    return { endpoint, token };
  };
  const saveConfig = (silent = false) => {
    const cfg = readConfig();
    try { localStorage.setItem(CONFIG_KEY, JSON.stringify(cfg)); } catch (_) {}
    if (!silent) status('Konfigurasi disimpan di browser ini. Gunakan endpoint /exec dan token yang sama dengan Script Properties.', 'success');
    return cfg;
  };
  const validateConfig = () => {
    const cfg = saveConfig(true);
    if (!/^https:\/\/script\.google\.com\/macros\/s\/[^\s]+\/exec(?:\?.*)?$/.test(cfg.endpoint)) {
      status('URL belum valid. Tempel URL Web App Google Apps Script yang berakhir dengan /exec.', 'error');
      return null;
    }
    if (cfg.token.length < 16) {
      status('Token minimal 16 karakter. Samakan dengan KARSTBLAST_SYNC_KEY pada Script Properties.', 'error');
      return null;
    }
    return cfg;
  };
  const jsonp = (cfg, action, extras = {}) => new Promise((resolve, reject) => {
    const callbackName = '__kbSheetsCb_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
    const script = document.createElement('script');
    const params = new URLSearchParams({ action, token: cfg.token, callback: callbackName });
    Object.entries(extras).forEach(([k, v]) => params.set(k, String(v)));
    let done = false;
    const cleanup = () => { if (done) return; done = true; clearTimeout(timer); script.remove(); try { delete window[callbackName]; } catch (_) { window[callbackName] = undefined; } };
    const timer = setTimeout(() => { cleanup(); reject(new Error('Koneksi timeout. Periksa URL deployment Apps Script dan izin akses Web App.')); }, 18000);
    window[callbackName] = result => {
      cleanup();
      if (result && result.ok) resolve(result);
      else reject(new Error(result?.error || 'Google Sheets mengembalikan respons gagal.'));
    };
    script.onerror = () => { cleanup(); reject(new Error('Tidak dapat memanggil Apps Script. Pastikan URL /exec benar dan deployment aktif.')); };
    script.src = cfg.endpoint + (cfg.endpoint.includes('?') ? '&' : '?') + params.toString();
    document.head.appendChild(script);
  });
  const makeHiddenFrame = () => {
    let frame = $('kbSheetsPostFrame');
    if (!frame) {
      frame = document.createElement('iframe');
      frame.id = 'kbSheetsPostFrame'; frame.name = 'kbSheetsPostFrame'; frame.title = 'Google Sheets save channel';
      frame.style.display = 'none'; frame.setAttribute('aria-hidden', 'true'); document.body.appendChild(frame);
    }
    return frame;
  };
  const formPost = (cfg, fields) => {
    makeHiddenFrame();
    const form = document.createElement('form');
    form.method = 'POST'; form.action = cfg.endpoint; form.target = 'kbSheetsPostFrame'; form.acceptCharset = 'UTF-8';
    form.style.display = 'none';
    const data = { ...fields, token: cfg.token };
    Object.entries(data).forEach(([key, value]) => {
      const input = document.createElement('input'); input.type = 'hidden'; input.name = key; input.value = String(value ?? ''); form.appendChild(input);
    });
    document.body.appendChild(form);
    try { form.submit(); } finally { setTimeout(() => form.remove(), 30000); }
  };
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  async function verifySaved(cfg, snapshotId, attempt = 0) {
    await wait(attempt === 0 ? 1400 : 1700);
    const latest = await jsonp(cfg, 'latest');
    if (latest.found && latest.snapshotId === snapshotId) {
      status(`Tersimpan dan terverifikasi di Google Sheets • ${latest.projectId} • ${new Date(latest.savedAt).toLocaleString('id-ID')}`, 'success');
      return true;
    }
    if (attempt + 1 < MAX_RETRIES) return verifySaved(cfg, snapshotId, attempt + 1);
    throw new Error('Permintaan dikirim, tetapi snapshot belum terverifikasi di sheet. Cek deployment, token, dan Log_Penyimpanan.');
  }
  async function testConnection() {
    const cfg = validateConfig(); if (!cfg) return;
    status('Memeriksa koneksi ke Google Spreadsheet…');
    try {
      const result = await jsonp(cfg, 'health');
      status(`Terhubung ke “${result.spreadsheet}”. Snapshot tersimpan: ${result.saves}.`, 'success');
    } catch (err) { status('Koneksi gagal: ' + err.message, 'error'); }
  }
  async function saveWorkspace() {
    const cfg = validateConfig(); if (!cfg) return;
    try {
      if (typeof window.KarstBlastForcePersist === 'function') window.KarstBlastForcePersist();
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) throw new Error('Working copy belum tersedia. Ubah/simpan input terlebih dahulu, lalu coba lagi.');
      const state = JSON.parse(raw);
      if (!state || !Number.isFinite(Number(state.version)) || Number(state.version) < 11) throw new Error('Versi working copy tidak dikenali; simpan ulang lewat aplikasi sebelum sinkronisasi.');
      if (raw.length > 4900000) throw new Error('Ukuran snapshot terlalu besar untuk sekali kirim (>4,9 MB). Ekspor berkas khusus atau kurangi data.');
      const snapshotId = 'KB-' + new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14) + '-' + Math.random().toString(36).slice(2, 8).toUpperCase();
      activeSaveId = snapshotId;
      const project = state.project || {};
      status(`Mengirim snapshot (${raw.length.toLocaleString('id-ID')} karakter) ke Google Sheets…`);
      formPost(cfg, {
        action: 'save', snapshotId, payload: raw,
        projectId: project.id || 'KarstBlast_Project', site: project.site || '', appVersion: state.version,
        savedAt: new Date().toISOString()
      });
      await verifySaved(cfg, snapshotId);
    } catch (err) { status((activeSaveId ? 'Penyimpanan belum terkonfirmasi: ' : 'Gagal menyimpan: ') + err.message, 'error'); }
  }
  async function loadWorkspace() {
    const cfg = validateConfig(); if (!cfg) return;
    try {
      status('Mencari snapshot terbaru…');
      const meta = await jsonp(cfg, 'latest');
      if (!meta.found) { status('Belum ada snapshot di Google Sheets. Tekan SIMPAN KE SHEETS terlebih dahulu.', 'info'); return; }
      const confirmText = `Muat snapshot terakhir?\n\nProject: ${meta.projectId}\nWaktu: ${new Date(meta.savedAt).toLocaleString('id-ID')}\nUkuran: ${Number(meta.payloadChars).toLocaleString('id-ID')} karakter\n\nWorking copy lokal saat ini akan diganti dan halaman dimuat ulang. Foto, kalibrasi foto, serta dataset fragmen PSD tidak termasuk backup versi ini.`;
      if (!window.confirm(confirmText)) { status('Pemuatan dibatalkan. Data lokal tidak diubah.', 'info'); return; }
      let raw = '';
      for (let i = 0; i < meta.chunkCount; i++) {
        status(`Mengunduh backup dari Sheets… bagian ${i + 1}/${meta.chunkCount}`);
        const part = await jsonp(cfg, 'chunk', { snapshotId: meta.snapshotId, index: i });
        if (part.index !== i || part.total !== meta.chunkCount || typeof part.data !== 'string') throw new Error('Potongan snapshot tidak cocok; pemulihan dihentikan.');
        raw += part.data;
      }
      const state = JSON.parse(raw);
      if (!state || !Number.isFinite(Number(state.version)) || Number(state.version) < 11) throw new Error('Snapshot tidak memiliki format KarstBlast yang didukung.');
      // V11: lindungi working copy lokal sebelum ditimpa (dapat dipulihkan manual dari kunci backup ini)
      try {
        const previous = localStorage.getItem(STORAGE_KEY);
        if (previous) localStorage.setItem(STORAGE_KEY + ':before-restore', JSON.stringify({ savedAt: new Date().toISOString(), restoredSnapshotId: meta.snapshotId, data: previous }));
      } catch (e) { throw new Error('Tidak dapat membuat backup lokal sebelum pemulihan (' + e.message + '). Pemulihan dibatalkan; data lokal tidak diubah.'); }
      localStorage.setItem(STORAGE_KEY, raw);
      status('Backup valid. Data lokal sebelumnya diamankan. Memuat ulang KarstBlast…', 'success');
      setTimeout(() => location.reload(), 600);
    } catch (err) { status('Gagal memuat: ' + err.message, 'error'); }
  }
  function init() {
    const cfg = (() => { try { return JSON.parse(localStorage.getItem(CONFIG_KEY) || '{}'); } catch (_) { return {}; } })();
    if ($('gsEndpoint') && cfg.endpoint) $('gsEndpoint').value = cfg.endpoint;
    if ($('gsToken') && cfg.token) $('gsToken').value = cfg.token;
    $('gsSaveConfig')?.addEventListener('click', () => saveConfig(false));
    $('gsTestConnection')?.addEventListener('click', testConnection);
    $('gsSaveWorkspace')?.addEventListener('click', saveWorkspace);
    $('gsLoadWorkspace')?.addEventListener('click', loadWorkspace);
    $('gsEndpoint')?.addEventListener('change', () => saveConfig(true));
    $('gsToken')?.addEventListener('change', () => saveConfig(true));
    if (cfg.endpoint && cfg.token) status('Konfigurasi lokal tersedia. Klik TES KONEKSI untuk memeriksa akses.', 'info');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true }); else init();
})();
