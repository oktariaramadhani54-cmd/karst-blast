/* a11y.js — aksesibilitas tambahan (WAI-ARIA Authoring Practices: Tabs + skip link).
   Dimuat SETELAH patches.js. Tidak mengubah logika aplikasi: hanya menambah keyboard + roving tabindex. */
(function(){
  'use strict';

  /* 1) Tabs: roving tabindex + panah kiri/kanan, Home, End (aktivasi otomatis lewat click() yang sudah ada). */
  try{
    var tabs=[].slice.call(document.querySelectorAll('.kb-tab[role="tab"]'));
    if(tabs.length){
      var list=tabs[0].parentElement;
      var sync=function(){
        tabs.forEach(function(t){ t.tabIndex=(t.getAttribute('aria-selected')==='true')?0:-1; });
      };
      sync();
      /* app.js mengubah aria-selected saat klik; observer menjaga tabindex tetap sinkron
         (termasuk saat tab dipindah lewat data-goto / patches.js). */
      new MutationObserver(sync).observe(list,{subtree:true,attributes:true,attributeFilter:['aria-selected']});
      list.addEventListener('keydown',function(e){
        var i=tabs.indexOf(document.activeElement);
        if(i<0||e.altKey||e.ctrlKey||e.metaKey) return;
        var n=null;
        if(e.key==='ArrowRight') n=(i+1)%tabs.length;
        else if(e.key==='ArrowLeft') n=(i-1+tabs.length)%tabs.length;
        else if(e.key==='Home') n=0;
        else if(e.key==='End') n=tabs.length-1;
        if(n===null) return;
        e.preventDefault();
        tabs[n].focus();
        tabs[n].click();
      });
    }
  }catch(err){ if(window.console) console.error('a11y tabs init failed',err); }

  /* 2) Skip link: pindahkan fokus ke <main id="main"> (href="#main" saja tidak memindahkan fokus keyboard di semua browser). */
  try{
    var skip=document.querySelector('.skip-link'), main=document.getElementById('main');
    if(skip&&main){
      skip.addEventListener('click',function(e){
        e.preventDefault();
        main.focus();
        main.scrollIntoView();
      });
    }
  }catch(err){ if(window.console) console.error('a11y skip link init failed',err); }
})();
