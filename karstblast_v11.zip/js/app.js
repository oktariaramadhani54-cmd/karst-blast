
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const qs = (sel, root=document) => root.querySelector(sel);
  const qsa = (sel, root=document) => [...root.querySelectorAll(sel)];
  const STORAGE = 'karstblast_working_copy_v9';
  let ROI_SAVED = null; /* ROI poligon tersimpan {key foto, poligon}; hanya dipakai lagi bila FOTO YANG SAMA diunggah ulang */

  /* PERSIST-ENGINE:BEGIN  fungsi murni: tanpa DOM, tanpa APP_STATE */
  // Persistence payload version. v11 adds `kuzram` (state Kuz-Ram) dan menggantikan `gas`. v3-v11 tetap terbaca (lihat migratePersistedState).
  // The localStorage KEY keeps its historical name (..._v9) on purpose: renaming it would orphan every
  // existing user's saved work. The payload carries its own `version`, which is what gates migration.
  const PERSIST_VERSION = 11;
  const PERSIST_READABLE_VERSIONS = [3,4,5,6,7,8,9,10,11];
  const PSD_SIZE_DEFINITIONS = ['feret','eqdiam','bbox'];
  const KZ_MAX_WIP_ENTRIES = 2000; // REQ-01: batas entri wipBy
  const KZ_MAX_WIP_ROWS = 2000;    // REQ-01: batas baris per entri

/* KUZRAM-ENGINE:BEGIN  fungsi murni: tanpa DOM, tanpa APP_STATE */
const KZ_VERSION='kuzram-v1';
function kzWrapAngle(a,b){ const d=Math.abs(a-b)%360; return d>180?360-d:d; }
/* mode 'excel' = meniru rumus sumber apa adanya; 'corrected' = koreksi (lihat KZ_AUDIT) */
function kzBlastability(p,mode){
  const ex=mode==='excel';
  const rmd=10+10*p.insituBlock;                       // spesifik spreadsheet (bukan Lilly diskret) - TIDAK diubah, ditandai
  let jps;
  if(p.jointSpacing<0.1) jps=10;
  else if(ex) jps=(p.jointSpacing===0.1)?20:50;        // Excel: 0.1<B13<F21 = (TRUE/FALSE)<F21; logika > angka => selalu FALSE
  else jps=(p.jointSpacing<=p.oversizeM)?20:50;
  let jpo;
  if(p.jointDip<10) jpo=10;
  else{
    const raw=p.jointDipDir-p.faceDipDir, th=ex?Math.abs(raw):kzWrapAngle(p.jointDipDir,p.faceDipDir);
    jpo= th<30?20 : (ex?(raw>60):(th>60))?30:40;      // ambang 30/60 dipertahankan; perlu verifikasi geoteknik
  }
  const rdi=25*(p.rockSG-2);
  const hf=(ex||p.elasticGPa<50)?p.elasticGPa/3:p.ucsMPa/5;
  return {A:0.06*(rmd+jps+jpo+rdi+hf),rmd,jps,jpo,rdi,hf};
}
function kzCompute(i,mode){
  mode=mode==='excel'?'excel':'corrected'; const ex=mode==='excel';
  const err=[],warn=[],need=['burdenM','spacingM','benchM','holeDiaMm','chargeLenM','chargeKg','driftSdM','patternFactor','rockSG','elasticGPa','jointSpacing','jointDip','jointDipDir','faceDipDir','insituBlock','rwsRatio','vodNominal','vodEffective','oversizeM','passingM','undersizeM'];
  need.forEach(k=>{ const v=i[k]; if(typeof v!=='number'||!Number.isFinite(v)) err.push('Input wajib kosong/tidak valid: '+k); });
  if(err.length) return {ok:false,errors:err,warnings:warn,mode};
  const pos=['burdenM','spacingM','benchM','holeDiaMm','chargeLenM','chargeKg','rockSG','rwsRatio','vodNominal','vodEffective','oversizeM','passingM','undersizeM','patternFactor'];
  pos.forEach(k=>{ if(!(i[k]>0)) err.push(k+' harus > 0'); });
  if(!(i.driftSdM>=0)) err.push('driftSdM harus >= 0');
  if(i.driftSdM>=i.burdenM) err.push('Akurasi bor (W) harus < burden');
  if(!(i.undersizeM<i.oversizeM)) err.push('Undersize harus < oversize');
  if(i.elasticGPa>=50&&!(i.ucsMPa>0)&&!ex) err.push('UCS wajib bila E >= 50 GPa');
  if(err.length) return {ok:false,errors:err,warnings:warn,mode};
  const pf=Number.isFinite(i.pfKgM3)&&i.pfKgM3>0?i.pfKgM3:i.chargeKg/(i.burdenM*i.spacingM*i.benchM); // kg/m3, basis B*S*H per lubang
  const bi=kzBlastability({...i},mode);
  const strengthRatio=(i.vodEffective/i.vodNominal)**2*i.rwsRatio, Eperc=strengthRatio*100;
  const x50cm=bi.A*pf**-0.8*i.chargeKg**0.166667*(115/Eperc)**(19/30);
  const dBC=Number.isFinite(i.bclMinusCclM)?Math.abs(i.bclMinusCclM):0;
  const lenFactor=ex?(0.1+i.chargeLenM/i.chargeLenM)**0.1:(dBC/i.chargeLenM+0.1)**0.1;
  const n=(2.2-14*(i.burdenM/i.holeDiaMm))*Math.sqrt(0.5*(1+i.spacingM/i.burdenM))*(1-i.driftSdM/i.burdenM)*lenFactor*(i.chargeLenM/i.benchM)*i.patternFactor;
  if(!(n>0)) return {ok:false,errors:['Uniformity exponent n <= 0 (geometri tidak masuk akal)'],warnings:warn,mode};
  if(n<0.7||n>2.2) warn.push('n='+n.toFixed(3)+' di luar rentang tipikal Kuz-Ram 0.7-2.2');
  if(i.vodEffective>i.vodNominal) warn.push('VOD efektif > nominal');
  const x50m=x50cm/100, c=ex?0.693:Math.LN2, xc=x50m/c**(1/n);
  const pass=x=>x<=0?0:1-Math.exp(-((x/xc)**n));
  const x80=xc*(-Math.log(0.2))**(1/n);
  const over=Math.exp(-((i.oversizeM/xc)**n)), under=pass(i.undersizeM);
  return {ok:true,mode,errors:[],warnings:warn,pfKgM3:pf,bi,strengthRatio,Eperc,x50cm,x50m,n,lenFactor,xc,x80,
    passAtTarget:pass(i.passingM),oversize:over,undersize:under,within:1-over-under,passFn:pass};
}
function kzCurve(r,pts=60){ const lo=Math.log10(r.xc*0.03),hi=Math.log10(Math.max(r.xc*4,r.x80*1.5));
  return Array.from({length:pts},(_,k)=>{const x=10**(lo+(hi-lo)*k/(pts-1));return {x,p:r.passFn(x)};}); }
/* partikel representatif: kuantil massa stratifikasi, tiap partikel = 1/N massa */
function kzParticles(r,N,seed){ let s=seed>>>0||1; const rnd=()=>{s=(s+0x6D2B79F5)|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};
  return Array.from({length:N},(_,k)=>{const u=(k+0.5)/N;return {sizeM:r.xc*(-Math.log(1-u))**(1/r.n),u,seed:rnd()};}); }
/* KUZRAM-ENGINE:END */
if(typeof module!=='undefined') module.exports={kzCompute,kzBlastability,kzCurve,kzParticles};
  /* ---- Kuz-Ram: definisi input manual + state (murni, di luar blok engine) ---- */
  const KZ_FIELDS=[
    ['driftSdM','Akurasi bor (W)','m'],['patternFactor','Faktor pola','–'],['rockSG','Densitas batuan (SG)','t/m³'],
    ['elasticGPa','Modulus Young (E)','GPa'],['ucsMPa','UCS (wajib bila E ≥ 50 GPa)','MPa'],
    ['jointSpacing','Spasi joint','m'],['jointDip','Dip joint','°'],['jointDipDir','Arah dip joint','°'],['faceDipDir','Arah dip muka jenjang','°'],
    ['insituBlock','Ukuran blok in-situ','m'],['rwsRatio','RWS (relatif ANFO)','–'],['vodNominal','VOD nominal','m/s'],['vodEffective','VOD efektif','m/s'],
    ['oversizeM','Oversize (F21)','m'],['passingM','Passing (F22)','m'],['undersizeM','Undersize','m'],['bclMinusCclM','|BCL−CCL|','m']];
  const KZ_EXAMPLE={driftSdM:0.1,patternFactor:1.1,rockSG:2.6,elasticGPa:7,ucsMPa:35,jointSpacing:1.2,jointDip:20,jointDipDir:135,faceDipDir:135,insituBlock:1.2,rwsRatio:1,vodNominal:4500,vodEffective:3700,oversizeM:0.9,passingM:0.8,undersizeM:0.1};
  const KZ_BASE_TEST={burdenM:2.5,spacingM:3.5,benchM:4.5,holeDiaMm:114.3,chargeLenM:2.974,chargeKg:14.8776,pfKgM3:0.37987878787878787,driftSdM:0.1,patternFactor:1.1,rockSG:2.6,elasticGPa:7,ucsMPa:35,jointSpacing:1.2,jointDip:20,jointDipDir:135,faceDipDir:135,insituBlock:1.2,rwsRatio:1,vodNominal:4500,vodEffective:3700,oversizeM:0.9,passingM:0.8,undersizeM:0.1};
  const KZ_SOURCES=['actual','ash','konya','mae'];
  const KZ_DIA_DEFAULT=114.3, KZ_GEO_KEYS=['burdenM','spacingM','benchM','holeDiaMm','chargeLenM','pfKgM3'], KZ_DV=2;
  // Default = nilai lembar Excel BB-6 (bukan data proyek). Semua bisa diedit; geo = override geometri (null = ikuti blok/baris).
  function kzDefaultState(){ const manual={},manualSrc={},geo={}; KZ_FIELDS.forEach(([k])=>{ if(k in KZ_EXAMPLE){ manual[k]=KZ_EXAMPLE[k]; manualSrc[k]='DEFAULT'; } else manual[k]=null; }); manual.bclMinusCclM=0; manualSrc.bclMinusCclM='ASUMSI'; KZ_GEO_KEYS.forEach(k=>{geo[k]=null;}); return {mode:'excel',source:null,manual,manualSrc,geo,wipBy:{},wipLegacy:[],simSrc:'kuzram'}; }
  /* Wipfrag: baris tersimpan = [fraksi 0..1, size mm]. Dibersihkan saat dimuat dari localStorage. */
  function kzCleanWipRows(a){ return Array.isArray(a)?a.slice(0,KZ_MAX_WIP_ROWS).filter(q=>Array.isArray(q)&&q.length===2&&q.every(v=>typeof v==='number'&&Number.isFinite(v))&&q[0]>=0&&q[0]<=1&&q[1]>0&&q[1]<1e7).map(q=>[q[0],q[1]]):[]; } /* REQ-01 */
  function kzSanitize(raw){
    const d=kzDefaultState(); if(!raw||typeof raw!=='object'||Array.isArray(raw)) return d;
    if(raw.mode==='corrected') d.mode='corrected'; if(KZ_SOURCES.includes(raw.source)) d.source=raw.source;
    const m=(raw.manual&&typeof raw.manual==='object'&&!Array.isArray(raw.manual))?raw.manual:{}, s=(raw.manualSrc&&typeof raw.manualSrc==='object')?raw.manualSrc:{};
    KZ_FIELDS.forEach(([k])=>{ if(k in m){ const v=m[k]; d.manual[k]=(typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<1e7)?v:(k==='bclMinusCclM'?0:null); }
      if(['USER','CONTOH','ASUMSI','DEFAULT'].includes(s[k])) d.manualSrc[k]=s[k]; else if(k in m&&k!=='bclMinusCclM'&&d.manual[k]!=null) d.manualSrc[k]='USER'; });
    KZ_FIELDS.forEach(([k])=>{ if(d.manual[k]==null){ if(raw.dv!==KZ_DV&&k in KZ_EXAMPLE){ d.manual[k]=KZ_EXAMPLE[k]; d.manualSrc[k]='DEFAULT'; } else delete d.manualSrc[k]; } });
    const gm=(raw.geo&&typeof raw.geo==='object'&&!Array.isArray(raw.geo))?raw.geo:{};
    KZ_GEO_KEYS.forEach(k=>{ const v=gm[k]; if(typeof v==='number'&&Number.isFinite(v)&&v>0&&v<1e7) d.geo[k]=v; });
    d.wipLegacy=kzCleanWipRows(Array.isArray(raw.wipLegacy)&&raw.wipLegacy.length?raw.wipLegacy:raw.wip);   /* sanitasi dipanggil 2x (migrate + restore): terima kedua nama */ if(d.wipLegacy.length<3) d.wipLegacy=[];   // data versi lama: satu tabel global tanpa ID blast
    const wb=(raw.wipBy&&typeof raw.wipBy==='object'&&!Array.isArray(raw.wipBy))?raw.wipBy:{};
    const DANGEROUS_KEYS=new Set(['__proto__','constructor','prototype']); /* REQ-07 AC-07a */
    const allKeys=Object.keys(wb); let overLimit=0,invalidEntries=0; /* REQ-01 */
    allKeys.forEach((k,idx)=>{ if(idx>=KZ_MAX_WIP_ENTRIES){ overLimit++; return; } if(DANGEROUS_KEYS.has(k)||DANGEROUS_KEYS.has(k.split('|')[0])){ invalidEntries++; return; } /* REQ-07 AC-07a */ const e=wb[k]; if(k.length>160||!k.includes('|')||!e||typeof e!=='object'){ invalidEntries++; return; } const rows=kzCleanWipRows(e.rows); if(rows.length<3){ invalidEntries++; return; } const rawLabel=typeof e.label==='string'?e.label.slice(0,160):k; const safeLabel=rawLabel.replace(/<[^>]*>/g,''); /* REQ-07 AC-07b: strip HTML tags */
      /* Snapshot fields: kzX50 (cm), kzX80 (cm), kzN — captured at Wipfrag paste time for traceability */
      const snapX50=(typeof e.kzX50==='number'&&Number.isFinite(e.kzX50)&&e.kzX50>0&&e.kzX50<10000)?e.kzX50:null;
      const snapX80=(typeof e.kzX80==='number'&&Number.isFinite(e.kzX80)&&e.kzX80>0&&e.kzX80<10000)?e.kzX80:null;
      const snapN=(typeof e.kzN==='number'&&Number.isFinite(e.kzN)&&e.kzN>0&&e.kzN<10)?e.kzN:null;
      d.wipBy[k]={rows,label:safeLabel,t:Number.isFinite(e.t)?e.t:0,kzX50:snapX50,kzX80:snapX80,kzN:snapN}; });
    d._rejectInfo={overLimit,invalidEntries,totalInput:allKeys.length}; /* REQ-01: info penolakan untuk pemanggil */
    if(raw.simSrc==='wipfrag') d.simSrc='wipfrag';   // REQ-04: preferensi dipertahankan; sumber efektif dihitung oleh kzEffectiveSrc()
    return d; }

  /* PROJECT-BLASTS-ENGINE:BEGIN */
  const DEFAULT_PROJECT_BLASTS = [
    { id:'CC-6', name:'CC-6', burden:2.5, spacing:3.5, stemming:1.9, holeDepth:4.8, bench:4.3, chargeLen:2.8, subdrill:0.5, holes:33.8, pf:0.4, diameter:4.5, explosive:5.5, volume:37.2, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true },
    { id:'CC-7', name:'CC-7', burden:2.5, spacing:3.5, stemming:1.9, holeDepth:4.8, bench:4.3, chargeLen:2.8, subdrill:0.5, holes:24.0, pf:0.4, diameter:4.5, explosive:5.3, volume:37.2, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true },
    { id:'GG-10', name:'GG-10', burden:3.0, spacing:4.5, stemming:3.0, holeDepth:6.5, bench:6.0, chargeLen:3.5, subdrill:0.5, holes:84.5, pf:0.4, diameter:4.5, explosive:9.3, volume:81.0, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true },
    { id:'UV-13', name:'UV-13', burden:3.0, spacing:4.5, stemming:3.0, holeDepth:6.5, bench:6.0, chargeLen:3.5, subdrill:0.5, holes:148.0, pf:0.4, diameter:4.5, explosive:8.8, volume:81.0, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true },
    { id:'DD-5', name:'DD-5', burden:2.5, spacing:3.5, stemming:1.9, holeDepth:4.8, bench:4.3, chargeLen:2.9, subdrill:0.5, holes:23.8, pf:0.4, diameter:4.5, explosive:5.6, volume:37.2, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true },
    { id:'GG-13', name:'GG-13', burden:2.5, spacing:3.5, stemming:1.8, holeDepth:5.0, bench:4.5, chargeLen:3.2, subdrill:0.5, holes:38.3, pf:0.5, diameter:4.5, explosive:5.4, volume:39.4, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true },
    { id:'II-11', name:'II-11', burden:3.0, spacing:4.5, stemming:3.0, holeDepth:6.5, bench:6.0, chargeLen:3.5, subdrill:0.5, holes:122.0, pf:0.4, diameter:4.5, explosive:8.8, volume:81.0, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true },
    { id:'HH-13', name:'HH-13', burden:2.5, spacing:3.5, stemming:2.5, holeDepth:6.1, bench:5.6, chargeLen:3.6, subdrill:0.5, holes:45.6, pf:0.4, diameter:4.5, explosive:5.0, volume:49.0, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true },
    { id:'JJ-11', name:'JJ-11', burden:3.0, spacing:4.5, stemming:3.9, holeDepth:8.5, bench:8.0, chargeLen:4.6, subdrill:0.5, holes:39.7, pf:0.4, diameter:4.5, explosive:8.6, volume:108.0, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true },
    { id:'JJ-13', name:'JJ-13', burden:3.0, spacing:4.0, stemming:2.9, holeDepth:7.1, bench:6.6, chargeLen:4.2, subdrill:0.5, holes:30.6, pf:0.3, diameter:4.5, explosive:5.1, volume:79.2, rockSG:2.6, explosiveDensity:0.85, isExample:true, isAverage:true }
  ];

  function defaultProjectBlastsMapping(){
    return {
      units: {
        length: 'm',
        diameter: 'in',
        pf: 'kg/m3',
        explosive: 'kg/m',
        volume: 'm3/hole'
      },
      derive: {
        bench: 'recorded',
        chargeLen: 'recorded',
        volume: 'recorded',
        pf: 'recorded'
      },
      tolerances: {
        lengthM: 0.1,
        volumePct: 5.0,
        pfPct: 15.0
      }
    };
  }

  function initProjectBlastsState(){
    return {
      blasts: deepClone(DEFAULT_PROJECT_BLASTS),
      activeId: 'CC-6',
      runMode: 'single',
      deriveQFromPF: false,
      mapping: defaultProjectBlastsMapping()
    };
  }

  /* Sanitasi payload lama (PERSIST): hanya objek datar, angka harus finite, string dipangkas,
     dan activeId dipaksa menunjuk blast yang ada. Mengembalikan null bila bentuknya tidak dapat dipakai. */
  function sanitizeProjectBlasts(p){
    if(!p || typeof p!=='object' || Array.isArray(p) || !Array.isArray(p.blasts)) return null;
    const SAFE_KEYS=['id','name','burden','spacing','stemming','holeDepth','bench','chargeLen','subdrill','holes','pf','diameter','explosive','volume','rockSG','explosiveDensity','isExample','isAverage'];
    const blasts=p.blasts.filter(b=>b && typeof b==='object' && !Array.isArray(b)).slice(0,500).map((b,i)=>{
      const o={};
      SAFE_KEYS.forEach(k=>{
        const v=b[k];
        if(typeof v==='number'){ if(Number.isFinite(v)) o[k]=v; }
        else if(typeof v==='boolean') o[k]=v;
        else if(v==null) o[k]=null;
        else o[k]=String(v).slice(0,120);
      });
      if(o.id==null||o.id==='') o.id='BLAST-'+(i+1);
      return o;
    });
    if(!blasts.length) return null;
    const ids=blasts.map(b=>String(b.id));
    return {
      blasts,
      activeId: ids.includes(String(p.activeId)) ? String(p.activeId) : ids[0],
      runMode: 'single',
      deriveQFromPF: p.deriveQFromPF===true,
      mapping: (p.mapping && typeof p.mapping==='object' && !Array.isArray(p.mapping)) ? p.mapping : defaultProjectBlastsMapping()
    };
  }

  function blastLengthToM(val, unit){
    if(!Number.isFinite(Number(val))) return null;
    return unit==='ft' ? Number(val)*0.3048 : Number(val);
  }
  function blastMToLength(valM, unit){
    if(!Number.isFinite(Number(valM))) return null;
    return unit==='ft' ? Number(valM)/0.3048 : Number(valM);
  }
  function blastDiameterToMm(val, unit){
    if(!Number.isFinite(Number(val))) return null;
    return unit==='in' ? Number(val)*25.4 : Number(val);
  }
  function blastMmToDiameter(valMm, unit){
    if(!Number.isFinite(Number(valMm))) return null;
    return unit==='in' ? Number(valMm)/25.4 : Number(valMm);
  }
  function blastPfToKgM3(val, unit, rockSG){
    if(!Number.isFinite(Number(val))) return null;
    const sg = (Number.isFinite(Number(rockSG)) && Number(rockSG)>0) ? Number(rockSG) : 2.6;
    return unit==='kg/ton' ? Number(val)*sg : Number(val);
  }
  function blastKgM3ToPf(valKgM3, unit, rockSG){
    if(!Number.isFinite(Number(valKgM3))) return null;
    const sg = (Number.isFinite(Number(rockSG)) && Number(rockSG)>0) ? Number(rockSG) : 2.6;
    return unit==='kg/ton' ? Number(valKgM3)/sg : Number(valKgM3);
  }

  function getNormalizedBlastGeometry(blast, mapping, deriveQFromPF){
    if(!blast) return null;
    const m = mapping || (APP_STATE.projectBlasts && APP_STATE.projectBlasts.mapping) || defaultProjectBlastsMapping();
    const u = m.units || {}, dr = m.derive || {};

    const B = blastLengthToM(blast.burden, u.length);
    const S = blastLengthToM(blast.spacing, u.length);
    const T = blastLengthToM(blast.stemming, u.length);
    const H = blastLengthToM(blast.holeDepth, u.length);
    const J = blastLengthToM(blast.subdrill, u.length);
    const holes = (Number.isFinite(Number(blast.holes)) && Number(blast.holes)>0) ? Number(blast.holes) : 1;
    const rockSG = (Number.isFinite(Number(blast.rockSG)) && Number(blast.rockSG)>0) ? Number(blast.rockSG) : null;
    const diaMm = blastDiameterToMm(blast.diameter, u.diameter);

    const L_derived = (H!=null && J!=null) ? H - J : null;
    const PC_derived = (H!=null && T!=null) ? H - T : null;
    const benchM = (dr.bench==='from_subdrill' && L_derived!=null) ? L_derived : blastLengthToM(blast.bench, u.length);
    const chargeLenM = (dr.chargeLen==='from_stemming' && PC_derived!=null) ? PC_derived : blastLengthToM(blast.chargeLen, u.length);

    const V_derived_bsl = (B!=null && S!=null && benchM!=null) ? B * S * benchM : null;
    let volumeM3Hole = null;
    if(dr.volume==='from_bsl' && V_derived_bsl!=null){
      volumeM3Hole = V_derived_bsl;
    } else if(Number.isFinite(Number(blast.volume))){
      const vRaw = Number(blast.volume);
      if(u.volume==='total_tonnage'){
        const sg = rockSG || 2.6;
        volumeM3Hole = vRaw / (holes * sg);
      } else if(u.volume==='total_m3'){
        volumeM3Hole = vRaw / holes;
      } else {
        volumeM3Hole = vRaw;
      }
    }

    let chargeKg = null;
    if(Number.isFinite(Number(blast.explosive))){
      const eRaw = Number(blast.explosive);
      if(u.explosive==='kg/hole'){
        chargeKg = eRaw;
      } else {
        const pc = chargeLenM || PC_derived || 0;
        chargeKg = eRaw * pc;
      }
    }

    const PF_derived_qv = (chargeKg!=null && volumeM3Hole!=null && volumeM3Hole>0) ? chargeKg / volumeM3Hole : null;
    let pfKgM3 = null;
    if(dr.pf==='from_qv' && PF_derived_qv!=null){
      pfKgM3 = PF_derived_qv;
    } else if(Number.isFinite(Number(blast.pf))){
      pfKgM3 = blastPfToKgM3(blast.pf, u.pf, rockSG);
    }

    if(deriveQFromPF && pfKgM3!=null && B!=null && S!=null && benchM!=null){
      chargeKg = pfKgM3 * B * S * benchM;
    }

    return {
      id: blast.id,
      name: blast.name || blast.id,
      burdenM: B,
      spacingM: S,
      stemmingM: T,
      holeDepthM: H,
      subdrillM: J,
      benchM,
      chargeLenM,
      holeDiaMm: diaMm,
      chargeKg,
      pfKgM3,
      rockSG,
      volumeM3Hole,
      holes,
      isAverage: !!blast.isAverage,
      isExample: !!blast.isExample,
      raw: blast,
      derived: {
        L_from_HJ: L_derived,
        PC_from_HT: PC_derived,
        V_from_BSL: V_derived_bsl,
        PF_from_QV: PF_derived_qv
      }
    };
  }

  function validateBlastConsistency(norm, mapping){
    if(!norm) return { ok: true, warnings: [], diffs: {} };
    const m = mapping || (APP_STATE.projectBlasts && APP_STATE.projectBlasts.mapping) || defaultProjectBlastsMapping();
    const tol = m.tolerances || { lengthM: 0.1, volumePct: 5.0, pfPct: 15.0 };
    const diffs = {};
    const warnings = [];

    if(norm.benchM!=null && norm.derived?.L_from_HJ!=null){
      const diff = Math.abs(norm.benchM - norm.derived.L_from_HJ);
      diffs.L = { rec: norm.benchM, der: norm.derived.L_from_HJ, diff, tol: tol.lengthM, ok: diff <= tol.lengthM + 1e-5 };
      if(!diffs.L.ok){
        warnings.push(`Tinggi jenjang L (${norm.benchM.toFixed(2)} m) berbeda ${diff.toFixed(2)} m dari H−J (${norm.derived.L_from_HJ.toFixed(2)} m).`);
      }
    }

    if(norm.chargeLenM!=null && norm.derived?.PC_from_HT!=null){
      const diff = Math.abs(norm.chargeLenM - norm.derived.PC_from_HT);
      diffs.PC = { rec: norm.chargeLenM, der: norm.derived.PC_from_HT, diff, tol: tol.lengthM, ok: diff <= tol.lengthM + 1e-5 };
      if(!diffs.PC.ok){
        warnings.push(`Panjang charge PC (${norm.chargeLenM.toFixed(2)} m) berbeda ${diff.toFixed(2)} m dari H−T (${norm.derived.PC_from_HT.toFixed(2)} m).`);
      }
    }

    if(norm.volumeM3Hole!=null && norm.derived?.V_from_BSL!=null && norm.derived.V_from_BSL>0){
      const pct = Math.abs(norm.volumeM3Hole - norm.derived.V_from_BSL) / norm.derived.V_from_BSL * 100;
      diffs.V = { rec: norm.volumeM3Hole, der: norm.derived.V_from_BSL, pct, tol: tol.volumePct, ok: pct <= tol.volumePct + 1e-4 };
      if(!diffs.V.ok){
        warnings.push(`Volume bank V (${norm.volumeM3Hole.toFixed(1)} m³) berbeda ${pct.toFixed(1)}% dari B×S×L (${norm.derived.V_from_BSL.toFixed(1)} m³).`);
      }
    }

    if(norm.pfKgM3!=null && norm.derived?.PF_from_QV!=null && norm.derived.PF_from_QV>0){
      const pct = Math.abs(norm.pfKgM3 - norm.derived.PF_from_QV) / norm.derived.PF_from_QV * 100;
      diffs.PF = { rec: norm.pfKgM3, der: norm.derived.PF_from_QV, pct, tol: tol.pfPct, ok: pct <= tol.pfPct + 1e-4 };
      if(!diffs.PF.ok){
        warnings.push(`PF tercatat (${norm.pfKgM3.toFixed(2)} kg/m³) berbeda ${pct.toFixed(1)}% dari Q/V (${norm.derived.PF_from_QV.toFixed(2)} kg/m³).`);
      }
    }

    const ok = Object.values(diffs).every(d => d.ok);
    return { ok, warnings, diffs };
  }

  function computeWeightedAverageBlast(blasts, mapping, deriveQFromPF){
    if(!blasts || !blasts.length) return null;
    const norms = blasts.map(b => getNormalizedBlastGeometry(b, mapping, deriveQFromPF)).filter(Boolean);
    if(!norms.length) return null;

    let totalHoles = 0;
    let sumB = 0, sumS = 0, sumT = 0, sumH = 0, sumBench = 0, sumPC = 0, sumJ = 0;
    let sumDia = 0, sumQ = 0, sumPF = 0, sumSG = 0, sumVol = 0;
    let countSG = 0, countDia = 0;

    for(const n of norms){
      const w = (Number.isFinite(n.holes) && n.holes > 0) ? n.holes : 1;
      totalHoles += w;
      if(n.burdenM!=null) sumB += n.burdenM * w;
      if(n.spacingM!=null) sumS += n.spacingM * w;
      if(n.stemmingM!=null) sumT += n.stemmingM * w;
      if(n.holeDepthM!=null) sumH += n.holeDepthM * w;
      if(n.benchM!=null) sumBench += n.benchM * w;
      if(n.chargeLenM!=null) sumPC += n.chargeLenM * w;
      if(n.subdrillM!=null) sumJ += n.subdrillM * w;
      if(n.chargeKg!=null) sumQ += n.chargeKg * w;
      if(n.pfKgM3!=null) sumPF += n.pfKgM3 * w;
      if(n.volumeM3Hole!=null) sumVol += n.volumeM3Hole * w;
      if(n.holeDiaMm!=null){ sumDia += n.holeDiaMm * w; countDia += w; }
      if(n.rockSG!=null){ sumSG += n.rockSG * w; countSG += w; }
    }

    if(totalHoles <= 0) totalHoles = norms.length;
    const avgDia = countDia > 0 ? sumDia / countDia : null;
    const avgSG = countSG > 0 ? sumSG / countSG : null;

    return {
      id: 'GROUP_AVG',
      name: `RATA-RATA TERBOBOT (${norms.length} BLAST)`,
      burdenM: sumB / totalHoles,
      spacingM: sumS / totalHoles,
      stemmingM: sumT / totalHoles,
      holeDepthM: sumH / totalHoles,
      benchM: sumBench / totalHoles,
      chargeLenM: sumPC / totalHoles,
      subdrillM: sumJ / totalHoles,
      holeDiaMm: avgDia,
      chargeKg: sumQ / totalHoles,
      pfKgM3: sumPF / totalHoles,
      rockSG: avgSG,
      volumeM3Hole: sumVol / totalHoles,
      holes: totalHoles,
      isAverage: true,
      isExample: norms.some(n => n.isExample),
      derived: {
        L_from_HJ: (sumH - sumJ) / totalHoles,
        PC_from_HT: (sumH - sumT) / totalHoles,
        V_from_BSL: (sumB / totalHoles) * (sumS / totalHoles) * (sumBench / totalHoles),
        PF_from_QV: (sumVol > 0) ? sumQ / sumVol : null
      }
    };
  }

  function parsePastedBlastTable(rawText){
    const text = String(rawText || '').trim();
    if(!text) return { ok: false, error: 'Teks tempel kosong.', blasts: [] };
    const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    if(lines.length < 2) return { ok: false, error: 'Minimal diperlukan 1 baris header dan 1 baris data.', blasts: [] };

    const firstLine = lines[0];
    const delimiter = firstLine.includes('\t') ? '\t' : (firstLine.includes(';') ? ';' : ',');
    const rawHeaders = firstLine.split(delimiter).map(h => h.trim().replace(/^["']|["']$/g, ''));

    const ALIAS_MAP = {
      id: ['blast', 'nama', 'name', 'id', 'blastid', 'namablast', 'no'],
      burden: ['b', 'burden'],
      spacing: ['s', 'spacing', 'spasi'],
      stemming: ['t', 'stemming'],
      holeDepth: ['h', 'kedalaman', 'depth', 'holedepth', 'subdepth'],
      bench: ['l', 'bench', 'jenjang', 'tinggi', 'tinggijenjang'],
      chargeLen: ['pc', 'charging', 'chargelen', 'charge', 'panjangkolom'],
      subdrill: ['j', 'subdrill', 'sub'],
      holes: ['n', 'holes', 'jumlahlubang', 'lubang', 'holecount'],
      pf: ['pf', 'powderfactor', 'powder_factor'],
      diameter: ['de', 'diameter', 'dia', 'lubangdia'],
      explosive: ['e', 'handak', 'explosive', 'an', 'anfo'],
      volume: ['v', 'volume', 'tonase', 'vol'],
      rockSG: ['sg', 'density', 'densitas', 'rocksg']
    };

    const headerIndices = {};
    rawHeaders.forEach((h, idx) => {
      const normH = h.toLowerCase().replace(/[^a-z0-9]/g, '');
      for(const [field, aliases] of Object.entries(ALIAS_MAP)){
        if(headerIndices[field] !== undefined) continue;
        if(aliases.some(a => normH === a || normH.startsWith(a))){
          headerIndices[field] = idx;
          break;
        }
      }
    });

    const num = v => {
      if(v == null) return null;
      const s = String(v).trim().replace(/\s/g, '');
      if(!s) return null;
      let clean = s;
      if(s.includes(',') && !s.includes('.')){
        clean = s.replace(',', '.');
      } else if(s.includes(',') && s.includes('.')){
        clean = s.replace(/,/g, '');
      }
      const n = Number(clean);
      return Number.isFinite(n) ? n : null;
    };

    const blasts = [];
    for(let i = 1; i < lines.length; i++){
      const parts = lines[i].split(delimiter).map(p => p.trim().replace(/^["']|["']$/g, ''));
      if(parts.length < 3) continue;

      const idVal = headerIndices.id !== undefined ? parts[headerIndices.id] : `B-${i}`;
      const blast = {
        id: idVal || `B-${i}`,
        name: idVal || `B-${i}`,
        burden: num(headerIndices.burden !== undefined ? parts[headerIndices.burden] : null),
        spacing: num(headerIndices.spacing !== undefined ? parts[headerIndices.spacing] : null),
        stemming: num(headerIndices.stemming !== undefined ? parts[headerIndices.stemming] : null),
        holeDepth: num(headerIndices.holeDepth !== undefined ? parts[headerIndices.holeDepth] : null),
        bench: num(headerIndices.bench !== undefined ? parts[headerIndices.bench] : null),
        chargeLen: num(headerIndices.chargeLen !== undefined ? parts[headerIndices.chargeLen] : null),
        subdrill: num(headerIndices.subdrill !== undefined ? parts[headerIndices.subdrill] : 0.5),
        holes: num(headerIndices.holes !== undefined ? parts[headerIndices.holes] : 1),
        pf: num(headerIndices.pf !== undefined ? parts[headerIndices.pf] : null),
        diameter: num(headerIndices.diameter !== undefined ? parts[headerIndices.diameter] : 4.5),
        explosive: num(headerIndices.explosive !== undefined ? parts[headerIndices.explosive] : null),
        volume: num(headerIndices.volume !== undefined ? parts[headerIndices.volume] : null),
        rockSG: num(headerIndices.rockSG !== undefined ? parts[headerIndices.rockSG] : 2.6),
        isExample: false,
        isAverage: false
      };
      blasts.push(blast);
    }

    if(!blasts.length) return { ok: false, error: 'Tidak ada baris data valid yang terbaca.', blasts: [] };
    return { ok: true, headers: rawHeaders, mapped: headerIndices, blasts };
  }
  /* PROJECT-BLASTS-ENGINE:END */

  // Version-safe migration of a raw persisted payload (v3..v10) -> normalized v10 payload, or null if unusable.
  // Never throws. Old payloads without `kuzram` get defaults (legacy `gas` dropped); wrongly-typed sections are dropped (=> "missing").
  function migratePersistedState(raw){
    if(!raw || typeof raw!=='object' || Array.isArray(raw)) return null;
    if(!PERSIST_READABLE_VERSIONS.includes(raw.version)) return null;
    const out={...raw};
    if(raw.version<11){ delete out.geometry; delete out.financial; delete out.seismic; if(out.formula) delete out.formula.mae; if(out.material) out.material={...out.material,qualityKey:null}; out.__legacyInputsDropped=true; /* PHASE A: v<11 payloads may contain demo defaults without provenance */ }
    ['project','formation','psdConfig','geometry','formula','financial','optimizer','seismic','simulation','material','freeFace','karst'].forEach(k=>{
      if(k in out && (!out[k] || typeof out[k]!=='object' || Array.isArray(out[k]))) delete out[k];
    });
    delete out.gas; /* payload lama berisi gas tetap terbaca; modul gas dihapus */
    out.kuzram = kzSanitize(raw.kuzram);
    // projectBlasts diterima hanya bila bentuknya masuk akal: item rusak dibuang, activeId wajib menunjuk blast
    // yang benar-benar ada, dan kunci berbahaya (__proto__/constructor/prototype) tidak pernah disalin.
    out.projectBlasts = sanitizeProjectBlasts(raw.projectBlasts) || initProjectBlastsState();
    // PERSISTENCE DESIGN DECISION (Phase 2, item 9, Option A): the photo dataset is NOT persisted.
    // image (canvas/base64), calibration (cm/pixel is only valid for one specific image) and fragments
    // are session-only, and the derived PSD summary (X50/X80/RR) is therefore session-only too. Persisting a
    // summary without its dataset would show X50/X80 after reload with nothing behind them. Only the user
    // *setting* `psd.sizeDefinition` survives. Old (v3-v9) payloads that contain derived PSD values are ignored.
    const sd = (raw.psd && typeof raw.psd==='object') ? raw.psd.sizeDefinition : undefined;
    out.psd = { sizeDefinition: PSD_SIZE_DEFINITIONS.includes(sd) ? sd : 'feret' };
    out.sourceVersion = raw.version; out.version = PERSIST_VERSION;
    return out;
  }
  /* PERSIST-ENGINE:END */

  // Embedded laboratory baseline sourced from the user's "Analisis Harian.xlsx" • sheet "Analisa Sample".
  // Only rows with a recognized Kualitas code (HG, MG, DOL, PEDEL) are embedded.
  const EMBEDDED_LAB_SOURCE = window.KB_EMBEDDED_LAB_SOURCE; // data dipindah ke js/lab-data.js
  const APP_STATE = {
    project: { id:'KarstBlast_Project', site:'', notes:'' },
    formation: { key:'limestone', label:'Gamping / Dolomit' },
    material: {
      labSnapshot: null,
      labWorking: null,
      labSource: null,
      importMeta: null,
      qualityKey: null,
      formations: {}
    },
    geometry: { input:{ diameterIn:null, benchHeight:null, explosiveDensity:null, holeCount:null, targetX80:null, airDeckPct:0 }, inputSource:'WAITING FOR PROJECT INPUT', result:null, results:{ash:null,konya:null,mae:null}, comparisonInputs:{diameterIn:null,benchHeight:null,explosiveDensity:null,rockDensity:null,holeCount:null,loaded:false,source:'NOT LOADED',rockSource:'LAB BASE',densityBasis:null,stv:null,firing:null,ashVod:null,ashKs:null,kd:null,kr:null,kgeo:null}, comparison:{status:'STALE',inputsHash:null,lastCalculated:null}, formulaRockDensityOverride:null, cost:{drilling:null,explosive:null,accessory:null} },
    formula: { key:'ash' },
    financial: { anfoIdrKg:null, secondaryIdrUnit:null, secondaryReductionPct:null, secondaryBaselineUnits:null, limestonePriceIdrTon:null, priceSource:'', quotationDate:'', vendorRef:'', limestonePriceSource:'', result:null },
    image: { file:null, metadata:null, sourceCanvas:null, workingCanvas:null, transform:null, displayTransform:{scaleX:1,scaleY:1,offsetX:0,offsetY:0}, qc:null, mode:'auto', selectedId:null, manualMode:null, manualTrace:[], roiPolygons:[], roiDraft:[] },
    calibration: { points:[], mode:'A', pixelDistanceSource:null, pixelDistanceWorking:null, metersPerSourcePixel:null, centimetersPerSourcePixel:null, metersPerWorkingPixel:null, centimetersPerWorkingPixel:null, status:'NOT CALIBRATED', quality:'POOR', perspectiveWarning:true },
    fragments: [],
    psd: { x50:null, x80:null, oversizeCount:null, oversizeFraction:null, xc:null, n:null, rrOversizeFraction:null, r2:null, fitStatus:'INSUFFICIENT SAMPLE', sizeDefinition:'feret', x50Px:null, x80Px:null, pixelSampleCount:0, sampleCount:0, calibrationCmPerPx:null, physicalStatus:'NOT AVAILABLE - NOT CALIBRATED' },
    psdConfig: { thresholdPct:62, minArea:100, maxArea:0, smoothRadius:1, edgeSensitivity:1, separationSensitivity:1, morphologyOpenPasses:1, morphologyClosePasses:1, maxObjectWidthPct:70, maxObjectHeightPct:70, minValidObjects:3, oversizeThresholdCm:80, rrMinSamples:8 },
    seismic: { K:null, n:null, D:null, W:null, ppv:null, fit:{status:'NO SITE FIT',residual:null,r2:null}, kSource:'NONE', dwSource:'NONE' },
    optimizer: { airDeckPct:0 },
    audit: { session:new Date().toISOString(), entries:[] },
    labHistory: [],
    simulation: { levelIndex:1, technique:'standar', animating:false, template:'group1', groupLabel:'GROUP I • J-13', activeBlastRow:1, rowOverrides:{}, customBlocks:[], parameters:{holeCount:4,anPerHoleKg:11.7,dnPerHoleKg:0.20,stemmingM:1.32,burdenM:2.5,spacingM:3.5,depthM:3.0,deckPct:0}, result:null, holePattern:[], activeView:'cross' },
    // FREE FACE ENGINE • single source of truth for blast direction.
    // normalVector/tangentVector/azimuthDeg/distanceToHole/burdenVector/linePoints are
    // DERIVED (recomputed by recalcFreeFace()) from mode/points/manualAzimuthDeg and the
    // current hole pattern. They are never hand-set; see recalcFreeFace().
    freeFace: { mode:'front', points:[], manualAzimuthDeg:0, normalVector:null, tangentVector:null, azimuthDeg:null, distanceToHole:null, burdenVector:null, referenceHoleId:null, linePoints:null, confidence:'MEDIUM' },
    karst: { cavities:[], autoLevel:true, placementMode:false, counts:{none:0,near:0,intersect:0,central:0}, worstSeverity:'NONE', fractionAffected:0, weightedExposure:0, holeSeverity:{} },
    // KUZ-RAM: sumber kebenaran input manual + mode. Hasil dihitung ulang dari input saat ini (tidak disimpan).
    kuzram: kzDefaultState(),
    projectBlasts: initProjectBlastsState()
  };
  window.APP_STATE = APP_STATE;

  const LABELS = { Density:'Density', SiO2:'SiO₂', Al2O3:'Al₂O₃', Fe2O3:'Fe₂O₃', CaO:'CaO', MgO:'MgO', K2O:'K₂O', Na2O:'Na₂O', H2O:'H₂O', Tonase:'Tonase' };
const BLAST_SHEET_ROWS = {
    group1:{label:'GROUP I • J-13',face:'Timur',totalHoles:138,rows:[
      {no:1,holes:4,spacing:3.50,burden:2.50,depth:3.0,subDepth:3.5,unit:'CRD',an:11.7,dn:.20,totalAn:47,totalDn:.8,det:4,cw:6,fuel:4,charging:2.2,stemming:1.32,dev:62.2,rc:.8,bsr:1.2,volume:149,pf:.320},
      {no:2,holes:21,spacing:3.50,burden:2.50,depth:3.5,subDepth:4.0,unit:'CRD',an:13.8,dn:.20,totalAn:290,totalDn:4.2,det:21,cw:null,fuel:23,charging:2.6,stemming:1.45,dev:63.9,rc:.8,bsr:1.4,volume:914,pf:.321},
      {no:3,holes:38,spacing:3.50,burden:2.50,depth:5.0,subDepth:5.5,unit:'CRD',an:17.8,dn:.20,totalAn:675,totalDn:7.6,det:38,cw:null,fuel:53,charging:3.2,stemming:2.32,dev:57.7,rc:1.4,bsr:2.0,volume:2363,pf:.289},
      {no:4,holes:75,spacing:3.50,burden:2.50,depth:5.5,subDepth:6.0,unit:'CRD',an:22.2,dn:.20,totalAn:1662,totalDn:15,det:75,cw:null,fuel:130,charging:3.5,stemming:2.50,dev:58.3,rc:1.5,bsr:2.2,volume:5131,pf:.327}
    ]},
    group2:{label:'GROUP II • BB-6',face:'Timur',totalHoles:121,rows:[
      {no:1,holes:3,spacing:3.50,burden:2.50,depth:3.0,subDepth:3.5,unit:'CRD',an:11.7,dn:.20,totalAn:35,totalDn:.6,det:3,cw:6,fuel:3,charging:2.2,stemming:1.32,dev:62.2,rc:.8,bsr:1.2,volume:112,pf:.320},
      {no:2,holes:3,spacing:3.50,burden:2.50,depth:3.5,subDepth:4.0,unit:'CRD',an:13.8,dn:.20,totalAn:41,totalDn:.6,det:3,cw:null,fuel:4,charging:2.6,stemming:1.45,dev:63.9,rc:.8,bsr:1.4,volume:131,pf:.321},
      {no:3,holes:26,spacing:3.50,burden:2.50,depth:5.0,subDepth:5.5,unit:'CRD',an:20.4,dn:.20,totalAn:530,totalDn:5.2,det:26,cw:null,fuel:42,charging:3.7,stemming:1.78,dev:67.5,rc:1.0,bsr:2.0,volume:1617,pf:.331},
      {no:4,holes:42,spacing:3.50,burden:2.50,depth:5.5,subDepth:6.0,unit:'CRD',an:22.2,dn:.20,totalAn:931,totalDn:8.4,det:42,cw:null,fuel:73,charging:4.0,stemming:2.00,dev:66.7,rc:1.2,bsr:2.2,volume:2873,pf:.327},
      {no:5,holes:13,spacing:3.50,burden:2.50,depth:6.5,subDepth:7.0,unit:'CRD',an:25.7,dn:.20,totalAn:334,totalDn:2.6,det:13,cw:null,fuel:26,charging:4.6,stemming:2.36,dev:66.2,rc:1.4,bsr:2.6,volume:1051,pf:.320},
      {no:6,holes:34,spacing:3.50,burden:2.50,depth:7.5,subDepth:8.0,unit:'CRD',an:29.2,dn:.20,totalAn:993,totalDn:6.8,det:34,cw:null,fuel:78,charging:5.3,stemming:2.73,dev:65.9,rc:1.6,bsr:3.0,volume:3172,pf:.315}
    ]},
    group3:{label:'GROUP III • II-8(4.5")',face:'Barat',totalHoles:116,rows:[
      {no:1,holes:16,spacing:4.50,burden:3.00,depth:3.0,subDepth:3.5,unit:'HCR',an:14.9,dn:.20,totalAn:238,totalDn:3.2,det:16,cw:6,fuel:19,charging:1.7,stemming:1.80,dev:48.7,rc:1.1,bsr:1.0,volume:1036,pf:.232},
      {no:2,holes:4,spacing:4.50,burden:3.00,depth:3.0,subDepth:3.5,unit:'HCR',an:14.9,dn:.50,totalAn:59,totalDn:2.0,det:4,cw:null,fuel:5,charging:1.7,stemming:1.80,dev:48.7,rc:1.1,bsr:1.0,volume:259,pf:.237},
      {no:3,holes:4,spacing:4.50,burden:3.00,depth:5.0,subDepth:5.5,unit:'HCR',an:24.4,dn:.50,totalAn:98,totalDn:2.0,det:4,cw:null,fuel:8,charging:2.8,stemming:2.70,dev:51.0,rc:1.6,bsr:1.7,volume:432,pf:.231},
      {no:4,holes:81,spacing:4.50,burden:3.00,depth:6.0,subDepth:6.5,unit:'HCR',an:31.4,dn:.50,totalAn:2542,totalDn:40.5,det:81,cw:null,fuel:198,charging:3.5,stemming:3.01,dev:53.8,rc:1.8,bsr:2.0,volume:10493,pf:.246},
      {no:5,holes:1,spacing:4.50,burden:3.00,depth:7.0,subDepth:7.5,unit:'HCR',an:37.6,dn:.50,totalAn:38,totalDn:.5,det:1,cw:null,fuel:3,charging:4.2,stemming:3.32,dev:55.8,rc:1.9,bsr:2.3,volume:151,pf:.252},
      {no:6,holes:10,spacing:4.50,burden:3.00,depth:9.0,subDepth:9.5,unit:'HCR',an:48.7,dn:.50,totalAn:487,totalDn:5.0,det:10,cw:null,fuel:38,charging:5.4,stemming:4.07,dev:57.1,rc:2.4,bsr:3.0,volume:1943,pf:.253}
    ]},
    group4:{label:'GROUP IV • kosong',face:'Blasting',totalHoles:0,rows:[]}
  };
  /* Acuan template getaran: hasil regresi GETARAN.SDF (software seismograf). Persamaan = "95% Line" (batas atas), bukan garis rata-rata.
     Square-root SD (m/kg^1/2), PPV mm/s: V = 335.0 * SD^(-1.307), R2 = 0.236, std dev = 0.126.
     sdMin/sdMax = rentang SD 14 event pada tabel GETARAN (dihitung dari tabel). */
  const SEISMIC_REF={file:'GETARAN.SDF',K:335.0,n:1.307,r2:0.236,sigma:0.126,sdMin:79.7,sdMax:111.8,label:'REGRESI GETARAN.SDF'};
  /* Template PPV 2026: tabel seismograf yang dikirim pengguna (10 & 14 Sep 2026). 14 event unik.
     Satu baris duplikat (serial '05' berlabel II 8, nilai identik dengan serial 05 J 13, tetapi isian 22.4 kg tidak cocok dengan II 8 = 31.9 kg) dikeluarkan.
     PPV = maksimum dari Tran/Vert/Long. Kedalaman, PF, dan jumlah hole tidak ada pada tabel sumber (null). */
  const SEISMIC_TEMPLATE_ROWS = [
    {date:'10/09/2026',block:'II-8',depth:null,distance:450,charge:31.9,trans:0.5,vert:0.59,long:0.43,ppv:0.59,pf:null,hole:null,sd:80},
    {date:'10/09/2026',block:'II-8',depth:null,distance:500,charge:31.9,trans:0.35,vert:0.55,long:0.45,ppv:0.55,pf:null,hole:null,sd:89},
    {date:'10/09/2026',block:'J-13',depth:null,distance:500,charge:22.4,trans:0.28,vert:0.28,long:0.55,ppv:0.55,pf:null,hole:null,sd:106},
    {date:'10/09/2026',block:'J-13',depth:null,distance:500,charge:22.4,trans:0.23,vert:0.27,long:0.29,ppv:0.29,pf:null,hole:null,sd:106},
    {date:'10/09/2026',block:'J-13',depth:null,distance:500,charge:22.4,trans:0.25,vert:0.27,long:0.34,ppv:0.34,pf:null,hole:null,sd:106},
    {date:'14/09/2026',block:'L-13',depth:null,distance:400,charge:19.7,trans:0.52,vert:0.78,long:0.5,ppv:0.78,pf:null,hole:null,sd:90},
    {date:'14/09/2026',block:'L-13',depth:null,distance:400,charge:19.7,trans:0.54,vert:0.49,long:0.64,ppv:0.64,pf:null,hole:null,sd:90},
    {date:'14/09/2026',block:'L-13',depth:null,distance:400,charge:19.7,trans:0.59,vert:0.56,long:0.65,ppv:0.65,pf:null,hole:null,sd:90},
    {date:'14/09/2026',block:'BB-6',depth:null,distance:400,charge:21.4,trans:0.24,vert:0.25,long:0.39,ppv:0.39,pf:null,hole:null,sd:86},
    {date:'14/09/2026',block:'GG-12',depth:null,distance:500,charge:20.0,trans:0.28,vert:0.25,long:0.21,ppv:0.28,pf:null,hole:null,sd:112},
    {date:'14/09/2026',block:'GG-12',depth:null,distance:500,charge:20.0,trans:0.34,vert:0.33,long:0.27,ppv:0.34,pf:null,hole:null,sd:112},
    {date:'14/09/2026',block:'GG-12',depth:null,distance:500,charge:20.0,trans:0.52,vert:0.65,long:0.5,ppv:0.65,pf:null,hole:null,sd:112},
    {date:'14/09/2026',block:'GG-12',depth:null,distance:500,charge:20.0,trans:0.29,vert:0.53,long:0.52,ppv:0.53,pf:null,hole:null,sd:112},
    {date:'14/09/2026',block:'GG-12',depth:null,distance:500,charge:20.0,trans:0.36,vert:0.29,long:0.29,ppv:0.36,pf:null,hole:null,sd:112}
  ];
  const SEISMIC_TEMPLATE_ROWS_2019 = [
    {date:'02/04/2019',block:'CC14',depth:6.2,distance:623,charge:36.8,trans:.45,vert:.66,long:.37,ppv:.66,pf:.29,hole:50,sd:102},
    {date:'02/04/2019',block:'FF10',depth:6.2,distance:790,charge:36.8,trans:.52,vert:.36,long:.31,ppv:.52,pf:.28,hole:100,sd:130},
    {date:'02/04/2019',block:'FF10',depth:6.2,distance:790,charge:92,trans:.49,vert:.65,long:.60,ppv:.65,pf:.28,hole:100,sd:82},
    {date:'04/04/2019',block:'CC17',depth:6.2,distance:412,charge:51,trans:1.34,vert:1.07,long:1.56,ppv:1.56,pf:.20,hole:67,sd:57},
    {date:'04/04/2019',block:'CC17',depth:6.2,distance:412,charge:77,trans:1.77,vert:1.28,long:1.75,ppv:1.77,pf:.20,hole:100,sd:46},
    {date:'04/04/2019',block:'CC17',depth:6.2,distance:412,charge:46.2,trans:.63,vert:.32,long:.49,ppv:.63,pf:.13,hole:62,sd:60},
    {date:'04/04/2019',block:'CC18',depth:6.2,distance:518,charge:45.9,trans:.89,vert:.72,long:1.00,ppv:1.00,pf:.13,hole:71,sd:65},
    {date:'09/04/2019',block:'CC18',depth:6.2,distance:518,charge:61.6,trans:1.27,vert:1.10,long:1.26,ppv:1.27,pf:.13,hole:70,sd:65},
    {date:'09/04/2019',block:'CC18',depth:6.2,distance:518,charge:71.4,trans:1.31,vert:1.05,long:1.08,ppv:1.31,pf:.13,hole:75,sd:65},
    {date:'13/04/2019',block:'Y10',depth:6.2,distance:563,charge:36,trans:.53,vert:.54,long:.55,ppv:.55,pf:.27,hole:80,sd:93},
    {date:'13/04/2019',block:'CC7',depth:6.2,distance:866,charge:54.6,trans:.39,vert:.24,long:.55,ppv:.55,pf:.32,hole:56,sd:117},
    {date:'13/04/2019',block:'CC7',depth:8.2,distance:866,charge:72.9,trans:.75,vert:.37,long:.69,ppv:.75,pf:.32,hole:64,sd:101},
    {date:'13/04/2019',block:'BB16',depth:6.2,distance:623,charge:54.3,trans:.69,vert:.53,long:.77,ppv:.77,pf:.12,hole:80,sd:84},
    {date:'13/04/2019',block:'CC17',depth:6.2,distance:464,charge:72.4,trans:1.67,vert:1.41,long:1.72,ppv:1.72,pf:.18,hole:77,sd:54},
    {date:'13/04/2019',block:'CC17',depth:6.2,distance:464,charge:72.4,trans:1.25,vert:.87,long:1.54,ppv:1.54,pf:.18,hole:70,sd:54},
    {date:'13/04/2019',block:'CC17',depth:6.2,distance:464,charge:72.4,trans:2.01,vert:1.02,long:2.00,ppv:2.01,pf:.18,hole:83,sd:54}
  ];
  const ALIASES = {
    Kualitas:['kualitas','quality','class','kelas'], Density:['density','densitas','specific gravity','sg'], SiO2:['sio2','siO2','silica'], Al2O3:['al2o3','ai203','alumina'], Fe2O3:['fe2o3','fe203','ferric oxide'], CaO:['cao','calcium oxide'], MgO:['mgo','magnesium oxide'], K2O:['k2o'], Na2O:['na2o'], H2O:['h2o','moisture','water'], Tonase:['tonase','tonnage','weight','ton']
  };

  function deepClone(x){ return x==null ? x : JSON.parse(JSON.stringify(x)); }
  function now(){ return new Date().toISOString(); }
  function audit(parameter, oldValue, newValue, source, action){ APP_STATE.audit.entries.unshift({timestamp:now(), parameter, oldValue, newValue, source, action}); renderAudit(); }
  function fmt(v,d=2){ return Number.isFinite(Number(v)) ? Number(v).toLocaleString('id-ID',{minimumFractionDigits:d,maximumFractionDigits:d}) : 'N/A'; }
  function moneyIDR(v){ return Number.isFinite(Number(v)) ? 'IDR '+Number(v).toLocaleString('id-ID',{maximumFractionDigits:0}) : 'N/A'; }
  function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }
  function median(a){ if(!a.length) return null; const s=a.slice().sort((x,y)=>x-y), m=Math.floor(s.length/2); return s.length%2?s[m]:(s[m-1]+s[m])/2; }
  function stats(values){ const a=values.filter(Number.isFinite); if(!a.length) return null; const mean=a.reduce((x,y)=>x+y,0)/a.length; const min=Math.min(...a),max=Math.max(...a), med=median(a); const variance=a.reduce((s,x)=>s+(x-mean)**2,0)/(a.length>1?a.length-1:1); return {n:a.length,min,max,mean,median:med,sd:Math.sqrt(variance)}; }

  // ==========================================================================
  // FREE-FACE + HOLE GEOMETRY ENGINE
  // Single computation path: hole pattern (from holeCount/burden/spacing) +
  // free-face line (from mode/points/manualAzimuthDeg) => per-hole vectors =>
  // one primary blast vector. No hardcoded direction constant is used anywhere
  // below; the old fixed SIM_DIR has been replaced by currentBlastDir(),
  // which reads APP_STATE.freeFace.normalVector every time it is called.
  // ==========================================================================
  function vSub(a,b){ return {x:a.x-b.x, y:a.y-b.y}; }
  function vAdd(a,b){ return {x:a.x+b.x, y:a.y+b.y}; }
  function vScale(a,s){ return {x:a.x*s, y:a.y*s}; }
  function vLen(a){ return Math.hypot(a.x,a.y); }
  function vNorm(a){ const l=vLen(a); return l>1e-9 ? {x:a.x/l,y:a.y/l} : {x:0,y:0}; }
  function vRotate(a,rad){ const c=Math.cos(rad), s=Math.sin(rad); return {x:a.x*c-a.y*s, y:a.x*s+a.y*c}; }

  function computeHolePattern(){
    const p=APP_STATE.simulation.parameters;
    const n=Math.max(1, Math.round(Number(p.holeCount)||1));
    const B=Math.max(0.1, Number(p.burdenM)||1);
    const S=Math.max(0.1, Number(p.spacingM)||1);
    const maxPerRow=14;
    let perRow=Math.round(Math.sqrt(n*(S/B)));
    if(!Number.isFinite(perRow)||perRow<1) perRow=n;
    perRow=Math.max(1,Math.min(maxPerRow,perRow,n));
    const rows=Math.ceil(n/perRow);
    const holes=[]; let id=1;
    for(let r=0;r<rows;r++){
      const cnt=Math.min(perRow, n-r*perRow);
      const rowWidth=(cnt-1)*S, offsetX=-rowWidth/2;
      for(let c=0;c<cnt;c++) holes.push({ id:id++, row:r, col:c, x:offsetX+c*S, y:r*B });
    }
    return holes; // local meters: x=lateral (centered 0), y=depth from face (row0=nearest face, y=0)
  }

  function nearestPointOnSegment(p,a,b){
    const ab=vSub(b,a), len2=Math.max(1e-9, ab.x*ab.x+ab.y*ab.y);
    let t=((p.x-a.x)*ab.x+(p.y-a.y)*ab.y)/len2;
    t=clamp(t,0,1);
    return {x:a.x+ab.x*t, y:a.y+ab.y*t};
  }

  function computeFaceLine(mode, holes, points, manualAzimuthDeg){
    const xs=holes.map(h=>h.x), ys=holes.map(h=>h.y);
    const minX=Math.min(...xs), maxX=Math.max(...xs), minY=Math.min(...ys), maxY=Math.max(...ys);
    const margin=Math.max(1,(maxX-minX)*0.2,2), standoff=Math.max(1,(maxY-minY)*0.3,2);
    if(mode==='custom' && points && points.length===2) return [points[0],points[1]];
    if(mode==='left') return [{x:minX-standoff,y:minY-margin},{x:minX-standoff,y:maxY+margin}];
    if(mode==='right') return [{x:maxX+standoff,y:minY-margin},{x:maxX+standoff,y:maxY+margin}];
    if(mode==='manual'){
      const rad=(Number(manualAzimuthDeg)||0)*Math.PI/180;
      const dir={x:Math.cos(rad),y:Math.sin(rad)};
      const cx=(minX+maxX)/2, cy=(minY+maxY)/2;
      const len=Math.max(maxX-minX,maxY-minY)+margin*4+standoff*2;
      return [{x:cx-dir.x*len/2,y:cy-dir.y*len/2},{x:cx+dir.x*len/2,y:cy+dir.y*len/2}];
    }
    // 'front' default, and fallback for 'custom' before 2 points exist
    return [{x:minX-margin,y:minY-standoff},{x:maxX+margin,y:minY-standoff}];
  }

  const FF_REFERENCE_VECTOR_FRONT={x:0,y:-1}; // normalVector produced by mode:'front' with default geometry
  const FF_BASE_SCREEN_DIR={x:1,y:-0.66}; // cross-section screen direction for the FRONT case (preserves prior visual)

  function recalcFreeFace(){
    const holes=computeHolePattern();
    APP_STATE.simulation.holePattern=holes;
    const ff=APP_STATE.freeFace;
    const line=computeFaceLine(ff.mode, holes, ff.points, ff.manualAzimuthDeg);
    ff.linePoints=line;
    let sum={x:0,y:0}, minDist=Infinity, minHole=null;
    holes.forEach(h=>{
      const np=nearestPointOnSegment(h,line[0],line[1]);
      const v=vSub(np,h), d=vLen(v), nv=vNorm(v);
      h.blastVector=nv; h.distanceToFace=d;
      sum=vAdd(sum,nv);
      if(d<minDist){ minDist=d; minHole=h; }
    });
    const normalVector = vLen(sum)>1e-6 ? vNorm(sum) : {...FF_REFERENCE_VECTOR_FRONT};
    ff.normalVector=normalVector;
    ff.tangentVector={x:-normalVector.y,y:normalVector.x};
    ff.azimuthDeg=(Math.atan2(normalVector.y,normalVector.x)*180/Math.PI+360)%360;
    ff.distanceToHole=Number.isFinite(minDist)?minDist:null;
    ff.referenceHoleId=minHole?minHole.id:null;
    ff.burdenVector=minHole?vScale(normalVector,minDist):null;
    const lineLen=vLen(vSub(line[1],line[0]));
    ff.confidence = lineLen<1 ? 'LOW (garis face terlalu pendek)' : (ff.mode==='custom' ? 'MEDIUM (custom, perlu review lapangan)' : 'HIGH (edge-derived)');
    return ff;
  }

  // Screen-space direction consumed by the cross-section animation FX (simFrag,
  // simDebris, simBlastJet, simDirectionalWave). Computed fresh every call from
  // APP_STATE.freeFace.normalVector • replaces the old fixed SIM_DIR constant.
  function currentBlastDir(){
    const nv=(APP_STATE.freeFace && APP_STATE.freeFace.normalVector) || FF_REFERENCE_VECTOR_FRONT;
    const angle=Math.atan2(nv.y,nv.x)-Math.atan2(FF_REFERENCE_VECTOR_FRONT.y,FF_REFERENCE_VECTOR_FRONT.x);
    return vRotate(FF_BASE_SCREEN_DIR, angle);
  }

  let lastPlanBounds=null;
  function planWorldToScreen(pt,bounds){
    const W=400,H=300,pad=34;
    const spanX=Math.max(1e-6,bounds.maxX-bounds.minX), spanY=Math.max(1e-6,bounds.maxY-bounds.minY);
    const scale=Math.min((W-2*pad)/spanX,(H-2*pad)/spanY);
    const cx=(bounds.minX+bounds.maxX)/2, cy=(bounds.minY+bounds.maxY)/2;
    return { x:W/2+(pt.x-cx)*scale, y:H/2+(pt.y-cy)*scale };
  }
  function planScreenToWorld(s){
    if(!lastPlanBounds) return {x:0,y:0};
    const W=400,H=300,pad=34, b=lastPlanBounds;
    const spanX=Math.max(1e-6,b.maxX-b.minX), spanY=Math.max(1e-6,b.maxY-b.minY);
    const scale=Math.min((W-2*pad)/spanX,(H-2*pad)/spanY);
    const cx=(b.minX+b.maxX)/2, cy=(b.minY+b.maxY)/2;
    return { x:cx+(s.x-W/2)/scale, y:cy+(s.y-H/2)/scale };
  }
  function svgPointFromEvent(svgEl,evt){
    const pt=svgEl.createSVGPoint(); pt.x=evt.clientX; pt.y=evt.clientY;
    const ctm=svgEl.getScreenCTM(); if(!ctm) return {x:0,y:0};
    const loc=pt.matrixTransform(ctm.inverse());
    return {x:loc.x,y:loc.y};
  }

  // ==========================================================================
  // KARST CAVITY ENGINE
  // ==========================================================================
  const KARST_SEVERITY_ORDER={NONE:0,NEAR:1,INTERSECT:2,CENTRAL:3};
  const KARST_AUTO_RADIUS={kecil:0.9,sedang:1.7,besar:2.6};
  function karstPatternBounds(){
    const holes=APP_STATE.simulation.holePattern?.length?APP_STATE.simulation.holePattern:computeHolePattern();
    APP_STATE.simulation.holePattern=holes;
    if(!holes.length)return {minX:-1,maxX:1,minY:-1,maxY:1};
    return {minX:Math.min(...holes.map(h=>h.x)),maxX:Math.max(...holes.map(h=>h.x)),minY:Math.min(...holes.map(h=>h.y)),maxY:Math.max(...holes.map(h=>h.y))};
  }
  function karstCavityWorldPos(cavity,bounds=karstPatternBounds()){
    const xPct=clamp(Number(cavity.xPct)||0,0,100),yPct=clamp(Number(cavity.yPct)||0,0,100);
    return {x:bounds.minX+(bounds.maxX-bounds.minX)*xPct/100,y:bounds.minY+(bounds.maxY-bounds.minY)*yPct/100};
  }
  function karstClassify(hole,cavity,bounds){
    const center=karstCavityWorldPos(cavity,bounds),r=Math.max(0.1,Number(cavity.radiusM)||0.1);
    const d=Math.hypot(hole.x-center.x,hole.y-center.y);
    const B=Math.max(0.1,Number(APP_STATE.simulation.parameters.burdenM)||1);
    const S=Math.max(0.1,Number(APP_STATE.simulation.parameters.spacingM)||1);
    const holeEff=Math.max(0.28,Math.min(0.55,Math.min(B,S)*0.16));
    if(d<=Math.max(0.28,r*0.45))return 'CENTRAL';
    if(d<=r+holeEff)return 'INTERSECT';
    if(d<=r+1.0)return 'NEAR';
    return 'NONE';
  }
  function recalcKarstInteractions(){
    const ks=APP_STATE.karst||(APP_STATE.karst={cavities:[],autoLevel:true,placementMode:false,counts:{none:0,near:0,intersect:0,central:0},worstSeverity:'NONE',fractionAffected:0,weightedExposure:0,holeSeverity:{}});
    const holes=APP_STATE.simulation.holePattern?.length?APP_STATE.simulation.holePattern:computeHolePattern();
    APP_STATE.simulation.holePattern=holes;
    const bounds=karstPatternBounds(),counts={none:0,near:0,intersect:0,central:0},holeSeverity={};
    let worst='NONE',weighted=0;
    ks.cavities=(Array.isArray(ks.cavities)?ks.cavities:[]).map((c,i)=>({id:c.id||('C'+(i+1)),xPct:clamp(Number(c.xPct)||0,0,100),yPct:clamp(Number(c.yPct)||0,0,100),radiusM:Math.max(0.1,Number(c.radiusM)||0.1)}));
    ks.cavities.forEach(c=>holes.forEach(h=>{
      const sev=karstClassify(h,c,bounds),key=sev.toLowerCase();
      const prev=holeSeverity[h.id]||'NONE';
      if(KARST_SEVERITY_ORDER[sev]>KARST_SEVERITY_ORDER[prev])holeSeverity[h.id]=sev;
    }));
    holes.forEach(h=>{
      const sev=holeSeverity[h.id]||'NONE';counts[sev.toLowerCase()]++;
      if(sev==='NEAR')weighted+=.25; else if(sev==='INTERSECT')weighted+=.75; else if(sev==='CENTRAL')weighted+=1;
      if(KARST_SEVERITY_ORDER[sev]>KARST_SEVERITY_ORDER[worst])worst=sev;
    });
    const affected=holes.length?Object.values(holeSeverity).filter(s=>s!=='NONE').length/holes.length:0;
    ks.counts=counts;ks.worstSeverity=worst;ks.fractionAffected=affected;ks.weightedExposure=holes.length?weighted/holes.length:0;ks.holeSeverity=holeSeverity;
    renderKarstPanel();
    return {bounds,holeSeverity};
  }
  function karstRadiusFromLevel(){return KARST_AUTO_RADIUS[simLevel()?.key||'sedang']||1.7;}
  function karstWorstForCavity(c){
    const holes=APP_STATE.simulation.holePattern||[],b=karstPatternBounds();let worst='NONE';
    holes.forEach(h=>{const s=karstClassify(h,c,b);if(KARST_SEVERITY_ORDER[s]>KARST_SEVERITY_ORDER[worst])worst=s;});
    return worst;
  }
  function renderKarstPanel(){
    const k=APP_STATE.karst;if(!$('karstTableBody'))return;
    const set=(id,v)=>{if($(id))$(id).textContent=v};
    set('karstCountNone',k.counts?.none??0);set('karstCountNear',k.counts?.near??0);set('karstCountIntersect',k.counts?.intersect??0);set('karstCountCentral',k.counts?.central??0);
    set('karstAffectedFraction',((k.fractionAffected||0)*100).toFixed(1)+'%');set('karstWorstSeverity',k.worstSeverity||'NONE');
    const body=$('karstTableBody');body.innerHTML='';
    if(!k.cavities?.length){body.innerHTML='<tr><td colspan="6" class="kb-muted">Belum ada cavity.</td></tr>';return;}
    k.cavities.forEach((c,i)=>{
      const tr=document.createElement('tr');
      const values=[String(i+1),
        `<input data-karst-field="xPct" data-karst-id="${htmlEscape(c.id)}" type="number" min="0" max="100" step="0.1" value="${Number(c.xPct).toFixed(1)}">`,
        `<input data-karst-field="yPct" data-karst-id="${htmlEscape(c.id)}" type="number" min="0" max="100" step="0.1" value="${Number(c.yPct).toFixed(1)}">`,
        `<input data-karst-field="radiusM" data-karst-id="${htmlEscape(c.id)}" type="number" min="0.1" step="0.1" value="${Number(c.radiusM).toFixed(1)}">`,
        karstWorstForCavity(c),
        `<button type="button" data-karst-delete="${htmlEscape(c.id)}">DEL</button>`];
      values.forEach(v=>{const td=document.createElement('td');if(String(v).startsWith('<'))td.innerHTML=v;else td.textContent=v;tr.appendChild(td)});body.appendChild(tr);
    });
  }
  function addKarstCavity(xPct,yPct,radiusM,source='USER'){
    const x=Number(xPct),y=Number(yPct),r=Number(radiusM);
    if(!Number.isFinite(x)||!Number.isFinite(y)||!Number.isFinite(r)||r<=0)return false;
    const id='C'+(APP_STATE.karst.cavities.length+1)+'_'+Date.now().toString(36).slice(-5);
    APP_STATE.karst.cavities.push({id,xPct:clamp(x,0,100),yPct:clamp(y,0,100),radiusM:r});
    audit('Karst cavity','',''+clamp(x,0,100).toFixed(1)+'%,'+clamp(y,0,100).toFixed(1)+'%, r='+r.toFixed(1)+' m',source,'ADD CAVITY');
    recalcKarstInteractions();renderPlanView();persistWorking();return true;
  }
  function removeKarstCavity(id){
    const idx=APP_STATE.karst.cavities.findIndex(c=>c.id===id);if(idx<0)return;
    const old=JSON.stringify(APP_STATE.karst.cavities[idx]);APP_STATE.karst.cavities.splice(idx,1);
    audit('Karst cavity',old,'REMOVED','USER ACTION','DELETE CAVITY');recalcKarstInteractions();renderPlanView();persistWorking();
  }
  function clearKarst(){
    if(!APP_STATE.karst.cavities.length)return;const old=APP_STATE.karst.cavities.length;
    APP_STATE.karst.cavities=[];APP_STATE.karst.placementMode=false;
    audit('Karst cavities',old,0,'USER ACTION','CLEAR CAVITIES');recalcKarstInteractions();renderPlanView();persistWorking();renderKarstPlacementState();
  }
  function renderKarstPlacementState(){
    const active=!!APP_STATE.karst.placementMode;$('btnPlaceKarst')?.classList.toggle('karst-placement-active',active);
    if($('karstPlacementStatus'))$('karstPlacementStatus').textContent=active?'PLACE MODE: klik titik pada PLAN VIEW untuk menambah cavity.':'Placement idle.';
  }
  function placeKarstFromPlanEvent(evt){
    if(!APP_STATE.karst.placementMode||APP_STATE.freeFace.mode==='custom')return;
    const svg=$('planSvg');if(!svg||!lastPlanBounds)return;
    const sp=svgPointFromEvent(svg,evt),W=400,H=300,pad=34,b=lastPlanBounds;
    const spanX=Math.max(1e-6,b.maxX-b.minX),spanY=Math.max(1e-6,b.maxY-b.minY),scale=Math.min((W-2*pad)/spanX,(H-2*pad)/spanY);
    const world={x:b.minX+(sp.x-W/2)/scale,y:b.minY+(sp.y-H/2)/scale};
    const xPct=clamp(100*(world.x-b.minX)/spanX,0,100),yPct=clamp(100*(world.y-b.minY)/spanY,0,100);
    const r=APP_STATE.karst.autoLevel?karstRadiusFromLevel():Number($('karstRadiusM')?.value);
    addKarstCavity(xPct,yPct,r,'PLAN CLICK');APP_STATE.karst.placementMode=false;renderKarstPlacementState();
  }
  function importKarstCsv(file){
    { const big=kbFileTooBig(file,'csv'); if(big){ if($('karstPlacementStatus'))$('karstPlacementStatus').textContent='IMPORT FAILED: '+big; return; } }
    if(typeof Papa==='undefined'){if($('karstPlacementStatus'))$('karstPlacementStatus').textContent='IMPORT FAILED: PapaParse tidak tersedia.';return;}
    Papa.parse(file,{header:true,skipEmptyLines:true,complete:res=>{
      try{
        const rows=(res.data||[]).map(r=>({xPct:Number(r.xPct),yPct:Number(r.yPct),radiusM:Number(r.radiusM)})).filter(r=>Number.isFinite(r.xPct)&&Number.isFinite(r.yPct)&&Number.isFinite(r.radiusM)&&r.radiusM>0);
        if(!rows.length)throw new Error('Tidak ada row valid; gunakan kolom xPct,yPct,radiusM.');
        const old=APP_STATE.karst.cavities.length;
        rows.forEach(r=>{APP_STATE.karst.cavities.push({id:'C'+(APP_STATE.karst.cavities.length+1)+'_'+Date.now().toString(36).slice(-6),xPct:clamp(r.xPct,0,100),yPct:clamp(r.yPct,0,100),radiusM:r.radiusM});});
        audit('Karst CSV import',old,APP_STATE.karst.cavities.length,'CSV IMPORT','KARST CSV');recalcKarstInteractions();renderPlanView();persistWorking();
        if($('karstPlacementStatus'))$('karstPlacementStatus').textContent=`Imported ${rows.length} cavity row(s) from ${file.name}.`;
      }catch(e){if($('karstPlacementStatus'))$('karstPlacementStatus').textContent='IMPORT FAILED: '+e.message;}
    },error:e=>{if($('karstPlacementStatus'))$('karstPlacementStatus').textContent='IMPORT FAILED: '+e.message;}});
  }
  function initKarst(){
    $('karstAutoLevel')?.addEventListener('change',e=>{APP_STATE.karst.autoLevel=!!e.target.checked;if(APP_STATE.karst.autoLevel&&$('karstRadiusM'))$('karstRadiusM').value=karstRadiusFromLevel();persistWorking();});
    $('btnAddKarstCavity')?.addEventListener('click',()=>addKarstCavity(Number($('karstXPct').value),Number($('karstYPct').value),APP_STATE.karst.autoLevel?karstRadiusFromLevel():Number($('karstRadiusM').value)));
    $('btnPlaceKarst')?.addEventListener('click',()=>{APP_STATE.karst.placementMode=!APP_STATE.karst.placementMode;renderKarstPlacementState();if(APP_STATE.karst.placementMode)setSimView('plan');});
    $('btnClearKarst')?.addEventListener('click',clearKarst);$('btnImportKarstCsv')?.addEventListener('click',()=>$('karstCsvInput')?.click());
    $('karstCsvInput')?.addEventListener('change',e=>{const f=e.target.files?.[0];if(f)importKarstCsv(f)});
    $('karstTableBody')?.addEventListener('change',e=>{
      const el=e.target.closest('[data-karst-field]');if(!el)return;const c=APP_STATE.karst.cavities.find(x=>x.id===el.dataset.karstId);if(!c)return;
      const old=c[el.dataset.karstField];let v=Number(el.value);v=el.dataset.karstField==='radiusM'?Math.max(.1,v):clamp(v,0,100);if(!Number.isFinite(v))v=old;
      c[el.dataset.karstField]=v;audit('Karst cavity '+c.id,old,v,'USER INPUT','EDIT CAVITY');recalcKarstInteractions();renderPlanView();persistWorking();
    });
    $('karstTableBody')?.addEventListener('click',e=>{const b=e.target.closest('[data-karst-delete]');if(b)removeKarstCavity(b.dataset.karstDelete)});
    $('planSvg')?.addEventListener('click',placeKarstFromPlanEvent);
    renderKarstPlacementState();recalcKarstInteractions();
  }
  const SHOW_PLAN_DIMS=false; // ubah true untuk menampilkan garis dimensi spacing/burden
  function renderPlanView(){
    const ff=APP_STATE.freeFace,holes=APP_STATE.simulation.holePattern||[];
    if(!holes.length||!ff.linePoints)return;
    const line=ff.linePoints,pts=holes.concat(line);
    const bounds={minX:Math.min(...pts.map(p=>p.x))-1,maxX:Math.max(...pts.map(p=>p.x))+1,minY:Math.min(...pts.map(p=>p.y))-1,maxY:Math.max(...pts.map(p=>p.y))+1};
    lastPlanBounds=bounds;const toScreen=pt=>planWorldToScreen(pt,bounds);
    const karst=recalcKarstInteractions(),severity=karst.holeSeverity||{};
    const p=APP_STATE.simulation.parameters||{},group=BLAST_SHEET_ROWS[APP_STATE.simulation.template];
    if($('planSpacingValue'))$('planSpacingValue').textContent=Number(p.spacingM||0).toFixed(2)+' m';
    if($('planBurdenValue'))$('planBurdenValue').textContent=Number(p.burdenM||0).toFixed(2)+' m';
    if($('planHoleCountValue'))$('planHoleCountValue').textContent=String(Number(p.holeCount||holes.length));
    if($('planTemplateValue'))$('planTemplateValue').textContent=(group?.label||'CUSTOM').replace(' • ',' / ');
    const dimg=$('planDimensions');
    if(dimg){dimg.innerHTML='';const row0=holes.filter(h=>h.row===0),nextRow=holes.find(h=>h.row===1&&h.col===0),first=row0[0],second=row0[1];
      if(SHOW_PLAN_DIMS&&first&&second){const a=toScreen(first),b=toScreen(second),y=Math.max(18,Math.min(a.y,b.y)-16);dimg.appendChild(simMake('line',{x1:a.x,y1:a.y-4,x2:a.x,y2:y,class:'plan-dim-ext'}));dimg.appendChild(simMake('line',{x1:b.x,y1:b.y-4,x2:b.x,y2:y,class:'plan-dim-ext'}));dimg.appendChild(simMake('line',{x1:a.x,y1:y,x2:b.x,y2:y,class:'plan-dim'}));const tx=(a.x+b.x)/2,ty=y-4,t=simMake('text',{x:tx,y:ty,'text-anchor':'middle',class:'plan-dim-label'});t.textContent=`SPACING ${Number(p.spacingM||0).toFixed(2)} m`;dimg.appendChild(t);}
      if(SHOW_PLAN_DIMS&&first&&nextRow){const a=toScreen(first),b=toScreen(nextRow),x=Math.max(14,a.x-18);dimg.appendChild(simMake('line',{x1:a.x,y1:a.y,x2:x,y2:a.y,class:'plan-dim-ext'}));dimg.appendChild(simMake('line',{x1:b.x,y1:b.y,x2:x,y2:b.y,class:'plan-dim-ext'}));dimg.appendChild(simMake('line',{x1:x,y1:a.y,x2:x,y2:b.y,class:'plan-dim'}));const tx=x-4,ty=(a.y+b.y)/2,t=simMake('text',{x:tx,y:ty,'text-anchor':'end',class:'plan-dim-label'});t.setAttribute('transform',`rotate(-90 ${tx} ${ty})`);t.textContent=`BURDEN ${Number(p.burdenM||0).toFixed(2)} m`;dimg.appendChild(t);}
    }
    const cg=$('planCavities');
    if(cg){
      cg.innerHTML='';
      const pb=karstPatternBounds(),scale=Math.min((400-68)/Math.max(1e-6,bounds.maxX-bounds.minX),(300-68)/Math.max(1e-6,bounds.maxY-bounds.minY));
      (APP_STATE.karst.cavities||[]).forEach(c=>{
        const s=toScreen(karstCavityWorldPos(c,pb)),r=Math.max(5,(Number(c.radiusM)||.1)*scale),sev=karstWorstForCavity(c);
        const node=simMake('circle',{cx:s.x.toFixed(2),cy:s.y.toFixed(2),r:r.toFixed(2),class:'karst-cavity '+sev.toLowerCase()});cg.appendChild(node);
      });
    }
    const hg=$('planHoles');if(hg){hg.innerHTML='';holes.forEach(h=>{const s=toScreen(h),sev=severity[h.id]||'NONE',c=simMake('circle',{cx:s.x.toFixed(2),cy:s.y.toFixed(2),r:4,class:'plan-hole'});if(sev!=='NONE')c.classList.add('sev-'+sev.toLowerCase());c.setAttribute('data-severity',sev);hg.appendChild(c);});}
    const a=toScreen(line[0]),b=toScreen(line[1]),faceLine=$('planFaceLine');
    if(faceLine){faceLine.setAttribute('x1',a.x.toFixed(2));faceLine.setAttribute('y1',a.y.toFixed(2));faceLine.setAttribute('x2',b.x.toFixed(2));faceLine.setAttribute('y2',b.y.toFixed(2));}
    const refHole=holes.find(h=>h.id===ff.referenceHoleId)||holes[0],start=toScreen(refHole),nv=ff.normalVector||FF_REFERENCE_VECTOR_FRONT,arrowLen=48,end={x:start.x+nv.x*arrowLen,y:start.y+nv.y*arrowLen};
    const arrow=$('planBlastArrowLine');if(arrow){arrow.setAttribute('x1',start.x.toFixed(2));arrow.setAttribute('y1',start.y.toFixed(2));arrow.setAttribute('x2',end.x.toFixed(2));arrow.setAttribute('y2',end.y.toFixed(2));}
    const lbl=$('planBlastArrowLabel');if(lbl){lbl.setAttribute('x',(end.x+6).toFixed(2));lbl.setAttribute('y',end.y.toFixed(2));}
    const cpg=$('planCustomPoints');if(cpg){cpg.innerHTML='';if(ff.mode==='custom')(ff.points||[]).forEach(p=>{const s=toScreen(p);cpg.appendChild(simMake('circle',{cx:s.x.toFixed(2),cy:s.y.toFixed(2),r:5,fill:'none',stroke:'#22c55e','stroke-width':2}));});}
    const meta=$('planMeta');if(meta)meta.textContent=`Mode: ${ff.mode.toUpperCase()} • Spacing: ${Number(p.spacingM||0).toFixed(2)} m • Burden: ${Number(p.burdenM||0).toFixed(2)} m • Azimuth relatif: ${ff.azimuthDeg!=null?fmt(ff.azimuthDeg,1)+'°':'N/A'} • Jarak hole: ${ff.distanceToHole!=null?fmt(ff.distanceToHole,2)+' m':'N/A'} • Karst affected: ${((APP_STATE.karst.fractionAffected||0)*100).toFixed(1)}% • Worst: ${APP_STATE.karst.worstSeverity||'NONE'}`;
  }

  function renderFreeFaceMeta(){
    const ff=APP_STATE.freeFace;
    if($('simFreeFaceMode')) $('simFreeFaceMode').textContent=ff.mode.toUpperCase();
    if($('simBlastAzimuth')) $('simBlastAzimuth').textContent=ff.azimuthDeg!=null?fmt(ff.azimuthDeg,1)+'°':'--';
    if($('ffDistanceToHole')) $('ffDistanceToHole').textContent=ff.distanceToHole!=null?fmt(ff.distanceToHole,2)+' m':'--';
    if($('ffConfidence')) $('ffConfidence').textContent=ff.confidence||'--';
    if($('rFreeFace')) $('rFreeFace').textContent=`${ff.mode.toUpperCase()} • azimuth relatif ${ff.azimuthDeg!=null?fmt(ff.azimuthDeg,1)+'°':'--'} • CALCULATED`;
  }

  function recalcFreeFaceAndRender(){
    recalcFreeFace();
    if(APP_STATE.simulation.activeView==='plan') renderPlanView();
    renderFreeFaceMeta();
    persistWorking();
  }

  function setFreeFaceMode(mode){
    const old=APP_STATE.freeFace.mode;
    if(old===mode) return;
    APP_STATE.freeFace.mode=mode;
    audit('Free Face mode', old.toUpperCase(), mode.toUpperCase(), 'USER ACTION', 'FREE FACE MODE SWITCH');
    renderFreeFaceModeButtons();
    recalcFreeFaceAndRender();
  }

  function renderFreeFaceModeButtons(){
    const m=APP_STATE.freeFace.mode;
    ['front','left','right','custom','manual'].forEach(k=>{ const b=$('ffMode_'+k); if(b) b.classList.toggle('btn--accent',k===m); });
    if($('ffCustomBlock')) $('ffCustomBlock').style.display = m==='custom' ? '' : 'none';
    if($('ffManualBlock')) $('ffManualBlock').style.display = m==='manual' ? '' : 'none';
    if($('planSvg')) $('planSvg').classList.toggle('ff-custom-active', m==='custom');
  }

  function setSimView(view){
    APP_STATE.simulation.activeView=view;
    if($('crossSectionWrap')) $('crossSectionWrap').style.display = view==='cross' ? '' : 'none';
    if($('planViewWrap')) $('planViewWrap').style.display = view==='plan' ? 'block' : 'none';
    if($('btnViewCross')) $('btnViewCross').classList.toggle('btn--accent', view==='cross');
    if($('btnViewPlan')) $('btnViewPlan').classList.toggle('btn--accent', view==='plan');
    if(view==='plan') renderPlanView();
  }

  function initFreeFace(){
    ['front','left','right','custom','manual'].forEach(k=>{ const b=$('ffMode_'+k); if(b) b.addEventListener('click',()=>setFreeFaceMode(k)); });
    if($('btnClearCustomFace')) $('btnClearCustomFace').addEventListener('click',()=>{
      const old=APP_STATE.freeFace.points.length;
      APP_STATE.freeFace.points=[];
      $('customFaceStatus').textContent='Belum ada titik dipilih.';
      audit('Free Face custom points', old+' points', '0 points', 'USER ACTION', 'FREE FACE CLEAR POINTS');
      recalcFreeFaceAndRender();
    });
    if($('btnApplyManualAzimuth')) $('btnApplyManualAzimuth').addEventListener('click',()=>{
      const old=APP_STATE.freeFace.manualAzimuthDeg;
      const val=Number($('manualAzimuthInput').value);
      if(!Number.isFinite(val)){ return; }
      APP_STATE.freeFace.manualAzimuthDeg=val;
      audit('Free Face azimuth (manual)', fmt(old,1)+'°', fmt(val,1)+'°', 'USER INPUT', 'FREE FACE MANUAL AZIMUTH');
      recalcFreeFaceAndRender();
    });
    if($('btnViewCross')) $('btnViewCross').addEventListener('click',()=>setSimView('cross'));
    if($('btnViewPlan')) $('btnViewPlan').addEventListener('click',()=>setSimView('plan'));
    if($('planClickCatcher')) $('planClickCatcher').addEventListener('click',(evt)=>{
      if(APP_STATE.freeFace.mode!=='custom') return;
      const s=svgPointFromEvent($('planSvg'),evt);
      const w=planScreenToWorld(s);
      let pts=APP_STATE.freeFace.points.slice();
      if(pts.length>=2) pts=[];
      pts.push(w);
      APP_STATE.freeFace.points=pts;
      if($('customFaceStatus')) $('customFaceStatus').textContent = pts.length<2 ? `Titik ${pts.length}/2 dipilih • klik titik berikutnya.` : 'Custom face: 2 titik dipilih.';
      if(pts.length===2) audit('Free Face custom points','pending','2 points set','USER ACTION','FREE FACE CUSTOM POINTS');
      recalcFreeFaceAndRender();
    });
    renderFreeFaceModeButtons();
    setSimView(APP_STATE.simulation.activeView||'cross');
    recalcFreeFaceAndRender();
  }

  const LAB_QUALITY_META = Object.freeze({
    HG:    {key:'HG',    label:'HG',    name:'Gamping High Grade',    description:'Indikasi gamping high grade', className:'limestone', priority:1},
    MG:    {key:'MG',    label:'MG',    name:'Gamping Medium Grade',  description:'Indikasi gamping medium grade', className:'limestone', priority:2},
    DOL:   {key:'DOL',   label:'DOL',   name:'Dolomit',               description:'Indikasi material dolomit', className:'dolomite', priority:3},
    PEDEL: {key:'PEDEL', label:'PEDEL', name:'Pedel',                 description:'Material pedel', className:'pedel', priority:4}
  });
  const LAB_QUALITY_ORDER = ['HG','MG','DOL'];

  function defaultEmptyLab(){ return {rows:[],columns:[],mapped:{},numericKeys:[],invalid:[],groups:{},defaultQuality:null,totalRows:0,source:null,sheetName:null,importedAt:null}; }

  function normalizeHeader(s){ return String(s??'').trim().toLowerCase().replace(/[^a-z0-9]+/g,''); }

  function parseLabNumber(raw){
    if(raw===null||raw===undefined||String(raw).trim()==='') return NaN;
    const s=String(raw).trim().replace(/\s/g,'');
    if(s.includes(',') && !s.includes('.')) return Number(s.replace(',','.'));
    return Number(s.replace(/,/g,''));
  }

  function normalizeLabQuality(value){
    const raw=String(value??'').trim();
    const n=normalizeHeader(raw);
    if(['hg','highgrade','gampinghighgrade','limestonehighgrade','gampinghg'].includes(n)) return 'HG';
    if(['mg','mediumgrade','gampingmediumgrade','limestonemediumgrade','gampingmg'].includes(n)) return 'MG';
    if(['dol','dolomit','dolomite','gampingdolomit'].includes(n)) return 'DOL';
    if(['pedel'].includes(n)) return 'PEDEL';
    return raw ? raw.toUpperCase().replace(/\s+/g,' ').trim() : '';
  }

  function qualityMeta(key){
    return LAB_QUALITY_META[key] || {key,label:String(key||'OTHER'),name:String(key||'Other lab class'),description:'Kelas material dari data laboratorium',className:'other',priority:99};
  }

  function mapColumns(headers){
    const n=headers.map(normalizeHeader), out={};
    for(const key of Object.keys(ALIASES)){
      const found=ALIASES[key].map(normalizeHeader).map(a=>n.findIndex(x=>x===a || x.includes(a))).find(i=>i>=0);
      if(found!=null) out[key]=headers[found];
    }
    return out;
  }

  function buildLabSnapshot(rows,source,sheetName){
    if(!rows.length) throw new Error('Tidak ada row data.');
    const headers=[...new Set(rows.flatMap(r=>Object.keys(r)).filter(Boolean))];
    const mapped=mapColumns(headers);
    if(!mapped.Kualitas) throw new Error('Kolom Kualitas tidak ditemukan. Pastikan header memuat Kualitas/Quality/Kelas.');

    const numericKeys=Object.keys(LABELS).filter(k=>mapped[k]);
    const normalizedRows=rows.map((row,idx)=>{
      const o={__row:idx+1};
      for(const key of Object.keys(mapped)){
        const raw=row[mapped[key]];
        o[key]=key==='Kualitas'?String(raw??'').trim():parseLabNumber(raw);
      }
      o.__qualityKey=normalizeLabQuality(o.Kualitas);
      return o;
    });

    const invalid=[];
    normalizedRows.forEach(r=>numericKeys.forEach(k=>{
      if(!Number.isFinite(r[k]) && String(r[k]??'')!=='NaN') invalid.push({row:r.__row,field:k,value:r[k]});
    }));

    const groups={};
    normalizedRows.forEach(r=>{
      const q=r.__qualityKey;
      if(q) (groups[q] ||= []).push(r);
    });

    const formationProfiles={};
    for(const [q,gr] of Object.entries(groups)){
      const st={};
      numericKeys.forEach(k=>{
        const s=stats(gr.map(r=>Number(r[k])).filter(Number.isFinite));
        if(s) st[k]=s;
      });
      const totalTonase=gr.reduce((sum,r)=>sum+(Number.isFinite(Number(r.Tonase))?Number(r.Tonase):0),0);
      formationProfiles[q]={
        quality:q,
        rawQualities:[...new Set(gr.map(r=>String(r.Kualitas||'').trim()).filter(Boolean))],
        sampleCount:gr.length,
        rows:gr,
        stats:st,
        totalTonase,
        source,
        sheetName,
        columns:mapped
      };
    }

    const defaultQuality=LAB_QUALITY_ORDER.find(k=>formationProfiles[k])
      || Object.keys(formationProfiles).sort((a,b)=>qualityMeta(a).priority-qualityMeta(b).priority || a.localeCompare(b))[0]
      || null;
    return {source,sheetName,fileName:String(source||''),columns:mapped,numericKeys,invalid,groups:formationProfiles,defaultQuality,totalRows:normalizedRows.length,importedAt:now()};
  }

  function getLabQualityKeys(snapshot=APP_STATE.material.labSnapshot){
    const groups=snapshot?.groups||{};
    return [...LAB_QUALITY_ORDER.filter(k=>groups[k]),...Object.keys(groups).filter(k=>!LAB_QUALITY_ORDER.includes(k)&&k!=='PEDEL').sort()];
  }

  function labCoverageText(snapshot){
    if(!snapshot?.groups) return 'LAB BASELINE: WAITING';
    const known=LAB_QUALITY_ORDER.map(k=>`${k} ${snapshot.groups[k]?.sampleCount||0}`).join(' • ');
    const other=Object.keys(snapshot.groups).filter(k=>!LAB_QUALITY_ORDER.includes(k)&&k!=='PEDEL').reduce((s,k)=>s+(snapshot.groups[k]?.sampleCount||0),0);
    const total=snapshot.totalRows||Object.values(snapshot.groups).reduce((s,g)=>s+(g.sampleCount||0),0);
    return `LAB total ${total.toLocaleString('id-ID')} • ${known}${other?` • OTHER ${other}`:''}`;
  }

  function activeLabQualityKey(){
    const groups=APP_STATE.material.labSnapshot?.groups||{};
    if(APP_STATE.material.qualityKey && APP_STATE.material.qualityKey!=='PEDEL' && groups[APP_STATE.material.qualityKey]) return APP_STATE.material.qualityKey;
    const formationDefault='HG';
    return groups[formationDefault]?formationDefault:(APP_STATE.material.labSnapshot?.defaultQuality||Object.keys(groups)[0]||null);
  }

  function getActiveLabProfile(){
    const key=activeLabQualityKey();
    return key ? APP_STATE.material.labSnapshot?.groups?.[key] || null : null;
  }

  function profileToWorking(profile,qualityKey){
    const values={sampleCount:profile?.sampleCount||0};
    const canonicalRows=(profile?.rows||[]).map(canonicalizeRow);
    for(const k of Object.keys(LABELS)){
      const arr=canonicalRows.map(r=>Number(r[k])).filter(Number.isFinite);
      if(arr.length) values[k]=arr.reduce((a,b)=>a+b,0)/arr.length;
      else if(profile?.stats?.[k]?.mean!=null) values[k]=profile.stats[k].mean;
    }
    const statsOut={};
    for(const k of Object.keys(LABELS)){
      const arr=canonicalRows.map(r=>Number(r[k])).filter(Number.isFinite);
      if(arr.length) statsOut[k]=stats(arr);
      else if(profile?.stats?.[k]) statsOut[k]=profile.stats[k];
    }
    return {
      quality:profile?.quality||qualityKey||'UNKNOWN',
      qualityKey:qualityKey||profile?.quality||'UNKNOWN',
      values,
      stats:statsOut,
      totalTonase:profile?.totalTonase||0,
      source:profile?.source||'LAB',
      sheetName:profile?.sheetName||profile?.sheet||'Analisa Sample',
      status:'BASELINE',
      rowCount:profile?.sampleCount||0
    };
  }

  function applyLabSnapshotToWorking(key=activeLabQualityKey()){
    if(!key) return false;
    const profile=APP_STATE.material.labSnapshot?.groups?.[key];
    if(!profile) return false;
    APP_STATE.material.qualityKey=key;
    APP_STATE.material.labWorking=profileToWorking(profile,key);
    return true;
  }

  function setLabQuality(key,source='USER ACTION'){
    const canonical=normalizeLabQuality(key);
    const profile=APP_STATE.material.labSnapshot?.groups?.[canonical];
    if(!profile) return false;
    const old=APP_STATE.material.qualityKey||activeLabQualityKey()||'NONE';
    if(old===canonical){
      ensureLabWorking();
      renderLab();
      refreshAll();
      return true;
    }
    APP_STATE.material.qualityKey=canonical;
    applyLabSnapshotToWorking(canonical);
    const meta=qualityMeta(canonical);
    audit('LAB QUALITY',old,`${canonical} • ${meta.name}`,source,'LAB QUALITY SWITCH');
    renderLab();
    refreshAll();
    persistWorking();
    return true;
  }

  function getMaterial(){
    if(APP_STATE.material.labWorking?.values) return APP_STATE.material.labWorking.values;
    const profile=getActiveLabProfile();
    if(profile) return profileToWorking(profile,activeLabQualityKey()).values;
    return APP_STATE.material.formations.limestone?.values || {};
  }

  function labWorkingIsValid(){
    const v=APP_STATE.material.labWorking?.values;
    const active=activeLabQualityKey();
    const profile=APP_STATE.material.labSnapshot?.groups?.[active];
    const expectedRows=Number(profile?.sampleCount||0);
    const workingRows=Number(APP_STATE.material.labWorking?.rowCount||APP_STATE.material.labWorking?.values?.sampleCount||0);
    return !!v && !!profile && APP_STATE.material.labWorking?.qualityKey===active && workingRows===expectedRows && Number.isFinite(Number(v.Density)) && Number(v.Density)>0;
  }

  function ensureLabWorking(){
    if(!APP_STATE.material.labSnapshot) return false;
    const key=activeLabQualityKey();
    if(!key) return false;
    if(!labWorkingIsValid()) applyLabSnapshotToWorking(key);
    return labWorkingIsValid();
  }

  function updateWorkingFromInputs(){
    if(!ensureLabWorking()) return;
    const old=deepClone(APP_STATE.material.labWorking.values);
    const vals={...old};
    for(const k of ['sampleCount','Density','SiO2','Al2O3','Fe2O3','CaO','MgO','K2O','Na2O','H2O','Tonase']){
      const el=$('lab_'+k);
      if(el) vals[k]=Number(el.value);
    }
    APP_STATE.material.labWorking={...APP_STATE.material.labWorking,values:vals,status:'EDITED'};
    audit(`LAB WORKING COPY • ${APP_STATE.material.qualityKey}`,JSON.stringify(old),JSON.stringify(vals),'USER INPUT','MATERIAL UPDATE');
    persistWorking();
    renderLab();
    refreshAll();
  }

  function renderLab(){
    const snap=getActiveLabProfile();
    const work=ensureLabWorking()?APP_STATE.material.labWorking:null;
    const statCells=['sampleCount','Density','SiO2','Al2O3','Fe2O3','CaO','MgO','K2O','Na2O','H2O','Tonase'];
    const activeKey=activeLabQualityKey();
    const activeMeta=qualityMeta(activeKey);

    const selector=$('labQualitySelector');
    if(selector){
      selector.innerHTML='';
      const keys=getLabQualityKeys();
      if(!keys.length) selector.innerHTML='<div class="kb-muted">NO LAB QUALITY AVAILABLE</div>';
      keys.forEach(k=>{
        const meta=qualityMeta(k),g=APP_STATE.material.labSnapshot.groups[k];
        const btn=document.createElement('button');
        btn.type='button';
        btn.className='kb-quality-card'+(k===activeKey?' active':'');
        btn.title=`${meta.name} • ${meta.description}`;
        const code=document.createElement('b');
        code.textContent=String(meta.label||k);
        btn.appendChild(code);
        btn.addEventListener('click',()=>setLabQuality(k));
        selector.appendChild(btn);
      });
    }

    const summary=$('labQualitySummary');
    if(summary){
      summary.innerHTML='';
      if(snap){
        const mk=(label,value)=>{
          const d=document.createElement('div');d.className='qstat';const a=document.createElement('span');a.textContent=String(label??'');const b=document.createElement('b');b.textContent=String(value??'');d.append(a,b);return d;
        };
        summary.appendChild(mk('Active class',activeMeta.label));
        summary.appendChild(mk('Samples',fmt(snap.sampleCount,0)));
        summary.appendChild(mk('Density',fmt(snap.stats?.Density?.mean??work?.values?.Density,3)));
        summary.appendChild(mk('Mean CaO',fmt(snap.stats?.CaO?.mean??work?.values?.CaO,2)));
        summary.appendChild(mk('Mean MgO',fmt(snap.stats?.MgO?.mean??work?.values?.MgO,2)));
        const desc=document.createElement('div');desc.className='qdesc';
        {const st=document.createElement('strong');st.textContent=String(activeMeta.name??'');desc.append(st,document.createTextNode(` • ${activeMeta.description}. Geometry / screening memakai nilai material dari kelas lab aktif.`));}
        summary.appendChild(desc);
      }else summary.innerHTML='<div class="kb-muted">LAB SNAPSHOT NOT AVAILABLE</div>';
    }

    const coverage=$('labQualityCoverage');
    if(coverage){
      coverage.innerHTML='';
      const groups=APP_STATE.material.labSnapshot?.groups||{};
      const keys=getLabQualityKeys();
      if(keys.length){
        const t=document.createElement('table');t.className='kb-table';
        t.innerHTML='<thead><tr><th>Code</th><th>Indication</th><th>Samples</th><th>Mean CaO</th><th>Mean MgO</th><th>Mean SiO₂</th><th>Density</th><th>Total Tonase</th></tr></thead>';
        const tb=document.createElement('tbody');
        keys.forEach(k=>{
          const g=groups[k],m=qualityMeta(k),tr=document.createElement('tr');
          [m.label,m.description,g.sampleCount,fmt(g.stats?.CaO?.mean,2),fmt(g.stats?.MgO?.mean,2),fmt(g.stats?.SiO2?.mean,2),fmt(g.stats?.Density?.mean,3),fmt(g.totalTonase,0)].forEach(v=>{
            const td=document.createElement('td');td.textContent=String(v??'--');tr.appendChild(td);
          });
          tb.appendChild(tr);
        });
        t.appendChild(tb);coverage.appendChild(t);
      }
    }

    const makeGrid=(el,obj,editable)=>{
      el.innerHTML='';
      if(!obj){el.innerHTML='<div class="kb-muted">NO LAB SNAPSHOT AVAILABLE</div>';return;}
      statCells.forEach(k=>{
        const wrap=document.createElement('div');wrap.className='kb-lab-stat';
        const label=document.createElement('div');label.className='name';label.textContent=k==='sampleCount'?'Samples':(LABELS[k]||k);
        if(editable){
          const value=document.createElement('input');value.id='lab_'+k;value.type='number';value.value=Number(obj.values?.[k]??obj.sampleCount??0);
          value.step=k==='sampleCount'?'1':'0.001';value.min='0';value.addEventListener('change',updateWorkingFromInputs);wrap.append(label,value);
        }else{
          const st=obj.stats?.[k];const value=document.createElement('div');value.className='val';
          value.textContent=k==='sampleCount'?fmt(obj.sampleCount,0):fmt(st?.mean??obj.values?.[k],k==='Density'?3:2);wrap.append(label,value);
          if(st&&k!=='sampleCount'){
            const meta=document.createElement('div');meta.className='kb-muted';meta.style.marginTop='4px';
            meta.textContent=`min ${fmt(st.min,k==='Density'?3:2)} • max ${fmt(st.max,k==='Density'?3:2)} • median ${fmt(st.median,k==='Density'?3:2)} • SD ${fmt(st.sd??st.std,k==='Density'?3:2)}`;
            wrap.append(meta);
          }
        }
        el.appendChild(wrap);
      });
    };

    makeGrid($('labSnapshotGrid'),snap,false);
    makeGrid($('labWorkingGrid'),work,true);
    $('labWorkingStatus').textContent=work?`STATUS: ${work.status||'BASELINE'} • ACTIVE ${activeKey} • baseline ${snap?.source||'not available'}`:'STATUS: NO BASELINE';
    $('labHistoryStatus').textContent=`LAB HISTORY: ${(APP_STATE.labHistory||[]).length} update`;
    $('sourceBadge').textContent=snap?`LAB BASELINE • ACTIVE ${activeKey}`:'LAB BASELINE: WAITING';
    $('sourceBadge').className='kb-badge '+(snap?'ok':'warn');
    if($('labImportStatus')&&APP_STATE.material.labSnapshot&&!APP_STATE.material.importMeta){
      $('labImportStatus').textContent='';
    }
  }

  function canonicalizeRow(row){
    const out={};
    const keys=Object.keys(row||{});
    for(const canonical of Object.keys(LABELS)){
      const aliases=(ALIASES[canonical]||[]).map(normalizeHeader);
      const rk=keys.find(k=>aliases.includes(normalizeHeader(k)));
      if(rk!=null) out[canonical]=canonical==='Kualitas'?String(row[rk]??'').trim():parseLabNumber(row[rk]);
    }
    return out;
  }

  function getLabSheetCandidate(wb){
    const sheets=wb.SheetNames||[];
    if(sheets.includes('Analisa Sample')) return 'Analisa Sample';
    for(const s of sheets){
      try{
        const rows=XLSX.utils.sheet_to_json(wb.Sheets[s],{defval:'',range:0});
        const h=Object.keys(rows[0]||{}).map(normalizeHeader);
        if(h.some(x=>['kualitas','quality','class','kelas'].includes(x)||x.includes('kualitas'))) return s;
      }catch(e){}
    }
    return sheets[0]||null;
  }

  function afterLabImport(snapshot,fileName,type,details){
    if(APP_STATE.material.labSnapshot){
      APP_STATE.labHistory.unshift({
        importedAt:now(),
        source:APP_STATE.material.labSnapshot.fileName||APP_STATE.material.labSnapshot.source||'previous baseline',
        coverage:labCoverageText(APP_STATE.material.labSnapshot)
      });
    }
    APP_STATE.material.labSnapshot={...snapshot,fileName:fileName||snapshot.source};
    APP_STATE.material.importMeta={type,...(details||{})};
    const preferred=APP_STATE.material.qualityKey&&snapshot.groups?.[APP_STATE.material.qualityKey]
      ? APP_STATE.material.qualityKey
      : snapshot.defaultQuality;
    APP_STATE.material.qualityKey=(APP_STATE.material.qualityKey&&snapshot.groups?.[APP_STATE.material.qualityKey])?APP_STATE.material.qualityKey:(preferred||null); /* lab VIEW key only; engineering material = comparison basis HG/MG/DOL */
    applyLabSnapshotToWorking(APP_STATE.material.qualityKey);
    audit('LAB SNAPSHOT','NONE',`${fileName||snapshot.source} • ${type}`,'LAB IMPORT',`${type} IMPORT`);
    if($('labImportStatus')) $('labImportStatus').textContent=`Imported ${fileName||snapshot.source} • sheet: ${snapshot.sheetName||'Analisa Sample'} • ${labCoverageText(snapshot)} • invalid numeric cells: ${snapshot.invalid.length}`;
    renderLab();
    persistWorking();
    validateAll();
    refreshAll();
  }

  async function importLabXlsx(file){
    if(typeof XLSX==='undefined') throw new Error('SheetJS tidak tersedia.');
    { const big=kbFileTooBig(file,'sheet'); if(big) throw new Error(big); }
    const buf=await file.arrayBuffer();
    const wb=XLSX.read(buf,{type:'array',cellDates:false,cellFormula:false,cellHTML:false,cellStyles:false,bookVBA:false});
    if((wb.SheetNames||[]).length>50) throw new Error('Jumlah worksheet tidak wajar (>50).');
    const candidate=getLabSheetCandidate(wb);
    if(!candidate) throw new Error('Tidak ditemukan worksheet yang dapat dibaca.');
    const rows=XLSX.utils.sheet_to_json(wb.Sheets[candidate],{defval:''});
    const snapshot=buildLabSnapshot(rows,file.name,candidate);
    afterLabImport(snapshot,file.name,'XLSX',{sheets:wb.SheetNames});
  }

  function importLabCsv(file){
    if(typeof Papa==='undefined') throw new Error('PapaParse tidak tersedia.');
    { const big=kbFileTooBig(file,'csv'); if(big){ if($('labImportStatus')) $('labImportStatus').textContent='IMPORT FAILED: '+big; return; } }
    Papa.parse(file,{
      header:true,skipEmptyLines:true,
      complete:res=>{
        try{
          const snapshot=buildLabSnapshot(res.data,file.name,'CSV');
          afterLabImport(snapshot,file.name,'CSV',{errors:res.errors||[]});
        }catch(e){
          if($('labImportStatus')) $('labImportStatus').textContent='IMPORT FAILED: '+e.message;
        }
      },
      error:e=>{ if($('labImportStatus')) $('labImportStatus').textContent='IMPORT FAILED: '+e.message; }
    });
  }

  // ==========================================================
  // TECHNICAL GEOMETRY ENGINES
  // ==========================================================
  // AUDIT v8 (2026-10): persamaan diverifikasi terhadap referensi publikasi:
  //  - Konya & Walter (1990) / USACE EM 1110-2-3800 (2018) Eq 5-2, 5-3, 5-4, 5-5 & Table 5-8
  //    [BUG FIX: engine lama MERATA-RATA 3 persamaan burden Konya — tidak ada di referensi manapun.
  //     Sekarang memakai Eq 5-4: B = (2·SGe/SGr + 1.5)·D·Kd·Ks. Varian 1972 & Eq 5-3 tetap ditampilkan sebagai info.]
  //  - MAE = Modified Available Energy, Mulenga & Kaunda (2020) JME 11(3):643-659, Eq (17)-(29); BI per Lilly (1986).
  //  - Ash (1963): B = Kb·D/12, KB 20-40; koreksi VOD mengikuti konsep Ash (1968).
  /* =====================================================================
     PHASE A — PROVENANCE • FORMULA REGISTRY • DEMO GATING • TRUE STALE
     ===================================================================== */
  const PHASE_A_VERSION='A.1';
  const SOURCE_TYPES=Object.freeze(['PROJECT_INPUT','LAB_DATA','REFERENCE','USER_EDIT','DEMO_EXAMPLE','CALCULATED','ASSUMPTION']);
  const ENGINEERING_MATERIALS=Object.freeze(['HG','MG','DOL']);
  const FORMULA_REGISTRY=Object.freeze({
    ash:Object.freeze({formulaId:'GEO-ASH',method:'ash',version:'ash-impl-2',status:'PARTIAL',
      implementationSource:'calculateAshGeometry() + ashKbEmpirical() + ashKbFullCorrection()',
      displayedFormula:'Kb = table[SGe class x SGr class]  (SGe<=0.95 low | <1.30 medium | else high; SGr<2.0 soft | <=2.5 medium | else hard)\n  low 30/25/20 | medium 35/30/25 | high 40/35/30  (soft/medium/hard)\n  if VOD entered: Kb = 30·Af1·Af2 ; Af1 = (2562.95 / (1000·SGr))^(1/3) ; Af2 = (SGe·VOD² / (1.20·3657.6²))^(1/3)\nB = Kb·D(in) / 39.37007874  [m]\nS = Ks·B   (Ks = user input, required; Ash KS = 1.0–2.0)\nT = 0.70·B\nJ = 0.30·B',
      constants:Object.freeze({kbTable:Object.freeze({low:Object.freeze({soft:30,medium:25,hard:20}),medium:Object.freeze({soft:35,medium:30,hard:25}),high:Object.freeze({soft:40,medium:35,hard:30})}),TB:0.70,JB:0.30,inchPerM:39.37007874015748}),
      assumptions:'Kb class table is coarse: all SGr<2.0 fall in one class; Kb table values are within the documented Ash KB range 20–40. VOD correction follows the Ash (1968) density×VOD² adjustment concept; exact standard-state constants (1.20 g/cc, 3657.6 m/s, 2562.95 kg/m³) are implementation values.',
      notes:'',
      reference:'Ash, R.L. (1963) burden ratio KB 20–40, KT 0.5–1.0, KJ 0.3, KS 1.0–2.0 (Pit & Quarry, "Blasting Mechanics Revisited", 2019); Ash (1968) VOD-based Kb adjustment (Darlington Mensah 2012, §3.2.3); B = Kb·D/12 ft (ibid. §3.2.2; Mulenga & Kaunda 2020, Eq 1–2).'}),
    konya:Object.freeze({formulaId:'GEO-KONYA',method:'konya',version:'konya-impl-2',status:'VERIFIED',
      implementationSource:'calculateKonyaGeometry()',
      displayedFormula:'Bc = (2·SGe/SGr + 1.5)·D   [D in inch, Bc in ft]   (Konya & Walter 1990; USACE EM 1110-2-3800 Eq 5-2)\nB = Bc·Kd·Ks·Kr·0.3048  [m]   (Kd deposition & Ks geology corrections: EM 1110-2-3800 Eq 5-4; Kr = project row-correction extension, default 1.00, NOT from EM 1110-2-3800)\nL = bench height ; L/B < 4 : S = (L+7B)/8 (delayed) | (L+2B)/3 (instantaneous)\nL/B >= 4 : S = 1.4B (delayed) | 2B (instantaneous)   (EM 1110-2-3800 Table 5-8)\nT = 0.70·B (Eq 5-5)\nJ = 0.30·B (Konya & Walter 1990)\nInfo variants (NOT used for design B): Konya 1972: 3.15·D·(SGe/SGr)^(1/3) ; energy form EM 1110 Eq 5-3: 0.67·D·(Stv/SGr)^(1/3)',
      constants:Object.freeze({c1:3.15,c2a:2,c2b:1.5,c3:0.67,ftToM:0.3048,TB:0.70,JB:0.30,slender:4}),
      assumptions:'Kd, Kgeo(=Ks) and firing mode are required user inputs (no silent defaults). Kr is optional (default 1.00) and is a project extension not present in EM 1110-2-3800. Stv is optional and only feeds the informational Eq 5-3 variant.',
      notes:'AUDIT v8: previous engine averaged B1/B2/B3 (three different published equations) — no reference supports averaging; replaced by the documented Eq 5-2/5-4 form.',
      reference:'USACE EM 1110-2-3800 (2018) "Engineering and Design: Blasting for Rock Excavations", Eq 5-2, 5-4, 5-5, Table 5-8; Konya & Walter (1990) via Mulenga & Kaunda (2020) §2.2; FHWA "Rock Blasting and Control Overbreak" Eq 6.2/6.4.'}),
    mae:Object.freeze({formulaId:'GEO-MAE',method:'mae',version:'mae-impl-2',status:'VERIFIED',
      implementationSource:'maeCalc() + calculateMaeGeometry()',
      displayedFormula:'BI = 0.5(RMD+JPS+JPO+RDI+Hk)        [17]\nRMD=10+10·x_i  RDI=25·ρRM−50  Hk=(UCS+23.7)/47.6  [18,20,21]\nPF_BI = 0.004·BI·ρRM  (kg/m³)         [22]\nAE = LD / PF_BI  (m²) ; LD = SGe·1000·π(D/2)²  (kg/m)   [6,23]\nStl = √AE·St_f   Sb = Stl·Sb_f        [24,25]\nSA = AE·(1−(Stl−Sb)/H_bench)          [26]\nN = ⌈CW/√SA⌉  S = CW/N  B = SA/S      [27-29]\nT = Stl ; J = Sb\n(H_bench = bench height, not Hk)',
      constants:Object.freeze({stfAssumed:0.7,sbfAssumed:0.3}),
      assumptions:'LD = π·ρ·D²/4000 verified identical to paper Eq (6). UCS in MPa (paper case study: UCS=100 MPa → H≈3 ✓). DEVIATION: N is rounded UP to an integer number of rows (paper uses fractional NR = CW/√SA directly); this slightly perturbs S and B. St_f=0.7 and Sb_f=0.3 defaults tagged ASSUMPTION (paper case study used St_f=0.7, Sb_f=0.375 for MAE). Model is calibrated for deep benches (paper: 12 m); on shallow benches Eq (26) collapses (Stl ≥ H) — such results are flagged INVALID, not shown as valid numbers.',
      notes:'',
      reference:'Mulenga, S. & Kaunda, R.B. (2020) "Blast Design for Improved Productivity using a Modified Available Energy Method", Journal of Mining and Environment 11(3):643–659 — MAE Eq (17)–(29), LD Eq (6); BI per Lilly (1986).'})
  });
  const FORMULA_STATUS_VALUES=Object.freeze(['IMPLEMENTED','VERIFIED','PARTIAL','ASSUMPTION']);
  function formulaUiText(k){ const f=FORMULA_REGISTRY[k]; return f.displayedFormula+'\n['+f.formulaId+' • '+f.version+' • '+f.status+']'+(f.reference?'\nREFERENCE: '+f.reference:'\nREFERENCE: not attached — BELUM TERVERIFIKASI')+(f.notes?'\nNOTE: '+f.notes:'')+(f.assumptions?'\nASSUMPTIONS/DEVIATIONS: '+f.assumptions:''); }

  /* ---- provenance store: APP_STATE.prov[path] = {value,unit,sourceType,sourceName,sourceField,timestamp,editable,confidence,notes} */
  if(!APP_STATE.prov) APP_STATE.prov={};
  if(!APP_STATE.demo) APP_STATE.demo={loaded:false,timestamp:null};
  const ORIGINAL_ENGINEER_ACTUAL=(function deepFreeze(o){ Object.getOwnPropertyNames(o).forEach(k=>{ if(o[k]&&typeof o[k]==='object') deepFreeze(o[k]); }); return Object.freeze(o); })(JSON.parse(JSON.stringify(BLAST_SHEET_ROWS)));
  function provSet(path,value,unit,sourceType,sourceName,sourceField,o={}){
    if(!SOURCE_TYPES.includes(sourceType)) throw new Error('invalid sourceType '+sourceType);
    APP_STATE.prov[path]={value,unit:unit||'',sourceType,sourceName:sourceName||'',sourceField:sourceField||'',timestamp:new Date().toISOString(),editable:o.editable!==false,confidence:o.confidence||(sourceType==='DEMO_EXAMPLE'?'NONE':'UNVERIFIED'),notes:o.notes||''};
    return APP_STATE.prov[path];
  }
  function inputRoot(path){ const ns=path.split('.')[0],G=APP_STATE.geometry; return ns==='ci'?(G.comparisonInputs||(G.comparisonInputs={})):ns==='gi'?G.input:ns==='mae'?(APP_STATE.formula.mae||(APP_STATE.formula.mae={})):ns==='cost'?(G.cost||(G.cost={drilling:null,explosive:null,accessory:null})):ns==='fin'?APP_STATE.financial:ns==='seis'?APP_STATE.seismic:null; }
  function inputKey(path){ return path.slice(path.indexOf('.')+1); }
  function setInput(path,value,unit,sourceType,sourceName,sourceField,o){
    const root=inputRoot(path),k=inputKey(path);
    const empty=value===null||value===undefined||value===''||(typeof value==='number'&&!Number.isFinite(value));
    if(empty){ root[k]=null; delete APP_STATE.prov[path]; return null; }
    root[k]=value; return provSet(path,value,unit,sourceType,sourceName,sourceField,o);
  }
  function copyInput(from,to){ const f=inputRoot(from)[inputKey(from)],p=APP_STATE.prov[from]; const root=inputRoot(to),k=inputKey(to); if(f==null||!p){root[k]=null;delete APP_STATE.prov[to];return;} root[k]=f; APP_STATE.prov[to]={...p,value:f,timestamp:new Date().toISOString()}; }
  /* readInput: a value is usable ONLY if it has provenance and (when DEMO) the user explicitly loaded the demo. */
  function readInput(path,o={}){
    const v=inputRoot(path)[inputKey(path)],p=APP_STATE.prov[path];
    if(v===null||v===undefined||v==='') return {ok:false,path,reason:'EMPTY'};
    if(!p||p.value!==v) return {ok:false,path,reason:'NO PROVENANCE'};
    if(p.sourceType==='DEMO_EXAMPLE'&&!APP_STATE.demo.loaded) return {ok:false,path,reason:'DEMO VALUE WITHOUT LOAD DEMO EXAMPLE'};
    if(typeof v==='number'){ if(!Number.isFinite(v)||(o.allowZero?v<0:v<=0)) return {ok:false,path,reason:'INVALID VALUE'}; }
    return {ok:true,path,value:v,prov:p};
  }
  const COMMON_REQ=[['ci.diameterIn','in',{}],['ci.benchHeight','m',{}],['ci.explosiveDensity','SG',{}],['ci.holeCount','holes',{}],['ci.rockDensity','SG',{}]];
  const METHOD_REQ={
    ash:[['ci.ashKs','S/B',{}]],
    konya:[['ci.kd','-',{}],['ci.kgeo','-',{}],['ci.firing','-',{}]],
    mae:[['mae.xi','-',{allowZero:true}],['mae.jps','-',{}],['mae.jpo','-',{}],['mae.ucs','MPa',{allowZero:true}],['mae.cw','m',{}],['mae.stf','-',{}],['mae.sbf','-',{allowZero:true}]]
  };
  /* Optional inputs: only consumed when explicitly present (with provenance); absent → neutral default documented in registry. */
  const METHOD_OPT={
    ash:[['ci.ashVod','m/s',{}]],
    konya:[['ci.kr','-',{}],['ci.stv','Stv',{}]],
    mae:[]
  };
  function collectEngineInputs(method){
    const missing=[],values={},lineage=[]; let demo=false;
    const take=(path,unit,o)=>{ const r=readInput(path,o); if(!r.ok){missing.push({path,reason:r.reason});return;} values[inputKey(path)]=r.value; lineage.push({path,value:r.value,unit:r.prov.unit||unit,sourceType:r.prov.sourceType,sourceName:r.prov.sourceName,sourceField:r.prov.sourceField,timestamp:r.prov.timestamp}); if(r.prov.sourceType==='DEMO_EXAMPLE') demo=true; };
    const takeOpt=(path,unit,o)=>{ if(inputRoot(path)[inputKey(path)]==null) return; const r=readInput(path,o); if(!r.ok) return; values[inputKey(path)]=r.value; lineage.push({path,value:r.value,unit:r.prov.unit||unit,sourceType:r.prov.sourceType,sourceName:r.prov.sourceName,sourceField:r.prov.sourceField,timestamp:r.prov.timestamp}); if(r.prov.sourceType==='DEMO_EXAMPLE') demo=true; };
    COMMON_REQ.forEach(([p,u,o])=>take(p,u,o));
    (METHOD_REQ[method]||[]).forEach(([p,u,o])=>take(p,u,o));
    (METHOD_OPT[method]||[]).forEach(([p,u,o])=>takeOpt(p,u,o));
    return {ok:missing.length===0,missing,values,lineage,demo};
  }
  function hash32(s){ let x=5381; for(let i=0;i<s.length;i++) x=((x<<5)+x+s.charCodeAt(i))|0; return (x>>>0).toString(16).padStart(8,'0'); }
  function phaseAHashFor(method){
    const c=collectEngineInputs(method),a=getActiveBlastRowForComparison();
    return hash32(JSON.stringify({m:method,v:FORMULA_REGISTRY[method].version,vals:c.values,miss:c.missing.map(x=>x.path+':'+x.reason),src:c.lineage.map(x=>x.sourceType),g:a?a.groupKey:null,r:a?a.row.no:null,basis:APP_STATE.geometry.comparisonInputs.densityBasis||null}));
  }
  function methodFreshness(k){ const r=(APP_STATE.geometry.results||{})[k]; if(!r) return 'NOT CALCULATED'; return r.inputsHash===phaseAHashFor(k)?'FRESH':'STALE'; }
  function decorateResult(method,res,inp){
    const f=FORMULA_REGISTRY[method];
    return Object.assign(res,{formulaId:f.formulaId,formulaVersion:f.version,formulaStatus:f.status,lineage:inp.lineage,demoContaminated:inp.demo,sourceTypes:[...new Set(inp.lineage.map(x=>x.sourceType))],inputsHash:phaseAHashFor(method),calculatedAt:new Date().toISOString(),calculationVersion:(APP_STATE.geometry.calcCounter=(APP_STATE.geometry.calcCounter||0)+1),resultType:'CALCULATED',blastRef:(function(){const a=getActiveBlastRowForComparison();return a?{groupKey:a.groupKey,groupLabel:a.groupLabel,rowNo:a.row.no}:null;})()});
  }
  function commonFrom(v){ const Dm=v.diameterIn*0.0254; return {i:{diameterIn:v.diameterIn},Dm,benchH:v.benchHeight,eSG:v.explosiveDensity,rockSG:v.rockDensity,holeCount:Math.max(1,Math.round(v.holeCount))}; }
  function calcAshFrom(v){
    const c=commonFrom(v),K=FORMULA_REGISTRY.ash.constants;
    const vodN=Number(v.ashVod),vodBad=vodN>0&&(vodN<1000||vodN>9000);
    const full=vodBad?null:ashKbFullCorrection(c.eSG,c.rockSG,vodN),empirical=ashKbEmpirical(c.eSG,c.rockSG),kb=full?.kb||empirical.kb;
    const B=kb*v.diameterIn/K.inchPerM;
    const result=finishGeometryMethod('ash',c,{B,S:v.ashKs*B,T:K.TB*B,J:K.JB*B});
    if(result){result.Kb=kb;result.KbMode=full?'FULL ASH ADJUSTMENT':'EMPIRICAL ASH Kb';result.AshClass=empirical;if(full)Object.assign(result,{Af1:full.af1,Af2:full.af2});
      const bad=[]; if(vodBad) bad.push(`VOD ${vodN} m/s di luar rentang 1000–9000 m/s — kemungkinan salah satuan (km/s atau ft/s). Koreksi VOD ditolak; hasil ini tidak boleh dipakai.`);
      if(!(kb>=15&&kb<=50)) bad.push(`Kb = ${kb.toFixed(1)} di luar rentang wajar Ash 15–50 (B/D = Kb) — burden tidak realistis.`);
      if(bad.length){ result.validity='INVALID'; result.warnings=bad.concat(result.warnings||[]); } }
    return result;
  }
  function calcKonyaFrom(v){
    const c=commonFrom(v),K=FORMULA_REGISTRY.konya.constants,D=v.diameterIn;
    const ratio=c.eSG/c.rockSG;
    /* DESIGN BURDEN — documented form: Konya & Walter (1990) / USACE EM 1110-2-3800 Eq 5-2 + Eq 5-4 corrections.
       Kr is an optional project extension (default 1.00), NOT part of the reference. */
    const Bc=(K.c2a*ratio+K.c2b)*D; // ft
    const kr=Number.isFinite(Number(v.kr))&&Number(v.kr)>0?Number(v.kr):1;
    const B=Bc*v.kd*v.kgeo*kr*K.ftToM,L=c.benchH,LbyB=B>0?L/B:0;
    /* informational variants only (never averaged, never used for design): Konya (1972) and EM 1110 Eq 5-3 */
    const B1972=K.c1*D*Math.cbrt(ratio)*K.ftToM;
    const BEnergy=Number.isFinite(Number(v.stv))&&Number(v.stv)>0?K.c3*D*Math.cbrt(Number(v.stv)/c.rockSG)*K.ftToM:null;
    let S; if(v.firing==='instantaneous') S=(LbyB<K.slender)?((L+2*B)/3):(2*B); else S=(LbyB<K.slender)?((L+7*B)/8):(1.4*B);
    const result=finishGeometryMethod('konya',c,{B,S,T:K.TB*B,J:K.JB*B});
    if(result) Object.assign(result,{Bc:Bc*K.ftToM,Bvariant1972:B1972,BvariantEnergy:BEnergy,Kd:v.kd,Kr:kr,krDefault:!(Number.isFinite(Number(v.kr))&&Number(v.kr)>0),KrNote:v.kr==null?'default 1.00 (not set)':'user input',Kgeo:v.kgeo,Stv:v.stv??null,firing:v.firing,LbyB});
    return result;
  }
  function calcMaeFrom(v){
    const c=commonFrom(v); MAE_ERR='';
    const r=maeCalc(c.Dm,c.benchH,c.eSG,c.rockSG,{xi:v.xi,jps:v.jps,jpo:v.jpo,ucs:v.ucs,cw:v.cw,stf:v.stf,sbf:v.sbf});
    return r?finishGeometryMethod('mae',c,r):null;
  }
  /* returns {result,status,missing} — reads ONLY APP_STATE (never DOM) */
  function computeMethod(method){
    const inp=collectEngineInputs(method);
    if(!inp.ok) return {result:null,status:'WAITING FOR PROJECT INPUT',missing:inp.missing};
    const raw=method==='ash'?calcAshFrom(inp.values):method==='konya'?calcKonyaFrom(inp.values):calcMaeFrom(inp.values);
    if(!raw) return {result:null,status:method==='mae'&&MAE_ERR?MAE_ERR:'INVALID INPUT (geometry check failed)',missing:[]};
    return {result:decorateResult(method,raw,inp),status:'CALCULATED',missing:[]};
  }
  function calculateAshGeometry(){ return computeMethod('ash').result; }
  function calculateKonyaGeometry(){ return computeMethod('konya').result; }
  function calculateMaeGeometry(){ return computeMethod('mae').result; }
  function calculateGeometryByMethod(method){ return FORMULA_REGISTRY[method]?computeMethod(method).result:null; }
  function calculateAllGeometryMethods(){ return {ash:computeMethod('ash').result,konya:computeMethod('konya').result,mae:computeMethod('mae').result}; }
  /* downstream consumers only ever see a FRESH calculated result */
  function calculateGeometry(){ const k=APP_STATE.formula.key||'ash',r=(APP_STATE.geometry.results||{})[k]; return r&&methodFreshness(k)==='FRESH'?r:null; }
  function engineeringMaterial(){ const d=geometryLabBaseDensity(); return d>0?{Density:d,source:'ENGINEERING MATERIAL BASIS '+(APP_STATE.geometry.comparisonInputs.densityBasis||'').toUpperCase()}:{}; }
  /* TRUE-STALE invariant: APP_STATE.geometry.result can only ever return a FRESH calculated result, regardless of which handler ran. */
  (function(){ let stored=null; Object.defineProperty(APP_STATE.geometry,'result',{enumerable:true,configurable:true,get(){ const k=APP_STATE.formula.key||'ash',r=(this.results||{})[k]; return (stored&&r&&stored===r&&methodFreshness(k)==='FRESH')?stored:null; },set(v){ stored=v; }}); })();
  function loadBlastSheetRow(g,n){ const x=loadBlastSheetRow__legacy(g,n); geometryComparisonInputSync(true); if($('geometryComparePanel')) renderGeometryComparison(); try{ kzRender(); }catch(_e){} try{ markScreeningStale(`baris blast aktif berubah ke ${g} / row ${n}`); }catch(_e){} return x; }
  function geometryLabBaseDensity(){ const d=Number(APP_STATE.geometry.comparisonInputs?.rockDensity); return d>0?d:null; }
  function geometryComparisonDensitySource(basis){
    const p=APP_STATE.prov['ci.rockDensity'],d=geometryLabBaseDensity();
    if(!basis||!p||d==null) return 'WAITING FOR PROJECT MATERIAL';
    return `${p.sourceType} • ${p.sourceName} • ${p.sourceField} = ${d.toFixed(3)} SG`;
  }
  function activeBlastDiameter(groupKey){ return groupKey==='group3'?4.5:null; }

  /* ---- DEMO: explicit user action only */
  const DEMO_VALUES={gi:{diameterIn:3.5,benchHeight:12,explosiveDensity:0.85,holeCount:16,targetX80:80},ci:{ashKs:1.30,stv:100,kd:1,kr:1,kgeo:1,firing:'delayed'},mae:{xi:1,jps:20,jpo:30,ucs:60,cw:24},fin:{anfoIdrKg:10000,secondaryIdrUnit:150000,secondaryBaselineUnits:100,secondaryReductionPct:15,limestonePriceIdrTon:100000},seis:{K:335.0,n:1.307,D:300,W:120},basis:'hg'};
  function phaseAResetInputs(){
    const G=APP_STATE.geometry;
    G.input={diameterIn:null,benchHeight:null,explosiveDensity:null,holeCount:null,targetX80:null,airDeckPct:0}; G.inputSource='WAITING FOR PROJECT INPUT';
    G.comparisonInputs={diameterIn:null,benchHeight:null,explosiveDensity:null,rockDensity:null,holeCount:null,loaded:false,source:'NOT LOADED',rockSource:'WAITING FOR PROJECT MATERIAL',densityBasis:null,stv:null,firing:null,ashVod:null,ashKs:null,kd:null,kr:null,kgeo:null};
    G.cost={drilling:null,explosive:null,accessory:null}; delete G.costMeta; G.result=null; G.results={ash:null,konya:null,mae:null}; G.comparison={status:'WAITING FOR PROJECT INPUT',inputsHash:null,lastCalculated:null};
    APP_STATE.formula.mae={xi:null,jps:null,jpo:null,ucs:null,cw:null,stf:0.7,sbf:0.3};
    const F=APP_STATE.financial; Object.assign(F,{anfoIdrKg:null,secondaryIdrUnit:null,secondaryReductionPct:null,secondaryBaselineUnits:null,limestonePriceIdrTon:null,priceSource:'',quotationDate:'',vendorRef:'',limestonePriceSource:'',result:null});
    Object.assign(APP_STATE.seismic,{K:null,n:null,D:null,W:null,ppv:null,fit:{status:'NO SITE FIT',residual:null,r2:null},kSource:'NONE',dwSource:'NONE'});
    APP_STATE.prov={}; APP_STATE.demo={loaded:false,timestamp:null};
    maeState();
  }
  function loadDemoExample(){
    const D=DEMO_VALUES,DM=(path,val,unit,k)=>setInput(path,val,unit,'DEMO_EXAMPLE','DEMO EXAMPLE','LOAD DEMO EXAMPLE • '+k,{notes:'DEMO EXAMPLE — not project data'});
    const un={diameterIn:'in',benchHeight:'m',explosiveDensity:'SG',holeCount:'holes',targetX80:'cm'};
    Object.keys(D.gi).forEach(k=>DM('gi.'+k,D.gi[k],un[k],k));
    APP_STATE.demo={loaded:true,timestamp:new Date().toISOString()}; APP_STATE.geometry.inputSource='DEMO EXAMPLE';
    geometryComparisonInputSync(true);
    Object.keys(D.ci).forEach(k=>DM('ci.'+k,D.ci[k],'-',k));
    Object.keys(D.mae).forEach(k=>DM('mae.'+k,D.mae[k],k==='ucs'?'MPa':'-',k));
    const sd=FORMULA_REGISTRY.mae.constants; setInput('mae.stf',sd.stfAssumed,'-','ASSUMPTION','MAE implementation default','St_f',{notes:'carried from legacy code'}); setInput('mae.sbf',sd.sbfAssumed,'-','ASSUMPTION','MAE implementation default','Sb_f',{notes:'carried from legacy code'});
    Object.keys(D.fin).forEach(k=>DM('fin.'+k,D.fin[k],k.includes('Pct')?'%':'IDR',k));
    Object.assign(APP_STATE.financial,{priceSource:'DEMO EXAMPLE • bukan quotation',vendorRef:'DEMO / NOT A QUOTATION'});
    Object.keys(D.seis).forEach(k=>{APP_STATE.seismic[k]=D.seis[k];}); APP_STATE.seismic.kSource='DEMO'; APP_STATE.seismic.dwSource='DEMO'; APP_STATE.seismic.fit={status:'DEMO EXAMPLE (not a site fit)',residual:null,r2:null};
    applyDensityBasis(D.basis,true);
    audit('DEMO EXAMPLE','WAITING',new Date().toISOString(),'USER ACTION','LOAD DEMO EXAMPLE');
    hydrateUI(); geometryComparisonInputSync(); maeShowInputs(APP_STATE.formula.key==='mae'); updateSeismic(); persistWorking(); refreshAll();
  }
  function applyDensityBasis(basis,asDemo){
    const ci=APP_STATE.geometry.comparisonInputs,ref=geometryComparisonDensityReference(); ci.densityBasis=basis||null;
    const names={hg:'HG',mg:'MG',dol:'DOL',avg:'AVERAGE (benchmark only)'};
    if(!basis){ setInput('ci.rockDensity',null); }
    else if(basis==='custom'){ /* value comes from the field listener as USER_EDIT */ if(!APP_STATE.prov['ci.rockDensity']||APP_STATE.prov['ci.rockDensity'].sourceType!=='USER_EDIT') setInput('ci.rockDensity',null); }
    else if(ref[basis]!=null){ setInput('ci.rockDensity',ref[basis],'SG',asDemo?'DEMO_EXAMPLE':(basis==='avg'?'REFERENCE':'LAB_DATA'),asDemo?'DEMO EXAMPLE':'LAB BASE (embedded)','material '+names[basis]); }
  }

  /* ---- Engineer Actual: prefer catatan aktual terpisah; nilai rencana hanya fallback referensi yang diberi label. */
  function actualEngineerGeometry(){
    const a=getActiveBlastRowForComparison(); if(!a) return null;
    const r=a.row,orig=(ORIGINAL_ENGINEER_ACTUAL[a.groupKey]?.rows||[]).find(x=>x.no===r.no)||null,isManualSource=!!BLAST_SHEET_ROWS[a.groupKey]?.isManual;
    const rowOverride=(APP_STATE.simulation.rowOverrides||{})[blastRowOverrideKey(a.groupKey,r.no)]||{};
    const overridden=isManualSource||!!Object.keys(rowOverride).length;
    const rec=pdRec(a),rho=geometryLabBaseDensity();
    const planNum=k=>r[k]==null||r[k]===''?null:Number(r[k]);
    const num=k=>rec[k]!=null&&rec[k]!==''?pdNumber(rec[k]):planNum(k);
    const hasRec=k=>rec[k]!=null&&rec[k]!=='';
    const isPlanCopy=k=>/SALIN DARI RENCANA/i.test(String(rec._sources?.[k]||''));
    const fieldMeta=(k,fallback='nilai rencana digunakan sebagai referensi')=>hasRec(k)?(isPlanCopy(k)?`PLAN REFERENCE ONLY • ${rec._sources?.[k]||'salinan rencana'}`:`ACTUAL RECORD • ${rec._sources?.[k]||'INPUT MANUAL'}`):'SOURCE';
    const holesIn=num('holes'),holes=holesIn!=null&&holesIn>0?holesIn:(isManualSource?null:1),divisor=holes||1;
    const depth=num('depth'),subDepth=num('subDepth'),sheetTonnage=num('volume'),chargeMass=num('an'),totalCharge=num('totalAn'),pf=num('pf');
    const dm=pdNumber(rec.depthMeasured)>0?pdNumber(rec.depthMeasured):null,hm=pdNumber(rec.holeMeter)>0?pdNumber(rec.holeMeter):null,recVol=pdNumber(rec.volumeM3)>0?pdNumber(rec.volumeM3):null;
    const totalVolume=recVol??(sheetTonnage!=null&&rho>0?sheetTonnage/rho:null),holeDepth=dm??subDepth;
    const calculatedSubDrill=rec.subDrill!=null?Number(rec.subDrill):(subDepth!=null&&depth!=null?Math.max(0,subDepth-depth):null);
    const totalDrilling=hm??(holeDepth!=null&&holes!=null?holeDepth*holes:null);
    const recordFields=Object.keys(rec).filter(k=>k!=='_sources'&&!PD_IDENT_FIELDS.has(k)&&rec[k]!=null&&rec[k]!=='');
    const planCopyCount=recordFields.filter(k=>isPlanCopy(k)).length;
    const actualFieldCount=recordFields.length-planCopyCount;
    const importedSources=[...new Set(Object.values(rec._sources||{}))].slice(0,2).join(' / ');
    const sourceDetail=[actualFieldCount?`${actualFieldCount} FIELD TERCATAT`:null,planCopyCount?`${planCopyCount} SALINAN RENCANA (NON-UKUR)`:null].filter(Boolean).join(' • ');
    return {method:'actual',label:'Engineer Actual',groupLabel:a.groupLabel,groupKey:a.groupKey,rowNo:r.no,
      source:`ENGINEER ACTUAL • ${a.groupLabel} • ROW ${r.no} • ${sourceDetail||'BELUM ADA CATATAN; RENCANA HANYA REFERENSI'}${importedSources?' • '+importedSources:''}`, 
      sourceType:actualFieldCount?'USER_EDIT':'PROJECT_INPUT',userOverride:overridden||actualFieldCount>0,actualFieldCount,planCopyCount,original:orig,
      B:num('burden'),S:num('spacing'),T:num('stemming'),J:calculatedSubDrill,holeDepth,chargeLength:num('charging'),chargeMass,totalCharge,
      totalTonnage:sheetTonnage,tonnagePerHole:sheetTonnage!=null&&holes!=null?sheetTonnage/divisor:null,pfKgT:pf,pfKgTCalc:sheetTonnage>0&&totalCharge!=null?totalCharge/sheetTonnage:null,
      totalVolume,volumePerHole:totalVolume!=null&&holes!=null?totalVolume/divisor:null,pfKgM3:totalVolume>0&&totalCharge!=null?totalCharge/totalVolume:null,
      totalDrilling,holeCount:holes,unit:rec.unit||r.unit||null,
      meta:{B:fieldMeta('burden'),S:fieldMeta('spacing'),T:fieldMeta('stemming'),holeDepth:dm!=null?fieldMeta('depthMeasured',''):fieldMeta('subDepth'),chargeMass:fieldMeta('an'),totalCharge:fieldMeta('totalAn'),pfKgT:fieldMeta('pf'),holeCount:fieldMeta('holes'),pfKgTCalc:totalCharge!=null&&sheetTonnage>0?'CALCULATED (total charge ÷ tonase)':'NOT AVAILABLE (data aktual belum lengkap)',totalTonnage:hasRec('volume')?fieldMeta('volume'):'SOURCE (tonase rencana sebagai referensi — ASSUMPTION: sheet field volume ditafsirkan sebagai tonase)',J:hasRec('subDrill')?fieldMeta('subDrill'):subDepth!=null&&depth!=null?'CALCULATED (kedalaman rencana − bench)':'NOT AVAILABLE',totalDrilling:hm!=null?fieldMeta('holeMeter'):(holeDepth!=null&&holes!=null?'ESTIMATED (kedalaman × lubang; belum ada hole meter terukur)':'NOT AVAILABLE'),totalVolume:recVol!=null?fieldMeta('volumeM3'):'CALCULATED (tonase ÷ density material; bukan volume ukur langsung)',volumePerHole:'CALCULATED',pfKgM3:totalVolume>0&&totalCharge!=null?'CALCULATED (total charge ÷ volume)':'NOT AVAILABLE'}};
  }

  /* ---- comparison inputs: DOM → normalize → APP_STATE.  Calculation never reads DOM. */
  function loadCiFromProject(a){
    /* Row-derived fields are refreshed; values the user typed (USER_EDIT) are never silently discarded or overwritten. */
    const ci=APP_STATE.geometry.comparisonInputs,r=a?.row,grp=a?.groupKey,tag=a?`ENGINEER ACTUAL • ${a.groupLabel} • ROW ${r.no}`:'PROJECT GEOMETRY INPUT';
    const keepOrClear=(path,gi)=>{ if(APP_STATE.prov[gi]) copyInput(gi,path); else { const p=APP_STATE.prov[path]; if(p&&p.sourceName==='BLAST_SHEET_ROWS') setInput(path,null); } };
    if(grp==='group3') setInput('ci.diameterIn',4.5,'in','PROJECT_INPUT','BLAST_SHEET_ROWS',`${a.groupLabel} (hole diameter in group label)`); else keepOrClear('ci.diameterIn','gi.diameterIn');
    const manual=!!BLAST_SHEET_ROWS[grp]?.isManual,sourceType=manual?'USER_EDIT':'PROJECT_INPUT',sourceName=manual?'MANUAL BLAST GROUP':'BLAST_SHEET_ROWS',rec=pdRec(a);
    const isPlanCopy=k=>/SALIN DARI RENCANA/i.test(String(rec._sources?.[k]||''));
    const hasPositive=k=>rec[k]!=null&&Number(rec[k])>0;
    const benchValue=hasPositive('depth')?Number(rec.depth):Number(r?.depth),holesValue=hasPositive('holes')?Number(rec.holes):Number(r?.holes);
    const benchIsRecorded=hasPositive('depth')&&!isPlanCopy('depth'),holesAreRecorded=hasPositive('holes')&&!isPlanCopy('holes');
    const benchIsCopied=hasPositive('depth')&&isPlanCopy('depth'),holesAreCopied=hasPositive('holes')&&isPlanCopy('holes');
    if(Number.isFinite(benchValue)&&benchValue>0) setInput('ci.benchHeight',benchValue,'m',benchIsRecorded?'USER_EDIT':(benchIsCopied?'PROJECT_INPUT':sourceType),(benchIsRecorded||benchIsCopied)?(rec._sources?.depth||'RECORD'):sourceName,`${tag} • ${benchIsRecorded?'catatan aktual':benchIsCopied?'SALINAN RENCANA • REFERENSI SAJA, BUKAN PENGUKURAN':'plan-reference fallback (belum dicatat sebagai aktual)'}`); else if(manual) setInput('ci.benchHeight',null); else keepOrClear('ci.benchHeight','gi.benchHeight');
    keepOrClear('ci.explosiveDensity','gi.explosiveDensity');
    if(Number.isFinite(holesValue)&&holesValue>0) setInput('ci.holeCount',Math.round(holesValue),'holes',holesAreRecorded?'USER_EDIT':(holesAreCopied?'PROJECT_INPUT':sourceType),(holesAreRecorded||holesAreCopied)?(rec._sources?.holes||'RECORD'):sourceName,`${tag} • ${holesAreRecorded?'catatan aktual':holesAreCopied?'SALINAN RENCANA • REFERENSI SAJA, BUKAN PENGUKURAN':'plan-reference fallback (belum dicatat sebagai aktual)'}`); else if(manual) setInput('ci.holeCount',null); else keepOrClear('ci.holeCount','gi.holeCount');
    ci.loaded=true; ci.source=tag;
  }
  /* Nama group di kartu BLAST PLAN BASE bisa diketik langsung; memakai logika rename yang sama dengan kolom Group / Lokasi. */
  function setBlastBaseDisplay(label,rowNo){
    const host=$('cmpBlastBase'); if(!host) return;
    let inp=$('cmpGroupName');
    if(!inp){
      host.textContent='';
      inp=document.createElement('input'); inp.id='cmpGroupName'; inp.type='text'; inp.className='kb-inline-edit'; inp.maxLength=80; inp.placeholder='--'; inp.autocomplete='off'; inp.spellcheck=false;
      inp.title='Klik untuk ganti nama group / lokasi'; inp.setAttribute('aria-label','Nama group / lokasi');
      const rowEl=document.createElement('span'); rowEl.id='cmpBlastRow';
      host.append(inp,rowEl);
      const fit=()=>{inp.size=Math.max(4,inp.value.length+1);};
      inp.addEventListener('input',fit);
      inp.addEventListener('keydown',e=>{ if(e.key==='Enter'){e.preventDefault();inp.blur();} else if(e.key==='Escape'){const g=BLAST_SHEET_ROWS[APP_STATE.simulation.template]; inp.value=g?g.label:''; fit(); inp.blur();} });
      inp.addEventListener('change',()=>{
        const bg=$('blastGroupInput'); if(!bg) return;
        bg.value=inp.value; bg.dispatchEvent(new Event('change',{bubbles:true}));
        const g=BLAST_SHEET_ROWS[APP_STATE.simulation.template]; if(g){ inp.value=g.label; fit(); }
      });
    }
    if(document.activeElement!==inp){ inp.value=label||''; inp.size=Math.max(4,inp.value.length+1); }
    const rowEl=$('cmpBlastRow'); if(rowEl) rowEl.textContent=(label&&rowNo!=null)?` • ROW ${rowNo}`:'';
  }
  function geometryComparisonInputSync(force=false){
    const ci=APP_STATE.geometry.comparisonInputs||(APP_STATE.geometry.comparisonInputs={}),a=getActiveBlastRowForComparison();
    if(ci.densityBasis==='active') applyDensityBasis(null);
    if(force||!ci.loaded) loadCiFromProject(a);
    const put=(id,v)=>{const el=$(id);if(el&&document.activeElement!==el)el.value=(v==null?'':v)};
    put('cmpDiameterIn',ci.diameterIn);put('cmpBenchHeight',ci.benchHeight);put('cmpExplosiveDensity',ci.explosiveDensity);put('cmpHoleCount',ci.holeCount);put('cmpRockDensity',ci.rockDensity);put('cmpStv',ci.stv);put('cmpFiring',ci.firing==null?'':ci.firing);put('cmpAshVod',ci.ashVod);put('cmpAshKs',ci.ashKs);put('cmpKonyaKd',ci.kd);put('cmpKonyaKr',ci.kr);put('cmpKonyaKs',ci.kgeo);
    const sel=$('cmpRockDensityBasis');
    if(sel){ [...sel.options].forEach(o=>{ if(o.value==='active') o.remove(); }); if(![...sel.options].some(o=>o.value==='')){ const o=document.createElement('option'); o.value='';o.textContent='— pilih material project (HG / MG / DOL) —'; sel.insertBefore(o,sel.firstChild);} sel.value=ci.densityBasis||''; }
    const fs=$('cmpFiring'); if(fs&&![...fs.options].some(o=>o.value==='')){ const o=document.createElement('option'); o.value='';o.textContent='— pilih —'; fs.insertBefore(o,fs.firstChild); fs.value=ci.firing==null?'':ci.firing; }
    if($('cmpRockDensity')) $('cmpRockDensity').readOnly=ci.densityBasis!=='custom';
    if($('cmpHoleCount')) $('cmpHoleCount').readOnly=true;
    if($('cmpRockSource'))$('cmpRockSource').textContent=geometryComparisonDensitySource(ci.densityBasis);
    setBlastBaseDisplay(a?a.groupLabel:null,a?a.row.no:null);
    if($('cmpLabBase'))$('cmpLabBase').textContent=ci.densityBasis?`${ci.densityBasis.toUpperCase()} • ${geometryLabBaseDensity()==null?'--':geometryLabBaseDensity().toFixed(3)} SG`:'WAITING FOR PROJECT MATERIAL';
    const am=(APP_STATE.formula.key||'ash').toUpperCase(); if($('cmpActiveMethod'))$('cmpActiveMethod').textContent=am; if($('cmpActiveMethod2'))$('cmpActiveMethod2').textContent=am;
    renderGeometryComparisonProvenance();
    if(typeof renderProjectData==='function') renderProjectData();
  }
  function renderGeometryComparisonProvenance(){
    const p=$('cmpProvenance'); if(!p) return;
    const ci=APP_STATE.geometry.comparisonInputs||{},a=getActiveBlastRowForComparison();
    const fields=['ci.diameterIn','ci.benchHeight','ci.explosiveDensity','ci.holeCount','ci.rockDensity'];
    p.textContent='SOURCE • '+(a?`ENGINEER ACTUAL • ${a.groupLabel} • ROW ${a.row.no}`:'--')+' • '+fields.map(f=>`${f.split('.')[1]}: ${APP_STATE.prov[f]?APP_STATE.prov[f].sourceType:'WAITING'}`).join(' | ');
  }
  const CMP_FIELDS=[['cmpDiameterIn','ci.diameterIn','in'],['cmpBenchHeight','ci.benchHeight','m'],['cmpExplosiveDensity','ci.explosiveDensity','SG'],['cmpRockDensity','ci.rockDensity','SG'],['cmpStv','ci.stv','-'],['cmpFiring','ci.firing','-'],['cmpAshVod','ci.ashVod','m/s'],['cmpAshKs','ci.ashKs','S/B'],['cmpKonyaKd','ci.kd','-'],['cmpKonyaKr','ci.kr','-'],['cmpKonyaKs','ci.kgeo','-']];
  const MAE_FIELDS=[['maeXi','mae.xi'],['maeUcs','mae.ucs','MPa'],['maeJps','mae.jps'],['maeJpo','mae.jpo'],['maeCw','mae.cw','m'],['maeStf','mae.stf'],['maeSbf','mae.sbf']];
  function commitDomField(domId,path,unit,sourceName){
    const el=$(domId); if(!el) return; const raw=String(el.value??'').trim(); const old=inputRoot(path)[inputKey(path)];
    const val=raw===''?null:(path==='ci.firing'?raw:Number(raw));
    setInput(path,val,unit,'USER_EDIT',sourceName,domId,{notes:'typed by user in browser'}); if(path.startsWith('ci.')) APP_STATE.geometry.comparisonInputs.loaded=true;
    if(path==='ci.rockDensity') APP_STATE.geometry.comparisonInputs.densityBasis='custom';
    audit(path,old??'',val??'',domId,'USER EDIT'); persistWorking();
  }
  function geometryComparisonReadInputs(){ return true; }
  function geometryCompareCostInputs(){ const rd=p=>{const r=readInput(p,{allowZero:true});return r.ok?r.value:null;}; return {drilling:rd('cost.drilling'),explosive:rd('cost.explosive'),accessory:rd('cost.accessory')}; }
  function costStatus(){ const c=geometryCompareCostInputs(),ps=['cost.drilling','cost.explosive','cost.accessory'].map(p=>APP_STATE.prov[p]?.sourceType).filter(Boolean); if(c.drilling==null||c.explosive==null||c.accessory==null) return {ready:false,label:'COST STATUS: WAITING FOR QUOTATION',types:ps}; return {ready:true,label:'COST STATUS: AVAILABLE • source '+[...new Set(ps)].join('/')+' (user-entered; '+(gfSourceCaptured()?'sumber/tanggal harga tercatat':'quotation reference not captured')+')',types:ps}; }
  function computeCostFor(r,c){ const drillingCost=r.totalDrilling*c.drilling,explosiveCost=r.totalCharge*c.explosive,accessoryCost=r.holeCount*c.accessory,totalCost=drillingCost+explosiveCost+accessoryCost; return {drillingCost,explosiveCost,accessoryCost,totalCost,costPerTon:r.totalTonnage>0?totalCost/r.totalTonnage:null}; }
  function geometryCompareHash(){ return ['ash','konya','mae'].map(phaseAHashFor).join('-'); }
  function geometryStatusSummary(){ const R=APP_STATE.geometry.results||{},st=['ash','konya','mae'].map(k=>({k,f:methodFreshness(k),r:R[k]})); const calc=st.filter(x=>x.r); if(!calc.length) return 'WAITING FOR CALCULATION'; return calc.some(x=>x.f==='STALE')?'STALE':(calc.length===3?'CALCULATED':'PARTIAL'); }

  function geometryCompareCalculate(methods){
    const selected=(Array.isArray(methods)&&methods.length?methods:['ash','konya','mae']).filter(k=>FORMULA_REGISTRY[k]);
    const cur=APP_STATE.geometry.results||(APP_STATE.geometry.results={ash:null,konya:null,mae:null}),ms=APP_STATE.geometry.methodStatus||(APP_STATE.geometry.methodStatus={});
    selected.forEach(k=>{ const c=computeMethod(k); cur[k]=c.result; ms[k]={status:c.status,missing:c.missing.map(x=>`${x.path} (${x.reason})`)}; audit('Geometry calculation',k.toUpperCase(),c.status,'CALCULATE','CALCULATION'); });
    APP_STATE.geometry.comparison={status:geometryStatusSummary(),lastCalculated:new Date().toISOString(),methods:selected.slice(),inputsHash:geometryCompareHash()};
    APP_STATE.geometry.result=calculateGeometry();
    renderGeometryComparison(); return true;
  }
  function applyActiveGeometryToSimulator(){
    const key=APP_STATE.formula.key||'ash',r=(APP_STATE.geometry.results||{})[key],msg=t=>{if($('geometryCompareMsg'))$('geometryCompareMsg').textContent=t;};
    if(!r){msg('BELUM ADA HASIL • hitung metode aktif terlebih dahulu.');return false;}
    if(methodFreshness(key)!=='FRESH'){msg('HASIL STALE • input berubah sejak perhitungan terakhir. Klik CALCULATE lagi sebelum APPLY TO SIMULATOR.');return false;}
    if(r.validity==='INVALID'){msg('⛔ HASIL INVALID — tidak diterapkan ke simulator. '+(r.warnings||[]).join(' • '));return false;}
    const active=getActiveBlastRowForComparison(),p=APP_STATE.simulation.parameters||{};
    p.holeCount=Math.max(1,Math.round(Number(r.holeCount)||1)); p.anPerHoleKg=Number(r.chargeMass); p.stemmingM=Number(r.T);p.burdenM=Number(r.B);p.spacingM=Number(r.S);p.depthM=Number(r.holeDepth);
    APP_STATE.simulation.template=active?.groupKey||APP_STATE.simulation.template||'group1';
    APP_STATE.simulation.groupLabel=`SCENARIO ${key.toUpperCase()}${r.demoContaminated?' (DEMO EXAMPLE)':''} • ${active?.groupLabel||'PROJECT'}`;
    APP_STATE.simulation.activeBlastRow=active?.rowNo||APP_STATE.simulation.activeBlastRow||1; APP_STATE.simulation.result=null;
    simHydrate();simVisual();persistWorking();
    audit('Geometry method applied',active?.groupLabel||'',`${key.toUpperCase()} • B=${r.B.toFixed(2)} • S=${r.S.toFixed(2)} • T=${r.T.toFixed(2)} • J=${r.J.toFixed(2)}`,'USER ACTION','APPLY GEOMETRY TO SIMULATOR');
    msg(`ACTIVE ${key.toUpperCase()} diterapkan ke Simulator • B ${r.B.toFixed(2)} m • S ${r.S.toFixed(2)} m • T ${r.T.toFixed(2)} m • J ${r.J.toFixed(2)} m.`+(r.demoContaminated?' DEMO EXAMPLE — bukan hasil proyek.':'')+` Status kelayakan: ${geoStatusOf(key,r).label} (hasil dihitung ≠ desain layak).`); return true;
  }
  function renderPhaseAStatus(){
    const el=$('phaseAStatus'); if(!el) return;
    const cs=costStatus(),ms=APP_STATE.geometry.methodStatus||{},R=APP_STATE.geometry.results||{},a=actualEngineerGeometry();
    const lines=[];
    if(APP_STATE.demo.loaded) lines.push('⚠ DEMO EXAMPLE LOADED — hasil turunan bukan hasil proyek.');
    lines.push('ENGINEER ACTUAL: '+(a?a.source:'WAITING FOR ENGINEER ACTUAL ROW'));
    lines.push('MATERIAL: '+(APP_STATE.geometry.comparisonInputs.densityBasis?geometryComparisonDensitySource(APP_STATE.geometry.comparisonInputs.densityBasis):'WAITING FOR PROJECT MATERIAL'));
    ['ash','konya','mae'].forEach(k=>{ const r=R[k],f=methodFreshness(k),m=ms[k]; let s=r?(f+(r.demoContaminated?' • DEMO EXAMPLE':'')+' • '+r.formulaVersion):(m&&m.status!=='CALCULATED'?m.status+(m.missing.length?': '+m.missing.join(', '):''):'WAITING FOR PROJECT INPUT'); if(!r&&!m){ const c=collectEngineInputs(k); s='WAITING FOR PROJECT INPUT'+(c.missing.length?': '+c.missing.map(x=>x.path).join(', '):''); } lines.push(k.toUpperCase()+': '+s); });
    lines.push(cs.label);
    el.textContent=lines.join('\n');
    const badge=$('geometryCompareStatus'); if(badge){ const s=geometryStatusSummary(); badge.textContent=s==='CALCULATED'?'DIHITUNG (bukan penilaian kelayakan)':s; badge.className='kb-badge '+(s==='CALCULATED'?'ok':'warn'); }
  }

  function validateAll(){
    const i=APP_STATE.geometry.input,errors=[],waiting=[];
    ['diameterIn','benchHeight','explosiveDensity','holeCount','targetX80','airDeckPct'].forEach(k=>{ const v=i[k]; if(v==null) waiting.push(k); else if(!Number.isFinite(v)) errors.push(`${k}: NaN/Infinity`); else if(v<0) errors.push(`${k}: negative`); else if(v===0&&k!=='airDeckPct') errors.push(`${k}: zero where positive value is required`); });
    if(i.airDeckPct>100) errors.push('airDeckPct > 100');
    const g=APP_STATE.geometry.result; if(g){ if(g.T>g.H) errors.push('stemming > hole depth'); else if(g.chargeMass<=0) errors.push('charge mass <= 0'); }
    const box=$('validationErrors'); if(box){ if(errors.length){box.classList.remove('kb-hidden');box.innerHTML='<strong>VALIDATION ERROR</strong><br>'+errors.map(e=>'• '+htmlEscape(e)).join('<br>');} else if(waiting.length&&!APP_STATE.demo.loaded){box.classList.remove('kb-hidden');box.innerHTML='<strong>WAITING FOR PROJECT INPUT</strong><br>'+waiting.filter(k=>k!=='airDeckPct').map(e=>'• '+htmlEscape(e)).join('<br>');} else box.classList.add('kb-hidden'); }
    return errors.length===0;
  }
  function recalcFromFormInput(){
    const units={diameterIn:'in',benchHeight:'m',explosiveDensity:'SG',holeCount:'holes',targetX80:'cm',airDeckPct:'%'};
    Object.keys(units).forEach(k=>{ const el=$(k); if(!el) return; const raw=String(el.value??'').trim(); const old=APP_STATE.geometry.input[k]; setInput('gi.'+k,raw===''?null:Number(raw),units[k],'USER_EDIT','Design page',k); if(old!==APP_STATE.geometry.input[k]) audit('geometry.'+k,old??'',APP_STATE.geometry.input[k]??'','USER INPUT','GEOMETRY UPDATE'); });
    APP_STATE.geometry.inputSource='USER EDIT'; APP_STATE.optimizer.airDeckPct=APP_STATE.geometry.input.airDeckPct||0;
    geometryComparisonInputSync(true); validateAll(); refreshAll(); persistWorking();
  }

  /* ---- financial / seismic gating */
  function calculateFinancial(){
    const f=APP_STATE.financial,need=['fin.anfoIdrKg','fin.secondaryIdrUnit'].map(p=>readInput(p));
    if(!need.every(x=>x.ok)){ f.result=null; f.costStatus='WAITING FOR QUOTATION'; return; }
    calculateFinancial__legacy(); f.costStatus='AVAILABLE'; if(f.result) f.result.demo=['fin.anfoIdrKg','fin.secondaryIdrUnit'].some(p=>APP_STATE.prov[p]?.sourceType==='DEMO_EXAMPLE');
  }
  function updateSeismic(){ updateSeismic__legacy(); const s=APP_STATE.seismic; if(!(s.D>0)) s.D=null; if(!(s.W>0)) s.W=null; if(!(s.K>0)||!(s.n>0)){ s.ppv=null; } tagSeismicSource(); }
  function applySeismicRef(){ applySeismicRef__legacy(); APP_STATE.seismic.kSource='REFERENCE'; tagSeismicSource(); }
  function fitSeismicTemplate(){ fitSeismicTemplate__legacy(); APP_STATE.seismic.kSource='SITE_FIT'; tagSeismicSource(); }
  function fitSeismicCsv(f){ APP_STATE.seismic.kSourcePending='SITE_FIT'; return fitSeismicCsv__legacy(f); }
  function tagSeismicSource(){
    const s=APP_STATE.seismic; if(s.K==null||s.n==null) s.kSource='NONE'; else if(s.kSourcePending&&/SITE FIT/.test((s.fit||{}).status||'')){s.kSource='SITE_FIT';s.kSourcePending=null;} else if(!s.kSource||s.kSource==='NONE') s.kSource='USER';
    if(s.D==null||!(s.D>0)) s.dwSource='NONE'; else if(!s.dwSource||s.dwSource==='NONE') s.dwSource='USER';
    let b=$('seismicSourceBadge'); const anchor=$('seismicFitStatus'); if(!b&&anchor){ b=document.createElement('div'); b.id='seismicSourceBadge'; b.className='kb-note'; anchor.parentNode.insertBefore(b,anchor.nextSibling); }
    if(b) b.textContent=`K/n SOURCE: ${s.kSource||'NONE'}${s.kSource==='DEMO'?' (DEMO EXAMPLE — not a site fit)':''} • D/W SOURCE: ${s.dwSource||'NONE'}`+(s.K==null?' • WAITING FOR SITE FIT / REFERENCE / USER K,n':'');
  }

  /* Snapshot of code-level initial state, taken before any handler/restore runs: must contain no engineering value. */
  const BOOT_DEFAULTS=(function(){ const G=APP_STATE.geometry,ci=G.comparisonInputs||{},F=APP_STATE.financial||{},S=APP_STATE.seismic||{},M=(APP_STATE.formula&&APP_STATE.formula.mae)||{};
    return {geometryInput:Object.entries(G.input||{}).filter(([k,v])=>v!==null&&k!=='airDeckPct').map(x=>x[0]),
      comparison:['diameterIn','benchHeight','explosiveDensity','holeCount','rockDensity','stv','firing','ashVod','ashKs','kd','kr','kgeo','densityBasis'].filter(k=>ci[k]!==null&&ci[k]!==undefined),
      financial:Object.keys(F).filter(k=>/Idr|Units|Pct/.test(k)&&F[k]!==null),seismic:['K','n','D','W'].filter(k=>S[k]!==null),mae:['xi','jps','jpo','ucs','cw'].filter(k=>M[k]!==null&&M[k]!==undefined),material:APP_STATE.material.qualityKey===null?[]:['material.qualityKey'],cost:Object.keys(G.cost||{}).filter(k=>G.cost[k]!==null)}; })();
  /* ---- PHASE A tests (appended to runTests) */
  function phaseASnapshot(){ return JSON.stringify({prov:APP_STATE.prov,demo:APP_STATE.demo,geometry:{...APP_STATE.geometry},formula:APP_STATE.formula,financial:APP_STATE.financial,seismic:APP_STATE.seismic,sim:{t:APP_STATE.simulation.template,r:APP_STATE.simulation.activeBlastRow,g:APP_STATE.simulation.groupLabel}}); }
  function phaseARestore(s){ const o=JSON.parse(s); APP_STATE.prov=o.prov; APP_STATE.demo=o.demo; Object.assign(APP_STATE.geometry,o.geometry); APP_STATE.formula=o.formula; APP_STATE.financial=o.financial; APP_STATE.seismic=o.seismic; APP_STATE.simulation.template=o.sim.t; APP_STATE.simulation.activeBlastRow=o.sim.r; APP_STATE.simulation.groupLabel=o.sim.g; }
  function phaseAProjectFill(){
    const P=(p,v,u)=>setInput(p,v,u,'PROJECT_INPUT','TEST PROJECT FIXTURE',p);
    APP_STATE.geometry.comparisonInputs.loaded=true; P('ci.diameterIn',3.5,'in');P('ci.benchHeight',3,'m');P('ci.explosiveDensity',0.85,'SG');P('ci.holeCount',4,'holes');
    setInput('ci.rockDensity',1.777,'SG','LAB_DATA','LAB BASE (embedded)','material HG'); APP_STATE.geometry.comparisonInputs.densityBasis='hg';
    P('ci.ashKs',1.30,'S/B');P('ci.stv',100,'-');P('ci.kd',1,'-');P('ci.kr',1,'-');P('ci.kgeo',1,'-');P('ci.firing','delayed','-');
    P('mae.xi',1,'-');P('mae.jps',20,'-');P('mae.jpo',30,'-');P('mae.ucs',60,'MPa');P('mae.cw',24,'m');P('mae.stf',0.7,'-');P('mae.sbf',0.3,'-');
  }
  function runPhaseATests(pass){
    const snap=phaseASnapshot(),T=(n,ok,m)=>pass('PHASE A • '+n,!!ok,m||'');
    try{
      /* T1 boot/waiting */
      T('Boot defaults: code-level initial state holds NO engineering value (geometry, ci, MAE, cost, financial, seismic, material)',Object.values(BOOT_DEFAULTS).every(a=>a.length===0),JSON.stringify(BOOT_DEFAULTS));
      phaseAResetInputs(); const w=calculateAllGeometryMethods(); const cs=costStatus();
      T('Waiting state: no engine returns a number without project input',!w.ash&&!w.konya&&!w.mae);
      T('Waiting state: cost status = WAITING FOR QUOTATION (not 0)',!cs.ready&&/WAITING FOR QUOTATION/.test(cs.label)&&geometryCompareCostInputs().drilling===null);
      T('Waiting state: MAE xi/JPS/JPO/UCS/CW not auto-filled',['xi','jps','jpo','ucs','cw'].every(k=>maeState()[k]===null));
      T('Waiting state: no engineering material selected (PEDEL not active)',APP_STATE.geometry.comparisonInputs.densityBasis===null&&geometryLabBaseDensity()===null);
      /* T2 demo contamination */
      APP_STATE.geometry.comparisonInputs.diameterIn=3.5; /* leak attempt: value without provenance */
      T('Demo/untraceable leak: value without provenance is rejected',!collectEngineInputs('ash').ok&&collectEngineInputs('ash').missing.some(x=>x.path==='ci.diameterIn'&&x.reason==='NO PROVENANCE'));
      phaseAResetInputs(); provSet('ci.diameterIn',3.5,'in','DEMO_EXAMPLE','x','y'); APP_STATE.geometry.comparisonInputs.diameterIn=3.5;
      T('Demo leak: DEMO value without LOAD DEMO EXAMPLE is rejected',collectEngineInputs('ash').missing.some(x=>x.reason==='DEMO VALUE WITHOUT LOAD DEMO EXAMPLE'));
      phaseAResetInputs(); loadDemoExample(); const d=calculateAllGeometryMethods();
      T('LOAD DEMO EXAMPLE: all three methods compute and are flagged demoContaminated',['ash','konya','mae'].every(k=>d[k]&&d[k].demoContaminated===true&&d[k].sourceTypes.includes('DEMO_EXAMPLE')),JSON.stringify(['ash','konya','mae'].map(k=>d[k]?d[k].demoContaminated:null)));
      geometryCompareCalculate(['ash','konya','mae']); T('Demo results are labelled in UI status',/DEMO EXAMPLE/.test($('phaseAStatus')?.textContent||'')||!$('phaseAStatus'));
      phaseAResetInputs(); phaseAProjectFill(); const p=calculateAllGeometryMethods();
      T('Project input after reset: zero DEMO_EXAMPLE in any lineage; flag false',['ash','konya','mae'].every(k=>p[k]&&!p[k].demoContaminated&&!p[k].lineage.some(x=>x.sourceType==='DEMO_EXAMPLE')));
      phaseAResetInputs(); loadDemoExample(); phaseAProjectFill(); setInput('mae.ucs',60,'MPa','DEMO_EXAMPLE','demo','ucs'); const pm=calculateAllGeometryMethods();
      T('Partial override: Ash/Konya clean, MAE still flagged (leftover demo UCS)',pm.ash&&!pm.ash.demoContaminated&&pm.konya&&!pm.konya.demoContaminated&&pm.mae&&pm.mae.demoContaminated===true);
      T('No result has DEMO lineage with flag false (global invariant)',['ash','konya','mae'].every(k=>[d,p,pm][0]&&[d,p,pm].every(x=>!x[k]||x[k].lineage.some(l=>l.sourceType==='DEMO_EXAMPLE')===x[k].demoContaminated)));
      /* T3 stale */
      phaseAResetInputs(); phaseAProjectFill(); geometryCompareCalculate(['ash','konya','mae']);
      const fr=['ash','konya','mae'].map(methodFreshness); T('Stale: all FRESH right after calculation',fr.every(x=>x==='FRESH'),fr.join());
      setInput('mae.ucs',90,'MPa','USER_EDIT','test','ucs'); const f2=['ash','konya','mae'].map(methodFreshness);
      T('Stale: changing MAE UCS makes ONLY MAE stale',f2[0]==='FRESH'&&f2[1]==='FRESH'&&f2[2]==='STALE',f2.join());
      T('Stale: active geometry result is withheld while stale (no stale output)',(APP_STATE.formula.key!=='mae')||calculateGeometry()===null);
      geometryCompareCalculate(['mae']); T('Stale: recalculation returns MAE to FRESH',methodFreshness('mae')==='FRESH');
      setInput('ci.diameterIn',4,'in','USER_EDIT','test','d'); T('Stale: changing diameter makes all three STALE',['ash','konya','mae'].every(k=>methodFreshness(k)==='STALE'));
      geometryCompareCalculate(); const sb=APP_STATE.simulation.activeBlastRow,sg=APP_STATE.simulation.template; const rows=(BLAST_SHEET_ROWS[sg]?.rows||[]).map(r=>r.no); APP_STATE.simulation.activeBlastRow=rows.find(n=>n!==sb)??sb;
      T('Stale: changing Group/Row makes results STALE',rows.length<2||['ash','konya','mae'].every(k=>methodFreshness(k)==='STALE'));
      APP_STATE.simulation.activeBlastRow=sb; geometryCompareCalculate(); const b0=APP_STATE.geometry.comparisonInputs.densityBasis; applyDensityBasis('dol'); T('Stale: changing material basis makes results STALE',['ash','konya','mae'].every(k=>methodFreshness(k)==='STALE')); applyDensityBasis(b0);
      geometryCompareCalculate(); T('Stale: after recalculation all FRESH again',['ash','konya','mae'].every(k=>methodFreshness(k)==='FRESH'));
      /* T4 formula consistency */
      const keyBefore=APP_STATE.formula.key; const ok4=[];
      ['ash','konya','mae'].forEach(k=>{ setFormula(k); const ui=$('formulaCode').textContent,f=FORMULA_REGISTRY[k],r=APP_STATE.geometry.results[k]; ok4.push(ui.startsWith(f.displayedFormula)&&FORMULA_STATUS_VALUES.includes(f.status)&&r&&r.formulaId===f.formulaId&&r.formulaVersion===f.version); });
      T('Formula consistency: UI text == registry == implementation metadata (Ash, Konya, MAE)',ok4.every(Boolean),ok4.join());
      const a=APP_STATE.geometry.results.ash,kn=APP_STATE.geometry.results.konya,K1=FORMULA_REGISTRY.ash.constants,K2=FORMULA_REGISTRY.konya.constants;
      T('Formula consistency: implemented T/J ratios == registry constants',a&&kn&&Math.abs(a.T/a.B-K1.TB)<1e-12&&Math.abs(a.J/a.B-K1.JB)<1e-12&&Math.abs(kn.T/kn.B-K2.TB)<1e-12&&Math.abs(kn.J/kn.B-K2.JB)<1e-12);
      const tok=(k)=>{const c=FORMULA_REGISTRY[k].constants,t=[];if(k==='ash'){t.push(c.TB.toFixed(2),c.JB.toFixed(2),'39.37007874');['low','medium','high'].forEach(e=>t.push(Object.values(c.kbTable[e]).join('/')));}if(k==='konya'){t.push(String(c.c1),String(c.c2a)+'·SGe/SGr + '+String(c.c2b),String(c.c3),String(c.ftToM),c.TB.toFixed(2),c.JB.toFixed(2),'L/B < '+c.slender);}if(k==='mae'){t.push('0.5(RMD+JPS+JPO+RDI+Hk)','0.004','47.6','23.7');}return t;};
      T('Formula consistency: every numeric constant the engine uses appears in the displayed formula',['ash','konya','mae'].every(k=>tok(k).every(x=>FORMULA_REGISTRY[k].displayedFormula.includes(x))),['ash','konya','mae'].map(k=>tok(k).filter(x=>!FORMULA_REGISTRY[k].displayedFormula.includes(x)).join('|')).join(' ; '));
      T('Formula wording: no formula claimed as "standard"/"reference"; no invented citation',Object.values(FORMULA_REGISTRY).every(f=>f.status!=='IMPLEMENTED'&&!/\b(standard|reference)\b/i.test(f.displayedFormula+' '+f.status)));
      setFormula(keyBefore);
      /* known-value regression: canonical engine unchanged (HG 1.777, 3.5in, bench 3, eSG 0.85) */
      phaseAResetInputs(); phaseAProjectFill(); const bench=3,hg=calculateAllGeometryMethods(); const refA=(()=>{const kb=ashKbEmpirical(0.85,1.777).kb;return kb*3.5/39.37007874015748;})();
      T('Regression: Ash B equals Kb·D/39.37 (equation unchanged)',hg.ash&&Math.abs(hg.ash.B-refA)<1e-9);
      T('Regression: Konya B equals EM 1110-2-3800 Eq 5-2/5-4 (AUDIT v8: 3-equation average removed)',hg.konya&&(()=>{const r=0.85/1.777,D=3.5;const B=(2*r+1.5)*D*0.3048;return Math.abs(hg.konya.B-B)<1e-9&&hg.konya.Bvariant1972>0;})());
      T('Regression: determinism (same input twice → identical result)',JSON.stringify(calculateAllGeometryMethods().ash.B)===JSON.stringify(hg.ash.B));
      /* T5 provenance lineage */
      T('Provenance: every result carries complete lineage (path, unit, sourceType, sourceName, timestamp)',['ash','konya','mae'].every(k=>{const r=hg[k];return r&&r.lineage.length>=6&&r.lineage.every(l=>SOURCE_TYPES.includes(l.sourceType)&&l.unit!==undefined&&l.sourceName&&l.timestamp&&l.path)&&r.formulaId&&r.calculatedAt;}));
      const act=actualEngineerGeometry();
      T('Engineer Actual: source label, immutable original, SOURCE vs CALCULATED separated',act&&/^ENGINEER ACTUAL • .* • ROW \d+/.test(act.source)&&Object.isFrozen(act.original)&&act.meta.totalVolume.startsWith('CALCULATED')&&/ASSUMPTION/.test(act.meta.totalTonnage)&&act.meta.B==='SOURCE');
      T('Engineer Actual: volume not derived when no material selected',(()=>{const s2=phaseASnapshot();applyDensityBasis(null);const x=actualEngineerGeometry();const ok=x.totalVolume===null&&x.pfKgM3===null;const o=JSON.parse(s2);APP_STATE.prov=o.prov;APP_STATE.geometry.comparisonInputs=o.geometry.comparisonInputs;return ok;})());
      /* T6 silent defaults */
      phaseAResetInputs(); phaseAProjectFill(); setInput('ci.ashKs',null); setInput('ci.kd',null); setInput('mae.cw',null);
      const nd=calculateAllGeometryMethods(); T('No silent method defaults: Ks / Kd / CW missing → WAITING (no 1.30, 1.00, 24 fallback)',!nd.ash&&!nd.konya&&!nd.mae);
      phaseAResetInputs(); phaseAProjectFill(); setInput('ci.stv',null); const nd2=calculateAllGeometryMethods();
      T('Optional inputs truly optional: Stv missing → Konya still computes (Stv only feeds info variant)',nd2.konya&&nd2.konya.B>0&&nd2.konya.BvariantEnergy===null);
      /* T7 physical validity gate (AUDIT v8) */
      phaseAResetInputs(); phaseAProjectFill();
      setInput('ci.benchHeight',3,'m','USER_EDIT','test','bench'); setInput('mae.cw',24,'m','USER_EDIT','test','cw');
      const shallow=calculateAllGeometryMethods();
      T('Validity gate: MAE on 3 m bench with CW 24 m is flagged INVALID (stemming/charge impossible, Eq 26 collapse)',shallow.mae&&shallow.mae.validity==='INVALID'&&shallow.mae.warnings.length>0);
      T('Validity gate: Ash on sane inputs stays OK/WARNING, not INVALID',shallow.ash&&shallow.ash.validity!=='INVALID');
      geometryCompareCalculate(['ash','konya','mae']); const rowsHTML=$('geometryCompareBody')?.innerHTML||'';
      T('Validity gate: comparison table renders INVALID status and warning notes',/INVALID/.test(rowsHTML)&&/is-invalid/.test(rowsHTML));
      phaseAResetInputs(); T('Financial: no quotation → no result, WAITING FOR QUOTATION',(()=>{calculateFinancial();return APP_STATE.financial.result===null&&APP_STATE.financial.costStatus==='WAITING FOR QUOTATION';})());
      T('Seismic: no K/n/D/W silently present',APP_STATE.seismic.K===null&&APP_STATE.seismic.n===null&&APP_STATE.seismic.D===null&&APP_STATE.seismic.W===null&&APP_STATE.seismic.kSource==='NONE');
    }catch(e){ T('Phase A test harness threw',false,String(e&&e.stack||e)); }
    finally{ phaseARestore(snap); }
  }
  /* ===== END PHASE A ===== */
  /* ===== TAHAP 4.1 (v12.1) regression tests: kebocoran STALE, kebijakan seri, status sumber harga. Logika + DOM. Skenario INVALID/seri/demo disuntikkan ke hasil model FRESH. ===== */
  function runStage41Tests(pass){
    const T=(n,ok,m)=>pass('TAHAP 4.1 • '+n,!!ok,m||''),snap=phaseASnapshot(),ovBak=JSON.stringify(APP_STATE.simulation.rowOverrides||{}),recBak=JSON.stringify(APP_STATE.geometry.actualRecord||{}),actBak=APP_STATE.simulation.activeBlastRow,grpBak=APP_STATE.simulation.template,decBak=JSON.stringify(APP_STATE.geometry.decision||null),demoBak=APP_STATE.demo.loaded;
    const U=(p,v,u,st)=>setInput(p,v,u,st||'USER_EDIT','TAHAP 4.1 TEST',p),price=(d,e,a)=>{U('cost.drilling',d,'IDR/m');U('cost.explosive',e,'IDR/kg');U('cost.accessory',a,'IDR/hole');};
    const inj=(k,o)=>Object.assign(APP_STATE.geometry.results[k],o),M=['ash','konya','mae'];
    let A=0,rh=0;
    const fresh=()=>{ phaseAResetInputs(); phaseAProjectFill(); delete APP_STATE.geometry.costMeta; delete APP_STATE.geometry.decision; APP_STATE.demo.loaded=false; rh=Math.round(Number(getActiveBlastRowForComparison().row.holes)); setInput('ci.holeCount',rh,'holes','PROJECT_INPUT','TEST PROJECT FIXTURE','ci.holeCount'); price(85000,14500,125000); geometryCompareCalculate(M); A=Number(getActiveBlastRowForComparison().row.volume); };
    const ok=k=>inj(k,{validity:'OK',warnings:[],sourceTypes:['PROJECT_INPUT'],krDefault:false,criteriaGaps:[],demoContaminated:false,totalTonnage:A,holeCount:rh});
    const bad=k=>inj(k,{validity:'INVALID',warnings:['[uji] INVALID']});
    const run=()=>{ renderGeometryComparison(); const D=geometryDecisionCompute(); return {D,R:dsResults(D),F:D.F}; };
    const txt=id=>($(id)&&$(id).textContent)||'';
    const cells=lab=>{ const tr=[...document.querySelectorAll('#geometryCompareBody tr')].find(r=>r.children[0]&&r.children[0].textContent.trim().startsWith(lab)); return tr?[...tr.children].map(c=>c.textContent.trim()):null; };
    const rows=()=>(BLAST_SHEET_ROWS[APP_STATE.simulation.template]?.rows||[]).map(r=>r.no);
    const noBad=()=>!/NaN|Infinity|undefined|\[object/.test(($('geometryComparePanel')||{}).innerText||'');
    const src=()=>{ const m=gfMeta(); m.vendor='PT Uji (data uji)'; m.quoteDate='2026-10-01'; };
    try{
      /* ===== A. STALE ===== */
      fresh(); ok('konya'); ok('mae'); ok('ash'); inj('ash',{totalDrilling:1,totalCharge:1}); inj('konya',{totalDrilling:14,totalCharge:46}); inj('mae',{totalDrilling:15,totalCharge:45});
      let X=run(); 
      T('Kontrol: semua FRESH → angka terendah Ash (1 m, 1 kg) memang terpilih',/R\.L\. Ash/.test(txt('cmpBestDrill'))&&/R\.L\. Ash/.test(txt('cmpBestExplosive')));
      setInput('ci.ashKs',1.5,'S/B','USER_EDIT','TAHAP 4.1 TEST','ci.ashKs'); X=run();
      const Rr=APP_STATE.geometry.results,fr=M.filter(k=>methodFreshness(k)==='FRESH'),expD=fr.reduce((a,k)=>Rr[k].totalDrilling<Rr[a].totalDrilling?k:a,fr[0]),expE=fr.reduce((a,k)=>Rr[k].totalCharge<Rr[a].totalCharge?k:a,fr[0]),nm={konya:'Calvin Konya',mae:'MAE'};
      T('Ash STALE (angka lama 1 m / 1 kg): ringkasan TIDAK memilih Ash; memilih terendah dari hasil FRESH (hitung independen)',methodFreshness('ash')==='STALE'&&!/Ash/.test(txt('cmpBestDrill'))&&!/Ash/.test(txt('cmpBestExplosive'))&&txt('cmpBestDrill').startsWith(nm[expD])&&txt('cmpBestExplosive').startsWith(nm[expE]),txt('cmpBestDrill')+' | '+txt('cmpBestExplosive'));
      T('Ringkasan menyebut metode STALE tidak dipakai',/1 metode STALE tidak dipakai/.test(txt('cmpBestDrill')));
      let c1=cells('Total drilling'),c2=cells('Burden (B)'),c3=cells('Δ Burden'),c4=cells('Status perhitungan'),c5=cells('Status kelayakan');
      T('Tabel detail: kolom Ash STALE tidak menampilkan angka lama (1,00 m), diganti penanda STALE',c1[2]==='STALE'&&c2[2]==='STALE'&&c3[2]==='STALE'&&!/1\.00/.test(c1[2])&&c1[3]!=='STALE',c1.join('|'));
      T('Status perhitungan dan status kelayakan dipisah & sama-sama menandai STALE',/STALE — hasil lama disembunyikan/.test(c4[2])&&/STALE — HASIL LAMA, BUKAN UNTUK KEPUTUSAN/.test(c5[2])&&c4[3]==='TERHITUNG'&&c5[3]!==c4[3]);
      T('Kartu geometri Ash STALE membawa banner "HASIL LAMA — STALE — BUKAN UNTUK KEPUTUSAN"',/HASIL LAMA — STALE — BUKAN UNTUK KEPUTUSAN/.test($('gcCard_ash').innerText)&&/PERHITUNGAN: STALE/.test($('gcCard_ash').innerText));
      T('Konsistensi STALE lintas panel: Financial (tanpa biaya), Decision (gate gagal, bukan kandidat), tabel & kartu',X.F.cols.ash.state==='STALE'&&X.F.cols.ash.total==null&&X.D.cand.ash.cls==='EXCLUDED'&&/STALE/.test(X.D.cand.ash.gates[0].txt)&&!X.D.pool.some(c=>c.key==='ash')&&/STALE/.test($('gfBody').innerText));
      APP_STATE.geometry.comparison.status='CALCULATED'; renderGeometryComparison();
      T('Status badge tabel = STALE bila ada metode STALE, walau status global tercatat CALCULATED (bukan "DIHITUNG")',methodFreshness('ash')==='STALE'&&txt('geometryCompareStatus')==='STALE'&&!/DIHITUNG/.test(txt('geometryCompareStatus')),txt('geometryCompareStatus'));
      /* jalur event asli: mengetik di input metode/umum harus memperbarui tabel, ringkasan, Financial, Decision tanpa render manual */
      fresh(); ok('konya'); ok('mae'); ok('ash'); inj('ash',{totalDrilling:1,totalCharge:1}); run(); setInput('ci.ashKs',1.30,'S/B','PROJECT_INPUT','TEST PROJECT FIXTURE','ci.ashKs'); renderGeometryComparison();
      T('Kontrol (sebelum mengetik): Ash FRESH dan terpilih sebagai angka terendah',methodFreshness('ash')==='FRESH'&&/Ash/.test(txt('cmpBestDrill')));
      (()=>{ const el=$('cmpAshKs'); el.value='1.55'; el.dispatchEvent(new Event('input',{bubbles:true}));
        const c=cells('Total drilling'),F2=geometryFinancialCompute();
        T('Event input asli pada #cmpAshKs: tabel detail, ringkasan, Financial, dan Decision langsung memperlakukan Ash sebagai STALE',methodFreshness('ash')==='STALE'&&c[2]==='STALE'&&!/Ash/.test(txt('cmpBestDrill'))&&F2.cols.ash.state==='STALE'&&/STALE/.test($('gfBody').innerText)&&$('geoDecPanel')._last.D.cand.ash.cls==='EXCLUDED',c.join('|')+' | '+txt('cmpBestDrill')); })();
      fresh(); ok('konya'); ok('mae'); ok('ash'); renderGeometryComparison();
      (()=>{ const f=MAE_FIELDS.find(x=>x[1]==='mae.cw'),el=f&&$(f[0]); if(!el){ T('Field MAE tersedia untuk uji event',false); return; } el.value=String(Number(el.value||APP_STATE.mae.cw||0)+1); el.dispatchEvent(new Event('input',{bubbles:true}));
        const c=cells('Total drilling');
        T('Event input asli pada field MAE: MAE STALE di tabel, ringkasan, Financial, dan Decision (metode lain tetap FRESH)',methodFreshness('mae')==='STALE'&&c[4]==='STALE'&&c[2]!=='STALE'&&$('geoDecPanel')._last.D.cand.mae.cls==='EXCLUDED'&&geometryFinancialCompute().cols.mae.state==='STALE',c.join('|')); })();
      fresh(); ok('konya'); ok('mae'); ok('ash'); renderGeometryComparison();
      (()=>{ const el=$('cmpDiameterIn'); el.value=String(Number(el.value)+0.5); el.dispatchEvent(new Event('input',{bubbles:true}));
        T('Event input asli pada input umum (diameter): semua metode STALE di semua panel; ringkasan "BELUM ADA HASIL FRESH"',M.every(k=>methodFreshness(k)==='STALE')&&txt('cmpBestDrill')==='BELUM ADA HASIL FRESH — HITUNG ULANG'&&cells('Total drilling').slice(2).every(x=>x==='STALE')&&['lowest','closest','balance'].every(k=>$('geoDecPanel')._last.res[k].winner===null)); })();
      /* semua STALE: tidak ada angka minimum dari hasil lama */
      setInput('ci.diameterIn',Number(APP_STATE.geometry.comparisonInputs.diameterIn)+0.5,'in','USER_EDIT','TAHAP 4.1 TEST','ci.diameterIn'); X=run();
      T('Tidak ada hasil FRESH: ringkasan = "BELUM ADA HASIL FRESH — HITUNG ULANG" (drilling, handak, biaya) — bukan angka minimum lama',M.every(k=>methodFreshness(k)==='STALE')&&['cmpBestDrill','cmpBestExplosive','cmpBestCost'].every(i=>txt(i)==='BELUM ADA HASIL FRESH — HITUNG ULANG'),['cmpBestDrill','cmpBestCost'].map(txt).join(' | '));
      T('Tidak ada hasil FRESH: ketiga hasil keputusan BELUM DAPAT DITENTUKAN tanpa pemenang; pesan geometri eksplisit',['lowest','closest','balance'].every(k=>X.R[k].status==='UND'&&X.R[k].winner===null)&&/BELUM ADA HASIL FRESH/.test(txt('geometryCompareMsg')));
      /* ganti baris */
      fresh(); ok('konya'); ok('mae'); ok('ash'); const oldB=M.map(k=>APP_STATE.geometry.results[k].B.toFixed(2)),oldCharge=M.map(k=>APP_STATE.geometry.results[k].totalCharge);
      const rs=rows(),other=rs.find(n=>n!==APP_STATE.simulation.activeBlastRow);
      if(other!=null){ APP_STATE.simulation.activeBlastRow=other; geometryComparisonInputSync(true); X=run(); const b=cells('Burden (B)'),tc=cells('Total charge');
        T('Ganti baris blast: ringkasan tidak memilih angka dari baris lama; tabel tidak menyajikan angka lama sebagai aktif',['cmpBestDrill','cmpBestExplosive','cmpBestCost'].every(i=>txt(i)==='BELUM ADA HASIL FRESH — HITUNG ULANG')&&[2,3,4].every(i=>b[i]==='STALE'&&tc[i]==='STALE'),b.join('|'));
        T('Ganti baris: Financial Comparison dan Decision Support juga tidak memakai hasil baris lama',M.every(k=>X.F.cols[k].state==='STALE'&&X.F.cols[k].total==null&&X.D.cand[k].cls==='EXCLUDED')&&X.R.lowest.winner===null);
        APP_STATE.simulation.activeBlastRow=actBak; geometryComparisonInputSync(true); }
      /* belum dihitung ≠ nol */
      phaseAResetInputs(); phaseAProjectFill(); price(85000,14500,125000); APP_STATE.geometry.results={ash:null,konya:null,mae:null}; X=run(); const nd=cells('Total drilling'),np=cells('Status perhitungan');
      T('Metode belum dihitung: bukan angka nol — "--" / "BELUM DIHITUNG", ringkasan "--", biaya N/A',[2,3,4].every(i=>nd[i]==='--'&&np[i]==='BELUM DIHITUNG')&&txt('cmpBestDrill')==='--'&&M.every(k=>X.F.cols[k].total==null)&&noBad());
      /* INVALID & DEMO dikecualikan */
      fresh(); ok('ash'); ok('konya'); ok('mae'); inj('konya',{totalDrilling:14,totalCharge:46}); inj('ash',{totalDrilling:15,totalCharge:47}); inj('mae',{totalDrilling:2,totalCharge:2}); bad('mae'); X=run();
      T('INVALID (angka terkecil) dikecualikan dari ringkasan angka terendah; catatan "INVALID dikecualikan"',!/MAE/.test(txt('cmpBestDrill'))&&/INVALID dikecualikan/.test(txt('cmpBestDrill'))&&txt('cmpBestDrill').startsWith('Calvin Konya'));
      ok('mae'); inj('mae',{totalDrilling:2,totalCharge:2,demoContaminated:true}); X=run();
      T('DEMO EXAMPLE (angka terkecil) dikecualikan dari pemenang ringkasan; pesan eksplisit',!/MAE/.test(txt('cmpBestDrill'))&&/DEMO EXAMPLE dikecualikan/.test(txt('cmpBestDrill'))&&X.D.cand.mae.cls==='EXCLUDED'&&/DEMO/.test(X.D.cand.mae.gates[1].txt));
      M.forEach(k=>inj(k,{demoContaminated:true})); X=run();
      T('Semua hasil DEMO: ringkasan "HASIL BERBASIS DEMO EXAMPLE", tanpa pemenang di Decision Support',/HASIL BERBASIS DEMO EXAMPLE/.test(txt('cmpBestDrill'))&&['lowest','closest','balance'].every(k=>X.R[k].winner===null));
      /* ===== B. SERI ===== */
      const clone=(to,from)=>{ const s=APP_STATE.geometry.results[from]; ['B','S','T','J','holeDepth','chargeMass','totalDrilling','totalCharge','totalTonnage','holeCount','pfKgT','pfKgM3','totalVolume','volumePerHole','tonnagePerHole'].forEach(f=>{ APP_STATE.geometry.results[to][f]=s[f]; }); };
      fresh(); ['ash','konya','mae'].forEach(ok); clone('ash','konya'); bad('mae'); X=run();
      const sk=['lowest','closest','balance'];
      T('Dua model identik (biaya/ton, deviasi geometri sama): LOWEST COST & CLOSEST = SERI, winner null, tidak memilih Ash menurut urutan',['lowest','closest'].every(k=>X.R[k].status==='UND'&&X.R[k].winner===null&&/SERI/.test(X.R[k].label)&&X.R[k].tied&&X.R[k].tied.length===2),JSON.stringify(sk.map(k=>[X.R[k].label,X.R[k].winner])));
      dsStore().requireField=false; X=run();
      T('BEST TECHNICAL BALANCE (bukti lapangan dimatikan): skor identik → SERI, winner null — kebijakan sama dengan dua hasil lainnya',X.R.balance.status==='UND'&&X.R.balance.winner===null&&/SERI/.test(X.R.balance.label)&&X.R.balance.tied.length===2); dsStore().requireField=true;
      T('Hasil seri menampilkan semua kandidat teratas, nilai, margin, dan alasan (DOM)',(()=>{ const t=$('dsCard_lowest').innerText; return /R\.L\. ASH/.test(t)&&/CALVIN KONYA/.test(t)&&/Margin seri/.test(t)&&/bukan ambang rekayasa/.test(t)&&/Rp/.test(t); })()&&/SERI/.test(txt('cmpBestCost'))&&/SERI/.test(txt('cmpBestDrill')),$('dsCard_lowest').innerText.slice(0,300));
      /* urutan tidak boleh menentukan pemenang */
      const R0=APP_STATE.geometry.results,sw={ash:R0.ash,konya:R0.konya,mae:R0.mae}; APP_STATE.geometry.results={mae:sw.mae,konya:sw.konya,ash:sw.ash}; X=run();
      T('Urutan properti/array tidak mengubah hasil: tetap SERI tanpa pemenang',X.R.lowest.winner===null&&X.R.closest.winner===null&&/SERI/.test(X.R.lowest.label)); APP_STATE.geometry.results=sw;
      /* biaya total sama, tonase berbeda */
      fresh(); M.forEach(ok); clone('ash','konya'); inj('ash',{totalTonnage:A*1.5}); bad('mae'); dsStore().costBasis='total'; X=run();
      T('Biaya TOTAL sama (tonase beda): basis total → SERI; ringkasan lama mengikuti basis (label "biaya total", teks SERI)',X.R.lowest.winner===null&&/SERI/.test(X.R.lowest.label)&&/biaya total/.test($('cmpBestCost').previousElementSibling.textContent)&&/SERI/.test(txt('cmpBestCost')));
      dsStore().costBasis='perTon'; X=run();
      T('Basis per ton (tonase Ash +50%): pemenang unik Ash secara sah; ringkasan lama konsisten dengan kartu LOWEST COST',X.R.lowest.winner==='ash'&&/^R\.L\. ASH/.test(txt('cmpBestCost'))&&/biaya langsung \/ ton/.test($('cmpBestCost').previousElementSibling.textContent),JSON.stringify({w:X.R.lowest.winner,l:X.R.lowest.label,cb:txt('cmpBestCost'),lab:$('cmpBestCost').previousElementSibling.textContent,lines:X.R.lowest.lines}));
      /* margin 1% */
      fresh(); M.forEach(ok); clone('ash','konya'); bad('mae'); inj('ash',{totalTonnage:A*1.005}); X=run();
      T('Selisih biaya/ton 0,5% (< margin 1%): SERI, bukan pemenang',X.R.lowest.winner===null&&/SERI/.test(X.R.lowest.label));
      inj('ash',{totalTonnage:A*1.03}); X=run();
      T('Selisih biaya/ton ~3% (> margin): pemenang unik Ash (kebijakan tidak menyeri-kan semuanya)',X.R.lowest.winner==='ash'&&X.R.lowest.status==='COND');
      /* ===== C. HARGA ===== */
      fresh(); ['ash'].forEach(bad); ok('konya'); ok('mae'); inj('konya',{totalDrilling:13,totalCharge:44}); inj('mae',{totalDrilling:15,totalCharge:50}); src(); X=run();
      T('Kontrol: dua model VALID, harga lengkap + sumber tercatat → LOWEST COST VALID (jalur VALID dapat dicapai)',X.F.costBlock.kind==='OK'&&X.R.lowest.winner==='konya'&&X.R.lowest.status==='VALID'&&/lolos pemeriksaan wajib/.test(X.R.lowest.label));
      price(null,14500,125000); X=run();
      T('Salah satu harga wajib kosong: LOWEST COST tidak ditetapkan ("HARGA BELUM LENGKAP"), kosong ≠ nol; Stage 3 & Stage 4 konsisten',X.F.costBlock.kind==='WAITING'&&X.R.lowest.winner===null&&/HARGA BELUM LENGKAP/.test(X.R.lowest.label)&&/WAITING FOR PRICE DATA/.test(txt('gfStatus'))&&/WAITING FOR PRICE DATA/.test($('dsAlerts').innerText)&&/HARGA BELUM LENGKAP/.test(txt('cmpBestCost'))&&X.F.cols.konya.total===null);
      T('Harga kosong: skor Balance mengeluarkan kriteria biaya untuk SEMUA kandidat dengan alasan eksplisit (bukan nilai 0)',(()=>{ const d=X.R.balance.sc.dropped.find(x=>x.id==='costPerTon'); return d&&/harga wajib belum lengkap/.test(d.why)&&X.R.balance.sc.used.every(u=>u.crit.id!=='costPerTon'); })());
      price(0,14500,125000); X=run();
      T('Tarif nol disengaja: tetap dihitung (bukan kosong) tetapi LOWEST COST BERSYARAT + peringatan tarif nol; tidak "VALID"',X.F.priceReady&&X.F.costBlock.kind==='OK'&&X.F.cols.konya.comp.drilling===0&&X.R.lowest.winner!==null&&X.R.lowest.status==='COND'&&!/lolos pemeriksaan wajib/.test(X.R.lowest.label)&&X.R.lowest.warns.some(w=>/NOL/.test(w)));
      T('Tarif nol: peringatan muncul di Financial dan Decision Support; selisih ditandai "TARIF NOL — bersyarat"',/NOL/.test($('gfAlerts').innerText)&&/NOL/.test($('dsAlerts').innerText)&&/TARIF NOL/.test($('gfCards').innerText)&&!/PENGHEMATAN/.test($('gfCards').innerText),$('gfCards').innerText.slice(0,200));
      price(85000,14500,125000);
      /* demo */
      APP_STATE.demo.loaded=true; U('cost.drilling',85000,'IDR/m','DEMO_EXAMPLE'); X=run();
      T('Harga DEMO EXAMPLE (demo dimuat eksplisit): LOWEST COST BELUM DAPAT DITENTUKAN — HARGA DEMO; tidak ada label VALID',X.F.costBlock.kind==='DEMO'&&X.R.lowest.winner===null&&/HARGA DEMO/.test(X.R.lowest.label)&&X.R.lowest.status==='UND'&&!/VALID|lolos/.test(X.R.lowest.label));
      T('Harga DEMO: biaya demo TIDAK dipakai sebagai kriteria ekonomi di skor; panel finansial & ringkasan lama ikut menandai demo',(()=>{ const d=X.R.balance.sc.dropped.find(x=>x.id==='costPerTon'); return d&&/DEMO EXAMPLE/.test(d.why)&&X.R.balance.sc.used.every(u=>u.crit.id!=='costPerTon'); })()&&/HARGA DEMO/.test(txt('gfStatus'))&&/DEMO EXAMPLE/.test($('gfAlerts').innerText)&&/DEMO EXAMPLE/.test($('dsAlerts').innerText)&&/HARGA DEMO/.test(txt('cmpBestCost')));
      T('Harga DEMO: angka selisih biaya tidak disamarkan sebagai penghematan nyata (label eksplisit, bukan "PENGHEMATAN")',/HARGA DEMO — bukan penghematan nyata/.test($('gfCards').innerText)&&!/PENGHEMATAN/.test($('gfCards').innerText)&&/HARGA DEMO/.test($('dsBody2').innerText));
      APP_STATE.demo.loaded=false; price(85000,14500,125000);
      /* sumber harga */
      const m=gfMeta(); m.vendor=''; m.quoteDate=''; X=run();
      T('Sumber harga belum tercatat: peringatan di kedua panel; hasil BERSYARAT (tidak VALID); vendor/tanggal TIDAK dikarang',!X.F.sourceCaptured&&gfMeta().vendor===''&&gfMeta().quoteDate===''&&X.R.lowest.status==='COND'&&X.R.lowest.warns.some(w=>/Sumber harga/.test(w))&&/Sumber harga/.test($('gfAlerts').innerText)&&/Sumber harga/.test($('dsAlerts').innerText));
      src(); X=run(); T('Sumber harga dicatat pengguna: peringatan hilang dan hasil kembali VALID (tidak over-downgrade)',X.F.sourceCaptured&&X.R.lowest.status==='VALID'&&!/Sumber harga/.test($('dsAlerts').innerText));
      /* biaya tambahan */
      gfMeta().extras[0]={label:'Setengah isi',rate:500,basis:''}; X=run();
      T('Biaya tambahan terisi sebagian (tanpa basis): total tidak tersedia; LOWEST COST ditahan; skor biaya dikeluarkan; konsisten di semua panel',!X.F.extras.ok&&X.F.cols.konya.total===null&&X.R.lowest.winner===null&&/BIAYA TAMBAHAN TIDAK LENGKAP/.test(X.R.lowest.label)&&/BIAYA TAMBAHAN TIDAK LENGKAP/.test(txt('gfStatus'))&&/BIAYA TAMBAHAN TIDAK LENGKAP/.test(txt('cmpBestCost'))&&/tidak lengkap/.test($('dsAlerts').innerText)&&X.R.balance.sc.dropped.some(d=>d.id==='costPerTon'&&/biaya tambahan/.test(d.why)));
      gfMeta().extras=gfMeta().extras.map(()=>({label:'',rate:null,basis:''}));
      /* jalur event asli untuk input Tahap 3/4 (sebelumnya hanya panel finansial yang dirender ulang) */
      fresh(); ['ash'].forEach(bad); ok('konya'); ok('mae'); inj('konya',{totalDrilling:13,totalCharge:44}); inj('mae',{totalDrilling:15,totalCharge:50}); gfMeta().vendor=''; gfMeta().quoteDate=''; run();
      const typeIn=(id,v)=>{ const el=$(id); el.value=v; el.dispatchEvent(new Event(el.tagName==='SELECT'?'change':'input',{bubbles:true})); };
      typeIn('gfExLabel0','Sebagian'); typeIn('gfExRate0','500');
      T('Event input asli (biaya tambahan tanpa basis): Financial, Decision, dan ringkasan lama SERENTAK menahan biaya',/BIAYA TAMBAHAN TIDAK LENGKAP/.test(txt('gfStatus'))&&/BIAYA TAMBAHAN TIDAK LENGKAP/.test($('dsCard_lowest').innerText)&&/BIAYA TAMBAHAN TIDAK LENGKAP/.test(txt('cmpBestCost')),txt('cmpBestCost'));
      typeIn('gfExBasis0','lump'); typeIn('gfExRate0','0');
      T('Event input asli (biaya tambahan dilengkapi): ketiga panel kembali menghitung biaya',!/TIDAK LENGKAP/.test(txt('gfStatus'))&&$('dsCard_lowest').innerText.includes('CALVIN KONYA')&&/CALVIN KONYA —/.test(txt('cmpBestCost')),txt('cmpBestCost'));
      typeIn('gfExLabel0',''); typeIn('gfExRate0',''); typeIn('gfExBasis0','');
      typeIn('gfVendor','PT Uji (data uji)'); typeIn('gfQuoteDate','2026-10-01');
      T('Event input asli (vendor + tanggal): peringatan sumber hilang di Financial dan Decision; hasil kembali VALID',!/Sumber harga/.test($('dsAlerts').innerText)&&!/Sumber harga/.test($('gfAlerts').innerText)&&$('geoDecPanel')._last.res.lowest.status==='VALID');
      typeIn('gfVendor',''); T('Event input asli (vendor dikosongkan): peringatan sumber kembali di kedua panel, hasil BERSYARAT',/Sumber harga/.test($('dsAlerts').innerText)&&/Sumber harga/.test($('gfAlerts').innerText)&&$('geoDecPanel')._last.res.lowest.status==='COND');
      typeIn('dsCostBasis','total'); T('Event change basis biaya: ringkasan lama langsung mengikuti basis (label dan nilai)',/biaya total/.test($('cmpBestCost').previousElementSibling.textContent)&&!/\/t —/.test(txt('cmpBestCost')),txt('cmpBestCost')); typeIn('dsCostBasis','perTon');
      /* matriks konsistensi Stage 3 ↔ Stage 4 ↔ ringkasan lama */
      const scen=[['lengkap',()=>{price(85000,14500,125000);src();}],['kosong',()=>{price(null,null,null);}],['nol',()=>{price(0,0,0);}],['tanpa-sumber',()=>{price(85000,14500,125000);gfMeta().vendor='';gfMeta().quoteDate='';}]];
      let matrix=true,info=[]; scen.forEach(([n,f])=>{ f(); const Y=run(),l=Y.R.lowest,cb=Y.F.costBlock.kind; const okRow=(cb==='OK'||l.winner===null)&&(cb!=='OK'||!(Y.F.priceFlags.zero.length||Y.F.priceFlags.noSource)||l.status!=='VALID')&&(l.winner?txt('cmpBestCost').startsWith(Y.D.cand[l.winner].label):!/^(R\.L\. ASH|CALVIN KONYA|MAE) —/.test(txt('cmpBestCost'))); if(!okRow) info.push(n); matrix=matrix&&okRow; });
      T('Matriks skenario harga: LOWEST COST VALID hanya bila harga lengkap, bukan nol, ada sumber; ringkasan lama selalu sama dengan kartu LOWEST COST',matrix,info.join(','));
      /* ===== D. REGRESI ===== */
      fresh(); ok('konya'); ok('mae'); ok('ash'); inj('konya',{totalTonnage:A*1.2}); src(); X=run();
      T('Actual tetap BASELINE: tidak pernah menjadi pemenang / kandidat; deviasi baseline = referensi',sk.every(k=>X.R[k].winner!=='actual')&&X.D.cand.actual.cls.startsWith('BASELINE')&&!X.D.pool.some(c=>c.key==='actual'));
      T('Tonase model berbeda >5% dari actual tetap diperingatkan (kartu LOWEST COST + panel)',X.D.tonOff.length>0&&/TIDAK SETARA: tonase/.test(X.R.lowest.warns.join(' '))&&/berbeda >5%/.test($('dsAlerts').innerText));
      price(null,null,null); run(); const ids=[...document.querySelectorAll('[id]')].map(e=>e.id),dups=ids.filter((x,i)=>ids.indexOf(x)!==i); const _vPre=['plotly','js-','cartesianlayer','geo','scene','polar','ternary','gl','legend','colorbar','hover','draglayer','infolayer'],_vEx=new Set(['symbol']),appDups=dups.filter(id=>{const lo=id.toLowerCase();return !_vEx.has(lo)&&!_vPre.some(p=>lo.startsWith(p));});
      T('Tidak ada NaN/Infinity/undefined di panel geometri pada harga kosong; tidak ada ID HTML duplikat',noBad()&&appDups.length===0,appDups.join(','));
      price(85000,14500,125000); run(); T('Tidak ada NaN/Infinity/undefined di panel geometri pada harga lengkap',noBad());
    }catch(e){ T('Tahap 4.1 test harness threw',false,String(e&&e.stack||e)); }
    finally{ phaseARestore(snap); try{ APP_STATE.simulation.rowOverrides=JSON.parse(ovBak); APP_STATE.geometry.actualRecord=JSON.parse(recBak); APP_STATE.simulation.activeBlastRow=actBak; APP_STATE.simulation.template=grpBak; APP_STATE.demo.loaded=demoBak; const d=JSON.parse(decBak); if(d) APP_STATE.geometry.decision=d; else delete APP_STATE.geometry.decision; }catch(_e){} try{ geometryComparisonInputSync(true); renderGeometryComparison(); }catch(_e){} }
  }

  /* ===== TAHAP 4 tests (dijalankan oleh runTests). Skor dihitung ULANG secara independen dari nilai mentah; skenario INVALID/WARNING/UNV disuntikkan ke hasil model FRESH. ===== */
  function runStage4Tests(pass){
    const T=(n,ok,m)=>pass('TAHAP 4 • '+n,!!ok,m||''),snap=phaseASnapshot(),ovBak=JSON.stringify(APP_STATE.simulation.rowOverrides||{}),recBak=JSON.stringify(APP_STATE.geometry.actualRecord||{}),actBak=APP_STATE.simulation.activeBlastRow,grpBak=APP_STATE.simulation.template,decBak=JSON.stringify(APP_STATE.geometry.decision||null);
    const U=(p,v,u)=>setInput(p,v,u,'USER_EDIT','TAHAP 4 TEST',p),price=(d,e,a)=>{U('cost.drilling',d,'IDR/m');U('cost.explosive',e,'IDR/kg');U('cost.accessory',a,'IDR/hole');};
    const near=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-6*Math.max(1,Math.abs(b));
    const fresh=()=>{ phaseAResetInputs(); phaseAProjectFill(); delete APP_STATE.geometry.costMeta; delete APP_STATE.geometry.decision; const rh=Math.round(Number(getActiveBlastRowForComparison().row.holes)); setInput('ci.holeCount',rh,'holes','PROJECT_INPUT','TEST PROJECT FIXTURE','ci.holeCount'); price(85000,14500,125000); geometryCompareCalculate(['ash','konya','mae']); return rh; };
    const inj=(k,o)=>Object.assign(APP_STATE.geometry.results[k],o);
    const run=()=>{ const D=geometryDecisionCompute(); return {D,R:dsResults(D)}; };
    const tonA=()=>Number(getActiveBlastRowForComparison().row.volume);
    try{
      /* ISOLASI TES: sama seperti Tahap 3 — data aktual/override proyek tidak boleh mengubah urutan biaya yang diuji. */
      APP_STATE.geometry.actualRecord={}; APP_STATE.simulation.rowOverrides={};
      const rh=fresh(); let X=run(); renderGeometryDecision();
      /* S1 default: tidak ada hasil lapangan, tidak ada data palsu */
      T('Tanpa hasil lapangan: semua kriteria lapangan DATA BELUM TERSEDIA, tidak dinilai, tidak ada klaim kualitas',X.D.field.count===0&&/DATA BELUM TERSEDIA/.test($('dsBody2').innerText)&&X.R.balance.sc.used.every(u=>!/fragmentasi|PPV|flyrock|produktivitas|toe|backbreak/i.test(u.crit.label)));
      T('BEST TECHNICAL BALANCE default (bukti lapangan wajib): BELUM DAPAT DITENTUKAN + peringkat hanya INDIKATIF',X.R.balance.status==='UND'&&X.R.balance.winner===null&&/INDIKATIF/.test(X.R.balance.lines.join(' ')));
      /* S2 skenario: Ash INVALID tetapi termurah; Konya WARNING sedikit lebih mahal; MAE BELUM TERVERIFIKASI */
      const A=Number(getActiveBlastRowForComparison().row.volume);
      ['ash','konya','mae'].forEach(k=>inj(k,{totalTonnage:A,holeCount:rh}));
      inj('ash',{validity:'INVALID',warnings:['[uji] disuntikkan INVALID'],totalDrilling:8,totalCharge:15});
      inj('konya',{validity:'WARNING',warnings:['[uji] stiffness L/B < 2'],sourceTypes:['PROJECT_INPUT'],krDefault:false,criteriaGaps:[],totalDrilling:13,totalCharge:44});
      inj('mae',{validity:'OK',warnings:[],sourceTypes:['ASSUMPTION','PROJECT_INPUT'],criteriaGaps:['kriteria B/D, S/B, L/B untuk MAE belum terpasang di aplikasi'],totalDrilling:13.4,totalCharge:44.5});
      X=run(); const C=X.D.cand,Rs=X.R;
      T('Ash INVALID (termurah) → DIKECUALIKAN dari kandidat, tidak dipilih di LOWEST COST / CLOSEST / BALANCE',C.ash.cls==='EXCLUDED'&&['lowest','closest','balance'].every(k=>Rs[k].winner!=='ash')&&!X.D.pool.some(c=>c.key==='ash'));
      T('Ash INVALID memang termurah per ton (bukti skenario valid), tetapi LOWEST COST memilih Konya BERSYARAT',(()=>{ const a=C.ash.m.costPerTon,k=C.konya.m.costPerTon; return a<k&&Rs.lowest.winner==='konya'&&Rs.lowest.status==='COND'; })());
      T('Konya WARNING: tetap dibandingkan tetapi berlabel BERSYARAT dengan alasan risiko',C.konya.cls==='CONDITIONAL'&&/WARNING/.test(C.konya.why.join(' '))&&/BERSYARAT/.test(Rs.lowest.label));
      T('MAE BELUM TERVERIFIKASI (asumsi + kriteria belum terpasang): CONDITIONAL, tidak dipromosikan sebagai VALID',C.mae.cls==='CONDITIONAL'&&C.mae.col.geo.cls==='unv'&&dsWinStatus(C.mae)==='COND');
      T('Tidak ada hasil yang berlabel "VALID" bila tidak ada kandidat berstatus VALID',['lowest','closest','balance'].every(k=>Rs[k].status!=='VALID'));
      /* S3 skor: hitung ulang independen */
      const rS=X.R.balance.sc; let okS=rS.used.length>=3;
      const pool=X.D.pool.filter(c=>!c.limitFail);
      pool.forEach(c=>{ let num=0,den=0; rS.used.forEach(u=>{ const vals=pool.map(p=>p.crit[u.crit.id]),best=Math.min(...vals),v=c.crit[u.crit.id]; let s; if(u.crit.dir==='min') s=v===0?1:best/v; else if(u.crit.dir==='min1') s=(1+best)/(1+v); else s=1-Math.min(Math.abs(v),100)/100; num+=u.w*s; den+=u.w; }); okS=okS&&near(rS.scores[c.key].score,100*num/den); });
      T('Skor = Σ bobot × skor ternormalisasi ÷ Σ bobot (hitung ulang independen dari nilai mentah)',okS);
      /* S4 bobot dapat diedit */
      const st=dsStore(); const s0=rS.scores.konya.score; DS_CRIT.forEach(c=>{ st.weights[c.id]=0; }); st.weights.costPerTon=100; st.weights.drillPerTon=1; st.weights.warnCount=1; X=run();
      T('Bobot diedit → kriteria bobot 0 tidak dipakai & skor berubah sesuai bobot baru (tanpa klik hitung)',X.R.balance.sc.used.map(u=>u.crit.id).sort().join()==='costPerTon,drillPerTon,warnCount'&&!near(X.R.balance.sc.scores.konya.score,s0));
      T('Hanya 3 kriteria / 3 kelompok tetap memenuhi syarat minimum; bila <3 kriteria → BELUM DAPAT DITENTUKAN',(()=>{ st.weights.drillPerTon=0; st.weights.warnCount=0; const y=run(); const ok=y.R.balance.status==='UND'&&/minimal/.test(y.R.balance.lines.join(' ')); st.weights.drillPerTon=1; st.weights.warnCount=1; return ok; })());
      DS_CRIT.forEach(c=>{ st.weights[c.id]=1; });
      /* S5 syarat bukti lapangan dimatikan → kandidat teratas BERSYARAT/INDIKATIF, bukan rekomendasi */
      st.requireField=false; X=run(); const bal=X.R.balance;
      T('Syarat bukti lapangan dimatikan: pemenang BERSYARAT-INDIKATIF (bukan VALID) + peringatan tanpa bukti kualitas, atau SERI',(bal.status==='COND'&&/INDIKATIF/.test(bal.label)&&bal.winner!=='ash'&&/bukan rekomendasi/.test(bal.warns.join(' ')))||(bal.status==='UND'&&/SERI/.test(bal.label)));
      st.requireField=true;
      /* S6 data hilang tidak menjadi nol */
      price(null,null,null); X=run();
      T('Harga kosong: kriteria biaya DIKELUARKAN untuk semua kandidat (bukan skor 0); LOWEST COST BELUM DAPAT DITENTUKAN',X.R.balance.sc.dropped.some(d=>d.id==='costPerTon'&&/dikeluarkan/.test(d.why))&&X.R.lowest.status==='UND'&&X.R.balance.sc.scores.konya.parts.costPerTon===undefined);
      price(0,0,0); X=run();
      T('Harga nol: biaya Rp 0, tidak ada pembagian nol / NaN / Infinity di keputusan',!/NaN|Infinity|undefined/.test($('geoDecPanel').innerText)&&X.D.F.priceReady);
      price(85000,14500,125000);
      /* S7 biaya aktual invoice tidak tersedia */
      T('Biaya aktual invoice tidak tersedia: tidak mengganggu LOWEST COST (memakai estimasi actual); tidak ada angka invoice dikarang',(()=>{ const y=run(); return y.D.F.recorded===null&&y.R.lowest.status!=='NONE'; })());
      /* S8 tonase antaralternatif >5% */
      ['ash','konya','mae'].forEach(k=>inj(k,{totalTonnage:A*1.2})); X=run(); renderGeometryDecision();
      T('Tonase model >5% berbeda dari actual: peringatan TIDAK SETARA muncul di panel (data + tampilan)',X.D.fair.some(t=>/berbeda >5%/.test(t))&&/berbeda >5%/.test($('dsAlerts').innerText));
      T('Kartu LOWEST COST sendiri memuat peringatan TIDAK SETARA saat tonase pemenang berbeda >5% dari actual',/TIDAK SETARA: tonase/.test(X.R.lowest.warns.join(' ')));
      st.costBasis='total'; X=run(); T('Basis total + tonase berbeda >5%: hasil LOWEST COST membawa peringatan TIDAK SETARA',X.R.lowest.winner!==null&&X.R.lowest.warns.some(w=>/TIDAK SETARA/.test(w))); st.costBasis='perTon';
      ['ash','konya','mae'].forEach(k=>inj(k,{totalTonnage:A}));
      /* S9 tidak ada kandidat lolos */
      ['ash','konya','mae'].forEach(k=>inj(k,{validity:'INVALID',warnings:['[uji] INVALID']})); X=run(); renderGeometryDecision();
      T('Semua model INVALID: BELUM ADA DESAIN YANG DAPAT DIREKOMENDASIKAN untuk ketiga hasil (tidak dipaksa memilih)',['lowest','closest','balance'].every(k=>X.R[k].status==='NONE'&&X.R[k].winner===null)&&/BELUM ADA DESAIN/.test($('dsCards').innerText));
      /* S10 hanya satu kandidat */
      inj('konya',{validity:'WARNING',warnings:['[uji]'],sourceTypes:['PROJECT_INPUT'],krDefault:false,criteriaGaps:[]}); X=run();
      T('Hanya 1 kandidat lolos: BELUM DAPAT DITENTUKAN (tidak ada pembanding), bukan pemenang otomatis',['lowest','closest','balance'].every(k=>X.R[k].status==='UND'&&X.R[k].winner===null));
      /* S11 VALID hanya bila status benar-benar VALID */
      ['ash','konya','mae'].forEach(k=>inj(k,{validity:'OK',warnings:[],sourceTypes:['PROJECT_INPUT'],krDefault:false,criteriaGaps:[],totalTonnage:A})); FORMULA_REGISTRY; X=run();
      T('Label "lolos pemeriksaan wajib" hanya muncul untuk kandidat berstatus VALID (Konya VERIFIED tanpa asumsi); Ash PARTIAL tetap BERSYARAT',(()=>{ const w=X.R.lowest.winner; return !w||((w==='konya')===(X.R.lowest.status==='VALID'))&&(w!=='ash'||X.R.lowest.status==='COND'); })());
      /* S12 STALE & penggantian baris */
      geometryCompareCalculate(['ash','konya','mae']); setInput('ci.ashKs',1.5,'S/B','USER_EDIT','TAHAP 4 TEST','ci.ashKs'); X=run();
      T('Input metode berubah: Ash STALE → gagal G1, tidak ikut kandidat; hasil memperbarui otomatis',X.D.cand.ash.cls==='EXCLUDED'&&/STALE/.test(X.D.cand.ash.gates[0].txt)&&!X.D.pool.some(c=>c.key==='ash'));
      setInput('ci.ashKs',1.30,'S/B','PROJECT_INPUT','TEST PROJECT FIXTURE','ci.ashKs'); geometryCompareCalculate(['ash','konya','mae']);
      const rows=(BLAST_SHEET_ROWS[APP_STATE.simulation.template]?.rows||[]).map(r=>r.no),other=rows.find(n=>n!==APP_STATE.simulation.activeBlastRow);
      if(other!=null){ APP_STATE.simulation.activeBlastRow=other; geometryComparisonInputSync(true); renderGeometryComparison(); X=run();
        T('Penggantian baris: semua model STALE → tidak ada keputusan palsu (BELUM DAPAT DITENTUKAN), angka baris lama tidak dipakai',DS_MODELS.every(k=>X.D.cand[k].cls==='EXCLUDED')&&['lowest','closest','balance'].every(k=>X.R[k].winner===null&&X.R[k].status==='UND'));
        APP_STATE.simulation.activeBlastRow=actBak; geometryComparisonInputSync(true); }
      /* S13 hasil lapangan nyata (actual) */
      pdSetRec('fieldX80',18); pdSetRec('fieldSource','uji: pengukuran manual'); fresh(); X=run(); renderGeometryDecision();
      T('Hasil lapangan diisi: tampil TERUKUR hanya untuk ACTUAL; model tetap DATA BELUM TERSEDIA; kriteria lapangan tetap tidak dinilai',X.D.field.vals.fieldX80===18&&/TERUKUR/.test($('dsBody2').innerText)&&X.R.balance.evidence.field.models===0&&X.R.balance.sc.used.every(u=>u.crit.id!=='fieldX80'));
      pdSetRec('fieldX80',-3); X=run(); T('Nilai lapangan negatif ditolak (bukan nol, bukan disimpan)',X.D.field.vals.fieldX80===18);
      pdSetRec('fieldX80',''); pdSetRec('fieldSource','');
      /* S14 deviasi */
      fresh(); X=run(); const bm=X.D.bm; T('Deviasi dari aktual = model − aktual (abs) dan ÷ aktual × 100 (%), hanya parameter definisi sama',DS_MODELS.every(k=>{ const c=X.D.cand[k]; if(!c.m) return true; return DS_DEV.every(([p])=>{ const d=c.dev[p]; if(!d||bm[p]==null) return true; return near(d.abs,c.m[p]-bm[p])&&(bm[p]>0?near(d.pct,100*(c.m[p]-bm[p])/bm[p]):true); }); }));
      /* S14b CLOSEST: pemenang & nilai dihitung ulang independen (rata-rata |deviasi %| parameter sebanding) */
      (()=>{ const pr=['B','S','T','J','holeDepth','chargeMass'].filter(p=>bm[p]!=null&&bm[p]>0),exp={}; X.D.pool.forEach(c=>{ exp[c.key]=pr.reduce((s,p)=>s+Math.abs(100*(c.m[p]-bm[p])/bm[p]),0)/pr.length; });
        const keys=Object.keys(exp),best=keys.reduce((a,b)=>exp[b]<exp[a]?b:a,keys[0]);
        T('CLOSEST TO ACTUAL: pemenang = rata-rata |deviasi %| terkecil (hitung ulang independen, bukan deviasi bertanda)',keys.length>=2&&X.R.closest.winner===best&&keys.every(k=>near(X.D.cand[k].geoDev,exp[k])),JSON.stringify(exp)); })();
      /* S14c hasil lapangan tidak bocor ke kolom model (DOM) */
      pdSetRec('fieldX80',18); renderGeometryDecision(); (()=>{ const tr=[...document.querySelectorAll('#dsBody2 tr')].find(r=>/X80/.test(r.textContent)); const cells=tr?[...tr.children].slice(1).map(c=>c.innerText):[];
        T('Hasil lapangan hanya di kolom ACTUAL (TERUKUR); kolom Ash/Konya/MAE = DATA BELUM TERSEDIA',cells.length===4&&/TERUKUR/.test(cells[0])&&cells.slice(1).every(c=>/DATA BELUM TERSEDIA/.test(c)&&!/TERUKUR/.test(c)),cells.join(' | ')); })(); pdSetRec('fieldX80','');
      /* S15 UI */
      renderGeometryComparison();
      T('UI: ringkasan keputusan di atas tabel; panel tepat di bawah Financial Comparison; empat kolom Actual/Ash/Konya/MAE',(()=>{ const p=$('geoDecPanel'),h=[...p.querySelectorAll('#dsBody2')].length&&[...p.querySelectorAll('table thead')[1].querySelectorAll('th')].map(x=>x.textContent.trim()).join('|'); return p.previousElementSibling&&p.previousElementSibling.id==='geoFinPanel'&&p.querySelector('#dsCards').compareDocumentPosition(p.querySelector('table'))&Node.DOCUMENT_POSITION_FOLLOWING&&h==='Parameter|GEOMETRY ACTUAL|R.L. ASH|CALVIN KONYA|MAE'; })());
      T('UI: tiga hasil terpisah (LOWEST COST, CLOSEST TO ACTUAL, BEST TECHNICAL BALANCE) dan tidak ada warna hijau untuk angka terkecil',['dsCard_lowest','dsCard_closest','dsCard_balance'].every(i=>$(i))&&(()=>{const r=[...document.styleSheets].flatMap(s=>{try{return [...s.cssRules];}catch(e){return [];}}).filter(x=>/\.ds-/.test(x.selectorText||'')); return r.length>0&&!/signal-safe|#1e7a4a/.test(r.map(x=>x.cssText).join(''));})());
    }catch(e){ T('Tahap 4 test harness threw',false,String(e&&e.stack||e)); }
    finally{ phaseARestore(snap); try{ APP_STATE.simulation.rowOverrides=JSON.parse(ovBak); APP_STATE.geometry.actualRecord=JSON.parse(recBak); APP_STATE.simulation.activeBlastRow=actBak; APP_STATE.simulation.template=grpBak; const d=JSON.parse(decBak); if(d) APP_STATE.geometry.decision=d; else delete APP_STATE.geometry.decision; }catch(_e){} try{ geometryComparisonInputSync(true); renderGeometryComparison(); }catch(_e){} }
  }

  /* ===== TAHAP 3 tests (dijalankan oleh runTests). Aritmetika diverifikasi ULANG secara independen dari angka kuantitas, bukan memanggil computeCostFor. ===== */
  function runStage3Tests(pass){
    const T=(n,ok,m)=>pass('TAHAP 3 • '+n,!!ok,m||''),snap=phaseASnapshot(),ovBak=JSON.stringify(APP_STATE.simulation.rowOverrides||{}),recBak=JSON.stringify(APP_STATE.geometry.actualRecord||{});
    const U=(p,v,u)=>setInput(p,v,u,'USER_EDIT','TAHAP 3 TEST',p),price=(d,e,a)=>{U('cost.drilling',d,'IDR/m');U('cost.explosive',e,'IDR/kg');U('cost.accessory',a,'IDR/hole');};
    const R3=x=>Math.round(x),near=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-6*Math.max(1,Math.abs(b));
    const noBad=()=>{ const t=($('geoFinPanel')?.innerText||''); return !/NaN|Infinity|undefined|null/.test(t); };
    try{
      /* ISOLASI TES: catatan aktual & override baris milik proyek harus dinetralkan agar harapan aritmetika di bawah
         dihitung dari baris rencana murni. recBak/ovBak di blok finally mengembalikan data pengguna setelah suite jalan. */
      APP_STATE.geometry.actualRecord={}; APP_STATE.simulation.rowOverrides={};
      phaseAResetInputs(); phaseAProjectFill(); delete APP_STATE.geometry.costMeta;
      const ab=getActiveBlastRowForComparison(),rowHoles=Math.round(Number(ab.row.holes)); setInput('ci.holeCount',rowHoles,'holes','PROJECT_INPUT','TEST PROJECT FIXTURE','ci.holeCount');
      geometryCompareCalculate(['ash','konya','mae']); renderGeometryComparison();
      /* S1 harga kosong */
      let F=geometryFinancialCompute();
      T('Harga kosong: WAITING FOR PRICE DATA, total null (bukan 0), tanpa NaN/Infinity/undefined di panel',!F.priceReady&&GF_KEYS.every(k=>F.cols[k].total==null)&&/WAITING FOR PRICE DATA/.test($('gfStatus').textContent)&&noBad(),$('gfStatus').textContent);
      price(85000,14500,125000); geometryCompareCalculate(['ash','konya','mae']); renderGeometryComparison(); F=geometryFinancialCompute();
      /* S2 rumus independen, 4 kolom */
      const R=APP_STATE.geometry.results,A=F.cols.actual,row=getActiveBlastRowForComparison().row,pdr=pdRec();
      const expAct={d:R3((Number(pdr.holeMeter)>0?Number(pdr.holeMeter):Number(row.subDepth)*rowHoles)*85000),e:R3(Number(row.totalAn)*14500),a:R3(rowHoles*125000)};
      T('Actual: biaya = meter × Rp/m, charge × Rp/kg, lubang × Rp/lubang (hitung independen)',A.comp.drilling===expAct.d&&A.comp.explosive===expAct.e&&A.comp.accessory===expAct.a&&A.total===expAct.d+expAct.e+expAct.a,JSON.stringify({got:A.comp,exp:expAct}));
      const mOk=['ash','konya','mae'].every(k=>{ const c=F.cols[k],r=R[k]; return c.state==='OK'&&c.comp.drilling===R3(r.totalDrilling*85000)&&c.comp.explosive===R3(r.totalCharge*14500)&&c.comp.accessory===R3(r.holeCount*125000)&&c.total===c.comp.drilling+c.comp.explosive+c.comp.accessory; });
      T('Ash/Konya/MAE: komponen & total cocok hitung independen dari output model; total = jumlah komponen (tanpa hitung ganda)',mOk);
      T('Biaya per lubang = total ÷ lubang; per ton = total ÷ tonase (semua kolom)',GF_KEYS.every(k=>{ const c=F.cols[k]; return c.total!=null&&near(c.perHole,c.total/c.q.holes.v)&&near(c.perTon,c.total/c.q.ton.v); }));
      /* S3 selisih */
      const okKeys=['ash','konya','mae'].filter(k=>F.cols[k].delta.state==='OK'),dOk=okKeys.length>=2&&okKeys.every(k=>{ const c=F.cols[k]; return c.delta.rp===c.total-A.total&&near(c.delta.pct,100*(c.total-A.total)/A.total); });
      T('Selisih = alternatif − basis ESTIMASI actual; % = selisih ÷ basis × 100',dOk&&F.basis.mode==='estimate'&&F.basis.total===A.total);
      /* S4 perubahan tarif */
      U('cost.drilling',90000,'IDR/m'); renderGeometryComparison(); let F2=geometryFinancialCompute();
      T('Perubahan tarif pengeboran memperbarui total semua kolom (tanpa klik hitung ulang)',GF_KEYS.every(k=>F2.cols[k].total-F.cols[k].total===R3(F2.cols[k].q.drill.v*90000)-R3(F.cols[k].q.drill.v*85000)));
      /* S5 tarif nol & negatif */
      U('cost.drilling',0,'IDR/m'); F2=geometryFinancialCompute();
      T('Tarif NOL: dihitung Rp 0 + peringatan eksplisit (tidak dianggap kosong)',F2.priceReady&&F2.cols.actual.comp.drilling===0&&F2.prices.drilling.zero&&gfAlerts(F2).some(x=>/NOL/.test(x.t)));
      U('cost.drilling',-5,'IDR/m'); F2=geometryFinancialCompute();
      T('Tarif negatif ditolak: WAITING FOR PRICE DATA, tidak ada total',!F2.priceReady&&F2.cols.actual.total==null);
      U('cost.drilling',85000,'IDR/m');
      /* S6 jumlah lubang */
      editActiveBlastRowField('holes',rowHoles+2); geometryComparisonInputSync(true); renderGeometryComparison(); F2=geometryFinancialCompute();
      T('Jumlah lubang actual berubah: biaya aksesori actual ikut berubah',F2.cols.actual.comp.accessory===(rowHoles+2)*125000,String(F2.cols.actual.comp.accessory));
      T('Input geometri berubah: model berstatus STALE dan TIDAK menampilkan biaya (bukan hasil basi)',['ash','konya','mae'].every(k=>F2.cols[k].state==='STALE'&&F2.cols[k].total==null)&&/STALE/.test($('gfBody').innerText));
      geometryCompareCalculate(['ash','konya','mae']); F2=geometryFinancialCompute();
      T('Setelah hitung ulang: biaya model kembali dan memakai jumlah lubang baru',['ash','konya','mae'].every(k=>F2.cols[k].state==='OK'&&F2.cols[k].comp.accessory===(rowHoles+2)*125000));
      editActiveBlastRowField('holes',rowHoles); geometryComparisonInputSync(true); geometryCompareCalculate(['ash','konya','mae']);
      /* S6b lubang kosong/nol + basis nol */
      editActiveBlastRowField('holes',0); renderGeometryComparison(); F2=geometryFinancialCompute();
      T('Jumlah lubang actual kosong/nol: ditandai DATA KOSONG, aksesori & total N/A — TIDAK diam-diam dianggap 1 lubang',F2.cols.actual.q.holes.tag==='MISSING'&&F2.cols.actual.comp.accessory===null&&F2.cols.actual.total===null&&noBad(),JSON.stringify(F2.cols.actual.comp));
      editActiveBlastRowField('holes',rowHoles); geometryComparisonInputSync(true); geometryCompareCalculate(['ash','konya','mae']);
      price(0,0,0); renderGeometryComparison(); F2=geometryFinancialCompute();
      T('Basis estimasi actual bernilai Rp 0 (semua tarif nol): selisih N/A, bukan Infinity/NaN/persen palsu',F2.priceReady&&F2.cols.actual.total===0&&!F2.basis.available&&['ash','konya','mae'].every(k=>F2.cols[k].delta.state==='NA_BASIS'||F2.cols[k].delta.state==='INVALID')&&['ash','konya'].every(k=>F2.cols[k].delta.state==='NA_BASIS')&&noBad(),JSON.stringify({pr:F2.priceReady,at:F2.cols.actual.total,av:F2.basis.available,ds:['ash','konya','mae'].map(k=>F2.cols[k].delta.state+'/'+F2.cols[k].state),nb:noBad(),m:(($('geoFinPanel')||{}).innerText||'').match(/.{0,30}(NaN|Infinity|undefined|null).{0,30}/g)}));
      price(85000,14500,125000); renderGeometryComparison();
      /* S7 charge, meter bor */
      const tc0=Number(getActiveBlastRowForComparison().row.totalAn); editActiveBlastRowField('totalAn',tc0+10); renderGeometryComparison(); F2=geometryFinancialCompute();
      T('Charge actual berubah (+10 kg): biaya handak actual naik tepat 10 × Rp/kg',F2.cols.actual.comp.explosive===R3((tc0+10)*14500)&&F2.cols.actual.q.charge.tag==='RECORDED');
      editActiveBlastRowField('totalAn',tc0);
      pdSetRec('holeMeter',20); renderGeometryComparison(); F2=geometryFinancialCompute();
      T('Meter pengeboran: hole meter aktual tercatat dipakai (RECORDED), bukan kedalaman rencana',F2.cols.actual.q.drill.tag==='RECORDED'&&F2.cols.actual.comp.drilling===20*85000);
      pdSetRec('holeMeter',''); F2=geometryFinancialCompute();
      T('Tanpa hole meter: meter diturunkan dari kedalaman rencana dan ditandai ESTIMATED + sumber disebut',F2.cols.actual.q.drill.tag==='ESTIMATED'&&/rencana/.test(F2.cols.actual.q.drill.src));
      /* S8 tonase kosong */
      const tv0=Number(getActiveBlastRowForComparison().row.volume); editActiveBlastRowField('volume',0); renderGeometryComparison(); F2=geometryFinancialCompute();
      T('Tonase actual kosong/nol: biaya per ton N/A (bukan Infinity), total tetap dihitung, tidak diisi diam-diam',F2.cols.actual.total!=null&&F2.cols.actual.perTon===null&&F2.cols.actual.q.ton.tag==='MISSING'&&noBad());
      editActiveBlastRowField('volume',tv0);
      /* S9 INVALID / STALE */
      F=geometryFinancialCompute(); const keep=R.mae.validity; R.mae.validity='INVALID'; F2=geometryFinancialCompute(); R.mae.validity=keep;
      T('Model INVALID: biaya tidak dibandingkan (selisih N/A), kartu diberi label INVALID — bukan alternatif layak',F2.cols.mae.invalid&&F2.cols.mae.delta.state==='INVALID'&&/INVALID/.test(gfCondText(F2.cols.mae)));
      setInput('ci.ashKs',1.4,'S/B','USER_EDIT','TAHAP 3 TEST','ci.ashKs'); F2=geometryFinancialCompute();
      T('Input metode berubah (Ash Ks): Ash STALE tanpa biaya; metode lain tetap FRESH',F2.cols.ash.state==='STALE'&&F2.cols.ash.total==null&&F2.cols.konya.state==='OK');
      setInput('ci.ashKs',1.30,'S/B','PROJECT_INPUT','TEST PROJECT FIXTURE','ci.ashKs');
      /* S10 recorded vs estimate */
      F=geometryFinancialCompute(); T('RECORDED ACTUAL COST belum diisi: basis recorded → selisih N/A (tidak diam-diam memakai estimasi)',(()=>{ gfMeta().basis='recorded'; const x=geometryFinancialCompute(); gfMeta().basis='estimate'; return !x.basis.available&&['ash','konya','mae'].every(k=>x.cols[k].delta.state!=='OK'); })());
      pdSetRec('recordedCost',0); gfMeta().basis='recorded'; F2=geometryFinancialCompute();
      T('Basis recorded bernilai nol: N/A, bukan Infinity / persen palsu',!F2.basis.available&&['ash','konya','mae'].every(k=>F2.cols[k].delta.state!=='OK')); 
      pdSetRec('recordedCost',9000000); pdSetRec('recordedCostRef','INV-TEST'); F2=geometryFinancialCompute();
      T('RECORDED ACTUAL COST terpisah dari estimasi; selisih memakai basis recorded',F2.recorded&&F2.recorded.value===9000000&&F2.basis.total===9000000&&['ash','konya','mae'].filter(k=>F2.cols[k].delta.state==='OK').length>=2&&['ash','konya','mae'].filter(k=>F2.cols[k].delta.state==='OK').every(k=>F2.cols[k].delta.rp===F2.cols[k].total-9000000)&&F2.cols.actual.total!==9000000);
      gfMeta().basis='estimate'; pdSetRec('recordedCost',''); pdSetRec('recordedCostRef','');
      /* S11 biaya tambahan */
      const m=gfMeta(); m.extras[0]={label:'Mobilisasi',rate:1000000,basis:'lump'}; m.extras[1]={label:'Air',rate:500,basis:'hole'}; F2=geometryFinancialCompute();
      T('Biaya tambahan: lump + per-lubang ditambahkan ke total tepat sekali',GF_KEYS.every(k=>{ const c=F2.cols[k]; return c.comp.extras===1000000+R3(500*c.q.holes.v)&&c.total===c.comp.drilling+c.comp.explosive+c.comp.accessory+c.comp.extras; }));
      m.extras[2]={label:'Setengah isi',rate:700,basis:''}; F2=geometryFinancialCompute();
      T('Biaya tambahan tidak lengkap (tanpa basis): total ditahan, pesan eksplisit',!F2.extras.ok&&GF_KEYS.every(k=>F2.cols[k].total==null)&&gfAlerts(F2).some(x=>/tidak lengkap/.test(x.t)));
      m.extras=m.extras.map(()=>({label:'',rate:null,basis:''}));
      /* S12 UI */
      renderGeometryComparison(); const heads=[...document.querySelectorAll('#gfTable thead th')].map(x=>x.textContent.trim()),labels=[...document.querySelectorAll('#gfBody th')].map(x=>x.textContent);
      T('Tabel: 4 kolom alternatif + semua baris wajib; panel tepat setelah empat kartu geometri',heads.join('|')==='Parameter|GEOMETRY ACTUAL|R.L. ASH|CALVIN KONYA|MAE'&&['Jumlah lubang','Total drilling','Tonase','Biaya pengeboran','Biaya handak','Biaya aksesori','Biaya tambahan','Total biaya','Biaya per lubang','Biaya per ton','Selisih biaya'].every(s=>labels.some(l=>l.includes(s)))&&$('geoFinPanel').previousElementSibling&&$('geoFinPanel').previousElementSibling.classList.contains('gc-wrap'),heads.join('|'));
    }catch(e){ T('Tahap 3 test harness threw',false,String(e&&e.stack||e)); }
    finally{ phaseARestore(snap); try{ APP_STATE.simulation.rowOverrides=JSON.parse(ovBak); APP_STATE.geometry.actualRecord=JSON.parse(recBak); }catch(_e){} try{ renderGeometryComparison(); }catch(_e){} }
  }


  /* ---- Phase A (cont.): MAE assumptions tagging + wiring (DOM -> APP_STATE only) */
  function maeState(){
    const m=maeState__legacy(),A=FORMULA_REGISTRY.mae.constants;
    if(m.stf===A.stfAssumed&&!APP_STATE.prov['mae.stf']) provSet('mae.stf',m.stf,'-','ASSUMPTION','MAE implementation default','St_f',{notes:'carried from legacy code; source not attached'});
    if(m.sbf===A.sbfAssumed&&!APP_STATE.prov['mae.sbf']) provSet('mae.sbf',m.sbf,'-','ASSUMPTION','MAE implementation default','Sb_f',{notes:'carried from legacy code; source not attached'});
    return m;
  }

  /* ---- TAHAP 1: Blast Data terpadu. Plan row tetap berada di BLAST_SHEET_ROWS/rowOverrides;
     actualRecord menyimpan realisasi secara independen plus sumber per-field (_sources). */
  const PD_NUM=new Set(['holes','depth','subDepth','depthMeasured','holeMeter','burden','spacing','stemming','subDrill','charging','an','dn','totalAn','totalDn','det','fuel','dev','rc','bsr','volume','volumeM3','pf','cw','recordedCost','fieldX80','fieldToe','fieldBackbreak','fieldOverbreak','fieldPPV','fieldFlyrock','fieldProd']);
  const PD_PLAN_FIELDS=new Set(['holes','depth','subDepth','burden','spacing','stemming','charging','an','dn','totalAn','totalDn','det','fuel','dev','rc','bsr','volume','pf','unit','cw']);
  const PD_ACTUAL_ONLY=new Set(['depthMeasured','holeMeter','subDrill','volumeM3']);
  const PD_IDENT_FIELDS=new Set(['blastNo','block','location','date','sourceId']);
  let pdPendingImport=null;
  function pdRecStore(){ const G=APP_STATE.geometry; if(!G.actualRecord||typeof G.actualRecord!=='object'||Array.isArray(G.actualRecord)) G.actualRecord={}; return G.actualRecord; }
  function pdRec(a){ a=a||getActiveBlastRowForComparison(); return a?(pdRecStore()[a.groupKey+'::'+a.row.no]||{}):{}; }
  function pdSetRec(field,raw,source='INPUT MANUAL',options={}){
    const a=getActiveBlastRowForComparison(); if(!a) return false;
    let v=String(raw??'').trim();
    if(PD_NUM.has(field)){
      if(v==='') v=null;
      else { v=Number(v); if(!Number.isFinite(v)||v<0) return false; if(['holes','det'].includes(field)&&!Number.isInteger(v)) return false; }
    } else if(v==='') v=null;
    const st=pdRecStore(),k=a.groupKey+'::'+a.row.no,o=st[k]||(st[k]={}),old=o[field]??'';
    if(v===null){ delete o[field]; if(o._sources) delete o._sources[field]; }
    else { o[field]=v; if(!o._sources||typeof o._sources!=='object') o._sources={}; o._sources[field]=String(source||'INPUT MANUAL').slice(0,180); }
    if(!Object.keys(o).filter(x=>x!=='_sources').length) delete st[k];
    if(!options.skipAudit) audit('Actual record '+field,old,v??'',source,'EDIT ACTUAL RECORD');
    if(!options.skipPersist) persistWorking();
    return true;
  }
  function pdNumber(v){ if(v==null||String(v).trim()==='')return null; const n=Number(v); return Number.isFinite(n)?n:null; }
  function pdCalc(a){
    const rec=pdRec(a),ci=APP_STATE.geometry.comparisonInputs||{},D=Number(ci.diameterIn)*0.0254,e=Number(ci.explosiveDensity),rho=geometryLabBaseDensity();
    const n=k=>pdNumber(rec[k]),holes=n('holes'),B=n('burden'),S=n('spacing'),H=n('depth'),charging=n('charging');
    const ok=x=>Number.isFinite(x)&&x>0;
    const vol=ok(B)&&ok(S)&&ok(H)&&ok(holes)?B*S*H*holes:null;
    const an= D>0&&e>0&&ok(charging)?Math.PI*(D/2)**2*charging*e*1000:null;
    const depthSub=n('subDepth'),depth=n('depth'),dm=n('depthMeasured')||depthSub;
    const totalAn=n('totalAn')!=null?n('totalAn'):(ok(n('an'))&&ok(holes)?n('an')*holes:null);
    const tonnage=n('volume'),volumeM3=n('volumeM3')!=null?n('volumeM3'):vol;
    const holeMeter=n('holeMeter')!=null?n('holeMeter'):(ok(dm)&&ok(holes)?dm*holes:null);
    const subDrill=n('subDrill')!=null?n('subDrill'):(depthSub!=null&&depth!=null?Math.max(0,depthSub-depth):null);
    return {an,totalAn,volume:vol!=null&&rho>0?vol*rho:null,volumeM3,holeMeter,subDrill,pf:ok(tonnage)&&totalAn!=null?totalAn/tonnage:null,rho,vol};
  }
  function pdActualOrigin(rec,k){
    const v=rec?.[k]; if(v==null||String(v).trim()==='')return 'BELUM DICATAT';
    const src=rec?._sources?.[k]; return src||'INPUT MANUAL (record lama)';
  }
  function pdPlanOrigin(a,k,orig,rowOv){
    const g=BLAST_SHEET_ROWS[a.groupKey]||{};
    if(g.isManual)return 'BLOK MANUAL / DATA IMPOR';
    if(rowOv&&Object.prototype.hasOwnProperty.call(rowOv,k))return 'WORKING OVERRIDE';
    return orig?.[k]!=null?'TEMPLATE BAWAAN':'TEMPLATE TANPA NILAI';
  }
  function renderProjectData(){
    const P=$('projectDataPanel'); if(!P) return;
    const a=getActiveBlastRowForComparison(),g=$('pdGroup'),rs=$('pdRow'),f2=(v,d=2)=>Number.isFinite(v)?v.toFixed(d):'--';
    if(g&&document.activeElement!==g){
      const dl=$('pdGroupSuggestions');
      if(dl) dl.innerHTML=Object.entries(BLAST_SHEET_ROWS).map(([k,v])=>`<option value="${htmlEscape(v.label||k)}" label="${htmlEscape(k)}"></option>`).join('');
      g.value=a?(a.groupLabel||a.groupKey):'';
    }
    if(rs&&document.activeElement!==rs){
      rs.innerHTML=((a&&BLAST_SHEET_ROWS[a.groupKey]?.rows)||[]).map(r=>`<option value="${htmlEscape(r.no)}">Row ${htmlEscape(r.no)} • ${r.holes==null?'hole belum diisi':htmlEscape(r.holes)} hole • depth ${r.depth==null?'—':Number(r.depth).toFixed(1)+' m'}</option>`).join('');
      if(a) rs.value=String(a.row.no);
    }
    if(!a){ $('pdSourceInfo').textContent='Belum ada baris aktif.'; return; }
    const groupInfo=BLAST_SHEET_ROWS[a.groupKey]||{},isManualGroup=!!groupInfo.isManual;
    const orig=(ORIGINAL_ENGINEER_ACTUAL[a.groupKey]?.rows||[]).find(x=>x.no===a.row.no)||{},rec=pdRec(a),c=pdCalc(a);
    const rowOv=(APP_STATE.simulation.rowOverrides||{})[blastRowOverrideKey(a.groupKey,a.row.no)]||{};
    let editedPlan=0,actualCount=0,planCopyCount=0;
    P.querySelectorAll('tr[data-f]').forEach(tr=>{
      const k=tr.dataset.f,planInp=tr.querySelector('.pd-plan-in'),inp=tr.querySelector('.pd-in');
      if(planInp){ const val=a.row[k]; if(document.activeElement!==planInp)planInp.value=val==null?'':val; planInp.title='Asal rencana: '+pdPlanOrigin(a,k,orig,rowOv); }
      const val=rec[k],hasActual=val!=null&&String(val).trim()!=='';
      const copied=hasActual&&/SALIN DARI RENCANA/i.test(String(rec._sources?.[k]||''));
      if(inp&&document.activeElement!==inp) inp.value=hasActual?val:'';
      tr.classList.toggle('pd-has-actual',!!hasActual&&!copied);
      tr.classList.toggle('pd-has-reference',!!copied);
      tr.classList.toggle('pd-edited',!!(planInp&&Object.prototype.hasOwnProperty.call(rowOv,k)));
      if(planInp&&Object.prototype.hasOwnProperty.call(rowOv,k))editedPlan++;
      if(copied)planCopyCount++;else if(hasActual)actualCount++;
      const src=tr.querySelector('[data-origin]'); if(src){src.textContent=pdActualOrigin(rec,k);src.title=src.textContent;src.classList.toggle('pd-origin--empty',!hasActual);src.classList.toggle('pd-origin--copied',!!copied);}
      const ref=tr.querySelector('[data-plan-ref]');
      if(ref){let rv=null;if(k==='subDrill'&&pdNumber(a.row.subDepth)!=null&&pdNumber(a.row.depth)!=null)rv=Math.max(0,Number(a.row.subDepth)-Number(a.row.depth));ref.textContent=rv==null?'Tidak ada di rencana':f2(rv)+' m';}
      const ce=tr.querySelector('[data-calc]'); if(ce){const v=c[k];ce.textContent=Number.isFinite(v)?f2(v,k==='pf'?3:2):'--';}
    });
    P.querySelectorAll('[data-pd-rec]:not(.pd-in)').forEach(el=>{ if(document.activeElement!==el)el.value=rec[el.dataset.pdRec]??''; if(el.dataset.pdRec==='sourceId'&&!rec.sourceId)el.placeholder='mis. lembar kerja blast 12/10, hal. 2'; if(rec[el.dataset.pdRec]!=null&&!PD_IDENT_FIELDS.has(el.dataset.pdRec)){if(/SALIN DARI RENCANA/i.test(String(rec._sources?.[el.dataset.pdRec]||'')))planCopyCount++;else actualCount++;} });
    const status=$('pdStatus'); if(status){status.textContent=`AKTUAL ${actualCount} FIELD`;status.className='kb-badge '+(actualCount?'warn':'ok');status.title=planCopyCount?`${actualCount} field berisi catatan aktual; ${planCopyCount} field hanya salinan rencana (bukan hasil ukur).`:actualCount?'Ada catatan aktual tersimpan.':'Belum ada catatan aktual untuk baris aktif.';}
    const froms=Object.values(rec._sources||{}); const sourceSummary=froms.length?[...new Set(froms)].slice(0,3).join(' / '):'belum ada catatan aktual';
    $('pdSourceInfo').textContent=`BARIS AKTIF: ${a.groupLabel} • ROW ${a.row.no} • RENCANA: ${pdPlanOrigin(a,'holes',orig,rowOv)} • AKTUAL: ${actualCount} catatan${planCopyCount?`; ${planCopyCount} salinan rencana non-ukur`:''} (${sourceSummary}) • ${isManualGroup?'blok manual/import':'template bawaan; perubahan rencana tersimpan sebagai working override'}`;
    const act=actualEngineerGeometry(),totalAn=pdNumber(rec.totalAn)??(pdNumber(rec.holes)>0&&pdNumber(rec.an)!=null?pdNumber(rec.holes)*pdNumber(rec.an):null),tonnage=pdNumber(rec.volume),pfT=tonnage>0&&totalAn!=null?totalAn/tonnage:null;
    $('pdDerived').innerHTML=[['PF tonase • tercatat','kg/t',pdNumber(rec.pf),3],['PF tonase • total charge ÷ tonase','kg/t',pfT,3],['PF volume • '+(pdNumber(rec.volumeM3)>0?'volume aktual':'geometri aktual'),'kg/m³',act?act.pfKgM3:null,3]].map(([l,u,v,d])=>`<div class="kb-metric"><span>${l} <small>${u}</small></span><b>${f2(v,d)}</b></div>`).join('');
  }

  /* ---- TAHAP 2: status validasi + empat kartu pembanding. Semua kartu membaca actualEngineerGeometry() / APP_STATE.geometry.results (state yang sama). */
  const GC_ROWS=[['Burden (B)','B','m',2],['Spacing (S)','S','m',2],['Stemming (T)','T','m',2],['Sub-drill (J)','J','m',2],['Kedalaman lubang','holeDepth','m',2],['Jumlah lubang','holeCount','lubang',0],['Total drilling','totalDrilling','m',2],['Charge / hole','chargeMass','kg',2],['Total charge','totalCharge','kg',1],['Volume / hole','volumePerHole','m³',2],['Total volume','totalVolume','m³',1],['Tonase total','totalTonnage','t',1],['PF tonase','pfKgT','kg/t',3],['PF volume','pfKgM3','kg/m³',3]];
  const GC_TITLE={actual:'GEOMETRY ACTUAL',ash:'R.L. ASH',konya:'CALVIN KONYA',mae:'MAE'};
  /* Status hanya dari pemeriksaan yang benar-benar ada: sanity fisik (geometrySanityCheck / cek konsistensi data aktual), status formula di FORMULA_REGISTRY, dan sumber input (ASSUMPTION/DEMO). */
  function geoStatusOf(key,res){
    if(!res) return {label:'BELUM DIHITUNG',cls:'none',notes:[],stale:false,assume:[],info:[]};
    const fin=Number.isFinite,inv=[],wr=[];
    if(key==='actual'){
      if(res.actualFieldCount===0&&res.planCopyCount>0) return {label:'REFERENSI SAJA',cls:'unv',notes:['Data yang terisi hanya salinan rencana, bukan hasil ukur lapangan. Isi catatan aktual terukur sebelum menilai hasil peledakan.'],stale:false,assume:[],info:[]};
      if(res.planCopyCount>0) wr.push(`${res.planCopyCount} field berasal dari salinan rencana, bukan pengukuran lapangan`);
      if(!(res.holeCount>0)||!(res.B>0)||!(res.S>0)) inv.push('jumlah lubang / burden / spacing kosong atau ≤ 0');
      if(fin(res.T)&&fin(res.holeDepth)&&res.T>=res.holeDepth) inv.push('stemming ≥ kedalaman lubang');
      if(res.pfKgT>0&&fin(res.pfKgTCalc)&&Math.abs(res.pfKgTCalc/res.pfKgT-1)>0.10) wr.push(`PF sumber ${res.pfKgT.toFixed(3)} ≠ total charge ÷ tonase ${res.pfKgTCalc.toFixed(3)} kg/t (selisih >10%)`);
      if(fin(res.chargeLength)&&fin(res.T)&&fin(res.holeDepth)&&Math.abs(res.chargeLength+res.T-res.holeDepth)>0.30) wr.push('stemming + panjang kolom isian ≠ kedalaman lubang (>0,3 m)');
      if(res.chargeMass>0&&res.totalCharge>0&&Math.abs(res.chargeMass*res.holeCount/res.totalCharge-1)>0.03) wr.push('total charge ≠ charge/hole × jumlah lubang (>3%)');
      if(!fin(res.totalTonnage)) wr.push('tonase belum tercatat');
      if(inv.length) return {label:'INVALID',cls:'invalid',notes:inv.concat(wr),stale:false};
      if(wr.length) return {label:'WARNING',cls:'warn',notes:wr,stale:false};
      return {label:'BELUM TERVERIFIKASI',cls:'unv',notes:['Konsisten internal; belum diverifikasi terhadap pengukuran lapangan.'],stale:false};
    }
    const f=FORMULA_REGISTRY[key],stale=methodFreshness(key)==='STALE',reasons=[],warns=res.warnings||[],st=res.sourceTypes||[],gaps=res.criteriaGaps||[],info=res.info||[],assume=[];
    if(stale) reasons.push('STALE: input / baris berubah sejak perhitungan — klik CALCULATE lagi');
    if(f.status!=='VERIFIED') reasons.push(`formula berstatus ${f.status} (bukan VERIFIED)`);
    if(res.demoContaminated) reasons.push('memakai input DEMO EXAMPLE');
    if(st.includes('ASSUMPTION')) assume.push('input berstatus ASSUMPTION (mis. St_f/Sb_f MAE) — isi dari data proyek');
    if(key==='konya'&&res.krDefault) assume.push('Kr = 1,00 DEFAULT (ASUMSI eksplisit; ekstensi proyek, bukan bagian EM 1110-2-3800) — hasil setara rumus tanpa koreksi baris, bukan nilai terukur');
    if(key==='ash'&&res.KbMode==='EMPIRICAL ASH Kb') assume.push('Kb dari tabel kelas empiris yang kasar (tanpa koreksi VOD)');
    assume.forEach(a=>reasons.push('ASUMSI: '+a));
    gaps.forEach(g=>reasons.push('kriteria belum tersedia: '+g));
    const base={stale,assume,info};
    if(res.validity==='INVALID') return Object.assign({label:'INVALID',cls:'invalid',notes:warns.concat(stale?[reasons[0]]:[])},base);
    if(res.validity==='WARNING') return Object.assign({label:'WARNING',cls:'warn',notes:warns.concat(reasons)},base);
    if(reasons.length) return Object.assign({label:'BELUM TERVERIFIKASI',cls:'unv',notes:reasons},base);
    return Object.assign({label:'VALID',cls:'valid',notes:['Lolos pemeriksaan wajib yang terpasang; formula VERIFIED; tanpa asumsi/demo. Ini bukan jaminan desain.']},base);
  }
  function gcTag(key,res,k){
    if(key==='actual'){ const m=String(res.meta?.[k]||''); if(m.includes('PLAN REFERENCE')||m.includes('SALIN DARI RENCANA')||m.includes('ESTIMATED')||m.includes('ASSUMPTION'))return 'est'; if(m.includes('ACTUAL RECORD'))return 'in'; return m.includes('CALCULATED')?'calc':'est'; }
    if(k==='holeCount') return 'in';
    const st=res.sourceTypes||[]; return (res.demoContaminated||st.includes('ASSUMPTION')||st.includes('DEMO_EXAMPLE'))&&!['totalTonnage','volumePerHole','totalVolume'].includes(k)?'est':'calc';
  }
  function renderGeometryCards(){
    const grid=$('geoCardsGrid'); if(!grid) return;
    const act=actualEngineerGeometry(),R=APP_STATE.geometry.results||{},ms=APP_STATE.geometry.methodStatus||{},TAG={in:'INPUT AKTUAL',calc:'HASIL HITUNG',est:'ESTIMASI'};
    const same=r=>act&&r&&r.groupKey===act.groupKey&&r.rowNo===act.rowNo; let allSame=!!act;
    ['actual','ash','konya','mae'].forEach(key=>{
      const el=$('gcCard_'+key); if(!el) return;
      const res=key==='actual'?act:R[key],stt=geoStatusOf(key,res);
      const ref=key==='actual'?(act?{groupKey:act.groupKey,groupLabel:act.groupLabel,rowNo:act.rowNo}:null):(res?res.blastRef:null);
      const okRef=key==='actual'?!!act:same(ref); if(res&&!okRef) allSame=false;
      const calcL=key==='actual'?'DATA TERCATAT':(!res?'BELUM DIHITUNG':(stt.stale?'STALE':'TERHITUNG')),feasL=!res?'BELUM DINILAI':stt.label;
      let h=`<header><h3>${GC_TITLE[key]}</h3><span class="gc-kind">${key==='actual'?'DATA LAPANGAN':'MODEL RUMUS'}</span></header><div class="gc-badges"><span class="gc-calc${stt.stale?' gc-calc--stale':''}" title="Status PERHITUNGAN: hasil dihitung ≠ desain layak">PERHITUNGAN: ${calcL}</span><span class="gc-st gc-st--${res?stt.cls:'none'}" title="Status KELAYAKAN: hasil pemeriksaan wajib yang terpasang">${key==='actual'?'PEMERIKSAAN DATA':'KELAYAKAN'}: ${htmlEscape(feasL)}</span></div>`;
      if(stt.stale) h+='<div class="gc-stale-banner" role="alert">HASIL LAMA — STALE — BUKAN UNTUK KEPUTUSAN. Input/baris berubah; hitung ulang.</div>';
      h+=`<div class="gc-ref${res&&!okRef?' gc-bad':''}">${ref?htmlEscape(ref.groupLabel)+' • ROW '+ref.rowNo+(res&&!okRef?' ⚠ berbeda dari baris aktif':''):(act?htmlEscape(act.groupLabel)+' • ROW '+act.rowNo+' (target)':'--')}</div>`;
      if(!res){
        const m=ms[key],miss=collectEngineInputs(key).missing.map(x=>x.path);
        h+=`<div class="kb-muted">Belum dihitung. ${m&&m.status!=='CALCULATED'?htmlEscape(m.status)+(m.missing.length?': '+htmlEscape(m.missing.join(', ')):''):(miss.length?'Input belum lengkap: '+htmlEscape(miss.join(', ')):'Klik CALCULATE.')}</div>`;
      } else {
        h+='<table class="gc-table"><tbody>'+GC_ROWS.map(([l,k,u,d])=>{ const v=res[k],t=gcTag(key,res,k); return `<tr><td>${l}</td><td class="gc-v">${Number.isFinite(v)?(d===0?Math.round(v):v.toFixed(d)):'--'} <small>${u}</small></td><td><span class="gc-tag gc-tag--${t}" title="${htmlEscape(key==='actual'?(res.meta?.[k]||''):'')}">${TAG[t]}</span></td></tr>`; }).join('')+'</tbody></table>';
        h+=`<ul class="gc-notes">${stt.notes.map(n=>'<li>'+htmlEscape(n)+'</li>').join('')}${(res.info||[]).map(n=>'<li class="gc-info">ℹ '+htmlEscape(n)+'</li>').join('')}</ul>`;
        if(key!=='actual'){ const f=FORMULA_REGISTRY[key]; let x=''; if(key==='ash') x=` • Kb ${Number(res.Kb).toFixed(1)} (${res.KbMode})`; else if(key==='konya') x=` • Kd ${res.Kd} Ks ${res.Kgeo} Kr ${res.Kr}${res.krDefault?' (ASUMSI default)':''} • ${res.firing} • L/B ${Number(res.LbyB).toFixed(2)}`; else x=` • N ${res.N} baris • BI ${Number(res.BI).toFixed(1)}`; h+=`<div class="gc-foot">${f.formulaId} • ${f.version} • ${f.status}${x}</div>`; }
        else h+=`<div class="gc-foot">${htmlEscape(act.source)}</div>`;
      }
      el.className='gc-card '+(key==='actual'?'gc-actual':'gc-model')+(stt.stale?' gc-stale':''); el.innerHTML=h;
    });
    const rl=$('gcRefLine'); if(rl) rl.textContent=act?(allSame?`• referensi seragam: ${act.groupLabel} • ROW ${act.rowNo}`:'• ⚠ ada kartu dengan referensi baris berbeda (hitung ulang)'):'• belum ada baris terpilih';
  }
  function renderGeometryActualCard(){
    const host=$('gaGrid'); if(!host) return; const a=actualEngineerGeometry();
    if(!a){ host.innerHTML='<div class="kb-muted">Belum ada baris aktual terpilih.</div>'; if($('gaSync')){ $('gaSync').textContent='BELUM LENGKAP • belum ada baris terpilih'; $('gaSync').dataset.state='incomplete'; } return; }
    const rec=pdRec(),defs=[['Burden (B)','B','m',2],['Spacing (S)','S','m',2],['Jumlah lubang','holeCount','',0],['Total drilling','totalDrilling','m',2],['Total charge','totalCharge','kg',1],['Tonase total','totalTonnage','t',1],['PF tonase (sumber)','pfKgT','kg/t',3],['PF volume','pfKgM3','kg/m³',3]];
    host.innerHTML=defs.map(([l,k,u,d])=>{ const v=a[k],m=String(a.meta[k]||'').split(' ')[0]; return `<div class="kb-metric ga-m ga-${String(m).toLowerCase().replace(/[^a-z0-9_-]/g,'')}" title="${htmlEscape(a.meta[k]||'')}"><span>${l}${u?' <small>'+u+'</small>':''}</span><b>${Number.isFinite(v)?(d===0?Math.round(v):v.toFixed(d)):'--'}</b><em>${m==='SOURCE'?'INPUT AKTUAL':m==='CALCULATED'?'HASIL HITUNG':''}</em></div>`; }).join('');
    $('gaBadge').textContent=a.userOverride?'USER OVERRIDE':'SOURCE'; $('gaBadge').className='kb-badge '+(a.userOverride?'warn':'ok');
    $('gaSource').textContent=`Blast No. ${rec.blastNo||'—'} • Blok ${rec.block||'—'} • ${rec.date||'tanpa tanggal'} • ${a.source}`;
    const pairs=[['pd_holes','holeCount','jumlah lubang'],['pd_burden','B','burden'],['pd_spacing','S','spacing'],['pd_totalAn','totalCharge','total charge'],['pd_volume','totalTonnage','tonase']];
    const res=pairs.map(([id,k,n])=>{ const el=$(id),raw=el?String(el.value).trim():'',iv=Number(raw),av=Number(a[k]);
      if(!el||raw===''||!Number.isFinite(iv)||!Number.isFinite(av)) return {n,s:'incomplete'};
      return {n,s:Math.abs(iv-av)<=1e-9*Math.max(1,Math.abs(av))?'ok':'mismatch'}; });
    const mm=res.filter(x=>x.s==='mismatch'),inc=res.filter(x=>x.s==='incomplete'),ok=res.filter(x=>x.s==='ok').length,g=$('gaSync');
    if(mm.length){ g.dataset.state='mismatch'; g.textContent=`⚠ TIDAK SINKRON dengan tabel input: ${mm.map(x=>x.n).join(', ')} — muat ulang baris`; }
    else if(inc.length){ g.dataset.state='incomplete'; g.textContent=`BELUM LENGKAP • ${ok}/${res.length} field cocok; belum dapat dibandingkan (kosong / bukan angka): ${inc.map(x=>x.n).join(', ')}`; }
    else { g.dataset.state='ok'; g.textContent=`✓ SINKRON dengan tabel input (${ok}/${res.length} field cocok)`; }
  }
  function pdReloadAll(){ const g=APP_STATE.simulation.template||'group1',n=Number(APP_STATE.simulation.activeBlastRow||1),r=getBlastRow(g,n); if(r) syncActiveBlastInputsToSimulation(r); refreshGeometry(); renderBlastTemplateTable(g); simHydrate(); simVisual(); renderPlanView(); calculateFinancial(); persistWorking(); geometryComparisonInputSync(true); renderGeometryComparison(); }
  function initProjectData(){
    const P=$('projectDataPanel'); if(!P||P.dataset.wired) return; P.dataset.wired='1';
    const groupInput=$('pdGroup');
    const cleanGroupLabel=(raw)=>String(raw??'').trim().replace(/\s+/g,' ').slice(0,80);
    const sameLabel=(a,b)=>String(a||'').trim().replace(/\s+/g,' ').toLowerCase()===String(b||'').trim().replace(/\s+/g,' ').toLowerCase();
    const resolveGroup=(raw)=>{const q=cleanGroupLabel(raw).toLowerCase();if(!q)return null;const all=Object.entries(BLAST_SHEET_ROWS);return all.find(([k,v])=>v.isManual&&(k.toLowerCase()===q||sameLabel(v.label,q)))||all.find(([k,v])=>k.toLowerCase()===q||sameLabel(v.label,q))||null;};
    const activateGroup=(k)=>{const g=BLAST_SHEET_ROWS[k];if(!g||!Array.isArray(g.rows)||!g.rows.length)return false;APP_STATE.simulation.template=k;APP_STATE.simulation.groupLabel=g.label||k;APP_STATE.simulation.activeBlastRow=g.rows[0].no;populateBlastRowSelect();loadBlastSheetRow(k,g.rows[0].no);populateBlastRowSelect();renderProjectData();return true;};
    const activateOrCreateManual=(raw)=>{
      const label=cleanGroupLabel(raw);if(!label)return false;
      const created=getOrCreateManualBlastGroup(label);
      if(!created)return false;
      const g=BLAST_SHEET_ROWS[created.key];
      if(!activateGroup(created.key))return false;
      if(created.isNew)audit('Buat blok manual','',`${g.label} • Row 1 kosong; seluruh parameter belum diisi`,'USER INPUT','CREATE MANUAL BLAST GROUP');
      persistWorking();refreshAll();return true;
    };
    /* Satukan kontrol Blast Plan yang masih diperlukan ke panel terpadu; panel kartu lama disembunyikan oleh CSS. */
    const actionHost=$('pdPlanActions'),legacyPlanPanel=$('blastPlanPanel'),mergedActionRow=P.querySelector('.pd-merged-action-row');
    if(actionHost&&legacyPlanPanel){
      const move=(node)=>{if(node)actionHost.appendChild(node);};
      move(legacyPlanPanel.querySelector('.kb-plan-actions'));
      move(legacyPlanPanel.querySelector('.kb-calc-result'));
      ['validationErrors','geometrySource','screeningNote'].forEach(id=>move($(id)));
      const auto=$('btnAutoRecalcBlastRow');if(auto)actionHost.insertBefore(auto,actionHost.firstChild);
    }
    const clearRecBtn=$('pdBtnClearRec');if(clearRecBtn&&mergedActionRow)mergedActionRow.appendChild(clearRecBtn);
    const copyPlanBtn=$('pdBtnCopyPlan');
    copyPlanBtn?.addEventListener('click',()=>{
      const a=getActiveBlastRowForComparison();if(!a)return;
      const store=pdRecStore(),key=a.groupKey+'::'+a.row.no,rec=store[key]||(store[key]={});
      const existingFields=Object.keys(rec).filter(k=>k!=='_sources'&&!PD_IDENT_FIELDS.has(k)&&rec[k]!=null&&rec[k]!==''),existingCopied=existingFields.filter(k=>/SALIN DARI RENCANA/i.test(String(rec._sources?.[k]||''))).length,existingActual=existingFields.length-existingCopied;
      if(existingFields.length&&!window.confirm(`Baris ini sudah memiliki ${existingActual} catatan aktual dan ${existingCopied} salinan rencana non-ukur. Field yang tersedia dari Blast Plan akan ditimpa sebagai SALIN DARI RENCANA. Catatan aktual khusus pengukuran (kedalaman terukur, hole meter, volume bank) tetap dipertahankan. Lanjutkan?`))return;
      const map=['holes','depth','subDepth','burden','spacing','stemming','charging','an','dn','totalAn','totalDn','det','fuel','dev','rc','bsr','unit','volume','pf'];
      if(!rec._sources||typeof rec._sources!=='object')rec._sources={};
      let copied=0;
      map.forEach(k=>{const v=a.row[k];if(v==null||String(v).trim()==='')return;rec[k]=v;rec._sources[k]='SALIN DARI RENCANA • REFERENSI NON-UKUR';copied++;});
      const bench=pdNumber(a.row.depth),fullDepth=pdNumber(a.row.subDepth);
      if(bench!=null&&fullDepth!=null){rec.subDrill=Math.max(0,fullDepth-bench);rec._sources.subDrill='SALIN DARI RENCANA • REFERENSI NON-UKUR';copied++;}
      // DepthMeasured, HoleMeter, dan VolumeM3 sengaja tidak diisi: harus berasal dari catatan aktual.
      audit('Salin Blast Plan ke Aktual','',`${a.groupLabel} • Row ${a.row.no} • ${copied} field; sumber SALIN DARI RENCANA`,'USER ACTION','COPY PLAN TO ACTUAL');
      persistWorking();renderProjectData();geometryComparisonInputSync(true);renderGeometryComparison();renderGeometryActualCard();renderGeometryCards();refreshAll();
      const st=$('pdCopyStatus');if(st)st.textContent=`${copied} field disalin dari rencana. Kedalaman terukur, hole meter, dan volume bank tetap kosong sampai ada catatan lapangan.`;
    });

    /* Import CSV/XLSX: preview dan validasi dulu; selalu membentuk blok manual baru, tidak menimpa template. */
    const importFile=$('pdImportFile'),importBtn=$('pdBtnImport'),applyImportBtn=$('pdBtnApplyImport'),importStatus=$('pdImportStatus'),importPreview=$('pdImportPreview'),importMapping=$('pdImportMapping'),importModal=$('pdImportModal');
    let pdLastImportFile=null; const pdImportColumnOverrides=Object.create(null);
    const openImportModal=()=>{if(!importModal)return;importModal.classList.add('is-open');importModal.setAttribute('aria-hidden','false');};
    const closeImportModal=()=>{if(!importModal)return;importModal.classList.remove('is-open');importModal.setAttribute('aria-hidden','true');$('pdBtnOpenImportModal')?.focus();};
    $('pdBtnOpenImportModal')?.addEventListener('click',openImportModal);
    $('btnClosePdImport')?.addEventListener('click',closeImportModal);$('btnCancelPdImport')?.addEventListener('click',closeImportModal);
    importModal?.addEventListener('click',e=>{if(e.target===importModal)closeImportModal();});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&importModal?.classList.contains('is-open'))closeImportModal();});
    if(importStatus&&$('pdImportInlineStatus')){new MutationObserver(()=>{$('pdImportInlineStatus').textContent=importStatus.textContent;}).observe(importStatus,{childList:true,subtree:true,characterData:true});}
    const hdrAliases={
      groupLabel:['group','groupname','blastgroup','grouplokasi','block','blok','lokasi','blastlocation'],
      rowNo:['row','rowno','rownumber','baris','nobar','nomorbaris','no','urut','urutan'],
      blastNo:['blastno','blastnumber','nomorledakan'],block:['blockid','blokid'],location:['lokasiledak','site'],date:['date','tanggal','blastdate'],sourceId:['sourceid','datasource','sumberdata','worksheet'],
      holes:['holes','holecount','totalholes','jumlahholes','jumlahhole','jumlahlubang','jumlahlubangbor','jumlahbor','jmlhole','jmlbor'],
      depth:['depth','depthm','benchheight','benchheightm','benchdepth','tinggibench','tinggijenjang'],
      subDepth:['subdepth','subdepthm','depthsub','totaldepth','totaldepthm','kedalamanlubangrencana','depthplussub'],
      depthMeasured:['depthmeasured','measureddepth','actualdepthmeasured','kedalamanaktualterukur','kedalamanterukur'],
      holeMeter:['holemeter','holemeterm','totalholemeter','totalmeterbor','meterboraktual','holemeteraktualtotal'],
      burden:['burden','burdenm','b','bm'], spacing:['spacing','spacingm','s','sm','spasi'],stemming:['stemming','stemmingm','t','tm'],
      subDrill:['subdrill','subdrillm','subdrilltercatat','subdrillactual'],
      charging:['charging','chargingm','charginglength','chargelength','chargelengthm','panjangkolomisian'],
      an:['an','ankgperhole','anperhole','anperholekg','chargeperholean','totalanperhole','bahanpeledakperlubang'],
      dn:['dn','dnkgperhole','dnperhole','dnperholekg','chargeperholedn'],
      totalAn:['totalan','totalankg','totalchargean','totalcharge','totalchargekg','totalhandakan','totalanfo'],
      totalDn:['totaldn','totaldnkg','totalchargedn'],det:['det','detonator','detonatorpcs','jumlahdetonator','jumlahdet'],
      fuel:['fuel','fueloil','fueloill','fueloilliter','bbm'],unit:['unit','satuan'],dev:['dev','dev75','devgt75','dev75pct'],rc:['rc','rc14','rcgt14'],bsr:['bsr','bsr25','bsrgt25'],
      volumeM3:['volumem3','volumeactualm3','actualvolume','volumebank','volumebankm3','volumeaktualm3'],
      volume:['volume','volumet','volumetonne','volumeton','tonnage','tonnes','tonase','tonasetotal','actualtonnage'],
      pf:['pf','pfkgt','pfkgpert','pfkgperton','pfkgpertonne','powderfactor','powderfactorperton','pfrec80'],
      cw:['cw','cutwidth','lebarcut'],
    };
    const headerFieldMap=new Map();Object.entries(hdrAliases).forEach(([field,aliases])=>aliases.forEach(a=>headerFieldMap.set(a,field)));
    const normHeader=(h)=>String(h??'').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'');
    const parseImportHeader=(raw)=>{
      let h=normHeader(raw),mode='auto';
      for(const [prefix,m] of [['actual','actual'],['aktual','actual'],['rencana','plan'],['planned','plan'],['plan','plan']]){if(h.startsWith(prefix)&&h.length>prefix.length){h=h.slice(prefix.length);mode=m;break;}}
      // Unit qualifiers can appear after a header's main token.
      let field=headerFieldMap.get(h)||null;
      if(!field){
        const ordered=[...headerFieldMap.entries()].sort((a,b)=>b[0].length-a[0].length);
        const hit=ordered.find(([alias])=>alias.length>=3&&h.startsWith(alias));if(hit)field=hit[1];
      }
      if(field==='groupLabel'||field==='rowNo')mode='meta';
      if(mode==='auto')mode=PD_ACTUAL_ONLY.has(field)?'actual':'plan';
      return {field,mode,header:String(raw??'')};
    };
    const importFieldNames={groupLabel:'Group / blok',rowNo:'Row / baris',blastNo:'Blast No.',block:'Blok',location:'Lokasi',date:'Tanggal',sourceId:'ID sumber',...Object.fromEntries(Object.keys(hdrAliases).filter(k=>!['groupLabel','rowNo','blastNo','block','location','date','sourceId'].includes(k)).map(k=>[k,k]))};
    const importFieldOptions=[['','Lewati kolom'],...Object.entries(importFieldNames).map(([v,l])=>[v,l])];
    const importModes=[['auto','Otomatis'],['plan','Rencana'],['actual','Aktual']];
    const renderImportMapping=(columnMap)=>{
      if(!importMapping)return;
      if(!columnMap?.length){importMapping.hidden=true;importMapping.innerHTML='';return;}
      importMapping.hidden=false;
      importMapping.innerHTML='<div class="kb-muted" style="margin-bottom:7px"><b>Pemetaan kolom</b> — kolom yang tidak dikenali dapat dipetakan manual. Kolom Group dan Row menjadi metadata.</div><table><thead><tr><th>Kolom file</th><th>Field aplikasi</th><th>Jenis data</th></tr></thead><tbody>'+columnMap.map((c,i)=>{
        const ov=pdImportColumnOverrides[i],field=ov?((Object.prototype.hasOwnProperty.call(ov,'field'))?ov.field:(c.field||'')):(c.field||''),mode=(ov&&ov.mode)|| (c.mode==='meta'?'auto':c.mode);
        const fieldOptions=importFieldOptions.map(([v,l])=>`<option value="${htmlEscape(v)}" ${v===field?'selected':''}>${htmlEscape(l)}</option>`).join('');
        const modeOptions=importModes.map(([v,l])=>`<option value="${v}" ${v===mode?'selected':''}>${l}</option>`).join('');
        return `<tr><td>${htmlEscape(c.h)}</td><td><select aria-label="Pemetaan kolom ${htmlEscape(c.h)}" data-import-map-field="1" data-import-map-index="${i}">${fieldOptions}</select></td><td><select aria-label="Jenis data ${htmlEscape(c.h)}" data-import-map-mode="1" data-import-map-index="${i}" ${field==='groupLabel'||field==='rowNo'?'disabled':''}>${modeOptions}</select></td></tr>`;
      }).join('')+'</tbody></table>';
    };
    const numericImportFields=new Set([...PD_NUM].filter(k=>!['recordedCost','fieldX80','fieldToe','fieldBackbreak','fieldOverbreak','fieldPPV','fieldFlyrock','fieldProd'].includes(k)));
    const parseImportNumber=(value)=>{
      if(typeof value==='number')return Number.isFinite(value)?value:null;
      let v=String(value??'').trim();if(!v)return null;
      v=v.replace(/\s+/g,'');
      if(v.includes(',')&&v.includes('.')){if(v.lastIndexOf(',')>v.lastIndexOf('.'))v=v.replace(/\./g,'').replace(',','.');else v=v.replace(/,/g,'');}
      else if(v.includes(','))v=v.replace(',','.');
      const n=Number(v);return Number.isFinite(n)?n:NaN;
    };
    const renderImportPreview=(pending,errors=[])=>{
      if(!importPreview||!importStatus||!applyImportBtn)return;
      importPreview.hidden=false;
      const groups=[...new Set((pending?.rows||[]).map(r=>r.groupLabel))];
      const mapped=[...new Set((pending?.rows||[]).flatMap(r=>[...Object.keys(r.plan),...Object.keys(r.actual)]))];
      const previewRows=(pending?.rows||[]).slice(0,6);
      let html=`<div class="kb-muted">${pending?`${pending.rows.length} baris data • ${groups.length} grup • field dikenali: ${htmlEscape(mapped.join(', ')||'tidak ada')}`:'File belum berhasil dibaca.'}</div>`;
      if(errors.length)html+='<div class="pd-import-error" role="alert"><b>Belum dapat diimpor:</b><ul>'+errors.slice(0,12).map(e=>'<li>'+htmlEscape(e)+'</li>').join('')+'</ul></div>';
      if(previewRows.length){html+='<table><thead><tr><th>Group</th><th>Row</th><th>Plan terpetakan</th><th>Aktual terpetakan</th></tr></thead><tbody>'+previewRows.map(r=>`<tr><td>${htmlEscape(r.groupLabel)}</td><td>${htmlEscape(r.rowNo)}</td><td>${htmlEscape(Object.entries(r.plan).map(([k,v])=>k+'='+v).join(' • ')||'—')}</td><td>${htmlEscape(Object.entries(r.actual).map(([k,v])=>k+'='+v).join(' • ')||'—')}</td></tr>`).join('')+'</tbody></table>';if(pending.rows.length>previewRows.length)html+=`<div class="kb-muted">Pratinjau menampilkan ${previewRows.length} dari ${pending.rows.length} baris.</div>`;}
      importPreview.innerHTML=html;applyImportBtn.disabled=!!errors.length||!pending||!pending.rows.length;
    };
    async function stageImport(file){
      pdPendingImport=null;applyImportBtn.disabled=true;if(importPreview){importPreview.hidden=true;importPreview.innerHTML='';}
      if(!file){importStatus.textContent='Belum ada file yang dipilih.';return;}
      if(file!==pdLastImportFile){pdLastImportFile=file;Object.keys(pdImportColumnOverrides).forEach(k=>delete pdImportColumnOverrides[k]);}
      const ext=(file.name.split('.').pop()||'').toLowerCase(),tooBig=kbFileTooBig(file,ext==='csv'?'csv':'sheet');
      if(tooBig){importStatus.textContent=tooBig;return;}
      if(!['csv','xlsx','xls'].includes(ext)){importStatus.textContent='Format tidak didukung. Pilih CSV atau Excel (.xlsx/.xls).';return;}
      try{
        let rows=[],parseErrors=[],headers=[];
        if(ext==='csv'){
          if(typeof Papa==='undefined')throw new Error('Parser CSV tidak tersedia pada paket ini.');
          const parsed=Papa.parse(await file.text(),{header:true,skipEmptyLines:'greedy',dynamicTyping:false});
          rows=parsed.data||[];headers=parsed.meta?.fields||[];parseErrors=(parsed.errors||[]).slice(0,8).map(e=>`CSV baris ${Number(e.row)+2}: ${e.message}`);
        }else{
          if(typeof XLSX==='undefined')throw new Error('Parser Excel tidak tersedia pada paket ini.');
          const buf=await file.arrayBuffer(),wb=XLSX.read(buf,{type:'array',cellFormula:false,cellHTML:false,cellStyles:false,bookVBA:false,sheetRows:10002});
          if(!wb.SheetNames?.length)throw new Error('Workbook tidak memiliki sheet.');
          if(wb.SheetNames.length>50)throw new Error('Workbook lebih dari 50 sheet; kurangi jumlah sheet.');
          const ws=wb.Sheets[wb.SheetNames[0]];if(!ws)throw new Error('Sheet pertama tidak dapat dibaca.');
          rows=XLSX.utils.sheet_to_json(ws,{defval:'',raw:true,blankrows:false});headers=rows.length?Object.keys(rows[0]):[];
        }
        if(rows.length>5000)throw new Error('Maksimal 5.000 baris per file agar impor tetap terkontrol.');
        const columnMap=headers.map((h,i)=>{
          const inferred=parseImportHeader(h),ov=pdImportColumnOverrides[i];
          if(!ov)return {h,index:i,...inferred};
          const field=Object.prototype.hasOwnProperty.call(ov,'field')?(ov.field||null):(inferred.field||null);
          const requestedMode=ov.mode||inferred.mode||'auto';
          let mode=(field==='groupLabel'||field==='rowNo')?'meta':(['blastNo','block','location','date','sourceId'].includes(field)?'actual':(requestedMode==='auto'?(PD_ACTUAL_ONLY.has(field)?'actual':'plan'):requestedMode));
          return {h,index:i,field,mode,header:String(h??'')};
        });
        renderImportMapping(columnMap);
        const recognised=columnMap.filter(c=>c.field&& !['groupLabel','rowNo'].includes(c.field));
        if(!recognised.length)parseErrors.push('Tidak ditemukan kolom parameter yang dikenali. Gunakan tombol UNDUH TEMPLATE CSV sebagai acuan.');
        const seenMapped=new Map();columnMap.forEach(c=>{if(!c.field||['groupLabel','rowNo'].includes(c.field))return;const sig=c.mode+':'+c.field;if(seenMapped.has(sig))parseErrors.push(`Kolom "${seenMapped.get(sig)}" dan "${c.h}" memetakan parameter ${c.field} yang sama (${c.mode}); sisakan satu kolom.`);else seenMapped.set(sig,c.h);});
        const fileBase=file.name.replace(/\.[^.]+$/,'').replace(/[_-]+/g,' ').trim().slice(0,80)||'IMPORT BLAST';
        const fallback=cleanGroupLabel($('pdImportGroup')?.value||fileBase);
        if(!columnMap.some(c=>c.field==='groupLabel')&&!fallback)parseErrors.push('Isi Nama blok default karena file tidak memiliki kolom Group.');
        if($('pdImportGroup')&&!$('pdImportGroup').value.trim())$('pdImportGroup').value=fallback;
        const staged=[],seen=new Set();let dataRows=0;
        rows.forEach((obj,i)=>{
          const item={groupLabel:fallback||fileBase,rowNo:null,plan:{},actual:{},sourceLine:i+2};
          let rowNoValue=null;
          columnMap.forEach(c=>{
            if(!c.field)return;const raw=obj[c.h]??obj[headers[c.index]];if(raw==null||String(raw).trim()==='')return;
            if(c.field==='groupLabel'){item.groupLabel=cleanGroupLabel(raw)||fallback||fileBase;return;}
            if(c.field==='rowNo'){rowNoValue=raw;return;}
            if(c.field==='blastNo'||c.field==='block'||c.field==='location'||c.field==='date'||c.field==='sourceId'){
              item.actual[c.field]=String(raw).trim();return;
            }
            if(c.mode==='actual'||PD_ACTUAL_ONLY.has(c.field)){
              if(numericImportFields.has(c.field)){const n=parseImportNumber(raw);if(n===null)return;if(Number.isNaN(n)||n<0){parseErrors.push(`Baris ${i+2}: ${c.header} harus angka ≥ 0.`);return;}if(['holes','det'].includes(c.field)&&!Number.isInteger(n)){parseErrors.push(`Baris ${i+2}: ${c.header} harus bilangan bulat.`);return;}item.actual[c.field]=n;}
              else item.actual[c.field]=String(raw).trim();
            }else{
              if(!PD_PLAN_FIELDS.has(c.field))return;
              if(numericImportFields.has(c.field)){const n=parseImportNumber(raw);if(n===null)return;if(Number.isNaN(n)||n<0){parseErrors.push(`Baris ${i+2}: ${c.header} harus angka ≥ 0.`);return;}if(['holes','det'].includes(c.field)&&!Number.isInteger(n)){parseErrors.push(`Baris ${i+2}: ${c.header} harus bilangan bulat.`);return;}item.plan[c.field]=n;}
              else item.plan[c.field]=String(raw).trim();
            }
          });
          const nrow=rowNoValue==null?i+1:parseImportNumber(rowNoValue);
          if(nrow==null||Number.isNaN(nrow)||!Number.isInteger(nrow)||nrow<1){parseErrors.push(`Baris ${i+2}: Row/Baris harus bilangan bulat ≥ 1.`);return;}
          item.rowNo=nrow;
          if(!item.groupLabel){parseErrors.push(`Baris ${i+2}: nama group kosong.`);return;}
          if(['burden','spacing'].some(k=>item.plan[k]!=null&&item.plan[k]<=0))parseErrors.push(`Baris ${i+2}: burden dan spacing pada rencana harus > 0 bila diisi.`);
          if(['burden','spacing'].some(k=>item.actual[k]!=null&&item.actual[k]<=0))parseErrors.push(`Baris ${i+2}: burden dan spacing aktual harus > 0 bila diisi.`);
          if(!Object.keys(item.plan).length&&!Object.keys(item.actual).length)return;
          const dupe=item.groupLabel.toLowerCase()+'::'+item.rowNo;if(seen.has(dupe)){parseErrors.push(`Group ${item.groupLabel}: Row ${item.rowNo} duplikat.`);return;}seen.add(dupe);staged.push(item);dataRows++;
        });
        if(!staged.length)parseErrors.push('Tidak ada baris berisi data parameter yang dapat diimpor.');
        if(!staged.some(r=>Object.keys(r.plan).length||Object.keys(r.actual).length))parseErrors.push('Setiap baris harus memiliki sekurang-kurangnya satu nilai rencana atau aktual.');
        // Keep parser warnings/errors separate; only clean files can be applied.
        pdPendingImport=parseErrors.length?null:{fileName:file.name,extension:ext,rows:staged,headers,createdAt:new Date().toISOString()};
        importStatus.textContent=`File terbaca: ${file.name} • ${staged.length} baris berisi data • ${parseErrors.length?parseErrors.length+' masalah validasi':'siap ditinjau'}.`;
        renderImportPreview(pdPendingImport||{rows:staged},parseErrors);
        if(parseErrors.length)applyImportBtn.disabled=true;
      }catch(err){pdPendingImport=null;importStatus.textContent='Gagal membaca file: '+(err?.message||String(err));renderImportPreview(null,[err?.message||String(err)]);applyImportBtn.disabled=true;}
    }
    importBtn?.addEventListener('click',()=>{openImportModal();importFile?.click();});
    importFile?.addEventListener('change',e=>{const file=e.target.files?.[0];if(file){openImportModal();stageImport(file);}});
    importMapping?.addEventListener('change',e=>{
      const el=e.target;if(!el.matches('[data-import-map-field],[data-import-map-mode]')||!pdLastImportFile)return;
      const i=Number(el.dataset.importMapIndex);if(!Number.isInteger(i)||i<0)return;
      const prior=pdImportColumnOverrides[i]||{};pdImportColumnOverrides[i]={...prior};
      if(el.hasAttribute('data-import-map-field'))pdImportColumnOverrides[i].field=el.value;
      if(el.hasAttribute('data-import-map-mode'))pdImportColumnOverrides[i].mode=el.value;
      stageImport(pdLastImportFile);
    });
    $('pdBtnDownloadTemplate')?.addEventListener('click',()=>{ 

      const headers=['Group','Row','Holes','Burden_m','Spacing_m','Depth_m','SubDepth_m','Stemming_m','Charging_m','AN_kg_per_hole','DN_kg_per_hole','TotalAN_kg','TotalDN_kg','Detonator_pcs','FuelOil_L','Unit','Volume_t','PF_kg_per_t','DEV_pct','RC','BSR','Actual_Holes','Actual_Depth_m','Actual_SubDepth_m','Actual_DepthMeasured_m','Actual_HoleMeter_m','Actual_SubDrill_m','Actual_Volume_m3','Actual_Burden_m','Actual_Spacing_m','Actual_Stemming_m','Actual_Charging_m','Actual_AN_kg_per_hole','Actual_DN_kg_per_hole','Actual_TotalAN_kg','Actual_TotalDN_kg','Actual_Detonator_pcs','Actual_FuelOil_L','Actual_Unit','Actual_Tonnage_t','Actual_PF_kg_per_t','Actual_DEV_pct','Actual_RC','Actual_BSR'];
      downloadText('KarstBlast_Blast_Import_Template.csv','\ufeff'+headers.join(',')+'\r\n','text/csv');
    });
    applyImportBtn?.addEventListener('click',()=>{
      const pending=pdPendingImport;if(!pending||applyImportBtn.disabled)return;
      const chosenLabels=new Map(),created=[],nameAdjustments=[];
      const currentLabels=()=>Object.values(BLAST_SHEET_ROWS).map(g=>String(g.label||'').toLowerCase());
      const uniqueImportedLabel=(raw)=>{
        if(chosenLabels.has(raw.toLowerCase()))return chosenLabels.get(raw.toLowerCase());
        let label=cleanGroupLabel(raw)||'IMPORT BLAST',all=currentLabels();
        if(all.includes(label.toLowerCase())){const base=label+' • IMPORT';label=base;let n=2;while(currentLabels().includes(label.toLowerCase())||[...chosenLabels.values()].some(x=>x.toLowerCase()===label.toLowerCase()))label=base+' '+n++;nameAdjustments.push(`${raw} → ${label}`);}
        chosenLabels.set(raw.toLowerCase(),label);return label;
      };
      const grouped=new Map();pending.rows.forEach(row=>{const label=uniqueImportedLabel(row.groupLabel);if(!grouped.has(label))grouped.set(label,[]);grouped.get(label).push(row);});
      const srcLabel=`IMPORT ${pending.extension.toUpperCase()} • ${pending.fileName}`;
      grouped.forEach((rows,label)=>{
        let key='manual_'+manualBlockSlug(label),seed=key,n=2;while(BLAST_SHEET_ROWS[key])key=seed+'_'+n++;
        const planRows=rows.sort((a,b)=>a.rowNo-b.rowNo).map(item=>{const row=blankManualBlastRow(item.rowNo);Object.entries(item.plan).forEach(([k,v])=>{row[k]=v;});return row;});
        const g={key,label,face:'Manual / Imported',totalHoles:planRows.reduce((sum,r)=>sum+(Number(r.holes)||0),0),rows:planRows,isManual:true,createdAt:new Date().toISOString(),importSource:srcLabel};
        BLAST_SHEET_ROWS[key]=g;
        if(!Array.isArray(APP_STATE.simulation.customBlocks))APP_STATE.simulation.customBlocks=[];
        APP_STATE.simulation.customBlocks.push({key,label,face:g.face,totalHoles:g.totalHoles,rows:planRows.map(r=>({...r})),isManual:true,createdAt:g.createdAt,importSource:srcLabel});
        rows.forEach(item=>{const actual={...item.actual};if(Object.keys(actual).length){actual._sources={};Object.keys(actual).forEach(f=>{actual._sources[f]=srcLabel;});pdRecStore()[key+'::'+item.rowNo]=actual;}});
        created.push({key,label,rows:planRows});
      });
      const first=created[0];if(!first){importStatus.textContent='Tidak ada baris yang berhasil diimpor.';return;}
      APP_STATE.simulation.template=first.key;APP_STATE.simulation.groupLabel=first.label;APP_STATE.simulation.activeBlastRow=first.rows[0].no;
      syncManualBlastGroupStorage(first.key);populateBlastRowSelect();loadBlastSheetRow(first.key,first.rows[0].no);populateBlastRowSelect();
      audit('Blast data import','',`${pending.fileName} • ${pending.rows.length} row • ${created.length} group`,'USER IMPORT','IMPORT MANUAL BLAST DATA');
      persistWorking();geometryComparisonInputSync(true);renderProjectData();renderGeometryComparison();renderGeometryActualCard();renderGeometryCards();refreshAll();
      importStatus.textContent=`Impor selesai: ${pending.rows.length} baris, ${created.length} blok manual. Template sumber bawaan tidak diubah.${nameAdjustments.length?' Nama bentrok diubah: '+nameAdjustments.join('; '):''}`;
      if(importPreview){importPreview.hidden=true;importPreview.innerHTML='';}if(importMapping){importMapping.hidden=true;importMapping.innerHTML='';}applyImportBtn.disabled=true;pdPendingImport=null;if(importFile)importFile.value='';pdLastImportFile=null;Object.keys(pdImportColumnOverrides).forEach(k=>delete pdImportColumnOverrides[k]);closeImportModal();
    });

    groupInput.addEventListener('change',()=>{
      const label=cleanGroupLabel(groupInput.value);if(!label)return;
      const hit=resolveGroup(label);
      if(hit){activateGroup(hit[0]);persistWorking();return;}
      // Ketik nama yang tidak ada di daftar lalu keluar dari kolom = langsung buat blok manual kosong.
      activateOrCreateManual(label);
    });
    groupInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('pdBtnManualGroup').click();}});
    $('pdBtnManualGroup').addEventListener('click',()=>{
      const label=cleanGroupLabel(groupInput.value);
      if(!label){$('pdSourceInfo').textContent='Ketik nama blok terlebih dahulu.';groupInput.focus();return;}
      // Tombol ini selalu membuat/memilih blok MANUAL. Tidak pernah diam-diam mengaktifkan baris template.
      // Jika namanya sama dengan template, beri akhiran supaya sumber tidak ambigu.
      const existingManual=Object.entries(BLAST_SHEET_ROWS).find(([k,g])=>g.isManual&&sameLabel(g.label,label));
      if(existingManual){activateGroup(existingManual[0]);persistWorking();refreshAll();return;}
      const templateCollision=Object.entries(BLAST_SHEET_ROWS).some(([k,g])=>!g.isManual&&sameLabel(g.label,label));
      let manualLabel=templateCollision?`${label} • MANUAL`:label, suffix=2;
      while(Object.entries(BLAST_SHEET_ROWS).some(([k,g])=>!g.isManual&&sameLabel(g.label,manualLabel))) manualLabel=`${label} • MANUAL ${suffix++}`;
      groupInput.value=manualLabel;
      activateOrCreateManual(manualLabel);
    });
    $('pdBtnAddManualRow').addEventListener('click',()=>{
      const key=APP_STATE.simulation.template,g=BLAST_SHEET_ROWS[key];
      if(!g?.isManual){$('pdSourceInfo').textContent='Pilih atau buat BLOK MANUAL terlebih dahulu sebelum menambah baris.';return;}
      const no=addManualBlastRow(key);if(!no)return;
      APP_STATE.simulation.activeBlastRow=no;loadBlastSheetRow(key,no);populateBlastRowSelect();renderProjectData();
      audit('Tambah baris manual',`${g.label} / row sebelumnya`,`${g.label} / Row ${no}`,'USER ACTION','ADD MANUAL BLAST ROW');persistWorking();refreshAll();
    });
    $('pdBtnDeleteManualGroup')?.addEventListener('click',()=>{
      const key=APP_STATE.simulation.template,g=BLAST_SHEET_ROWS[key];
      if(!g?.isManual){$('pdSourceInfo').textContent='Penghapusan hanya tersedia untuk blok MANUAL; template bawaan dilindungi.';return;}
      if(!window.confirm(`Hapus seluruh blok manual "${g.label}" beserta catatan aktual, override rencana, dan Wipfrag miliknya? Tindakan tidak dapat dibatalkan.`))return;
      const label=g.label, prefix=key+'::';
      delete BLAST_SHEET_ROWS[key];
      APP_STATE.simulation.customBlocks=(APP_STATE.simulation.customBlocks||[]).filter(x=>x.key!==key);
      Object.keys(pdRecStore()).forEach(k=>{if(k.startsWith(prefix))delete pdRecStore()[k];});
      Object.keys(APP_STATE.simulation.rowOverrides||{}).forEach(k=>{if(k.startsWith(prefix))delete APP_STATE.simulation.rowOverrides[k];});
      Object.keys(APP_STATE.kuzram.wipBy||{}).forEach(k=>{if(k.startsWith(key+'|'))delete APP_STATE.kuzram.wipBy[k];});
      const fallback=BLAST_SHEET_ROWS.group1?.rows?.[0];APP_STATE.simulation.template='group1';APP_STATE.simulation.groupLabel=BLAST_SHEET_ROWS.group1?.label||'GROUP I • J-13';APP_STATE.simulation.activeBlastRow=fallback?.no||1;
      $('pdGroup').value=APP_STATE.simulation.groupLabel;populateBlastRowSelect();loadBlastSheetRow('group1',APP_STATE.simulation.activeBlastRow);populateBlastRowSelect();renderProjectData();
      audit('Hapus blok manual',label,'Blok dan data terkait dihapus','USER ACTION','DELETE MANUAL BLAST GROUP');persistWorking();refreshAll();
    });
    /* TAHAP-1: hapus satu baris manual dengan konfirmasi, lengkap dengan catatan aktual / override / Wipfrag baris itu. */
    $('pdBtnDeleteManualRow')?.addEventListener('click',()=>{
      const key=APP_STATE.simulation.template, g=BLAST_SHEET_ROWS[key];
      if(!g?.isManual){ $('pdSourceInfo').textContent='Penghapusan baris hanya tersedia untuk blok MANUAL; baris template bawaan dilindungi (gunakan KEMBALIKAN KE NILAI SUMBER).'; return; }
      const no=Number(APP_STATE.simulation.activeBlastRow||g.rows?.[0]?.no||1);
      if(!Array.isArray(g.rows)||!g.rows.some(r=>Number(r.no)===no)){ $('pdSourceInfo').textContent='Baris aktif tidak ditemukan pada blok ini; pilih baris terlebih dahulu.'; return; }
      if(g.rows.length<=1){ $('pdSourceInfo').textContent='Blok manual harus menyisakan sekurang-kurangnya satu baris. Untuk membuang seluruh blok gunakan HAPUS BLOK MANUAL.'; return; }
      if(!window.confirm(`Hapus Row ${no} dari blok manual "${g.label}"? Catatan aktual, override rencana, dan Wipfrag baris ini ikut terhapus dan tidak dapat dibatalkan.`)) return;
      const removed=deleteManualBlastRow(key,no);
      if(removed===false||removed===null){ $('pdSourceInfo').textContent='Baris tidak dihapus (blok terakhir atau baris tidak ditemukan).'; return; }
      const nextNo=(g.rows.find(r=>Number(r.no)>=no)||g.rows[0]).no;
      APP_STATE.simulation.activeBlastRow=Number(nextNo);
      loadBlastSheetRow(key,nextNo); populateBlastRowSelect(); renderProjectData();
      audit('Hapus baris manual',`${g.label} / Row ${no}`,`${g.label} • sisa ${removed} baris`,'USER ACTION','DELETE MANUAL BLAST ROW');
      persistWorking(); refreshAll();
      $('pdSourceInfo').textContent=`Row ${no} dihapus dari blok ${g.label} • sisa ${removed} baris.`;
    });
    $('pdRow').addEventListener('change',()=>{ loadBlastSheetRow(APP_STATE.simulation.template,Number($('pdRow').value)); populateBlastRowSelect(); renderProjectData(); });
    $('pdBtnLoad').addEventListener('click',()=>{ loadBlastSheetRow(APP_STATE.simulation.template,Number($('pdRow').value||APP_STATE.simulation.activeBlastRow||1)); populateBlastRowSelect(); });
    const twoClick=(id,label,fn)=>{ const b=$(id); let t=null; b.addEventListener('click',()=>{ if(!t){ b.textContent='KLIK LAGI UNTUK KONFIRMASI'; t=setTimeout(()=>{b.textContent=label;t=null;},4000); return; } clearTimeout(t); t=null; b.textContent=label; fn(); }); };
    twoClick('pdBtnRestore','KEMBALIKAN KE NILAI SUMBER',()=>{ const g=APP_STATE.simulation.template||'group1',n=Number(APP_STATE.simulation.activeBlastRow||1),all=ensureBlastRowOverrides(),k=blastRowOverrideKey(g,n),old=JSON.stringify(all[k]||{}); delete all[k]; audit('Blast plan restore to source',old,'{}','USER ACTION','RESTORE ROW TO SOURCE'); pdReloadAll(); });
    twoClick('pdBtnClearRec','KOSONGKAN AKTUAL',()=>{ const a=getActiveBlastRowForComparison(); if(!a) return; const st=pdRecStore(),k=a.groupKey+'::'+a.row.no,old=JSON.stringify(st[k]||{}); delete st[k]; audit('Actual record clear',old,'{}','USER ACTION','CLEAR ACTUAL RECORD'); persistWorking(); renderProjectData(); geometryComparisonInputSync(true); renderGeometryComparison(); renderGeometryActualCard(); renderGeometryCards(); refreshAll(); });
    /* registered AFTER the existing #view-design delegate, so editActiveBlastRowField has already applied the edit */
    $('view-design').addEventListener('change',e=>{
      const be=e.target.closest('[data-blast-edit]'),pr=e.target.closest('[data-pd-rec]');
      if(pr){ const ok=pdSetRec(pr.dataset.pdRec,pr.value,'INPUT MANUAL'); if(!ok){renderProjectData();return;} renderProjectData(); geometryComparisonInputSync(true); renderGeometryComparison(); renderGeometryActualCard(); renderGeometryCards(); refreshAll(); }
      else if(be){ geometryComparisonInputSync(['depth','holes'].includes(be.dataset.blastEdit)); renderProjectData(); renderGeometryComparison(); }
    });
    maeShowInputs(true); renderProjectData(); renderGeometryActualCard(); renderGeometryCards();
  }
  function wireGeometryComparison(){
    const panel=$('projectDataPanel')||$('geometryComparePanel');
    if(panel&&!$('phaseAStatus')){ const bar=document.createElement('div'); bar.style.cssText='margin:8px 0'; bar.innerHTML='<button id="btnLoadDemoExample" class="btn" type="button">LOAD DEMO EXAMPLE</button><pre id="phaseAStatus" hidden style="display:none"></pre>'; panel.insertBefore(bar,panel.querySelector('.kb-section-title')||panel.firstChild); }
    $('btnLoadDemoExample')?.addEventListener('click',loadDemoExample);
    initProjectData();
    geometryComparisonInputSync(true);
    $('btnLoadProjectGeometryCompare')?.addEventListener('click',()=>{geometryComparisonInputSync(true);renderGeometryComparison();});
    [['btnCalcAsh','ash'],['btnCalcKonya','konya'],['btnCalcMae','mae']].forEach(([id,key])=>$(id)?.addEventListener('click',()=>setFormula(key)));
    $('btnCalcAllGeometry')?.addEventListener('click',()=>geometryCompareCalculate(['ash','konya','mae']));
    $('btnApplyGeometryToSim')?.addEventListener('click',applyActiveGeometryToSimulator);
    $('btnExportGeometryCompare')?.addEventListener('click',exportGeometryComparison);
    $('cmpRockDensityBasis')?.addEventListener('change',()=>{ const old=APP_STATE.geometry.comparisonInputs.densityBasis,b=$('cmpRockDensityBasis').value||null; applyDensityBasis(b); audit('Material basis',old||'',b||'','USER ACTION','MATERIAL CHANGE'); geometryComparisonInputSync(); renderGeometryComparison(); persistWorking(); });
    CMP_FIELDS.forEach(([dom,path,unit])=>{ const el=$(dom); if(!el) return; const h=()=>{commitDomField(dom,path,unit,'Comparison panel');renderGeometryComparison();}; el.addEventListener('input',h); if(dom==='cmpFiring') el.addEventListener('change',h); });
    MAE_FIELDS.forEach(([dom,path,unit])=>{ const el=$(dom); if(!el) return; const h=()=>{commitDomField(dom,path,unit||'-','MAE inputs');renderGeometryComparison();}; el.addEventListener('input',h); el.addEventListener('change',h); });
    [['cmpDrillingCost','cost.drilling','IDR/m'],['cmpExplosiveCost','cost.explosive','IDR/kg'],['cmpAccessoryCost','cost.accessory','IDR/hole']].forEach(([dom,path,unit])=>$(dom)?.addEventListener('input',()=>{commitDomField(dom,path,unit,'Cost inputs (user-entered)');renderGeometryComparison();}));
    ['anfoIdrKg','secondaryIdrUnit','secondaryBaselineUnits','secondaryReductionPct','limestonePriceIdrTon'].forEach(id=>$(id)?.addEventListener('change',()=>{ const raw=String($(id).value??'').trim(); setInput('fin.'+id,raw===''?null:Number(raw),id.includes('Pct')?'%':'IDR','USER_EDIT','Financial inputs',id,{notes:'user-entered; quotation reference in vendorRef/priceSource'}); refreshAll(); persistWorking(); }));
    ['ppvK','ppvN'].forEach(id=>$(id)?.addEventListener('input',()=>{APP_STATE.seismic.kSource='USER';tagSeismicSource();}));
    ['ppvD','ppvW'].forEach(id=>$(id)?.addEventListener('input',()=>{APP_STATE.seismic.dwSource='USER';tagSeismicSource();}));
    wireGeometryFinancial();
    wireGeometryDecision();
    renderPhaseAStatus(); tagSeismicSource();
  }

  function geometryCommonInputs(state,rockDensityOverride){
    const i=state.geometry.input||{};
    const Dm=Number(i.diameterIn)*0.0254;
    const benchH=Number(i.benchHeight);
    const eSG=Number(i.explosiveDensity);
    const holeCount=Math.max(1,Math.round(Number(i.holeCount)||0));
    const rockSG=Number.isFinite(Number(rockDensityOverride))&&Number(rockDensityOverride)>0?Number(rockDensityOverride):Number(getMaterial()?.Density);
    if(!Number.isFinite(Dm)||Dm<=0||!Number.isFinite(benchH)||benchH<=0||!Number.isFinite(eSG)||eSG<=0||!Number.isFinite(rockSG)||rockSG<=0) return null;
    return {i,Dm,benchH,eSG,rockSG,holeCount};
  }

  function ashKbEmpirical(eSG,rockSG){
    const e=eSG<=0.95?'low':eSG<1.30?'medium':'high';
    const r=rockSG<2.0?'soft':rockSG<=2.5?'medium':'hard';
    const table=FORMULA_REGISTRY.ash.constants.kbTable;
    return {kb:table[e][r],eClass:e,rClass:r};
  }

  function ashKbFullCorrection(eSG,rockSG,vod){
    if(!(vod>0)) return null;
    const ref=ashKbEmpirical(eSG,rockSG);
    const DstdKgM3=160*16.018463; // 160 lb/ft3 = 2562.95 kg/m3
    const SGstd=1.20;
    const VODstd=12000*0.3048; // ft/s -> m/s
    const Dm3=rockSG*1000;
    const af1=Math.cbrt(DstdKgM3/Dm3);
    const af2=Math.cbrt((eSG*vod*vod)/(SGstd*VODstd*VODstd));
    return {kb:30*af1*af2,af1,af2,baseKb:ref.kb,standardKb:30};
  }

  /* Physical-plausibility screening for any geometry result (AUDIT v8).
     INVALID = physically impossible / model outside its valid range — the number must never be read as a valid design.
     WARNING = computable but outside typical documented ranges. Smallest value is never auto-"best" (see geometryCompareBest). */
  function geometrySanityCheck(r){
    /* v10.1: pemeriksaan dipisah per metode. A = fisik/geometris (semua metode, tanpa rentang rumus tertentu); B = kriteria yang hanya berlaku untuk metode tsb.
       Kriteria yang belum terpasang untuk suatu metode TIDAK dianggap lolos: dicatat di criteriaGaps → status BELUM TERVERIFIKASI. */
    const w=[],info=[],gaps=[],fin=Number.isFinite; let invalid=false;
    if(!r) return {validity:'INVALID',warnings:['no result'],info:[],criteriaGaps:[]};
    const m=r.method;
    /* A. fisik / geometris */
    if(fin(r.T)&&fin(r.benchH)&&r.T>r.benchH){ invalid=true; w.push(`stemming T = ${r.T.toFixed(2)} m MELEBIHI tinggi bench ${r.benchH} m — desain mustahil (model di luar rentang valid; khas untuk MAE pada bench dangkal)`); }
    if(fin(r.holeDepth)&&fin(r.T)){
      const cl=r.holeDepth-r.T;
      if(cl<=0){ invalid=true; w.push('panjang kolom isian ≤ 0 — tidak ada ruang untuk bahan peledak'); }
      else if(cl<0.15*r.holeDepth) w.push(`kolom isian hanya ${cl.toFixed(2)} m (${(100*cl/r.holeDepth).toFixed(1)}% dari kedalaman lubang) — tidak realistis (heuristik screening, bukan kriteria referensi)`);
    }
    if(fin(r.pfKgM3)&&(r.pfKgM3<0.10||r.pfKgM3>1.20)) w.push(`PF ${r.pfKgM3.toFixed(3)} kg/m³ di luar rentang tipikal bench blasting 0,10–1,20 kg/m³ (heuristik screening, bukan kriteria referensi)`);
    /* B. kriteria per metode */
    const bd=fin(r.Dm)&&r.Dm>0&&fin(r.B)?r.B/r.Dm:null,sb=fin(r.S)&&fin(r.B)&&r.B>0?r.S/r.B:null,lb=fin(r.B)&&r.B>0&&fin(r.benchH)?r.benchH/r.B:null;
    if(m==='ash'){
      if(bd!=null&&(bd<15||bd>45)) w.push(`B/D = ${bd.toFixed(1)} di luar rentang tipikal 20–40 (rasio Ash KB)`);
      if(sb!=null&&(sb<1.0||sb>2.0)) w.push(`S/B = ${sb.toFixed(2)} di luar rentang Ash KS 1.0–2.0`);
      if(lb!=null) info.push(`L/B = ${lb.toFixed(2)} — kriteria stiffness untuk Ash belum terpasang di aplikasi (tidak dinilai)`);
      gaps.push('kriteria stiffness L/B untuk Ash belum terpasang');
    } else if(m==='konya'){
      if(lb!=null){ if(lb<1) w.push(`stiffness L/B = ${lb.toFixed(2)} < 1 — masalah berat menurut tabel Konya (redesign disarankan)`); else if(lb<2) w.push(`stiffness L/B = ${lb.toFixed(2)} < 2 — fragmentasi poor menurut tabel Konya`); }
      if(bd!=null&&sb!=null) info.push(`B/D = ${bd.toFixed(1)}, S/B = ${sb.toFixed(2)} — hasil rumus Konya; rentang KB/KS milik Ash tidak diterapkan`);
    } else if(m==='mae'){
      if(bd!=null&&sb!=null&&lb!=null) info.push(`B/D = ${bd.toFixed(1)}, S/B = ${sb.toFixed(2)}, L/B = ${lb.toFixed(2)} — tidak dinilai: rentang Ash/Konya tidak berlaku untuk MAE`);
      gaps.push('kriteria B/D, S/B, L/B untuk MAE belum terpasang di aplikasi');
    } else gaps.push('kriteria untuk metode ini belum terpasang');
    return {validity:invalid?'INVALID':(w.length?'WARNING':'OK'),warnings:w,info,criteriaGaps:gaps};
  }

  function finishGeometryMethod(method,common,base){
    if(!common||!base||![base.B,base.S,base.T,base.J].every(Number.isFinite)) return null;
    const {Dm,benchH,eSG,rockSG,holeCount}=common;
    if(base.B<=0||base.S<=0||base.T<0||base.J<0) return null;
    const holeDepth=benchH+base.J;
    const holeArea=Math.PI*(Dm/2)**2;
    const chargeLength=Math.max(0,holeDepth-base.T); /* clamp retained; T>holeDepth is flagged INVALID by sanity check below */
    const chargeMass=holeArea*chargeLength*eSG*1000;
    const volumePerHole=base.B*base.S*benchH;
    const tonnagePerHole=volumePerHole*rockSG;
    if(!(volumePerHole>0)||!(tonnagePerHole>0)||!(chargeMass>=0)) return null;
    const totalCharge=chargeMass*holeCount;
    const totalVolume=volumePerHole*holeCount;
    const totalTonnage=tonnagePerHole*holeCount;
    const totalDrilling=holeDepth*holeCount;
    const pfKgM3=chargeMass/volumePerHole;
    const pfKgT=chargeMass/tonnagePerHole;
    const out=Object.assign({},base,{method,H:holeDepth,holeDepth,chargeLength,chargeMass,totalCharge,volumePerHole,totalVolume,tonnagePerHole,totalTonnage,totalDrilling,powderFactor:pfKgT,pfKgT,pfKgM3,Dm,benchH,eSG,rockSG,holeCount});
    const sc=geometrySanityCheck(out); out.validity=sc.validity; out.warnings=sc.warnings; out.info=sc.info; out.criteriaGaps=sc.criteriaGaps;
    return out;
  }

  function calculateAshGeometry__legacy(state,rockDensityOverride){
    const c=geometryCommonInputs(state,rockDensityOverride); if(!c) return null;
    const vod=Number(state.geometry?.comparisonInputs?.ashVod);
    const full=ashKbFullCorrection(c.eSG,c.rockSG,vod);
    const empirical=ashKbEmpirical(c.eSG,c.rockSG);
    const kb=full?.kb||empirical.kb;
    const B=kb*c.i.diameterIn/39.37007874015748;
    const Ks=Number(state.geometry?.comparisonInputs?.ashKs);
    const ratio=Number.isFinite(Ks)&&Ks>0?Ks:1.30;
    const result=finishGeometryMethod('ash',c,{B,S:ratio*B,T:0.70*B,J:0.30*B});
    if(result){result.Kb=kb;result.KbMode=full?'FULL ASH ADJUSTMENT':'EMPIRICAL ASH Kb';result.AshClass=empirical;/* full adjustment metadata */ if(full) Object.assign(result,{Af1:full.af1,Af2:full.af2});}
    return result;
  }

  function calculateKonyaGeometry__legacy(state,rockDensityOverride){
    const c=geometryCommonInputs(state,rockDensityOverride); if(!c) return null;
    const cmp=state.geometry?.comparisonInputs||{};
    const Stv=Number(cmp.stv)>0?Number(cmp.stv):100;
    const Kd=Number(cmp.kd)>0?Number(cmp.kd):1;
    const Kr=Number(cmp.kr)>0?Number(cmp.kr):1;
    const Kgeo=Number(cmp.kgeo)>0?Number(cmp.kgeo):1;
    const ratio=c.eSG/c.rockSG;
    const B1=3.15*c.i.diameterIn*Math.cbrt(ratio);
    const B2=(2*ratio+1.5)*c.i.diameterIn;
    const B3=0.67*c.i.diameterIn*Math.cbrt(Stv/c.rockSG);
    const Bbase=(B1+B2+B3)/3;
    const B=Bbase*Kd*Kr*Kgeo*0.3048;
    const L=c.benchH;
    const LbyB=B>0?L/B:0;
    const firing=cmp.firing||'delayed';
    let S;
    if(firing==='instantaneous') S=(LbyB<4)?((L+2*B)/3):(2*B);
    else S=(LbyB<4)?((L+7*B)/8):(1.4*B);
    const result=finishGeometryMethod('konya',c,{B,S,T:0.70*B,J:0.30*B});
    if(result) Object.assign(result,{B1:B1*0.3048,B2:B2*0.3048,B3:B3*0.3048,Bbase:Bbase*0.3048,Kd,Kr,Kgeo,Stv,firing,LbyB});
    return result;
  }

  function calculateMaeGeometry__legacy(state,rockDensityOverride){
    const c=geometryCommonInputs(state,rockDensityOverride); if(!c) return null;
    MAE_ERR='';
    const r=maeCalc(c.Dm,c.benchH,c.eSG,c.rockSG,state.formula.mae);
    if(!r) return null;
    return finishGeometryMethod('mae',c,r);
  }
  function calculateGeometryByMethod__legacy(method,state,rockDensityOverride){
    if(method==='ash') return calculateAshGeometry(state,rockDensityOverride);
    if(method==='konya') return calculateKonyaGeometry(state,rockDensityOverride);
    if(method==='mae') return calculateMaeGeometry(state,rockDensityOverride);
    return null;
  }
  function calculateAllGeometryMethods__legacy(state,rockDensityOverride){
    return {ash:calculateAshGeometry(state,rockDensityOverride),konya:calculateKonyaGeometry(state,rockDensityOverride),mae:calculateMaeGeometry(state,rockDensityOverride)};
  }
  function calculateGeometry__legacy(state){
    const key=state.formula.key||'ash';
    return calculateGeometryByMethod(key,state,state.geometry.formulaRockDensityOverride);
  }

  function geometryLabBaseDensity__legacy(){
    const profile=getActiveLabProfile();
    const d=Number(profile?.stats?.Density?.mean);
    if(Number.isFinite(d)&&d>0) return d;
    const vals=geometryComparisonDensityReference();
    const k=activeLabQualityKey()?.toLowerCase();
    return Number.isFinite(vals[k])?vals[k]:vals.avg;
  }
  function geometryComparisonDensityReference(){ return {hg:1.777,mg:1.927,dol:1.365,avg:1.689666667}; }
  function geometryComparisonDensitySource__legacy(basis){
    const active=activeLabQualityKey()||'LAB';
    return basis==='active'?`LAB BASE • ACTIVE ${active} = ${geometryLabBaseDensity().toFixed(6)} SG`:
      basis==='hg'?'LAB BASE • HIGH GRADE = 1.777 SG':basis==='mg'?'LAB BASE • MEDIUM GRADE = 1.927 SG':basis==='dol'?'LAB BASE • DOLOMIT = 1.365 SG':basis==='custom'?'USER CUSTOM DENSITY':'LAB BASE • RATA-RATA HG+MG+DOL = 1.689667 SG';
  }
  function activeBlastDiameter__legacy(groupKey){ return groupKey==='group3'?4.5:Number(APP_STATE.geometry.input?.diameterIn)||3.5; }
  function getActiveBlastRowForComparison(){
    const key=APP_STATE.simulation?.template||'group1';
    const rowNo=Number(APP_STATE.simulation?.activeBlastRow||1);
    const r=getBlastRow(key,rowNo);
    const g=BLAST_SHEET_ROWS[key];
    return r?{groupKey:key,groupLabel:g?.label||key,row:r}:null;
  }
  function actualEngineerGeometry__legacy(){
    const a=getActiveBlastRowForComparison(); if(!a) return null;
    const r=a.row, rho=geometryLabBaseDensity();
    const holes=Math.max(1,Number(r.holes)||1);
    const totalTonnage=Number(r.volume);
    const totalVolume=Number.isFinite(totalTonnage)&&rho>0?totalTonnage/rho:null;
    const volumePerHole=totalVolume!=null?totalVolume/holes:null;
    const tonnagePerHole=Number.isFinite(totalTonnage)?totalTonnage/holes:null;
    const j=Math.max(0,Number(r.subDepth)-Number(r.depth));
    const chargePerHole=Number(r.an);
    const totalCharge=Number(r.totalAn);
    const pfKgT=Number(r.pf);
    const pfKgM3=totalVolume>0?totalCharge/totalVolume:null;
    return {method:'actual',label:'Engineer Actual',groupLabel:a.groupLabel,rowNo:r.no,B:Number(r.burden),S:Number(r.spacing),T:Number(r.stemming),J:j,holeDepth:Number(r.subDepth),chargeLength:Number(r.charging),chargeMass:chargePerHole,totalCharge,totalVolume,volumePerHole,tonnagePerHole,totalTonnage,pfKgT,pfKgM3,totalDrilling:Number(r.subDepth)*holes,holeCount:holes,unit:r.unit};
  }

  function geometryComparisonInputSync__legacy(force=false){
    const active=getActiveBlastRowForComparison(), i=APP_STATE.geometry.input||{};
    const ci=APP_STATE.geometry.comparisonInputs||(APP_STATE.geometry.comparisonInputs={loaded:false,source:'NOT LOADED',densityBasis:'active'});
    if(!ci.densityBasis) ci.densityBasis='active';
    const ref=geometryComparisonDensityReference();
    const activeDensity=geometryLabBaseDensity();
    if(force || !ci.loaded){
      const r=active?.row;
      ci.diameterIn=activeBlastDiameter(active?.groupKey||'group1');
      ci.benchHeight=Number(r?.depth)||Number(i.benchHeight)||12;
      ci.explosiveDensity=Number(i.explosiveDensity)>0?Number(i.explosiveDensity):0.85;
      ci.holeCount=Math.max(1,Math.round(Number(r?.holes)||Number(i.holeCount)||1));
      ci.rockDensity=ci.densityBasis==='custom'&&Number(ci.rockDensity)>0?Number(ci.rockDensity):activeDensity;
      ci.loaded=true;
      ci.source=active?`BLAST PLAN • ${active.groupLabel} • ROW ${active.row.no}`:'PROJECT GEOMETRY INPUT';
      ci.rockSource=geometryComparisonDensitySource(ci.densityBasis);
    }
    const put=(id,v)=>{const el=$(id);if(el)el.value=(v==null?'':v)};
    put('cmpDiameterIn',ci.diameterIn);put('cmpBenchHeight',ci.benchHeight);put('cmpExplosiveDensity',ci.explosiveDensity);put('cmpHoleCount',ci.holeCount);
    put('cmpRockDensity',ci.rockDensity??activeDensity);put('cmpStv',ci.stv??100);put('cmpFiring',ci.firing??'delayed');put('cmpAshVod',ci.ashVod??'');put('cmpAshKs',ci.ashKs??1.30);put('cmpKonyaKd',ci.kd??1);put('cmpKonyaKr',ci.kr??1);put('cmpKonyaKs',ci.kgeo??1);
    const basis=ci.densityBasis||'active';
    if(basis==='active') ci.rockDensity=activeDensity;
    if($('cmpRockDensityBasis')) $('cmpRockDensityBasis').value=basis;
    if($('cmpRockDensity')) $('cmpRockDensity').readOnly=basis!=='custom';
    if($('cmpHoleCount')) $('cmpHoleCount').readOnly=true;
    if($('cmpRockSource'))$('cmpRockSource').textContent=geometryComparisonDensitySource(basis);
    setBlastBaseDisplay(active?active.groupLabel:null,active?active.row.no:null);
    if($('cmpLabBase'))$('cmpLabBase').textContent=`${activeLabQualityKey()||'LAB'} • ${geometryLabBaseDensity().toFixed(6)} SG`;
    if($('cmpActiveMethod'))$('cmpActiveMethod').textContent=(APP_STATE.formula.key||'ash').toUpperCase();
    if($('cmpActiveMethod2'))$('cmpActiveMethod2').textContent=(APP_STATE.formula.key||'ash').toUpperCase();
    renderGeometryComparisonProvenance();
  }

  function renderGeometryComparisonProvenance__legacy(){
    const ci=APP_STATE.geometry.comparisonInputs||{},p=$('cmpProvenance');if(!p)return;
    const a=getActiveBlastRowForComparison();
    const lab=activeLabQualityKey()||'LAB';
    p.textContent=`SOURCE • BLAST PLAN: ${a?`${a.groupLabel} / Row ${a.row.no}`:'--'} • LAB BASE: ${lab} • Rock density ${geometryLabBaseDensity().toFixed(6)} SG • Explosive density ${Number(ci.explosiveDensity||0).toFixed(2)} g/cc. Input contoh tidak dipakai diam-diam.`;
  }

  function geometryComparisonReadInputs__legacy(){
    const n=id=>Number($(id)?.value);
    const ci=APP_STATE.geometry.comparisonInputs||(APP_STATE.geometry.comparisonInputs={});
    const vals={diameterIn:n('cmpDiameterIn'),benchHeight:n('cmpBenchHeight'),explosiveDensity:n('cmpExplosiveDensity'),holeCount:n('cmpHoleCount'),rockDensity:n('cmpRockDensity'),stv:n('cmpStv'),firing:String($('cmpFiring')?.value||'delayed'),ashVod:n('cmpAshVod'),ashKs:n('cmpAshKs'),kd:n('cmpKonyaKd'),kr:n('cmpKonyaKr'),kgeo:n('cmpKonyaKs')};
    const valid=[vals.diameterIn,vals.benchHeight,vals.explosiveDensity,vals.holeCount,vals.rockDensity].every(Number.isFinite)&&vals.diameterIn>0&&vals.benchHeight>0&&vals.explosiveDensity>0&&vals.holeCount>=1&&vals.rockDensity>0;
    if(!valid)return false;
    Object.assign(ci,vals,{holeCount:Math.max(1,Math.round(vals.holeCount)),loaded:true,source:ci.source||'USER COMPARISON INPUT'});
    return true;
  }
  function geometryCompareCostInputs__legacy(){
    const read=id=>{const el=$(id);if(!el)return null;const raw=String(el.value??'').trim();if(raw==='')return null;const v=Number(raw);return Number.isFinite(v)&&v>=0?v:null;};
    return {drilling:read('cmpDrillingCost'),explosive:read('cmpExplosiveCost'),accessory:read('cmpAccessoryCost')};
  }
  function geometryCompareHash__legacy(){
    const i=APP_STATE.geometry.comparisonInputs||{},m=maeState(),c=geometryCompareCostInputs();return JSON.stringify({i,m,c,active:getActiveBlastRowForComparison()?.rowNo||null,lab:activeLabQualityKey()});
  }
  function geometryCompareFormat(v,dec=2){return Number.isFinite(v)?v.toFixed(dec):'--';}

  function geometryCompareCalculate__legacy(methods){
    const ok=geometryComparisonReadInputs();
    if(!ok){if($('geometryCompareMsg'))$('geometryCompareMsg').textContent='INPUT ERROR • lengkapi diameter, bench height, explosive density, holes, dan rock density.';return false;}
    const selected=Array.isArray(methods)&&methods.length?methods:['ash','konya','mae'];
    const ci=APP_STATE.geometry.comparisonInputs;
    const cmpState={...APP_STATE,geometry:{...APP_STATE.geometry,input:{diameterIn:ci.diameterIn,benchHeight:ci.benchHeight,explosiveDensity:ci.explosiveDensity,holeCount:ci.holeCount},comparisonInputs:ci}};
    const current=APP_STATE.geometry.results||{ash:null,konya:null,mae:null};
    MAE_ERR='';
    selected.forEach(k=>{current[k]=calculateGeometryByMethod(k,cmpState,ci.rockDensity);if(current[k])APP_STATE.geometry.result=(APP_STATE.formula.key===k?current[k]:APP_STATE.geometry.result);});
    APP_STATE.geometry.results=current;
    APP_STATE.geometry.comparison={status:selected.length===3?'CALCULATED':'PARTIAL',inputsHash:geometryCompareHash(),lastCalculated:new Date().toISOString(),methods:selected.slice()};
    // Active method should feed downstream simulation when calculated.
    const activeKey=APP_STATE.formula.key||'ash';
    if(current[activeKey]) APP_STATE.geometry.result=current[activeKey];
    renderGeometryComparison();
    return true;
  }

  function geometryCompareBest(costReady,rows){
    /* v12.1: PERBANDINGAN ANGKA dari hasil FRESH saja. STALE tidak dibaca; INVALID & DEMO EXAMPLE dikecualikan; nilai sama → SERI (bukan urutan array).
       Baris biaya mengambil hasil LOWEST COST dari Decision Support (satu sumber, mengikuti basis per ton/total pilihan pengguna dan status sumber harga). */
    const R=APP_STATE.geometry.results||{},calc=rows.filter(x=>x.key!=='actual'&&R[x.key]),fresh=calc.filter(x=>methodFreshness(x.key)==='FRESH'),nStale=calc.length-fresh.length,stOf=x=>geoStatusOf(x.key,R[x.key]);
    const noInv=fresh.filter(x=>stOf(x).cls!=='invalid'),invN=fresh.length-noInv.length,demo=noInv.filter(x=>R[x.key].demoContaminated),cand=noInv.filter(x=>!R[x.key].demoContaminated);
    const parts=[]; if(invN) parts.push(invN+' metode INVALID dikecualikan'); if(demo.length&&cand.length) parts.push(demo.length+' hasil DEMO EXAMPLE dikecualikan'); if(nStale) parts.push(nStale+' metode STALE tidak dipakai'); const note=parts.length?' ('+parts.join('; ')+')':'';
    const none=!calc.length?'--':(!fresh.length?'BELUM ADA HASIL FRESH — HITUNG ULANG':(!cand.length?(demo.length?'HASIL BERBASIS DEMO EXAMPLE — tidak dinilai sebagai kandidat':'TIDAK ADA HASIL YANG DAPAT DIBANDINGKAN'):null));
    const by=k=>{ const arr=cand.filter(x=>Number.isFinite(R[x.key][k])); if(!arr.length) return null; const mn=Math.min(...arr.map(x=>R[x.key][k])),ties=arr.filter(x=>Math.abs(R[x.key][k]-mn)<=1e-9*Math.max(1,Math.abs(mn)));
      if(ties.length>1) return 'SERI — '+ties.map(x=>x.label).join(' = ')+' (nilai sama), tanpa pemenang unik'; const b=ties[0],s=stOf(b); return b.label+' — '+(s.cls==='valid'?'status VALID':`status ${s.label}, bukan kandidat layak`); };
    const put=(id,v)=>{ const el=$(id); if(el) el.textContent=none!=null?none:(v==null?'TIDAK ADA HASIL YANG DAPAT DIBANDINGKAN':v+note); };
    put('cmpBestDrill',by('totalDrilling')); put('cmpBestExplosive',by('totalCharge'));
    const ce=$('cmpBestCost'); if(ce){ const D=geometryDecisionCompute(),lc=dsResults(D).lowest,tot=D.S.costBasis==='total',lbl=ce.previousElementSibling; if(lbl) lbl.textContent='Angka terendah • '+(tot?'biaya total':'biaya langsung / ton')+' (= LOWEST COST)';
      ce.textContent=none!=null?none:(lc.winner?(D.cand[lc.winner].label+' — '+gfRp(D.cand[lc.winner].m[tot?'costTotal':'costPerTon'])+(tot?'':'/t')+' — '+lc.label):(lc.label+(lc.lines[0]?' — '+lc.lines[0]:''))); }
    const eligible=cand.filter(x=>stOf(x).cls==='valid'),fn=$('cmpFeasNote'); if(fn) fn.textContent=!calc.length?'Belum ada metode yang dihitung.':(!fresh.length?'BELUM ADA HASIL FRESH — HITUNG ULANG. Hasil lama (STALE) tidak dipakai untuk perbandingan maupun keputusan.':(eligible.length?`Lolos semua pemeriksaan wajib yang terpasang (VALID): ${eligible.map(x=>x.label).join(', ')}. Angka terendah tetap perbandingan numerik, bukan rekomendasi desain.`:'Belum ada kandidat yang lolos semua pemeriksaan wajib (VALID). Angka terendah di atas hanya perbandingan numerik — bukan metode terbaik atau termurah yang layak.'));
  }
  function deltaPct(v,actual){return Number.isFinite(v)&&Number.isFinite(actual)&&actual!==0?100*(v/actual-1):null;}
  function applyActiveGeometryToSimulator__legacy(){
    const key=APP_STATE.formula.key||'ash';
    const r=APP_STATE.geometry.results?.[key];
    const active=getActiveBlastRowForComparison();
    if(!r){if($('geometryCompareMsg'))$('geometryCompareMsg').textContent='BELUM ADA HASIL • hitung metode aktif terlebih dahulu.';return false;}
    const p=APP_STATE.simulation.parameters||{};
    p.holeCount=Math.max(1,Math.round(Number(r.holeCount)||Number(p.holeCount)||1));
    p.anPerHoleKg=Number(r.chargeMass);
    p.stemmingM=Number(r.T);p.burdenM=Number(r.B);p.spacingM=Number(r.S);p.depthM=Number(r.holeDepth);
    APP_STATE.simulation.template=active?.groupKey||APP_STATE.simulation.template||'group1';
    APP_STATE.simulation.groupLabel=`CALC ${key.toUpperCase()} • ${active?.groupLabel||'PROJECT'}`;
    APP_STATE.simulation.activeBlastRow=active?.rowNo||APP_STATE.simulation.activeBlastRow||1;
    APP_STATE.simulation.result=null;
    simHydrate();simVisual();persistWorking();
    audit('Geometry method applied',active?.groupLabel||'',`${key.toUpperCase()} • B=${r.B.toFixed(2)} • S=${r.S.toFixed(2)} • T=${r.T.toFixed(2)} • J=${r.J.toFixed(2)}`,'USER ACTION','APPLY GEOMETRY TO SIMULATOR');
    if($('geometryCompareMsg'))$('geometryCompareMsg').textContent=`ACTIVE ${key.toUpperCase()} diterapkan ke Simulator • B ${r.B.toFixed(2)} m • S ${r.S.toFixed(2)} m • T ${r.T.toFixed(2)} m • J ${r.J.toFixed(2)} m.`;
    return true;
  }

  /* ===== TAHAP 3 (v11): GEOMETRY FINANCIAL COMPARISON =====
     Memakai ulang modul biaya lama: geometryCompareCostInputs() / costStatus() / computeCostFor() (aritmetika komponen),
     geoStatusOf() (status kelayakan), methodFreshness() (STALE), actualEngineerGeometry() (data aktual).
     State harga   : APP_STATE.geometry.cost (lama; setInput/readInput + provenance).
     State tambahan: APP_STATE.geometry.costMeta  (sumber/tanggal/catatan harga, biaya tambahan opsional, basis pembanding).
     Biaya tercatat: APP_STATE.geometry.actualRecord["group::row"].recordedCost / recordedCostRef.
     Tidak ada cache biaya: semua angka dihitung ulang dari state di setiap render, sehingga tidak ada hasil biaya yang STALE.
     Pembulatan: tiap komponen dibulatkan ke Rupiah penuh, total = jumlah komponen terbulat; per-lubang/per-ton dibulatkan hanya saat tampil. */
  const GF_BASES={hole:'Rp/lubang',meter:'Rp/m bor',kg:'Rp/kg handak',ton:'Rp/ton',lump:'Rp tetap / blast'};
  const GF_SLOTS=3, GF_KEYS=['actual','ash','konya','mae'];
  const GF_COMP=[['drilling','Pengeboran'],['explosive','Bahan peledak'],['accessory','Aksesori'],['extras','Biaya tambahan']];
  function gfMeta(){
    const G=APP_STATE.geometry; if(!G.costMeta||typeof G.costMeta!=='object'||Array.isArray(G.costMeta)) G.costMeta={};
    const m=G.costMeta; ['vendor','quoteDate','note'].forEach(k=>{ if(typeof m[k]!=='string') m[k]=''; });
    if(!Array.isArray(m.extras)) m.extras=[];
    while(m.extras.length<GF_SLOTS) m.extras.push({label:'',rate:null,basis:''});
    m.extras=m.extras.slice(0,GF_SLOTS).map(e=>({label:String((e&&e.label)||''),rate:(e&&e.rate!=null&&e.rate!==''&&Number.isFinite(Number(e.rate)))?Number(e.rate):null,basis:(e&&GF_BASES[e.basis])?e.basis:''}));
    if(m.basis!=='recorded') m.basis='estimate';
    return m;
  }
  function gfSourceCaptured(){ const m=APP_STATE.geometry.costMeta; return !!(m&&String(m.vendor||'').trim()&&String(m.quoteDate||'').trim()); }
  /* --- format id-ID: ribuan titik, desimal koma --- */
  function gfNum(v,d=0){ if(typeof v!=='number'||!Number.isFinite(v)) return null; const s=Math.abs(v).toFixed(d),p=s.split('.'),i=p[0].replace(/\B(?=(\d{3})+(?!\d))/g,'.'); return (v<0&&Number(s)!==0?'\u2212':'')+i+(p[1]?','+p[1]:''); }
  function gfRp(v,sign){ if(typeof v!=='number'||!Number.isFinite(v)) return null; const r=Math.round(v); return (r<0?'\u2212':(sign&&r>0?'+':''))+'Rp\u00A0'+gfNum(Math.abs(r),0); }
  function gfPct(v,d=1){ if(typeof v!=='number'||!Number.isFinite(v)) return null; const s=Math.abs(v).toFixed(d),z=Number(s)===0; return (z?'':(v<0?'\u2212':'+'))+s.replace('.',',')+'%'; }
  /* --- harga: status tiap tarif wajib (membaca provenance lewat readInput, sama seperti modul lama) --- */
  function gfPriceStates(){
    const defs=[['drilling','cost.drilling','Tarif pengeboran (Rp/m)'],['explosive','cost.explosive','Harga bahan peledak (Rp/kg)'],['accessory','cost.accessory','Harga aksesori (Rp/lubang)']],out={},c=geometryCompareCostInputs();
    defs.forEach(([k,p,l])=>{ const r=readInput(p,{allowZero:true}); let st='ok';
      if(!r.ok) st=r.reason==='EMPTY'?'missing':'invalid';
      out[k]={label:l,state:st,value:c[k],zero:r.ok&&r.value===0,demo:r.ok&&r.prov.sourceType==='DEMO_EXAMPLE',reason:r.ok?'':r.reason}; });
    return out;
  }
  function gfExtrasState(m){
    const items=[],issues=[];
    m.extras.forEach((e,i)=>{ const empty=e.rate==null&&!e.label.trim()&&!e.basis; if(empty) return;
      const nm=e.label.trim()||('Biaya tambahan '+(i+1));
      if(e.rate==null||!Number.isFinite(e.rate)){ issues.push(nm+': tarif belum diisi'); return; }
      if(e.rate<0){ issues.push(nm+': tarif negatif'); return; }
      if(!e.basis){ issues.push(nm+': satuan/basis belum dipilih'); return; }
      items.push({idx:i,label:nm,rate:e.rate,basis:e.basis}); });
    return {items,issues,ok:issues.length===0};
  }
  /* --- kuantitas: null = kosong / nol / bukan angka (TIDAK pernah diganti diam-diam dengan 1 atau 0) --- */
  function gfQty(v,tag,src){ return {v:(typeof v==='number'&&Number.isFinite(v)&&v>0)?v:null,tag,src}; }
  function gfActualQty(){
    const act=actualEngineerGeometry(),ab=getActiveBlastRowForComparison(); if(!act||!ab) return null;
    const row=ab.row,rec=pdRec(ab),hv=Number(row.holes),holesOk=Number.isFinite(hv)&&hv>0&&Number.isInteger(hv),rho=geometryLabBaseDensity();
    const holes=holesOk?gfQty(hv,'RECORDED','jumlah lubang — Blast Plan / Data Aktual'):gfQty(NaN,'MISSING','jumlah lubang kosong / nol / bukan bilangan bulat');
    let drill;
    if(Number(rec.holeMeter)>0) drill=gfQty(Number(rec.holeMeter),'RECORDED','hole meter aktual tercatat (Data Aktual)');
    else if(Number(rec.depthMeasured)>0&&holesOk) drill=gfQty(Number(rec.depthMeasured)*hv,'ESTIMATED','kedalaman aktual terukur × jumlah lubang (hole meter total belum dicatat)');
    else if(Number(row.subDepth)>0&&holesOk) drill=gfQty(Number(row.subDepth)*hv,'ESTIMATED','kedalaman rencana (depth + sub-drill) × jumlah lubang (hole meter aktual belum dicatat)');
    else drill=gfQty(NaN,'MISSING','hole meter / kedalaman / jumlah lubang belum tersedia');
    let charge;
    if(Number(row.totalAn)>0) charge=gfQty(Number(row.totalAn),'RECORDED','total charge tercatat (Blast Plan / Data Aktual)');
    else if(Number(row.an)>0&&holesOk) charge=gfQty(Number(row.an)*hv,'ESTIMATED','charge/lubang × jumlah lubang (total charge belum tercatat)');
    else charge=gfQty(NaN,'MISSING','total charge belum tercatat');
    let ton;
    if(Number(row.volume)>0) ton=gfQty(Number(row.volume),'RECORDED','tonase tercatat (field "volume" sumber, satuan ton adalah ASUMSI aplikasi)');
    else if(Number(rec.volumeM3)>0&&rho>0) ton=gfQty(Number(rec.volumeM3)*rho,'ESTIMATED','volume aktual tercatat × densitas batuan LAB BASE (tonase belum tercatat)');
    else ton=gfQty(NaN,'MISSING','tonase belum tercatat');
    return {holes,drill,charge,ton};
  }
  function gfModelQty(res){ const t='MODEL',s='hasil rumus model'; return {holes:gfQty(Number(res.holeCount),t,s),drill:gfQty(Number(res.totalDrilling),t,s),charge:gfQty(Number(res.totalCharge),t,s),ton:gfQty(Number(res.totalTonnage),t,s)}; }
  function gfRecorded(){ const ab=getActiveBlastRowForComparison(); if(!ab) return null; const rec=pdRec(ab),v=Number(rec.recordedCost); return (rec.recordedCost!=null&&Number.isFinite(v)&&v>0)?{value:v,ref:String(rec.recordedCostRef||'')}:null; }
  /* --- satu kolom alternatif --- */
  function gfColumn(key,ctx){
    const col={key,label:GC_TITLE[key],kind:key==='actual'?'ESTIMASI BIAYA ACTUAL':'ESTIMASI BIAYA MODEL',state:'OK',geo:null,q:null,comp:null,total:null,perHole:null,perTon:null,largest:null,delta:null,incomplete:[],warnings:[],invalid:false,extraItems:[]};
    let res;
    if(key==='actual'){ res=actualEngineerGeometry(); if(!res){col.state='NO_ACTUAL';return col;} col.q=gfActualQty(); }
    else{ res=(APP_STATE.geometry.results||{})[key]; if(!res){col.state='NO_RESULT';return col;} if(methodFreshness(key)!=='FRESH'){col.state='STALE';col.geo=geoStatusOf(key,res);return col;} col.q=gfModelQty(res); }
    col.geo=geoStatusOf(key,res); col.invalid=col.geo.cls==='invalid'&&key!=='actual';
    const q=col.q,val=x=>(x&&x.v>0)?x.v:null,rt=ctx.rates;
    const base=computeCostFor({totalDrilling:val(q.drill)??NaN,totalCharge:val(q.charge)??NaN,holeCount:val(q.holes)??NaN,totalTonnage:val(q.ton)??NaN},{drilling:rt.drilling,explosive:rt.explosive,accessory:rt.accessory});
    const rd=x=>Number.isFinite(x)?Math.round(x):null;
    col.comp={drilling:rd(base.drillingCost),explosive:rd(base.explosiveCost),accessory:rd(base.accessoryCost),extras:null};
    let ex=0,exOk=ctx.extras.ok;
    ctx.extras.items.forEach(it=>{ const qty=it.basis==='hole'?val(q.holes):it.basis==='meter'?val(q.drill):it.basis==='kg'?val(q.charge):it.basis==='ton'?val(q.ton):1;
      if(qty==null){ exOk=false; col.extraItems.push({label:it.label,amount:null}); } else { const a=Math.round(it.rate*qty); ex+=a; col.extraItems.push({label:it.label,amount:a}); } });
    col.comp.extras=exOk?ex:null;
    if(val(q.drill)==null) col.incomplete.push('total drilling'); if(val(q.charge)==null) col.incomplete.push('total charge'); if(val(q.holes)==null) col.incomplete.push('jumlah lubang');
    const parts=[col.comp.drilling,col.comp.explosive,col.comp.accessory,col.comp.extras];
    if(ctx.priceReady&&parts.every(x=>x!==null)){
      col.total=parts.reduce((s,x)=>s+x,0);
      col.perHole=val(q.holes)?col.total/val(q.holes):null;
      col.perTon=val(q.ton)?col.total/val(q.ton):null;
      let best=null; GF_COMP.forEach(([k,l])=>{ const v=col.comp[k]; if(v>0&&(!best||v>best.value)) best={key:k,label:l,value:v}; });
      if(best&&col.total>0) col.largest=Object.assign(best,{pct:100*best.value/col.total});
    }
    return col;
  }
  /* --- perhitungan penuh (murni: hanya membaca APP_STATE) --- */
  function geometryFinancialCompute(){
    const m=gfMeta(),ps=gfPriceStates(),cs=costStatus(),extras=gfExtrasState(m),c=geometryCompareCostInputs();
    const rates={drilling:c.drilling==null?NaN:c.drilling,explosive:c.explosive==null?NaN:c.explosive,accessory:c.accessory==null?NaN:c.accessory};
    const ctx={rates,priceReady:cs.ready,extras};
    const cols={}; GF_KEYS.forEach(k=>{ cols[k]=gfColumn(k,ctx); });
    const rec=gfRecorded(),act=cols.actual,actTon=act.q&&act.q.ton?act.q.ton.v:null;
    const basis={mode:m.basis,label:null,total:null,perTon:null,available:false,reason:''};
    if(m.basis==='recorded'){ basis.label='RECORDED ACTUAL COST (invoice / catatan pengeluaran)'; if(rec){ basis.total=rec.value; basis.available=true; basis.perTon=actTon?rec.value/actTon:null; } else basis.reason='RECORDED ACTUAL COST belum diisi untuk baris aktif (atau bernilai nol)'; }
    else{ basis.label='ESTIMASI BIAYA ACTUAL (meter, charge, jumlah lubang aktual × tarif bersama)'; if(act.total!=null&&act.total>0){ basis.total=act.total; basis.available=true; basis.perTon=act.perTon; } else basis.reason=!cs.ready?'WAITING FOR PRICE DATA':(act.state!=='OK'?'data actual belum tersedia':'ESTIMASI BIAYA ACTUAL tidak lengkap atau nol'); }
    GF_KEYS.forEach(k=>{ const c2=cols[k];
      if(c2.state==='OK'&&actTon&&c2.q.ton.v) c2.tonDeltaPct=100*(c2.q.ton.v/actTon-1); else c2.tonDeltaPct=null;
      if(c2.state!=='OK'||c2.total==null){ c2.delta={state:'NA_COST'}; return; }
      if(c2.invalid){ c2.delta={state:'INVALID'}; return; }
      if(!basis.available){ c2.delta={state:'NA_BASIS'}; return; }
      const rp=c2.total-basis.total; c2.delta={state:'OK',rp,pct:100*rp/basis.total,perTonPct:(basis.perTon&&c2.perTon)?100*(c2.perTon/basis.perTon-1):null}; });
    /* v12.1: status sumber harga satu pintu — dipakai Financial Comparison, ringkasan lama, dan Decision Support */
    const pf={demo:[],zero:[],invalid:[],missing:[],noSource:!gfSourceCaptured()};
    Object.values(ps).forEach(p=>{ if(p.state==='missing') pf.missing.push(p.label); else if(p.state==='invalid') pf.invalid.push(p.label+' ('+p.reason+')'); if(p.zero) pf.zero.push(p.label); if(p.demo) pf.demo.push(p.label); });
    const costBlock=!cs.ready?{kind:'WAITING',msg:'WAITING FOR PRICE DATA',detail:pf.missing.concat(pf.invalid)}:(!extras.ok?{kind:'EXTRAS',msg:'BIAYA TAMBAHAN TIDAK LENGKAP',detail:extras.issues}:(pf.demo.length?{kind:'DEMO',msg:'HARGA DEMO EXAMPLE — bukan harga aktual',detail:pf.demo}:{kind:'OK',msg:'',detail:[]}));
    return {meta:m,prices:ps,cost:cs,extras,cols,basis,recorded:rec,priceReady:cs.ready,sourceCaptured:gfSourceCaptured(),priceFlags:pf,costBlock};
  }
  /* --- render --- */
  const GF_TAGCLS={RECORDED:'rec',ESTIMATED:'est',MISSING:'miss'};
  function gfQtyCell(c,k,d,unit){
    const x=c.q&&c.q[k]; if(!x) return 'N/A';
    if(x.v==null) return '<span class="gf-tag gf-tag--miss" title="'+htmlEscape(x.src)+'">DATA KOSONG</span>';
    return gfNum(x.v,d)+' <small>'+unit+'</small>'+(c.key==='actual'?' <span class="gf-tag gf-tag--'+GF_TAGCLS[x.tag]+'" title="'+htmlEscape(x.src)+'">'+x.tag+'</span>':'');
  }
  function gfStateText(c){ return c.state==='NO_ACTUAL'?'BELUM ADA BARIS AKTUAL':c.state==='NO_RESULT'?'BELUM DIHITUNG':c.state==='STALE'?'STALE — hitung ulang':null; }
  function gfCostCell(F,c,f){
    const st=gfStateText(c); if(st) return '<span class="gf-na">'+st+'</span>';
    const v=c.comp[f];
    if(v==null){ if(f==='extras'&&!F.extras.ok) return '<span class="gf-na">BIAYA TAMBAHAN TIDAK LENGKAP</span>'; if(f!=='extras'&&F.prices[f]&&F.prices[f].state!=='ok'&&!F.prices[f].zero&&!F.prices[f].demo) return '<span class="gf-na">WAITING FOR PRICE DATA</span>'; return '<span class="gf-na">N/A • data kuantitas kosong</span>'; }
    return gfRp(v)+(c.invalid?'':'');
  }
  function gfTotalMsg(F,c){ const st=gfStateText(c); if(st) return st; if(!F.priceReady) return 'WAITING FOR PRICE DATA'; if(!F.extras.ok) return 'BIAYA TAMBAHAN TIDAK LENGKAP'; if(c.total==null) return 'N/A • '+(c.incomplete.length?c.incomplete.join(', ')+' kosong':'data tidak lengkap'); return null; }
  function gfGeoPill(c){ if(!c.geo||c.state==='NO_RESULT'||c.state==='NO_ACTUAL') return '--'; const t={invalid:'\u26D4 INVALID',warn:'\u26A0 WARNING',valid:'VALID',unv:'BELUM TERVERIFIKASI'}[c.geo.cls]||c.geo.label; return '<span class="gc-st gc-st--'+c.geo.cls+'">'+t+'</span>'; }
  function gfCondText(c){ if(c.key==='actual'||c.state!=='OK'||!c.geo) return ''; if(c.invalid) return 'INVALID — angka biaya hanya informasi; tidak dibandingkan dan tidak boleh dianggap alternatif layak karena lebih murah.'; if(c.geo.cls==='valid') return 'Estimasi biaya model. Status VALID bukan rekomendasi desain; penilaian desain dilakukan di Tahap 4.'; return 'ESTIMASI BERSYARAT — status '+c.geo.label+'; bukan rekomendasi desain yang lolos.'; }
  function gfDeltaText(F,c){
    const d=c.delta; if(!d||c.state!=='OK') return null;
    if(d.state==='INVALID') return {txt:'N/A • metode INVALID',cls:'invalid'};
    if(d.state==='NA_COST') return {txt:'N/A • biaya belum lengkap',cls:'na'};
    if(d.state==='NA_BASIS') return {txt:'N/A • basis pembanding tidak tersedia',cls:'na'};
    return {rp:d.rp,pct:d.pct,perTonPct:d.perTonPct,cls:Math.round(d.rp)>0?'up':Math.round(d.rp)<0?'down':'zero'};
  }
  function gfPriceAlerts(F){
    const a=[],P=F.prices;
    if(!F.priceReady){ const miss=Object.values(P).filter(p=>p.state!=='ok'&&!p.zero&&!p.demo); a.push({lv:'warn',t:'WAITING FOR PRICE DATA — '+(miss.length?'harga wajib belum valid: '+miss.map(p=>p.label+(p.state==='invalid'?' (nilai tidak valid: '+p.reason+')':'')).join('; ')+'.':'harga wajib belum lengkap.')+' Tidak ada harga bawaan; angka DEMO bukan harga aktual.'}); }
    const z=Object.values(P).filter(p=>p.zero); if(z.length) a.push({lv:'warn',t:'Tarif bernilai NOL dipakai: '+z.map(p=>p.label).join('; ')+'. Komponen tersebut dihitung Rp 0 — pastikan memang disengaja, bukan harga yang belum diisi.'});
    if(Object.values(P).some(p=>p.demo)) a.push({lv:'bad',t:'Ada harga bersumber DEMO EXAMPLE — bukan harga aktual / quotation. Jangan dipakai untuk keputusan.'});
    if(F.priceReady&&!F.sourceCaptured) a.push({lv:'info',t:'Sumber harga (vendor/quotation dan tanggal) belum dicatat — angka biaya tetap estimasi dan tidak dapat ditelusuri.'});
    if(!F.extras.ok) a.push({lv:'warn',t:'Biaya tambahan tidak lengkap/tidak valid: '+F.extras.issues.join('; ')+'. Total biaya ditahan sampai diperbaiki atau dikosongkan.'});
    return a;
  }
  function gfAlerts(F){
    const a=gfPriceAlerts(F),P=F.prices;
    const ac=F.cols.actual; if(ac.state==='OK'&&ac.q){ const est=['holes','drill','charge','ton'].filter(k=>ac.q[k].tag==='ESTIMATED'),ms=['holes','drill','charge','ton'].filter(k=>ac.q[k].tag==='MISSING'),nm={holes:'jumlah lubang',drill:'total drilling',charge:'total charge',ton:'tonase'};
      if(est.length) a.push({lv:'info',t:'ESTIMATED pada data actual: '+est.map(k=>nm[k]+' ('+ac.q[k].src+')').join('; ')+'.'});
      if(ms.length) a.push({lv:'warn',t:'Data actual kosong (tidak diganti hasil hitung): '+ms.map(k=>nm[k]).join(', ')+'.'}); }
    if(F.basis.mode==='recorded'&&!F.basis.available) a.push({lv:'warn',t:'Basis pembanding = RECORDED ACTUAL COST, tetapi nilainya belum diisi — selisih ditampilkan N/A (tidak diam-diam diganti estimasi).'});
    if(F.basis.mode==='recorded'&&F.basis.available) a.push({lv:'info',t:'Basis RECORDED ACTUAL COST memuat cakupan invoice yang bisa berbeda dari tiga komponen estimasi; selisih terhadap estimasi model belum tentu sebanding (apple-to-apple). Estimasi actual vs recorded ditampilkan sebagai rekonsiliasi.'});
    const holeDiff=GF_KEYS.slice(1).filter(k=>{const c=F.cols[k];return c.state==='OK'&&ac.state==='OK'&&c.q.holes.v&&ac.q.holes.v&&c.q.holes.v!==ac.q.holes.v;}); if(holeDiff.length) a.push({lv:'warn',t:'Jumlah lubang '+holeDiff.map(k=>GC_TITLE[k]).join(', ')+' berbeda dari actual — total biaya tidak sebanding; lihat biaya per ton.'});
    const tonDiff=GF_KEYS.slice(1).filter(k=>{const c=F.cols[k];return c.state==='OK'&&c.tonDeltaPct!=null&&Math.abs(c.tonDeltaPct)>5;}); if(tonDiff.length) a.push({lv:'info',t:'Tonase '+tonDiff.map(k=>GC_TITLE[k]+' ('+gfPct(F.cols[k].tonDeltaPct)+')').join(', ')+' berbeda >5% dari actual (tonase model = B×S×tinggi bench×densitas; tonase actual = nilai sumber). Selisih total biaya bukan perbandingan setara — baca juga biaya per ton.'});
    return a;
  }
  function gfFlagLab(F){ return F.priceFlags.demo.length?' • HARGA DEMO — bukan penghematan nyata':(F.priceFlags.zero.length?' • TARIF NOL — bersyarat':''); }
  function gfFlagTag(F){ return F.priceFlags.demo.length?' <small class="gf-flag">HARGA DEMO</small>':(F.priceFlags.zero.length?' <small class="gf-flag">TARIF NOL</small>':''); }
  function gfCardHtml(F,c){
    const st=gfStateText(c),tm=gfTotalMsg(F,c),dt=gfDeltaText(F,c),cond=gfCondText(c),isA=c.key==='actual';
    let h='<article class="gf-card '+(isA?'gf-card--actual':'gf-card--model')+(c.invalid?' is-invalid':'')+(c.state==='STALE'?' is-stale':'')+'" id="gfCard_'+c.key+'"><div class="gf-card-head"><h4>'+c.label+'</h4><span class="gf-kind">'+c.kind+'</span></div>';
    h+='<div class="gf-pills"><span class="gf-pill">'+(isA?'DATA TERCATAT':(st||'TERHITUNG'))+'</span>'+(c.state==='OK'||c.state==='STALE'?gfGeoPill(c):'')+'</div>';
    h+='<div class="gf-total'+(tm?' gf-total--na':'')+'" aria-label="Total biaya">'+(tm?htmlEscape(tm):gfRp(c.total))+'</div>';
    if(c.state==='OK'&&c.total!=null){
      h+='<dl class="gf-kv"><div><dt>Per lubang</dt><dd>'+(c.perHole!=null?gfRp(c.perHole):'N/A')+'</dd></div><div><dt>Per ton</dt><dd>'+(c.perTon!=null?gfRp(c.perTon):'N/A • tonase kosong')+'</dd></div><div><dt>Komponen terbesar</dt><dd>'+(c.largest?htmlEscape(c.largest.label)+' ('+gfPct(c.largest.pct,0).replace('+','')+')':'--')+'</dd></div></dl>';
    }
    if(isA&&F.recorded) h+='<div class="gf-rec"><b>RECORDED ACTUAL COST</b> '+gfRp(F.recorded.value)+(F.recorded.ref?' <small>• '+htmlEscape(F.recorded.ref)+'</small>':'')+'</div>';
    if(dt){ if(dt.rp===undefined) h+='<div class="gf-delta gf-delta--'+dt.cls+'">'+htmlEscape(dt.txt)+'</div>';
      else { const fl=gfFlagLab(F),lab=dt.cls==='up'?'TAMBAHAN BIAYA':dt.cls==='down'?(fl?'SELISIH LEBIH RENDAH':'PENGHEMATAN'):(isA&&F.basis.mode==='estimate'?'BASIS PEMBANDING':'SAMA DENGAN BASIS'); h+='<div class="gf-delta gf-delta--'+dt.cls+((c.geo&&c.geo.cls!=='valid'&&!isA)||fl?' is-cond':'')+'"><span>'+lab+fl+'</span><b>'+gfRp(dt.rp,true)+' <i>('+gfPct(dt.pct)+')</i></b></div>'; } }
    if(cond) h+='<p class="gf-cond">'+htmlEscape(cond)+'</p>';
    return h+'</article>';
  }
  function gfTableHtml(F){
    const C=GF_KEYS.map(k=>F.cols[k]),row=(label,fn,cls)=>'<tr'+(cls?' class="'+cls+'"':'')+'><th scope="row">'+label+'</th>'+C.map((c,i)=>'<td class="'+(i===0?'gf-actual-cell ':'')+(c.invalid?'is-invalid':'')+'">'+fn(c)+'</td>').join('')+'</tr>';
    const qty=(k,d,u)=>c=>gfStateText(c)?'<span class="gf-na">'+gfStateText(c)+'</span>':gfQtyCell(c,k,d,u);
    let h='';
    h+=row('Jenis angka biaya',c=>c.key==='actual'?'ESTIMASI BIAYA ACTUAL'+(F.recorded?'<br><small>+ RECORDED ACTUAL COST tersedia</small>':'<br><small>RECORDED ACTUAL COST belum diisi</small>'):'ESTIMASI BIAYA MODEL');
    h+=row('Status perhitungan',c=>c.key==='actual'?(c.state==='OK'?'DATA TERCATAT':gfStateText(c)):(gfStateText(c)||'TERHITUNG'));
    h+=row('Status kelayakan geometri',c=>c.key==='actual'?(c.state==='OK'?gfGeoPill(c)+' <small>pemeriksaan data</small>':'--'):gfGeoPill(c));
    h+=row('Jumlah lubang',qty('holes',0,'lubang'));
    h+=row('Total drilling',qty('drill',2,'m'));
    h+=row('Total charge',qty('charge',1,'kg'));
    h+=row('Tonase',qty('ton',1,'t'));
    h+=row('Selisih tonase vs actual <small>%</small>',c=>gfStateText(c)?'<span class="gf-na">'+gfStateText(c)+'</span>':(c.key==='actual'?'basis':(c.tonDeltaPct!=null?gfPct(c.tonDeltaPct):'N/A')));
    h+=row('Biaya pengeboran',c=>gfCostCell(F,c,'drilling'),'gf-cost');
    h+=row('Biaya handak',c=>gfCostCell(F,c,'explosive'),'gf-cost');
    h+=row('Biaya aksesori',c=>gfCostCell(F,c,'accessory'),'gf-cost');
    h+=row('Biaya tambahan',c=>{ const base=gfCostCell(F,c,'extras'); if(!gfStateText(c)&&c.comp&&c.comp.extras!=null&&c.extraItems.length) return base+'<br><small>'+c.extraItems.map(e=>htmlEscape(e.label)+': '+gfRp(e.amount)).join('<br>')+'</small>'; return base; },'gf-cost');
    h+=row('<b>Total biaya</b>',c=>{ const m=gfTotalMsg(F,c); return m?'<span class="gf-na">'+htmlEscape(m)+'</span>':'<b>'+gfRp(c.total)+'</b>'; },'gf-total-row');
    h+=row('Biaya per lubang',c=>{ const m=gfStateText(c); if(m) return '<span class="gf-na">'+m+'</span>'; return c.total==null?'<span class="gf-na">N/A</span>':(c.perHole!=null?gfRp(c.perHole):'<span class="gf-na">N/A</span>'); });
    h+=row('Biaya per ton',c=>{ const m=gfStateText(c); if(m) return '<span class="gf-na">'+m+'</span>'; return c.total==null?'<span class="gf-na">N/A</span>':(c.perTon!=null?gfRp(c.perTon):'<span class="gf-na">N/A • tonase kosong</span>'); });
    h+=row('Komponen biaya terbesar',c=>c.largest?htmlEscape(c.largest.label)+' <small>'+gfPct(c.largest.pct,1).replace('+','')+'</small>':'<span class="gf-na">--</span>');
    h+=row('RECORDED ACTUAL COST (invoice)',c=>c.key==='actual'?(F.recorded?gfRp(F.recorded.value)+(F.recorded.ref?'<br><small>'+htmlEscape(F.recorded.ref)+'</small>':''):'<span class="gf-na">belum diisi</span>'):'<span class="gf-na">—</span>');
    h+=row('Basis pembanding terpilih',c=>c.key==='actual'?(F.basis.available?gfRp(F.basis.total)+'<br><small>'+(F.basis.mode==='recorded'?'RECORDED':'ESTIMASI')+'</small>':'<span class="gf-na">N/A • '+htmlEscape(F.basis.reason)+'</span>'):'<span class="gf-na">—</span>');
    const dcell=(fn)=>c=>{ const st=gfStateText(c); if(st) return '<span class="gf-na">'+st+'</span>'; const d=gfDeltaText(F,c); if(!d) return 'N/A'; if(d.rp===undefined) return '<span class="gf-na">'+htmlEscape(d.txt)+'</span>'; return fn(d,c)+gfFlagTag(F); };
    h+=row('Selisih biaya vs basis <small>Rp</small>',dcell((d,c)=>'<span class="gf-d gf-d--'+d.cls+'">'+gfRp(d.rp,true)+'</span>'+(c.key==='actual'?'<br><small>'+(F.basis.mode==='recorded'?'estimasi − recorded':'basis = 0')+'</small>':'')),'gf-delta-row');
    h+=row('Selisih biaya vs basis <small>%</small>',dcell((d,c)=>'<span class="gf-d gf-d--'+d.cls+'">'+gfPct(d.pct)+'</span>'),'gf-delta-row');
    h+=row('Selisih biaya per ton vs basis <small>%</small>',dcell((d)=>d.perTonPct!=null?'<span class="gf-d gf-d--'+(d.perTonPct>0?'up':d.perTonPct<0?'down':'zero')+'">'+gfPct(d.perTonPct)+'</span>':'<span class="gf-na">N/A • tonase kosong</span>'));
    h+=row('Peringatan',c=>{ const w=[]; if(c.state==='OK'&&c.key!=='actual'){ const t=gfCondText(c); if(t) w.push(t); } if(c.state==='OK'&&c.key==='actual'&&c.geo&&(c.geo.cls==='invalid'||c.geo.cls==='warn')) w.push('Pemeriksaan data actual: '+c.geo.label+' — estimasi biaya actual bersyarat.'); return w.length?'<small>'+w.map(htmlEscape).join('<br>')+'</small>':'—'; });
    return h;
  }
  function gfHydrate(F){
    const G=APP_STATE.geometry,m=F.meta,set=(id,v)=>{ const el=$(id); if(el&&document.activeElement!==el){ const s=v==null?'':String(v); if(el.value!==s) el.value=s; } };
    set('cmpDrillingCost',G.cost&&G.cost.drilling); set('cmpExplosiveCost',G.cost&&G.cost.explosive); set('cmpAccessoryCost',G.cost&&G.cost.accessory);
    set('gfVendor',m.vendor); set('gfQuoteDate',m.quoteDate); set('gfNote',m.note); set('gfBasis',m.basis);
    m.extras.forEach((e,i)=>{ set('gfExLabel'+i,e.label); set('gfExRate'+i,e.rate); set('gfExBasis'+i,e.basis); });
    const rec=pdRec(); set('gfRecCost',rec.recordedCost); set('gfRecRef',rec.recordedCostRef);
    const ab=getActiveBlastRowForComparison(),rl=$('gfRecRow'); if(rl) rl.textContent=ab?(ab.groupLabel+' • ROW '+ab.row.no):'belum ada baris aktif';
    ['cmpDrillingCost','cmpExplosiveCost','cmpAccessoryCost'].forEach((id,i)=>{ const p=F.prices[['drilling','explosive','accessory'][i]],el=$(id); if(el) el.setAttribute('aria-invalid',p.state==='invalid'?'true':'false'); });
  }
  function renderGeometryFinancial(){
    const host=$('geoFinPanel'); if(!host) return null;
    let F; try{ F=geometryFinancialCompute(); }catch(e){ console.error('geometry financial compute failed',e); $('gfAlerts').innerHTML='<div class="gf-alert gf-alert--bad">Perhitungan biaya gagal: '+htmlEscape(String(e&&e.message||e))+'</div>'; return null; }
    gfHydrate(F);
    const badge=$('gfStatus'),calc=GF_KEYS.slice(1).filter(k=>F.cols[k].state==='OK').length;
    badge.textContent=!F.priceReady?'WAITING FOR PRICE DATA':(F.extras.ok?(F.priceFlags.demo.length?'HARGA DEMO — BUKAN HARGA AKTUAL':('ESTIMASI • '+calc+'/3 MODEL TERHITUNG'+(F.priceFlags.zero.length?' • TARIF NOL':''))):'BIAYA TAMBAHAN TIDAK LENGKAP'); badge.className='kb-badge '+(F.costBlock.kind==='OK'&&!F.priceFlags.zero.length?'ok':'warn');
    $('gfAlerts').innerHTML=gfAlerts(F).map(x=>'<div class="gf-alert gf-alert--'+x.lv+'">'+htmlEscape(x.t)+'</div>').join('');
    $('gfCards').innerHTML=GF_KEYS.map(k=>gfCardHtml(F,F.cols[k])).join('');
    $('gfBody').innerHTML=gfTableHtml(F);
    const bl=$('gfBasisNote'); if(bl) bl.innerHTML='<b>Basis pembanding:</b> '+htmlEscape(F.basis.label)+(F.basis.available?' = '+gfRp(F.basis.total):' — <b>tidak tersedia</b>: '+htmlEscape(F.basis.reason))+'. <b>Selisih biaya</b> = estimasi biaya alternatif − basis; <b>%</b> = selisih ÷ basis × 100%; basis kosong/nol → N/A.';
    return F;
  }
  function exportGeometryFinancial(){
    const F=geometryFinancialCompute(),q=s=>'"'+String(s??'').replace(/"/g,"'")+'"',cols=['Alternatif','JenisBiaya','StatusPerhitungan','StatusKelayakan','Lubang','Drilling_m','Charge_kg','Tonase_t','Biaya_Pengeboran_Rp','Biaya_Handak_Rp','Biaya_Aksesori_Rp','Biaya_Tambahan_Rp','Total_Rp','PerLubang_Rp','PerTon_Rp','Selisih_Rp','Selisih_Persen','Basis','Vendor_Quotation','Tanggal_Quotation','Catatan_Harga','Flag_Harga'],L=[cols.join(',')],flags=[].concat(F.priceFlags.demo.length?['HARGA_DEMO']:[],F.priceFlags.zero.length?['TARIF_NOL']:[],F.priceFlags.noSource?['SUMBER_HARGA_TIDAK_TERCATAT']:[]).join('|');
    GF_KEYS.forEach(k=>{ const c=F.cols[k],ok=c.state==='OK',d=c.delta&&c.delta.state==='OK'?c.delta:null;
      L.push([q(c.label),q(c.kind),q(gfStateText(c)||(k==='actual'?'DATA TERCATAT':'TERHITUNG')),q(c.geo?c.geo.label:''),ok?c.q.holes.v??'':'',ok?c.q.drill.v??'':'',ok?c.q.charge.v??'':'',ok?c.q.ton.v??'':'',ok&&c.comp.drilling!=null?c.comp.drilling:'',ok&&c.comp.explosive!=null?c.comp.explosive:'',ok&&c.comp.accessory!=null?c.comp.accessory:'',ok&&c.comp.extras!=null?c.comp.extras:'',c.total??'',c.perHole!=null?Math.round(c.perHole):'',c.perTon!=null?Math.round(c.perTon):'',d?Math.round(d.rp):'N/A',d?d.pct.toFixed(2):'N/A',q(F.basis.label+(F.basis.available?'':' (TIDAK TERSEDIA)')),q(F.meta.vendor),q(F.meta.quoteDate),q(F.meta.note),q(flags)].join(',')); });
    downloadText('Geometry_Financial_Comparison.csv',L.join('\n'),'text/csv');
  }
  function wireGeometryFinancial(){
    const P=$('geoFinPanel'); if(!P||P.dataset.wired) return; P.dataset.wired='1';
    const save=()=>{ persistWorking(); renderGeometryComparison(); };   /* v12.1: semua panel (ringkasan lama, Financial, Decision) mengikuti, bukan hanya panel ini */
    const bindText=(id,key,label)=>{ const el=$(id); if(!el) return; el.addEventListener('input',()=>{ gfMeta()[key]=el.value; save(); }); el.addEventListener('change',()=>audit('Cost price '+label,'',el.value,'USER INPUT','EDIT COST META')); };
    bindText('gfVendor','vendor','vendor/quotation'); bindText('gfQuoteDate','quoteDate','quotation date'); bindText('gfNote','note','note');
    $('gfBasis')?.addEventListener('change',()=>{ const old=gfMeta().basis; gfMeta().basis=$('gfBasis').value==='recorded'?'recorded':'estimate'; audit('Cost comparison basis',old,gfMeta().basis,'USER INPUT','EDIT COST META'); save(); });
    for(let i=0;i<GF_SLOTS;i++){
      const lb=$('gfExLabel'+i),rt=$('gfExRate'+i),bs=$('gfExBasis'+i);
      lb?.addEventListener('input',()=>{ gfMeta().extras[i].label=lb.value; save(); });
      rt?.addEventListener('input',()=>{ const raw=String(rt.value).trim(); gfMeta().extras[i].rate=raw===''?null:Number(raw); save(); });
      bs?.addEventListener('change',()=>{ gfMeta().extras[i].basis=bs.value; save(); });
      [lb,rt,bs].forEach(el=>el?.addEventListener('change',()=>audit('Cost extra #'+(i+1),'',(lb?.value||'')+' | '+(rt?.value||'')+' | '+(bs?.value||''),'USER INPUT','EDIT COST META')));
    }
    const rc=$('gfRecCost'),rr=$('gfRecRef');
    rc?.addEventListener('input',()=>{ const ok=pdSetRec('recordedCost',rc.value); rc.setAttribute('aria-invalid',ok?'false':'true'); const m=$('gfRecMsg'); if(m) m.textContent=ok?'':'Nilai ditolak (negatif / bukan angka); nilai sebelumnya dipertahankan.'; renderGeometryComparison(); });
    rr?.addEventListener('input',()=>{ pdSetRec('recordedCostRef',rr.value); renderGeometryComparison(); });
    $('btnExportGeometryFinancial')?.addEventListener('click',exportGeometryFinancial);
  }
  /* ===== TAHAP 4 (v12): ENGINEERING PERFORMANCE & DECISION SUPPORT =====
     Prinsip: (1) pemeriksaan WAJIB dipisah dari SKOR; (2) tiga jawaban terpisah, bukan satu skor; (3) data kosong tidak pernah menjadi nol;
     (4) hasil lapangan hanya dari pengukuran nyata yang dimasukkan pengguna untuk blast aktual — tidak ada model prediksi fragmentasi/getaran
     yang terverifikasi di aplikasi, sehingga alternatif model selalu "DATA BELUM TERSEDIA" untuk kriteria hasil lapangan; (5) Geometry Actual = BASELINE.
     Memakai ulang (tanpa state biaya/geometri ganda): geometryFinancialCompute() [v11], actualEngineerGeometry(), APP_STATE.geometry.results,
     geoStatusOf(), methodFreshness(), FORMULA_REGISTRY, geometrySanityCheck() (lewat res.validity/warnings/criteriaGaps).
     Parameter desain (BUKAN ambang rekayasa): DS_TON_TOL=5% (ketentuan perbandingan setara dari spesifikasi proyek), DS_TIE_POINTS=5 poin (margin seri skor). */
  const DS_KEYS=['actual','ash','konya','mae'], DS_MODELS=['ash','konya','mae'], DS_TON_TOL=5, DS_TIE_POINTS=5, DS_CLOSE_MIN_PARAMS=4, DS_MIN_CRITERIA=3;
  const DS_CRIT=[
    {id:'costPerTon',label:'Biaya per ton',group:'Ekonomi',unit:'Rp/t',dir:'min',norm:'nilai terkecil ÷ nilai (kandidat terkecil = 1,00)',src:'Financial Comparison v11 (tarif bersama × kuantitas model)'},
    {id:'drillPerTon',label:'Pengeboran per ton',group:'Konsumsi pengeboran',unit:'m/t',dir:'min',norm:'nilai terkecil ÷ nilai (kandidat terkecil = 1,00)',src:'total drilling ÷ tonase (output model)'},
    {id:'pfDev',label:'Deviasi PF kg/t dari baseline',group:'Konsumsi handak',unit:'%',dir:'dev',norm:'1 − min(|deviasi|,100%) ÷ 100 (dekat baseline = tinggi; BUKAN klaim PF rendah lebih baik)',src:'total charge ÷ tonase, model vs actual'},
    {id:'geoDev',label:'Deviasi geometri rata-rata dari baseline',group:'Geometri',unit:'%',dir:'dev',norm:'1 − min(rata-rata |deviasi|,100%) ÷ 100',src:'B, S, T, J, kedalaman, charge/lubang (definisi & satuan sama)'},
    {id:'warnCount',label:'Jumlah peringatan pemeriksaan fisik',group:'Kelayakan',unit:'jumlah',dir:'min1',norm:'(1 + terkecil) ÷ (1 + jumlah)',src:'geometrySanityCheck() — peringatan fisik/kriteria metode'}
  ];
  const DS_FIELD=[['fieldX80','X80 / P80 fragmentasi terukur','cm',true],['fieldToe','Toe (sisa tonjolan lantai)','m',false],['fieldBackbreak','Backbreak','m',false],['fieldOverbreak','Overbreak','m',false],['fieldPPV','Getaran PPV terukur','mm/s',false],['fieldFlyrock','Flyrock (jarak lempar terukur)','m',false],['fieldProd','Produktivitas digging/loading','t/jam',true]];
  const DS_DEV=[['B','Burden (B)','m'],['S','Spacing (S)','m'],['T','Stemming (T)','m'],['J','Sub-drill (J)','m'],['holeDepth','Kedalaman lubang','m'],['chargeMass','Charge / lubang','kg']];
  const DS_RANGE={
    ash:'B/D 20–40 (Ash KB; peringatan di luar 15–45) • S/B 1,0–2,0 (Ash KS). Ref: Ash (1963) via Pit & Quarry (2019).',
    konya:'Stiffness L/B: <1 masalah berat, <2 fragmentasi poor (tabel Konya). Rentang KB/KS milik Ash TIDAK dipakai. Ref: USACE EM 1110-2-3800 (2018).',
    mae:'Tidak ada kriteria B/D, S/B, L/B untuk MAE — BELUM TERVERIFIKASI (rentang Ash/Konya tidak berlaku).',
    actual:'Tidak ada kriteria referensi untuk data aktual — BELUM TERVERIFIKASI (rentang metode lain tidak dipakai).'
  };
  function dsStore(){
    const G=APP_STATE.geometry; if(!G.decision||typeof G.decision!=='object'||Array.isArray(G.decision)) G.decision={};
    const d=G.decision; if(!d.weights||typeof d.weights!=='object'||Array.isArray(d.weights)) d.weights={};
    DS_CRIT.forEach(c=>{ const w=d.weights[c.id]; d.weights[c.id]=(w!=null&&w!==''&&Number.isFinite(Number(w))&&Number(w)>=0&&Number(w)<=100)?Number(w):1; });
    d.costBasis=d.costBasis==='total'?'total':'perTon'; d.requireField=d.requireField===false?false:true;
    d.maxCostPerTon=(d.maxCostPerTon!=null&&Number(d.maxCostPerTon)>0)?Number(d.maxCostPerTon):null; return d;
  }
  const dsFin=v=>typeof v==='number'&&Number.isFinite(v);
  /* --- hasil lapangan terukur (hanya untuk blast aktual, tersimpan per baris di actualRecord) --- */
  function dsFieldData(){
    const rec=pdRec(),out={},bad=[];
    DS_FIELD.forEach(([k,l,u,pos])=>{ const raw=rec[k]; if(raw==null||raw===''){ out[k]=null; return; } const v=Number(raw); if(!Number.isFinite(v)||v<0||(pos&&v<=0)){ out[k]=null; bad.push(l); return; } out[k]=v; });
    return {vals:out,count:Object.values(out).filter(v=>v!=null).length,source:String(rec.fieldSource||'').trim(),bad};
  }
  /* --- gate (pemeriksaan wajib) satu kandidat --- */
  function dsGate(id,label,st,txt){ return {id,label,st,txt}; }
  function dsCandidate(key,F,act,R,ctx){
    const col=F.cols[key],isBase=key==='actual',res=isBase?act:R[key],reg=isBase?null:FORMULA_REGISTRY[key];
    const c={key,label:GC_TITLE[key],isBase,col,res,state:col.state,gates:[],cls:'',m:null,why:[],limitFail:null};
    const g=c.gates,geo=col.geo;
    /* G1 FRESH/STALE */
    if(isBase) g.push(dsGate('fresh','Status hasil',res?'PASS':'FAIL',res?('Data tercatat • '+res.groupLabel+' / Row '+res.rowNo):'belum ada baris aktual'));
    else if(!res) g.push(dsGate('fresh','Status hasil','FAIL','BELUM DIHITUNG'));
    else if(methodFreshness(key)!=='FRESH') g.push(dsGate('fresh','Status hasil','FAIL','STALE — input/baris berubah sejak perhitungan; hitung ulang'));
    else g.push(dsGate('fresh','Status hasil','PASS','FRESH'));
    /* G2 kelengkapan & validitas input */
    if(isBase){ const q=col.q; if(!q) g.push(dsGate('inputs','Input lengkap & valid','FAIL','data aktual tidak tersedia')); else { const ms=['drill','charge','ton'].filter(k=>q[k].v==null).map(k=>({drill:'total drilling',charge:'total charge',ton:'tonase'})[k]); if(q.holes.v==null) g.push(dsGate('inputs','Input lengkap & valid','FAIL','jumlah lubang aktual kosong/nol/tidak bulat')); else g.push(dsGate('inputs','Input lengkap & valid',ms.length?'FLAG':'PASS',ms.length?('kosong (tidak diisi hasil hitung): '+ms.join(', ')):'lengkap')); } }
    else if(!res){ const miss=collectEngineInputs(key).missing.map(x=>x.path); g.push(dsGate('inputs','Input lengkap & valid','FAIL',miss.length?('input kosong/tidak valid: '+miss.join(', ')):'belum dihitung')); }
    else if(res.demoContaminated) g.push(dsGate('inputs','Input lengkap & valid','FAIL','memakai input DEMO EXAMPLE — bukan data proyek'));
    else g.push(dsGate('inputs','Input lengkap & valid','PASS','lengkap, bersumber proyek/lab'));
    /* G3 pemeriksaan geometri sesuai metode (geoStatusOf = geometrySanityCheck + cek konsistensi aktual) */
    if(!geo||!res) g.push(dsGate('geom','Pemeriksaan geometri (sesuai metode)','NA','tidak ada hasil untuk diperiksa'));
    else if(geo.cls==='invalid') g.push(dsGate('geom','Pemeriksaan geometri (sesuai metode)','FAIL','INVALID — '+(geo.notes||[]).slice(0,2).join(' • ')));
    else if(geo.cls==='warn') g.push(dsGate('geom','Pemeriksaan geometri (sesuai metode)','FLAG','WARNING — '+(geo.notes||[]).slice(0,2).join(' • ')));
    else g.push(dsGate('geom','Pemeriksaan geometri (sesuai metode)','PASS',geo.cls==='valid'?'lolos semua pemeriksaan terpasang':'lolos pemeriksaan fisik; '+(isBase?'tidak ada kriteria referensi untuk data aktual':('kriteria metode: '+((res.criteriaGaps&&res.criteriaGaps[0])||'—')))));
    /* G4 verifikasi formula */
    if(isBase) g.push(dsGate('formula','Verifikasi formula','NA','data tercatat — bukan hasil rumus'));
    else g.push(dsGate('formula','Verifikasi formula',reg.status==='VERIFIED'?'PASS':'FLAG',reg.formulaId+' • '+reg.version+' • '+reg.status+(reg.status==='VERIFIED'?'':' (belum VERIFIED → BELUM TERVERIFIKASI)')));
    /* G5 asumsi & keterbatasan model */
    const assume=[]; if(isBase){ ['holes','drill','charge','ton'].forEach(k=>{ if(col.q&&col.q[k].tag==='ESTIMATED') assume.push(({holes:'lubang',drill:'drilling',charge:'charge',ton:'tonase'})[k]+' ESTIMATED'); }); if(col.q&&col.q.ton.tag==='RECORDED') assume.push('satuan tonase sumber = ton (ASUMSI)'); }
    else if(geo&&res){ (geo.assume||[]).forEach(a=>assume.push(a)); (res.criteriaGaps||[]).forEach(x=>assume.push('kriteria belum terpasang: '+x)); }
    g.push(dsGate('assume','Asumsi & keterbatasan',assume.length?'FLAG':'PASS',assume.length?assume.join('; '):'tidak ada asumsi tercatat'));
    /* G6 kuantitas & satuan */
    if(!res||!col.q) g.push(dsGate('units','Kuantitas & konsistensi satuan','NA','—'));
    else { const q=col.q,bad=['holes','drill','charge','ton'].filter(k=>q[k].v==null).map(k=>({holes:'lubang',drill:'drilling (m)',charge:'charge (kg)',ton:'tonase (t)'})[k]);
      if(isBase) g.push(dsGate('units','Kuantitas & konsistensi satuan',q.holes.v==null?'FAIL':(bad.length?'FLAG':'PASS'),bad.length?('kosong/nol: '+bad.join(', ')):'semua > 0, satuan m / kg / t'));
      else g.push(dsGate('units','Kuantitas & konsistensi satuan',bad.length?'FAIL':'PASS',bad.length?('kosong/nol: '+bad.join(', ')):'semua > 0, satuan m / kg / t')); }
    /* G7 kelengkapan biaya (menentukan kriteria biaya, bukan kelayakan geometri) */
    if(col.state!=='OK') g.push(dsGate('cost','Kelengkapan biaya','NA','—')); else { const pf=F.priceFlags,fl=[]; if(pf.demo.length) fl.push('HARGA DEMO EXAMPLE — bukan harga aktual'); if(pf.zero.length) fl.push('tarif NOL dipakai'); if(col.total!=null&&pf.noSource) fl.push('sumber harga tidak tercatat');
      g.push(dsGate('cost','Kelengkapan biaya',col.total==null?'FLAG':(fl.length?'FLAG':'PASS'),col.total==null?gfTotalMsg(F,col):(fl.length?('lengkap tetapi bersyarat: '+fl.join('; ')):'lengkap, sumber harga tercatat'))); }
    /* klasifikasi */
    const hard=g.filter(x=>x.st==='FAIL'&&['fresh','inputs','geom','units'].includes(x.id)),soft=g.filter(x=>x.st==='FLAG'&&['geom','formula','assume'].includes(x.id));
    if(isBase){ c.cls=hard.length?'BASELINE_UNUSABLE':'BASELINE'; c.why=hard.map(x=>x.label+': '+x.txt); }
    else if(hard.length){ c.cls='EXCLUDED'; c.why=hard.map(x=>x.label+': '+x.txt); }
    else if(soft.length){ c.cls='CONDITIONAL'; c.why=soft.map(x=>x.label+': '+x.txt); }
    else c.cls='ELIGIBLE';
    /* metrik (hanya bila hasil ada & FRESH) */
    if(col.state==='OK'&&col.q&&res){
      const q=col.q,v=k=>q[k].v,m={};
      m.holes=v('holes');m.drill=v('drill');m.charge=v('charge');m.ton=v('ton');
      m.pfKgT=(m.charge!=null&&m.ton!=null)?m.charge/m.ton:null; m.drillPerTon=(m.drill!=null&&m.ton!=null)?m.drill/m.ton:null;
      m.pfKgM3=dsFin(res.pfKgM3)?res.pfKgM3:null; m.volume=dsFin(res.totalVolume)?res.totalVolume:null;
      DS_DEV.forEach(([k])=>{ m[k]=dsFin(Number(res[k]))&&res[k]!==null&&res[k]!==''?Number(res[k]):null; });
      m.BD=(ctx.Dm&&m.B!=null)?m.B/ctx.Dm:null; m.SB=(m.B>0&&m.S!=null)?m.S/m.B:null; m.LB=(ctx.bench&&m.B>0)?ctx.bench/m.B:null;
      m.costTotal=col.total; m.costPerTon=col.perTon; m.costPerHole=col.perHole; m.largest=col.largest; m.warnCount=isBase?null:((res.warnings||[]).length);
      c.m=m;
    }
    return c;
  }
  /* --- normalisasi & skor (kriteria dipakai hanya bila SEMUA kandidat punya data; data hilang TIDAK menjadi nol) --- */
  function dsNormalize(crit,vals){ /* vals: {key:number} */
    const keys=Object.keys(vals),out={},arr=keys.map(k=>vals[k]),best=Math.min(...arr);
    keys.forEach(k=>{ const v=vals[k];
      if(crit.dir==='min') out[k]=v===0?1:best/v;
      else if(crit.dir==='min1') out[k]=(1+best)/(1+v);
      else out[k]=1-Math.min(Math.abs(v),100)/100; });
    return out;
  }
  function dsScore(pool,weights,reasons){
    const used=[],dropped=[],res={};
    pool.forEach(c=>{ res[c.key]={score:null,parts:{}}; });
    DS_CRIT.forEach(cr=>{ const w=weights[cr.id];
      if(!(w>0)){ dropped.push({id:cr.id,label:cr.label,why:'bobot 0 — tidak dipakai'}); return; }
      const miss=pool.filter(c=>!c.crit||c.crit[cr.id]==null||!Number.isFinite(c.crit[cr.id]));
      if(miss.length){ dropped.push({id:cr.id,label:cr.label,why:(reasons&&reasons[cr.id])||('data kosong untuk '+miss.map(c=>c.label).join(', ')+' — dikeluarkan untuk SEMUA kandidat (bukan dinilai 0)')}); return; }
      const vals={}; pool.forEach(c=>{ vals[c.key]=c.crit[cr.id]; }); const nz=dsNormalize(cr,vals); used.push({crit:cr,w,vals,nz}); });
    const sw=used.reduce((s,u)=>s+u.w,0);
    if(used.length&&sw>0) pool.forEach(c=>{ let s=0; used.forEach(u=>{ res[c.key].parts[u.crit.id]={raw:u.vals[c.key],norm:u.nz[c.key],w:u.w}; s+=u.w*u.nz[c.key]; }); res[c.key].score=100*s/sw; });
    return {used,dropped,scores:res,totalWeight:sw};
  }
  /* --- perhitungan penuh (murni: hanya membaca state) --- */
  function geometryDecisionCompute(){
    const F=geometryFinancialCompute(),S=dsStore(),act=actualEngineerGeometry(),R=APP_STATE.geometry.results||{},ci=APP_STATE.geometry.comparisonInputs||{};
    const ctx={Dm:Number(ci.diameterIn)>0?Number(ci.diameterIn)*0.0254:null,bench:Number(ci.benchHeight)>0?Number(ci.benchHeight):null};
    const cand={}; DS_KEYS.forEach(k=>{ cand[k]=dsCandidate(k,F,act,R,ctx); });
    const base=cand.actual,bm=base.cls==='BASELINE'?base.m:null,field=dsFieldData();
    /* deviasi dari baseline: parameter dengan definisi & satuan sama; set parameter seragam untuk semua kandidat */
    const devParams=bm?DS_DEV.filter(([k])=>bm[k]!=null&&bm[k]>0):[];
    DS_MODELS.forEach(k=>{ const c=cand[k]; c.dev={}; c.geoDev=null; c.maxDev=null; c.pfDev=null; if(!c.m||!bm) return;
      DS_DEV.forEach(([p])=>{ const a=bm[p],v=c.m[p]; c.dev[p]=(a!=null&&v!=null)?{abs:v-a,pct:a>0?100*(v-a)/a:null}:null; });
      const used=devParams.map(([p])=>c.dev[p]).filter(x=>x&&x.pct!=null); if(devParams.length>=DS_CLOSE_MIN_PARAMS&&used.length===devParams.length){ c.geoDev=used.reduce((s,x)=>s+Math.abs(x.pct),0)/used.length; c.maxDev=devParams.map(([p,l])=>({p,l,pct:c.dev[p].pct})).reduce((a,b)=>Math.abs(b.pct)>Math.abs(a.pct)?b:a); }
      if(bm.pfKgT>0&&c.m.pfKgT!=null) c.pfDev=Math.abs(100*(c.m.pfKgT/bm.pfKgT-1)); });
    /* batas wajib opsional dari pengguna (USER-DEFINED, tanpa referensi) */
    DS_MODELS.forEach(k=>{ const c=cand[k]; if(S.maxCostPerTon==null||!c.m){ c.limitFail=null; return; } c.limitFail=c.m.costPerTon==null?'unknown':(c.m.costPerTon>S.maxCostPerTon?'over':null); });
    DS_MODELS.forEach(k=>{ const c=cand[k]; c.crit=c.m?{costPerTon:(F.costBlock.kind==='DEMO'?null:c.m.costPerTon),drillPerTon:c.m.drillPerTon,pfDev:c.pfDev,geoDev:c.geoDev,warnCount:c.m.warnCount}:null; });
    const cbk=F.costBlock.kind,costDrop=cbk==='WAITING'?'harga wajib belum lengkap/invalid — biaya tidak tersedia; dikeluarkan untuk SEMUA kandidat (bukan dinilai 0)':cbk==='EXTRAS'?'biaya tambahan tidak lengkap — total biaya tidak tersedia; dikeluarkan untuk SEMUA kandidat (bukan dinilai 0)':cbk==='DEMO'?'harga DEMO EXAMPLE — bukan harga aktual; tidak dipakai sebagai kriteria ekonomi; dikeluarkan untuk SEMUA kandidat':null;
    const pool=DS_MODELS.map(k=>cand[k]).filter(c=>(c.cls==='ELIGIBLE'||c.cls==='CONDITIONAL')&&c.m);
    const costPool=pool.filter(c=>!c.limitFail);
    /* kewajaran perbandingan */
    const fair=[],okTon=bm&&bm.ton;
    const tonOff=DS_MODELS.filter(k=>{ const c=cand[k]; return c.m&&okTon&&c.m.ton!=null&&Math.abs(100*(c.m.ton/bm.ton-1))>DS_TON_TOL; });
    if(tonOff.length) fair.push('Tonase '+tonOff.map(k=>cand[k].label+' ('+gfPct(100*(cand[k].m.ton/bm.ton-1))+')').join(', ')+' berbeda >'+DS_TON_TOL+'% dari actual — selisih biaya TOTAL tidak setara; gunakan biaya per ton (itu pun dengan tonase yang didefinisikan berbeda: model = B×S×bench×densitas, actual = nilai sumber).');
    const tp=pool.filter(c=>c.m.ton!=null).map(c=>c.m.ton); if(tp.length>1&&(Math.max(...tp)/Math.min(...tp)-1)*100>DS_TON_TOL) fair.push('Tonase antar-model berbeda >'+DS_TON_TOL+'% — total biaya antar-model tidak sebanding.');
    const hOff=DS_MODELS.filter(k=>cand[k].m&&bm&&bm.holes!=null&&cand[k].m.holes!=null&&cand[k].m.holes!==bm.holes); if(hOff.length) fair.push('Jumlah lubang '+hOff.map(k=>cand[k].label).join(', ')+' berbeda dari actual.');
    if(F.basis.mode==='recorded') fair.push('Basis biaya = RECORDED ACTUAL COST (invoice): cakupan invoice bisa berbeda dari estimasi tiga komponen — selisih tidak setara.');
    if(F.extras.items.length) fair.push('Biaya tambahan aktif ('+F.extras.items.map(x=>x.label).join(', ')+') ikut dalam total; pastikan berlaku sama untuk semua alternatif.');
    fair.push('Cakupan biaya hanya pengeboran + bahan peledak + aksesori (+ tambahan opsional); primer/booster, tenaga kerja, digging/hauling tidak termasuk.');
    if(!field.count) fair.push('Hasil lapangan terukur (fragmentasi, toe, backbreak, getaran, flyrock, produktivitas) belum diisi — kualitas peledakan TIDAK dapat dinilai untuk alternatif mana pun.');
    else fair.push('Hasil lapangan hanya tersedia untuk geometri ACTUAL; alternatif model tidak punya pengukuran maupun model prediksi terverifikasi — tidak ada klaim kualitas untuk model.');
    return {F,S,cand,base,bm,field,pool,costPool,devParams,fair,tonOff,costDrop};
  }
  function dsTonWarn(c,D){ const a=D.bm&&D.bm.ton,t=c&&c.m&&c.m.ton; if(!a||!t) return null; const dv=100*(t/a-1); return Math.abs(dv)>DS_TON_TOL?('TIDAK SETARA: tonase '+c.label+' '+gfPct(dv)+' dari actual (model = B×S×bench×densitas; actual = nilai sumber). Selisih biaya/penghematan di atas belum merupakan perbandingan setara.'):null; }
  function dsPick(label,list,metric,lowerBetter,tie){ /* urut menurut metrik; kandidat dengan nilai sama TIDAK dipilih berdasarkan urutan array (lihat dsTie) */
    const arr=list.slice().sort((a,b)=>lowerBetter?metric(a)-metric(b):metric(b)-metric(a)); return {arr,winner:arr[0],second:arr[1]||null,close:arr[1]?tie(metric(arr[0]),metric(arr[1])):false};
  }
  function dsWinStatus(c){ return c.cls==='ELIGIBLE'&&c.col.geo&&c.col.geo.cls==='valid'?'VALID':'COND'; }
  /* v12.1: kebijakan seri tunggal untuk ketiga hasil — masuk margin seri → winner=null, semua kandidat teratas ditampilkan. Margin = aturan keputusan aplikasi, BUKAN standar teknis. */
  function dsTie(r,arr,metric,fmt,tie,margin,warns){
    const best=metric(arr[0]),tied=arr.filter(c=>tie(best,metric(c)));
    return Object.assign(r,{status:'UND',label:'BELUM DAPAT DITENTUKAN — SERI',winner:null,tied:tied.map(c=>c.key),lines:['Tidak ada pemenang unik (masuk margin seri): '+tied.map(c=>c.label+' '+fmt(metric(c))).join(' • ')+'.','Margin seri '+margin+' adalah aturan keputusan aplikasi, bukan ambang rekayasa/standar teknis peledakan. Kandidat tidak dipilih berdasarkan urutan daftar.'],warns:(warns||[]).slice()});
  }
  function dsResults(D){
    const {F,S,cand,base,bm,pool,costPool,devParams,field}=D,out={},cb=F.costBlock,pf=F.priceFlags,nFreshZero=()=>DS_MODELS.every(k=>!(cand[k].res&&methodFreshness(k)==='FRESH'));
    const freshZeroR=()=>({status:'UND',label:'BELUM DAPAT DITENTUKAN',winner:null,lines:['Belum ada hasil model yang FRESH — klik CALCULATE (atau hitung ulang bila STALE) sebelum keputusan dapat dibuat.'],warns:[]});
    const none=(r)=>nFreshZero()?freshZeroR():{status:'NONE',label:'BELUM ADA DESAIN YANG DAPAT DIREKOMENDASIKAN',winner:null,lines:[r],warns:[]};
    const excl=DS_MODELS.map(k=>cand[k]).filter(c=>c.cls==='EXCLUDED'||!c.m&&c.cls!=='ELIGIBLE'&&c.cls!=='CONDITIONAL');
    const exTxt=excl.length?('Dikecualikan: '+excl.map(c=>c.label+' ('+(c.why[0]||'tidak memenuhi syarat')+')').join('; ')+'.'):'';
    const priceWarns=()=>{ const w=[]; if(pf.zero.length) w.push('TARIF NOL dipakai ('+pf.zero.join('; ')+') — biaya komponen tersebut Rp 0; ini bukan keputusan ekonomi VALID.'); if(pf.noSource) w.push('Sumber harga (vendor/quotation dan tanggal) tidak tercatat — angka biaya tidak dapat ditelusuri.'); return w; };
    const costDepStatus=c=>(dsWinStatus(c)==='VALID'&&!pf.zero.length&&!pf.noSource)?'VALID':'COND';
    const costBlockR=()=>cb.kind==='WAITING'?{status:'UND',label:'BELUM DAPAT DITENTUKAN — HARGA BELUM LENGKAP',winner:null,lines:['WAITING FOR PRICE DATA — harga wajib belum valid: '+(cb.detail.join('; ')||'belum lengkap')+'.','LOWEST COST tidak ditetapkan; nilai kosong tidak dianggap nol.'],warns:[]}
      :cb.kind==='EXTRAS'?{status:'UND',label:'BELUM DAPAT DITENTUKAN — BIAYA TAMBAHAN TIDAK LENGKAP',winner:null,lines:['Biaya tambahan tidak lengkap/tidak valid: '+cb.detail.join('; ')+'.','Total biaya tidak tersedia sampai diperbaiki atau dikosongkan.'],warns:[]}
      :{status:'UND',label:'BELUM DAPAT DITENTUKAN — HARGA DEMO',winner:null,lines:['Harga bersumber DEMO EXAMPLE ('+cb.detail.join('; ')+') — biaya tidak dapat dinilai sebagai keputusan ekonomi.','Isi harga dari quotation/vendor (bukan data demo) untuk menetapkan LOWEST COST.'],warns:[]};
    /* 1. LOWEST COST */
    (function(){ const basisPT=S.costBasis==='perTon',key=basisPT?'costPerTon':'costTotal',lab=basisPT?'biaya per ton':'biaya total',unit=basisPT?'/t':'';
      const have=costPool.filter(c=>c.m[key]!=null),dropped=costPool.filter(c=>c.m[key]==null);
      const r={id:'lowest',title:'LOWEST COST',q:'Biaya terendah di antara kandidat yang memenuhi syarat kelayakan minimum',basis:lab,lines:[],warns:[]};
      if(nFreshZero()) Object.assign(r,freshZeroR());
      else if(!pool.length) Object.assign(r,none('Tidak ada model yang memenuhi syarat minimum (FRESH, input lengkap, bukan INVALID, bukan DEMO). '+exTxt));
      else if(cb.kind!=='OK') Object.assign(r,costBlockR());
      else if(!costPool.length) Object.assign(r,none('Semua kandidat melewati syarat geometri tetapi melanggar/tidak dapat diverifikasi terhadap batas biaya per ton yang diisi pengguna.'));
      else if(have.length<2) Object.assign(r,{status:'UND',label:'BELUM DAPAT DITENTUKAN',winner:null,lines:[have.length?('Hanya 1 kandidat dengan '+lab+' lengkap ('+have[0].label+') — tidak ada pembanding.'):'Biaya belum lengkap untuk kandidat mana pun (data kuantitas).',dropped.length?('Biaya tidak lengkap: '+dropped.map(c=>c.label).join(', ')+'.'):''].filter(Boolean)});
      else { const fmt=v=>gfRp(v)+unit,p=dsPick('',have,c=>c.m[key],true,(a,b)=>b-a<=0.01*Math.abs(a)),w=p.winner;
        if(p.close) dsTie(r,p.arr,c=>c.m[key],fmt,(a,b)=>b-a<=0.01*Math.abs(a),'1% dari biaya terendah',priceWarns());
        else { const st=costDepStatus(w);
          Object.assign(r,{status:st,label:st==='VALID'?'TERENDAH — lolos pemeriksaan wajib':'TERENDAH BERSYARAT',winner:w.key,lines:[w.label+' — '+fmt(w.m[key])+' ('+lab+')',(p.second?'Berikutnya: '+p.second.label+' '+fmt(p.second.m[key])+'.':'')].filter(Boolean),warns:priceWarns().concat(w.why)});
          if(dropped.length) r.lines.push('Tidak diikutkan (biaya tidak lengkap): '+dropped.map(c=>c.label).join(', ')+'.');
          const bv=bm&&bm[key]!=null?bm[key]:null;
          if(bv!=null&&base.cls==='BASELINE'){ const dd=w.m[key]-bv; r.lines.push('Baseline ACTUAL: '+fmt(bv)+' — '+(dd<0?'kandidat terendah lebih murah '+fmt(-dd)+' ('+gfPct(100*dd/bv)+')':'BASELINE ACTUAL lebih murah/sama dibanding semua model yang memenuhi syarat')+'.'); }
          else r.lines.push('Baseline ACTUAL belum dapat dibandingkan ('+(base.cls==='BASELINE'?'biaya actual tidak lengkap':'data actual tidak dapat dipakai')+').');
          { const tw=dsTonWarn(w,D); if(tw) r.warns.unshift(tw); }
          if(!basisPT&&D.tonOff.length) r.warns.push('TIDAK SETARA: tonase berbeda >'+DS_TON_TOL+'% dari actual — selisih/penghematan total jangan ditafsirkan sebagai perbandingan setara; baca biaya per ton.');
          r.alt=(function(){ const k2=basisPT?'costTotal':'costPerTon',h2=costPool.filter(c=>c.m[k2]!=null); if(h2.length<2) return null; const pk=dsPick('',h2,c=>c.m[k2],true,(a,b)=>b-a<=0.01*Math.abs(a)); if(pk.close) return {label:basisPT?'biaya total':'biaya per ton',winner:'seri',agree:false}; return {label:basisPT?'biaya total':'biaya per ton',winner:pk.winner.label,agree:pk.winner.key===w.key}; })();
          if(r.alt&&!r.alt.agree) r.warns.push('Menurut '+r.alt.label+' hasilnya '+(r.alt.winner==='seri'?'SERI':r.alt.winner)+' — keputusan bergantung pada basis (tonase tidak seragam).'); } }
      out.lowest=r; })();
    /* 2. CLOSEST TO ACTUAL (tidak bergantung pada harga) */
    (function(){ const r={id:'closest',title:'CLOSEST TO ACTUAL',q:'Model paling dekat dengan geometri aktual (rata-rata |deviasi %| parameter sebanding)',lines:[],warns:[]};
      if(nFreshZero()) Object.assign(r,freshZeroR());
      else if(base.cls!=='BASELINE'||!bm) Object.assign(r,{status:'UND',label:'BELUM DAPAT DITENTUKAN',winner:null,lines:['Baseline ACTUAL tidak dapat dipakai: '+(base.why.join('; ')||'belum ada baris aktual')+'.']});
      else if(devParams.length<DS_CLOSE_MIN_PARAMS) Object.assign(r,{status:'UND',label:'BELUM DAPAT DITENTUKAN',winner:null,lines:['Hanya '+devParams.length+' parameter actual > 0 yang sebanding (minimal '+DS_CLOSE_MIN_PARAMS+').']});
      else if(!pool.length) Object.assign(r,none('Tidak ada model yang memenuhi syarat minimum. '+exTxt));
      else { const have=pool.filter(c=>c.geoDev!=null); if(have.length<2) Object.assign(r,{status:'UND',label:'BELUM DAPAT DITENTUKAN',winner:null,lines:[have.length?('Hanya 1 kandidat yang memenuhi syarat ('+have[0].label+') — tidak ada pembanding.'):'Tidak ada kandidat dengan deviasi yang dapat dihitung.']});
        else { const fmt=v=>gfPct(v).replace('+',''),tie=(a,b)=>b-a<0.5,p=dsPick('',have,c=>c.geoDev,true,tie),w=p.winner;
          if(p.close) dsTie(r,p.arr,c=>c.geoDev,fmt,tie,'0,5 poin persen');
          else { const st=dsWinStatus(w);
            Object.assign(r,{status:st,label:st==='VALID'?'TERDEKAT — lolos pemeriksaan wajib':'TERDEKAT BERSYARAT',winner:w.key,lines:[w.label+' — deviasi rata-rata '+fmt(w.geoDev)+' dari actual ('+devParams.length+' parameter)','Deviasi terbesar: '+w.maxDev.l+' '+gfPct(w.maxDev.pct)+(p.second?' • Berikutnya: '+p.second.label+' '+fmt(p.second.geoDev)+'.':'.')],warns:w.why.slice()});
            r.warns.push('Dekat dengan actual ≠ lebih baik: actual hanyalah baseline pembanding.'); } } }
      out.closest=r; })();
    /* 3. BEST TECHNICAL BALANCE */
    (function(){ const r={id:'balance',title:'BEST TECHNICAL BALANCE',q:'Keseimbangan kelayakan, konsumsi handak, pengeboran, biaya, dan hasil lapangan terukur',lines:[],warns:[]},bp=pool.filter(c=>!c.limitFail),sc=dsScore(bp,S.weights,{costPerTon:D.costDrop});
      r.sc=sc; const nPos=DS_CRIT.filter(c=>S.weights[c.id]>0).length;
      r.evidence={used:sc.used.length,positive:nPos,groups:new Set(sc.used.map(u=>u.crit.group)).size,field:{models:0,baseline:field.count}};
      const costUsed=sc.used.some(u=>u.crit.id==='costPerTon');
      if(nFreshZero()) Object.assign(r,freshZeroR());
      else if(!pool.length) Object.assign(r,none('Tidak ada model yang memenuhi syarat minimum. '+exTxt));
      else if(bp.length<2) Object.assign(r,{status:'UND',label:'BELUM DAPAT DITENTUKAN',winner:null,lines:[bp.length?'Hanya 1 kandidat memenuhi syarat ('+bp[0].label+') — tidak ada pembanding.':'Semua kandidat tersaring oleh batas biaya per ton pengguna.']});
      else if(sc.used.length<DS_MIN_CRITERIA||r.evidence.groups<2) Object.assign(r,{status:'UND',label:'BELUM DAPAT DITENTUKAN',winner:null,lines:['Kriteria yang dapat dinilai untuk SEMUA kandidat hanya '+sc.used.length+' dalam '+r.evidence.groups+' kelompok (minimal '+DS_MIN_CRITERIA+' kriteria, 2 kelompok).','Dikeluarkan: '+(sc.dropped.map(d=>d.label+' ('+d.why+')').join('; ')||'—')]});
      else { const tie=(a,b)=>a-b<DS_TIE_POINTS,p=dsPick('',bp,c=>sc.scores[c.key].score,false,tie),w=p.winner,fmt=v=>gfNum(v,1)+' poin',ind=p.arr.map(c=>c.label+' '+gfNum(sc.scores[c.key].score,1)).join(' • ');
        if(S.requireField) Object.assign(r,{status:'UND',label:'BELUM DAPAT DITENTUKAN',winner:null,lines:['Syarat bukti lapangan aktif: tidak ada hasil lapangan terukur untuk alternatif model, dan aplikasi tidak punya model prediksi fragmentasi/getaran terverifikasi — keseimbangan TEKNIS tidak dapat dibuktikan.','Peringkat INDIKATIF berbasis biaya, konsumsi, geometri, dan peringatan fisik saja: '+ind+' (bukan keputusan).'].concat(p.close?['Skor teratas juga masuk margin seri (<'+DS_TIE_POINTS+' poin; aturan keputusan aplikasi, bukan standar teknis).']:[])});
        else if(p.close) { dsTie(r,p.arr,c=>sc.scores[c.key].score,fmt,tie,DS_TIE_POINTS+' poin skor'); }
        else Object.assign(r,{status:'COND',label:'KANDIDAT TERATAS BERSYARAT — INDIKATIF',winner:w.key,lines:[w.label+' — skor '+gfNum(sc.scores[w.key].score,1)+' dari 100','Peringkat: '+ind],warns:w.why.slice()});
        if(r.winner){ const tw=dsTonWarn(w,D); if(tw) r.warns.unshift(tw); }
        if(costUsed) r.warns=priceWarns().concat(r.warns);
        if(!S.requireField&&r.winner) r.warns.push('Syarat bukti lapangan DIMATIKAN pengguna: tidak ada bukti kualitas fragmentasi/getaran/produktivitas untuk model — ini bukan rekomendasi desain.'); }
      if(sc.dropped.length&&r.status!=='NONE') r.warns.push('Kriteria tidak dinilai: '+sc.dropped.map(d=>d.label+(d.id==='costPerTon'?' ('+d.why.split(';')[0]+')':'')).join(', ')+'.');
      out.balance=r; })();
    return out;
  }
  /* --- render --- */
  const DS_STLAB={PASS:'LOLOS',FAIL:'GAGAL',FLAG:'BERSYARAT',NA:'—'};
  function dsStClass(s){ return s==='VALID'?'info':s==='COND'?'cond':s==='NONE'?'none':'und'; }
  function dsGateCell(g){ if(!g) return '—'; return '<span class="ds-g ds-g--'+g.st.toLowerCase()+'">'+DS_STLAB[g.st]+'</span><br><small>'+htmlEscape(g.txt)+'</small>'; }
  function dsClsLabel(c){ return c.cls==='BASELINE'?'BASELINE (pembanding)':c.cls==='BASELINE_UNUSABLE'?'BASELINE TIDAK DAPAT DIPAKAI':c.cls==='EXCLUDED'?'DIKECUALIKAN':c.cls==='CONDITIONAL'?'KANDIDAT BERSYARAT':'KANDIDAT LAYAK'; }
  function dsResultCard(r,D){
    let h='<article class="ds-card ds-card--'+dsStClass(r.status)+'" id="dsCard_'+r.id+'"><div class="ds-card-head"><h4>'+r.title+'</h4><span class="ds-pill ds-pill--'+dsStClass(r.status)+'">'+htmlEscape(r.label)+'</span></div><p class="ds-q">'+htmlEscape(r.q)+'</p>';
    if(r.winner) h+='<div class="ds-winner">'+htmlEscape(D.cand[r.winner].label)+'</div>';
    h+=r.lines.map(l=>'<p class="ds-line">'+htmlEscape(l)+'</p>').join('');
    if(r.warns&&r.warns.length) h+='<ul class="ds-warns">'+r.warns.slice(0,5).map(w=>'<li>'+htmlEscape(w)+'</li>').join('')+'</ul>';
    if(r.id==='balance'&&r.evidence) h+='<p class="ds-ev">Bukti: '+r.evidence.used+'/'+r.evidence.positive+' kriteria terskor • hasil lapangan: model 0/'+DS_FIELD.length+(D.field.count?', actual '+D.field.count+'/'+DS_FIELD.length:', actual 0/'+DS_FIELD.length)+'</p>';
    return h+'</article>';
  }
  function dsRowsHtml(rows){ return rows.map(r=>r.head?('<tr class="ds-grp"><th colspan="5" scope="colgroup">'+r.head+'</th></tr>'):('<tr><th scope="row">'+r.l+'</th>'+r.c.map((x,i)=>'<td class="'+(i===0?'ds-base ':'')+(r.cls&&r.cls[i]||'')+'">'+(x==null?'<span class="gf-na">—</span>':x)+'</td>').join('')+'</tr>')).join(''); }
  function dsTables(D,res){
    const K=DS_KEYS.map(k=>D.cand[k]),n=(v,d)=>v==null?null:gfNum(v,d),dash='<span class="gf-na">N/A</span>',nm=(c,fn)=>c.m?fn(c.m,c):'<span class="gf-na">'+(c.state==='STALE'?'STALE — hitung ulang':c.state==='NO_RESULT'?'BELUM DIHITUNG':'BELUM ADA DATA')+'</span>';
    const mk=(l,f,d,u)=>({l:l+(u?' <small>'+u+'</small>':''),c:K.map(c=>nm(c,m=>m[f]==null?dash:n(m[f],d))),cls:K.map(c=>c.cls==='EXCLUDED'||c.col.invalid?'is-excl':'')});
    /* tabel 1: pemeriksaan wajib */
    const gateRows=[['fresh','Status hasil (FRESH/STALE)'],['inputs','Kelengkapan & validitas input'],['geom','Pemeriksaan geometri sesuai metode'],['formula','Status verifikasi formula'],['assume','Asumsi & keterbatasan model'],['units','Kuantitas & konsistensi satuan'],['cost','Kelengkapan biaya']];
    let t1=gateRows.map(([id,l])=>'<tr><th scope="row">'+l+'</th>'+K.map((c,i)=>'<td class="'+(i===0?'ds-base':'')+'">'+dsGateCell(c.gates.find(x=>x.id===id))+'</td>').join('')+'</tr>').join('');
    t1+='<tr class="ds-class"><th scope="row">Klasifikasi minimum</th>'+K.map((c,i)=>'<td class="'+(i===0?'ds-base ':'')+'ds-cls ds-cls--'+c.cls.toLowerCase()+'">'+dsClsLabel(c)+(c.limitFail?'<br><small>'+(c.limitFail==='over'?'melebihi batas biaya/ton (USER-DEFINED)':'biaya/ton tidak dapat diverifikasi terhadap batas pengguna')+'</small>':'')+'</td>').join('')+'</tr>';
    /* tabel 2: A, B, D, E */
    const rows=[];
    rows.push({head:'A • GEOMETRI'});
    [['B','Burden (B)','m'],['S','Spacing (S)','m'],['T','Stemming (T)','m'],['J','Sub-drill (J)','m'],['holeDepth','Kedalaman lubang','m']].forEach(([f,l,u])=>rows.push(mk(l,f,2,u)));
    rows.push(mk('B/D','BD',1,'')); rows.push(mk('S/B','SB',2,'')); rows.push(mk('Stiffness L/B','LB',2,''));
    rows.push({l:'Kriteria rentang yang berlaku (sumber)',c:K.map(c=>'<small>'+htmlEscape(DS_RANGE[c.key])+'</small>')});
    rows.push({head:'B • KONSUMSI & EFISIENSI'});
    rows.push(mk('Jumlah lubang','holes',0,'lubang')); rows.push(mk('Total drilling','drill',2,'m')); rows.push(mk('Charge / lubang','chargeMass',2,'kg')); rows.push(mk('Total charge','charge',1,'kg'));
    rows.push(mk('Powder factor','pfKgT',3,'kg/t')); rows.push(mk('Powder factor','pfKgM3',3,'kg/m³')); rows.push(mk('Volume','volume',1,'m³')); rows.push(mk('Tonase','ton',1,'t')); rows.push(mk('Pengeboran per ton','drillPerTon',4,'m/t'));
    rows.push({l:'Catatan definisi',c:K.map((c,i)=>i===0?'<small>tonase = nilai sumber (satuan ton: ASUMSI); drilling/charge bisa RECORDED atau ESTIMATED (lihat tabel biaya v11)</small>':'<small>tonase = B×S×bench×densitas; drilling = (bench+J)×lubang</small>')});
    rows.push({head:'D • EKONOMI (ESTIMASI — dari Financial Comparison v11)'});
    rows.push({l:'Total biaya <small>Rp</small>',c:K.map(c=>nm(c,m=>m.costTotal==null?'<span class="gf-na">'+htmlEscape(gfTotalMsg(D.F,c.col)||'N/A')+'</span>':gfRp(m.costTotal)+gfFlagTag(D.F))),cls:K.map(c=>c.col.invalid?'is-excl':'')});
    rows.push({l:'Biaya per lubang <small>Rp</small>',c:K.map(c=>nm(c,m=>m.costPerHole==null?dash:gfRp(m.costPerHole)))});
    rows.push({l:'Biaya per ton <small>Rp/t</small>',c:K.map(c=>nm(c,m=>m.costPerTon==null?dash:gfRp(m.costPerTon)+gfFlagTag(D.F)))});
    rows.push({l:'Selisih biaya vs basis',c:K.map(c=>{ const d=c.col.delta; if(!d||c.col.state!=='OK') return dash; if(d.state==='OK') return gfRp(d.rp,true)+' <small>('+gfPct(d.pct)+')</small>'; return '<span class="gf-na">N/A • '+(d.state==='INVALID'?'INVALID':d.state==='NA_BASIS'?'basis tidak tersedia':'biaya belum lengkap')+'</span>'; })});
    rows.push({l:'Selisih biaya per ton vs basis <small>%</small>',c:K.map(c=>{ const d=c.col.delta; return (d&&d.state==='OK'&&d.perTonPct!=null)?gfPct(d.perTonPct):dash; })});
    rows.push({l:'Komponen biaya terbesar',c:K.map(c=>c.m&&c.m.largest?htmlEscape(c.m.largest.label)+' <small>'+gfPct(c.m.largest.pct,0).replace('+','')+'</small>':dash)});
    rows.push({head:'E • HASIL LAPANGAN TERUKUR (hanya data nyata)'});
    DS_FIELD.forEach(([k,l,u])=>{ const v=D.field.vals[k]; rows.push({l:l+' <small>'+u+'</small>',c:K.map((c,i)=>i===0?(v==null?'<span class="ds-nodata">DATA BELUM TERSEDIA</span>':gfNum(v,2)+' <span class="gf-tag gf-tag--rec">TERUKUR</span>'):'<span class="ds-nodata">DATA BELUM TERSEDIA</span>')}); });
    rows.push({l:'Sumber pengukuran',c:K.map((c,i)=>i===0?(D.field.count?(D.field.source?htmlEscape(D.field.source):'<span class="gf-na">sumber belum dicatat</span>'):'<span class="gf-na">—</span>'):'<small>tidak ada pengukuran maupun model prediksi terverifikasi untuk alternatif ini</small>')});
    /* tabel 3: deviasi */
    const dv=[]; DS_DEV.forEach(([p,l,u])=>{ const a=D.bm?D.bm[p]:null; dv.push({l:l+' <small>'+u+'</small>',c:K.map((c,i)=>{ if(i===0) return a==null?dash:gfNum(a,2)+' <small>baseline</small>'; if(!c.m||!D.bm) return dash; const d=c.dev&&c.dev[p]; return d?(gfNum(d.abs,2)+' '+u+(d.pct!=null?' <small>('+gfPct(d.pct)+')</small>':' <small>(baseline ≤ 0)</small>')):dash; })}); });
    dv.push({l:'Rata-rata |deviasi %| (dasar CLOSEST)',c:K.map((c,i)=>i===0?'<small>—</small>':(c.geoDev!=null?'<b>'+gfPct(c.geoDev).replace('+','')+'</b>':dash))});
    const tn=(lab,f,u,d)=>({l:lab,c:K.map((c,i)=>{ const a=D.bm?D.bm[f]:null; if(i===0) return a==null?dash:gfNum(a,d)+' <small>baseline</small>'; if(!c.m||a==null||c.m[f]==null) return dash; const ab=c.m[f]-a; return gfNum(ab,d)+' '+u+' <small>('+gfPct(100*ab/a)+')</small>'; })});
    dv.push({head:'TIDAK SETARA / tidak dipakai untuk CLOSEST — definisi berbeda'});
    dv.push(tn('Tonase (model B×S×H×ρ vs nilai sumber)','ton','t',1)); dv.push(tn('PF kg/t (bergantung tonase)','pfKgT','kg/t',3));
    dv.push({l:'Total drilling / total charge',c:K.map((c,i)=>{ if(i===0) return '<small>baseline</small>'; if(!c.m||!D.bm) return dash; if(c.m.holes!==D.bm.holes) return '<span class="gf-na">TIDAK SETARA — jumlah lubang berbeda</span>'; const a=D.bm.drill,b=D.bm.charge; return (a?gfNum(c.m.drill-a,2)+' m '+'<small>('+gfPct(100*(c.m.drill/a-1))+')</small>':'')+'<br>'+(b?gfNum(c.m.charge-b,1)+' kg <small>('+gfPct(100*(c.m.charge/b-1))+')</small>':''); })});
    /* tabel 4: skor */
    const sc=res.balance.sc,pool=D.pool.filter(c=>!c.limitFail);
    let t4='<tr class="ds-head"><th>Kriteria</th><th>Normalisasi • sumber</th><th>Bobot</th>'+K.map(c=>'<th>'+c.label+'</th>').join('')+'</tr>';
    DS_CRIT.forEach(cr=>{ const w=D.S.weights[cr.id],u=sc.used.find(x=>x.crit.id===cr.id),dr=sc.dropped.find(x=>x.id===cr.id);
      t4+='<tr class="'+(u?'':'ds-dropped')+'"><th scope="row">'+cr.label+' <small>'+cr.unit+'</small><br><small>'+cr.group+'</small></th><td><small>'+htmlEscape(cr.norm)+'<br>'+htmlEscape(cr.src)+(dr?'<br><b>TIDAK DINILAI:</b> '+htmlEscape(dr.why):'')+'</small></td><td>'+gfNum(w,0)+(u&&sc.totalWeight?'<br><small>'+gfPct(100*w/sc.totalWeight,0).replace('+','')+' dari total</small>':'')+'</td>'+
        K.map((c,i)=>{ if(i===0){ const bv=D.bm?(cr.id==='costPerTon'?D.bm.costPerTon:cr.id==='drillPerTon'?D.bm.drillPerTon:null):null; return '<td class="ds-base">'+(bv!=null?gfNum(bv,cr.id==='costPerTon'?0:4)+'<br><small>referensi — tidak diskor</small>':'<small>referensi (deviasi = 0 menurut definisi)</small>')+'</td>'; }
          const p=pool.find(x=>x.key===c.key); if(!p) return '<td><span class="gf-na">tidak dikandidatkan</span></td>'; const raw=c.crit?c.crit[cr.id]:null; if(raw==null) return '<td><span class="ds-nodata">DATA KOSONG</span></td>';
          const part=sc.scores[c.key]&&sc.scores[c.key].parts[cr.id]; return '<td>'+gfNum(raw,cr.id==='costPerTon'?0:(cr.id==='drillPerTon'?4:(cr.dir==='min1'?0:2)))+(part?'<br><b>skor '+gfNum(part.norm,3)+'</b> <small>× '+gfNum(part.w,0)+'</small>':'<br><small>tidak dinilai</small>')+'</td>'; }).join('')+'</tr>'; });
    DS_FIELD.forEach(([k,l,u])=>{ t4+='<tr class="ds-dropped"><th scope="row">'+l+' <small>'+u+'</small><br><small>Hasil lapangan</small></th><td><small><b>TIDAK DINILAI:</b> hanya dapat dinilai bila pengukuran nyata ada untuk SEMUA kandidat; tidak ada model prediksi terverifikasi. Bukan nol.</small></td><td>—</td>'+K.map((c,i)=>'<td'+(i===0?' class="ds-base"':'')+'>'+(i===0&&D.field.vals[k]!=null?gfNum(D.field.vals[k],2)+'<br><small>terukur (baseline saja)</small>':'<span class="ds-nodata">DATA BELUM TERSEDIA</span>')+'</td>').join('')+'</tr>'; });
    t4+='<tr class="ds-total"><th scope="row">SKOR (0–100) = Σ bobot × skor ÷ Σ bobot kriteria terpakai</th><td><small>'+(sc.used.length?sc.used.length+' kriteria terpakai: '+sc.used.map(u=>u.crit.label).join(', '):'tidak ada kriteria yang dapat dinilai')+'</small></td><td>'+gfNum(sc.totalWeight,0)+'</td>'+K.map((c,i)=>{ if(i===0) return '<td class="ds-base"><small>baseline tidak diskor</small></td>'; const s=sc.scores[c.key]; return '<td>'+(s&&s.score!=null?'<b>'+gfNum(s.score,1)+'</b><br><small>'+(res.balance.status==='UND'?'INDIKATIF':'indikatif • bersyarat')+'</small>':'<span class="gf-na">'+(pool.find(x=>x.key===c.key)?'tidak dapat dinilai':'tidak dikandidatkan')+'</span>')+'</td>'; }).join('')+'</tr>';
    return {t1,t2:dsRowsHtml(rows),t3:dsRowsHtml(dv),t4};
  }
  function dsSourcesHtml(){
    return DS_MODELS.map(k=>{ const f=FORMULA_REGISTRY[k]; return '<details class="ds-src"><summary>'+GC_TITLE[k]+' • '+f.formulaId+' • '+f.version+' • '+f.status+'</summary><p><b>Referensi:</b> '+htmlEscape(f.reference||'tidak terlampir — BELUM TERVERIFIKASI')+'</p><p><b>Asumsi / deviasi implementasi:</b> '+htmlEscape(f.assumptions||'—')+'</p><pre>'+htmlEscape(f.displayedFormula)+'</pre></details>'; }).join('');
  }
  function dsHydrate(D){
    const S=D.S,set=(id,v)=>{ const el=$(id); if(el&&document.activeElement!==el){ const s=v==null?'':String(v); if(el.value!==s) el.value=s; } };
    DS_CRIT.forEach(c=>set('dsW_'+c.id,S.weights[c.id])); set('dsCostBasis',S.costBasis); set('dsMaxCost',S.maxCostPerTon);
    const rq=$('dsReqField'); if(rq) rq.checked=S.requireField;
    const rec=pdRec(); DS_FIELD.forEach(([k])=>set('dsF_'+k,rec[k])); set('dsF_fieldSource',rec.fieldSource);
    const ab=getActiveBlastRowForComparison(),rl=$('dsFieldRow'); if(rl) rl.textContent=ab?(ab.groupLabel+' • ROW '+ab.row.no):'belum ada baris aktif';
    const ps=$('dsPsdNote'); if(ps){ const x=psdPhys().x80; ps.textContent=Number.isFinite(x)?('Analisis foto PSD sesi ini: X80 = '+gfNum(x,1)+' cm. Tidak terikat ke baris blast — dipakai hanya bila Anda salin manual ke kolom X80 di atas.'):(psdUncalWithObjects()?'Analisis foto PSD ada tetapi foto belum dikalibrasi: X80 fisik NOT AVAILABLE (tidak ada nilai cm).':'Analisis foto PSD belum ada (atau tidak terikat ke baris blast).'); }
  }
  function renderGeometryDecision(){
    const host=$('geoDecPanel'); if(!host) return null;
    let D,res; try{ D=geometryDecisionCompute(); res=dsResults(D); }catch(e){ console.error('decision compute failed',e); $('dsAlerts').innerHTML='<div class="gf-alert gf-alert--bad">Perhitungan keputusan gagal: '+htmlEscape(String(e&&e.message||e))+'</div>'; return null; }
    dsHydrate(D); const T=dsTables(D,res);
    const sts=['lowest','closest','balance'].map(k=>res[k].status),nDet=sts.filter(s=>s==='VALID'||s==='COND').length,b=$('dsStatus');
    b.textContent=nDet===0?'BELUM ADA KEPUTUSAN YANG DAPAT DITETAPKAN':(nDet+'/3 HASIL — BERSYARAT'); b.className='kb-badge warn';
    $('dsCards').innerHTML=['lowest','closest','balance'].map(k=>dsResultCard(res[k],D)).join('');
    $('dsAlerts').innerHTML=gfPriceAlerts(D.F).concat(D.fair.map(t=>({lv:/TIDAK|berbeda|belum diisi/.test(t)?'warn':'info',t}))).map(x=>'<div class="gf-alert gf-alert--'+x.lv+'">'+htmlEscape(x.t)+'</div>').join('');
    $('dsBody1').innerHTML=T.t1; $('dsBody2').innerHTML=T.t2; $('dsBody3').innerHTML=T.t3; $('dsBody4').innerHTML=T.t4; $('dsSources').innerHTML=dsSourcesHtml();
    const fm=$('dsFieldMsg'); if(fm) fm.textContent=D.field.bad.length?('Nilai tidak valid diabaikan (bukan nol): '+D.field.bad.join(', ')):'';
    host._last={D,res}; return {D,res};
  }
  function wireGeometryDecision(){
    const P=$('geoDecPanel'); if(!P||P.dataset.wired) return; P.dataset.wired='1';
    const after=()=>{ persistWorking(); renderGeometryComparison(); };   /* v12.1: basis biaya memengaruhi ringkasan lama juga */
    DS_CRIT.forEach(c=>{ const el=$('dsW_'+c.id); el?.addEventListener('input',()=>{ const raw=String(el.value).trim(),v=Number(raw),ok=raw!==''&&Number.isFinite(v)&&v>=0&&v<=100,m=$('dsWMsg'); if(ok){ dsStore().weights[c.id]=v; if(m) m.textContent=''; } else if(m) m.textContent='Bobot harus angka 0–100 (0 = kriteria tidak dipakai). Nilai tidak valid ditolak.'; el.setAttribute('aria-invalid',ok?'false':'true'); after(); }); el?.addEventListener('change',()=>audit('Decision weight '+c.id,'',el.value,'USER INPUT','EDIT DECISION SETTINGS')); });
    $('dsCostBasis')?.addEventListener('change',()=>{ dsStore().costBasis=$('dsCostBasis').value==='total'?'total':'perTon'; audit('Decision cost basis','',dsStore().costBasis,'USER INPUT','EDIT DECISION SETTINGS'); after(); });
    $('dsReqField')?.addEventListener('change',()=>{ dsStore().requireField=!!$('dsReqField').checked; audit('Decision require field evidence','',String(dsStore().requireField),'USER INPUT','EDIT DECISION SETTINGS'); after(); });
    $('dsMaxCost')?.addEventListener('input',()=>{ const raw=String($('dsMaxCost').value).trim(),v=Number(raw); dsStore().maxCostPerTon=(raw!==''&&Number.isFinite(v)&&v>0)?v:null; after(); });
    DS_FIELD.forEach(([k])=>{ const el=$('dsF_'+k); el?.addEventListener('input',()=>{ const ok=pdSetRec(k,el.value); el.setAttribute('aria-invalid',ok?'false':'true'); const m=$('dsFieldMsg'); if(m&&!ok) m.textContent='Nilai ditolak (negatif / bukan angka).'; renderGeometryDecision(); }); });
    $('dsF_fieldSource')?.addEventListener('input',()=>{ pdSetRec('fieldSource',$('dsF_fieldSource').value); renderGeometryDecision(); });
  }

  function renderGeometryComparison(){
    geometryComparisonInputSync();
    const R=APP_STATE.geometry.results||{},cost=geometryCompareCostInputs();
    const costReady=cost.drilling!=null&&cost.explosive!=null&&cost.accessory!=null;
    const actual=actualEngineerGeometry();
    const methods=[['ash','R.L. Ash'],['konya','Calvin Konya'],['mae','MAE']];
    /* v12.1: hasil STALE tidak boleh dibaca tabel, delta, maupun ringkasan. Kolom STALE disembunyikan (result=null) dan ditandai; angka lama tidak ditampilkan. */
    const rows=[{key:'actual',label:'Engineer Actual',result:actual},...methods.map(([key,label])=>{ const raw=R[key],stale=!!raw&&methodFreshness(key)!=='FRESH'; return {key,label,result:stale?null:raw,stale}; })];
    /* v11: biaya hanya dari mesin biaya tunggal (geometryFinancialCompute): hasil STALE/INVALID tidak membawa angka biaya */
    const GFc=geometryFinancialCompute().cols;
    rows.forEach(x=>{ const c=GFc[x.key]; if(x.result) x.result=Object.assign({},x.result,{costPerTon:(c&&c.state==='OK'&&c.total!=null&&!c.invalid&&c.perTon!=null)?c.perTon:null}); });
    const defs=[
      ['Burden (B)','B','m',2],['Spacing (S)','S','m',2],['Stemming (T)','T','m',2],['Sub-drill (J)','J','m',2],['Hole depth','holeDepth','m',2],['Charge / hole','chargeMass','kg',2],['Total charge','totalCharge','kg',2],['Volume / hole','volumePerHole','m³',2],['Total volume','totalVolume','m³',1],['Tonnage / hole','tonnagePerHole','t',2],['Total tonnage','totalTonnage','t',1],['PF','pfKgT','kg/t',3],['PF volume','pfKgM3','kg/m³',3],['Total drilling','totalDrilling','m',2]
    ];
    /* v11: baris biaya dipindah ke panel PERBANDINGAN BIAYA GEOMETRI (menghindari dua tampilan biaya yang bisa berbeda) */
    let html='';
    /* AUDIT v8: validity row — a computed number is NOT automatically a valid design; smallest value is never auto-best. */
    html+='<tr><td><b>Status perhitungan</b></td><td class="actual-cell">DATA TERCATAT</td>'; rows.slice(1).forEach(x=>{html+=`<td class="${x.stale?'gc-stale-cell':''}">${x.stale?'STALE — hasil lama disembunyikan':(!x.result?'BELUM DIHITUNG':'TERHITUNG')}</td>`;}); html+='</tr>';
    html+='<tr><td><b>Status kelayakan (pemeriksaan wajib)</b></td><td class="actual-cell">SOURCE</td>';
    rows.slice(1).forEach(x=>{
      const stt=geoStatusOf(x.key,x.result),cls=x.stale?'is-warn':stt.cls==='invalid'?'is-invalid':stt.cls==='warn'?'is-warn':stt.cls==='valid'?'is-ok':stt.cls==='unv'?'is-unv':'',txt=x.stale?'STALE — HASIL LAMA, BUKAN UNTUK KEPUTUSAN':!x.result?'--':({invalid:'⛔ INVALID',warn:'⚠ WARNING',valid:'VALID',unv:'BELUM TERVERIFIKASI'})[stt.cls]||stt.label;
      html+=`<td class="${cls}"><b>${txt}</b></td>`;
    });
    html+='</tr>';
    html+='<tr><td>Catatan pemeriksaan fisik</td><td class="actual-cell">--</td>';
    rows.slice(1).forEach(x=>{
      const ws=(x.result&&x.result.warnings)||[];
      html+=`<td class="${ws.length||x.stale?'is-warn':''}" style="font-size:10.5px;text-align:left">${x.stale?'HASIL LAMA — STALE — BUKAN UNTUK KEPUTUSAN. Hitung ulang.':(ws.length?ws.map(htmlEscape).join('<br>'):'—')}</td>`;
    });
    html+='</tr>';
    for(const [label,key,unit,dec] of defs){
      const vals=rows.map(x=>x.result?x.result[key]:null);
      html+=`<tr><td>${label}${unit?' <small>'+unit+'</small>':''}</td>`;
      vals.forEach((v,idx)=>{let cls=idx===0?'actual-cell':'';if(idx>0&&rows[idx].result&&rows[idx].result.validity==='INVALID')cls+=' is-invalid';html+=`<td class="${cls.trim()}">${Number.isFinite(v)?(dec===0?Math.round(v).toLocaleString('id-ID'):v.toFixed(dec)):(rows[idx].stale?'<span class="gf-na">STALE</span>':'--')}</td>`;});html+='</tr>';
    }
    if(actual){
      const deltaDefs=[['Δ Burden vs Actual','B'],['Δ Spacing vs Actual','S'],['Δ Stemming vs Actual','T'],['Δ Sub-drill vs Actual','J'],['Δ Charge/hole vs Actual','chargeMass'],['Δ PF kg/t vs Actual','pfKgT']];
      for(const [label,key] of deltaDefs){html+=`<tr><td>${label} <small>%</small></td>`;html+='<td class="actual-cell">0.00</td>';rows.slice(1).forEach(x=>{const d=x.result?deltaPct(x.result[key],actual[key]):null;const cls=d!=null?(Math.abs(d)<=10?'delta-near':'delta-far'):'';html+=`<td class="${cls}">${d==null?(x.stale?'STALE':'--'):(d>=0?'+':'')+d.toFixed(1)+'%'}</td>`;});html+='</tr>';}
    }
    const body=$('geometryCompareBody');if(body)body.innerHTML=html||'<tr><td colspan="5">Belum ada hasil.</td></tr>';
    const status=APP_STATE.geometry.comparison?.status||'STALE';if($('geometryCompareStatus')){ $('geometryCompareStatus').textContent=status==='CALCULATED'?'DIHITUNG (bukan penilaian kelayakan)':status; $('geometryCompareStatus').className='kb-badge '+(status==='CALCULATED'?'ok':'warn'); }
    const active=(APP_STATE.formula.key||'ash').toUpperCase();if($('cmpActiveMethod'))$('cmpActiveMethod').textContent=active;if($('cmpActiveMethod2'))$('cmpActiveMethod2').textContent=active;
    const hasCalc=methods.some(([key])=>!!R[key]),nFreshM=methods.filter(([key])=>R[key]&&methodFreshness(key)==='FRESH').length;
    $('geometryCompareMsg').textContent=actual?(hasCalc&&!nFreshM?'BELUM ADA HASIL FRESH — HITUNG ULANG (hasil lama disembunyikan; tidak dipakai untuk keputusan).':hasCalc?`PERHITUNGAN SELESAI — kelayakan dinilai per kartu • dibandingkan dengan ${actual.groupLabel} / Row ${actual.rowNo} pada Blast Plan.`:`ACTUAL ROW LOADED • ${actual.groupLabel} / Row ${actual.rowNo}. Hitung 3 metode untuk compare.`):'Belum ada row aktual yang bisa dibandingkan.';
    geometryCompareBest(costReady,rows);
    renderGeometryActualCard();
    renderGeometryCards();
    renderPhaseAStatus();
    renderGeometryFinancial();
    renderGeometryDecision();
  }
  function exportGeometryComparison(){
    const R=APP_STATE.geometry.results||{},cost=geometryCompareCostInputs(),costReady=cost.drilling!=null&&cost.explosive!=null&&cost.accessory!=null,actual=actualEngineerGeometry();
    const keys=[['actual','Engineer Actual'],['ash','R.L. Ash'],['konya','Calvin Konya'],['mae','MAE']],cols=['Method','Source','Group','Row','Validity','Warnings','Burden_m','Spacing_m','Stemming_m','Subdrill_m','HoleDepth_m','ChargeKgPerHole','TotalChargeKg','VolumePerHole_m3','TotalVolume_m3','TonnagePerHole_t','TotalTonnage_t','PF_kg_t','PF_kg_m3','TotalDrilling_m','DrillingCost_IDR','ExplosiveCost_IDR','AccessoryCost_IDR','TotalDirectBlastCost_IDR','DirectCostPerTon_IDR'];
    const lines=[cols.join(',')],GFx=geometryFinancialCompute().cols,gcv=(k,f)=>{const c=GFx[k];if(!c||c.state!=='OK')return '';const v=f==='total'?c.total:f==='perTon'?c.perTon:c.comp[f];return v==null?'':Math.round(v);};
    keys.forEach(([k,name])=>{const r=k==='actual'?actual:R[k];if(!r)return;
      if(k!=='actual'&&methodFreshness(k)!=='FRESH'){ lines.push([name,'CALCULATION',r.groupLabel||'',r.rowNo??'','STALE — HASIL LAMA TIDAK DIEKSPOR','"hitung ulang sebelum ekspor"'].concat(Array(19).fill('')).join(',')); return; }
      const val=k==='actual'?'SOURCE':geoStatusOf(k,r).label;const warn=k==='actual'?'':('"'+(r.warnings||[]).join(' | ').replace(/"/g,"'")+'"');lines.push([name,k==='actual'?'BLAST PLAN':'CALCULATION',r.groupLabel||'',r.rowNo??'',val,warn,r.B,r.S,r.T,r.J,r.holeDepth,r.chargeMass,r.totalCharge,r.volumePerHole,r.totalVolume,r.tonnagePerHole,r.totalTonnage,r.pfKgT,r.pfKgM3,r.totalDrilling,gcv(k,'drilling'),gcv(k,'explosive'),gcv(k,'accessory'),gcv(k,'total'),gcv(k,'perTon')].join(','));});
    downloadText('Geometry_3_Method_Comparison.csv',lines.join('\n'),'text/csv');
  }
  function wireGeometryComparison__legacy(){
    geometryComparisonInputSync(true);
    $('btnLoadProjectGeometryCompare')?.addEventListener('click',()=>{geometryComparisonInputSync(true);APP_STATE.geometry.comparison.status='STALE';renderGeometryComparison();});
    [['btnCalcAsh','ash'],['btnCalcKonya','konya'],['btnCalcMae','mae']].forEach(([id,key])=>$(id)?.addEventListener('click',()=>{setFormula(key);geometryComparisonReadInputs();geometryCompareCalculate([key]);}));
    $('btnCalcAllGeometry')?.addEventListener('click',()=>geometryCompareCalculate(['ash','konya','mae']));
    $('btnApplyGeometryToSim')?.addEventListener('click',applyActiveGeometryToSimulator);
    $('btnExportGeometryCompare')?.addEventListener('click',exportGeometryComparison);
    $('cmpRockDensityBasis')?.addEventListener('change',()=>{const basis=$('cmpRockDensityBasis').value||'active',ref=geometryComparisonDensityReference(),ci=APP_STATE.geometry.comparisonInputs||(APP_STATE.geometry.comparisonInputs={});ci.densityBasis=basis;if(basis==='active')ci.rockDensity=geometryLabBaseDensity();else if(basis==='custom'){}else ci.rockDensity=ref[basis];geometryComparisonInputSync();APP_STATE.geometry.comparison.status='STALE';renderGeometryComparisonProvenance();});
    ['cmpDiameterIn','cmpBenchHeight','cmpExplosiveDensity','cmpRockDensity','cmpStv','cmpFiring','cmpAshVod','cmpAshKs','cmpKonyaKd','cmpKonyaKr','cmpKonyaKs'].forEach(id=>$(id)?.addEventListener('input',()=>{const ci=APP_STATE.geometry.comparisonInputs||(APP_STATE.geometry.comparisonInputs={});ci.loaded=true;ci.source='USER COMPARISON INPUT';if(id==='cmpRockDensity')ci.densityBasis='custom';APP_STATE.geometry.comparison.status='STALE';if($('geometryCompareStatus'))$('geometryCompareStatus').textContent='STALE';renderGeometryComparisonProvenance();}));
    ['cmpDrillingCost','cmpExplosiveCost','cmpAccessoryCost'].forEach(id=>$(id)?.addEventListener('input',()=>{APP_STATE.geometry.comparison.status='STALE';renderGeometryComparisonProvenance();}));
  }

  function validateAll__legacy(){
    const i=APP_STATE.geometry.input, errors=[]; const vals=[['diameterIn',i.diameterIn],['benchHeight',i.benchHeight],['explosiveDensity',i.explosiveDensity],['holeCount',i.holeCount],['targetX80',i.targetX80],['airDeckPct',i.airDeckPct]];
    vals.forEach(([k,v])=>{ if(!Number.isFinite(v)) errors.push(`${k}: NaN/Infinity`); else if(v<0) errors.push(`${k}: negative`); });
    if(i.diameterIn===0||i.benchHeight===0||i.holeCount===0||i.targetX80===0) errors.push('zero input where positive value is required');
    if(i.airDeckPct>100) errors.push('airDeckPct > 100');
    const g=calculateGeometry(APP_STATE); if(!g) errors.push((APP_STATE.formula.key==='mae'&&MAE_ERR)||'material density missing/invalid'); else if(g.T>g.H) errors.push('stemming > hole depth'); else if(g.chargeMass<=0) errors.push('charge mass <= 0');
    const f=APP_STATE.financial; if(f.anfoIdrKg<0||f.secondaryIdrUnit<0) errors.push('financial price < 0');
    if(errors.length){ $('validationErrors').classList.remove('kb-hidden'); $('validationErrors').innerHTML='<strong>VALIDATION ERROR</strong><br>'+errors.map(e=>'• '+htmlEscape(e)).join('<br>'); return false; }
    $('validationErrors').classList.add('kb-hidden'); return true;
  }

  function ensureBlastRowOverrides(){
    if(!APP_STATE.simulation.rowOverrides || typeof APP_STATE.simulation.rowOverrides!=='object') APP_STATE.simulation.rowOverrides={};
    return APP_STATE.simulation.rowOverrides;
  }
  const MANUAL_BLAST_NUMERIC_FIELDS=['holes','spacing','burden','depth','subDepth','an','dn','totalAn','totalDn','det','cw','fuel','charging','stemming','dev','rc','bsr','volume','pf'];
  function blankManualBlastRow(no){const r={no,unit:''};MANUAL_BLAST_NUMERIC_FIELDS.forEach(k=>r[k]=null);return r;}
  function manualBlockSlug(label){return String(label||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,48)||'blok';}
  function registerManualBlastGroups(){
    if(!APP_STATE.simulation||typeof APP_STATE.simulation!=='object')return;
    if(!Array.isArray(APP_STATE.simulation.customBlocks))APP_STATE.simulation.customBlocks=[];
    const clean=[];
    APP_STATE.simulation.customBlocks.forEach(g=>{
      if(!g||typeof g!=='object')return;
      let label=String(g.label||'').trim().replace(/\s+/g,' ').slice(0,80);if(!label)return;
      let key=String(g.key||'');if(!/^manual_[a-z0-9_]+$/i.test(key)||BLAST_SHEET_ROWS[key])key='manual_'+manualBlockSlug(label);
      let seed=key,n=2;while(BLAST_SHEET_ROWS[key]||clean.some(x=>x.key===key)){key=seed+'_'+n++;}
      let rows=Array.isArray(g.rows)?g.rows.filter(r=>r&&Number.isFinite(Number(r.no))&&Number(r.no)>0).map(r=>({...blankManualBlastRow(Math.round(Number(r.no))),...r,no:Math.round(Number(r.no)),unit:String(r.unit||'')})):[];
      if(!rows.length)rows=[blankManualBlastRow(1)];
      rows.sort((a,b)=>a.no-b.no);
      const manual={key,label,face:'Manual',totalHoles:rows.reduce((sum,r)=>sum+(Number(r.holes)||0),0),rows,isManual:true,createdAt:g.createdAt||new Date().toISOString()};
      BLAST_SHEET_ROWS[key]=manual;clean.push({key,label,face:'Manual',totalHoles:manual.totalHoles,rows:rows.map(r=>({...r})),isManual:true,createdAt:manual.createdAt});
    });
    APP_STATE.simulation.customBlocks=clean;
  }
  function getOrCreateManualBlastGroup(label){
    const raw=String(label||'').trim().replace(/\s+/g,' ').slice(0,80);if(!raw)return null;
    const norm=x=>String(x||'').trim().replace(/\s+/g,' ').toLowerCase();
    // Only reuse a manual block. A source-template label must never hijack manual creation.
    const exists=Object.entries(BLAST_SHEET_ROWS).find(([k,g])=>g.isManual&&norm(g.label)===norm(raw));
    if(exists)return {key:exists[0],isNew:false};
    if(!Array.isArray(APP_STATE.simulation.customBlocks))APP_STATE.simulation.customBlocks=[];
    const saved=APP_STATE.simulation.customBlocks.find(g=>g&&g.isManual&&norm(g.label)===norm(raw));
    if(saved&&BLAST_SHEET_ROWS[saved.key]?.isManual)return {key:saved.key,isNew:false};
    const seed='manual_'+manualBlockSlug(raw);let key=seed,n=2;while(BLAST_SHEET_ROWS[key])key=seed+'_'+n++;
    const row=blankManualBlastRow(1),custom={key,label:raw,face:'Manual',totalHoles:0,rows:[row],isManual:true,createdAt:new Date().toISOString()};
    BLAST_SHEET_ROWS[key]=custom;APP_STATE.simulation.customBlocks.push({key,label:raw,face:'Manual',totalHoles:0,rows:[{...row}],isManual:true,createdAt:custom.createdAt});
    return {key,isNew:true};
  }
  function addManualBlastRow(groupKey){
    const g=BLAST_SHEET_ROWS[groupKey];if(!g||!g.isManual)return null;
    const no=Math.max(0,...g.rows.map(r=>Number(r.no)||0))+1,row=blankManualBlastRow(no);g.rows.push(row);
    const saved=(APP_STATE.simulation.customBlocks||[]).find(x=>x.key===groupKey);if(saved){saved.rows=g.rows.map(r=>({...r}));saved.totalHoles=g.rows.reduce((sum,r)=>sum+(Number(r.holes)||0),0);}
    return no;
  }
  /* TAHAP-1: hapus satu baris pada BLOK MANUAL. Template bawaan tetap dilindungi (isManual saja),
     baris terakhir tidak boleh dihapus sendiri (pakai HAPUS BLOK MANUAL), dan data turunannya ikut dibersihkan. */
  function deleteManualBlastRow(groupKey,rowNo){
    const g=BLAST_SHEET_ROWS[groupKey]; if(!g||!g.isManual||!Array.isArray(g.rows)) return null;
    const no=Number(rowNo), i=g.rows.findIndex(r=>Number(r.no)===no); if(i<0) return null;
    if(g.rows.length<=1) return false;
    g.rows.splice(i,1);
    const recKey=blastRowOverrideKey(groupKey,no);
    try{ delete pdRecStore()[recKey]; }catch(_e){}
    try{ delete (APP_STATE.simulation.rowOverrides||{})[recKey]; }catch(_e){}
    try{ const wb=APP_STATE.kuzram&&APP_STATE.kuzram.wipBy; if(wb) Object.keys(wb).forEach(k=>{ if(k===groupKey+'|'+no) delete wb[k]; }); }catch(_e){}
    const saved=(APP_STATE.simulation.customBlocks||[]).find(x=>x.key===groupKey);
    if(saved){ saved.rows=g.rows.map(r=>({...r})); saved.totalHoles=g.rows.reduce((s,r)=>s+(Number(r.holes)||0),0); }
    return g.rows.length;
  }
  function syncManualBlastGroupStorage(groupKey){
    const g=BLAST_SHEET_ROWS[groupKey];if(!g?.isManual)return;
    if(!Array.isArray(APP_STATE.simulation.customBlocks))APP_STATE.simulation.customBlocks=[];
    let saved=APP_STATE.simulation.customBlocks.find(x=>x.key===groupKey);
    if(!saved){saved={key:groupKey,label:g.label,face:'Manual',isManual:true,createdAt:g.createdAt||new Date().toISOString()};APP_STATE.simulation.customBlocks.push(saved);}
    saved.label=g.label;saved.rows=g.rows.map(r=>({...r}));saved.totalHoles=g.rows.reduce((sum,r)=>sum+(Number(r.holes)||0),0);
  }
  function blastRowOverrideKey(groupKey,rowNo){ return `${groupKey}::${rowNo}`; }
  function getBlastRow(groupKey,rowNo){
    const base=BLAST_SHEET_ROWS[groupKey]?.rows?.find(x=>x.no===Number(rowNo))||null;
    if(!base) return null;
    const ov=ensureBlastRowOverrides()[blastRowOverrideKey(groupKey,rowNo)]||{};
    return {...base,...ov};
  }
  function setBlastRowField(groupKey,rowNo,field,value){
    const key=blastRowOverrideKey(groupKey,rowNo), all=ensureBlastRowOverrides();
    if(value==null){if(all[key]){delete all[key][field];if(!Object.keys(all[key]).length)delete all[key];}return;}
    if(!all[key]) all[key]={};
    all[key][field]=value;
  }
  function syncActiveBlastInputsToSimulation(r){
    if(!r) return;
    const manual=!!BLAST_SHEET_ROWS[APP_STATE.simulation.template]?.isManual;
    const rowNum=v=>{if(v==null||String(v).trim()==='')return manual?null:0;const n=Number(v);return Number.isFinite(n)?n:(manual?null:0);};
    APP_STATE.simulation.parameters.holeCount=rowNum(r.holes);
    APP_STATE.simulation.parameters.spacingM=rowNum(r.spacing);
    APP_STATE.simulation.parameters.burdenM=rowNum(r.burden);
    APP_STATE.simulation.parameters.depthM=rowNum(r.depth);
    APP_STATE.simulation.parameters.subDepthM=rowNum(r.subDepth);
    APP_STATE.simulation.parameters.anPerHoleKg=rowNum(r.an);
    APP_STATE.simulation.parameters.dnPerHoleKg=rowNum(r.dn);
    APP_STATE.simulation.parameters.stemmingM=rowNum(r.stemming);
    APP_STATE.simulation.parameters.det=rowNum(r.det);
    if(manual){
      setInput('gi.holeCount',Number(r.holes)>0?Number(r.holes):null,'holes','USER_EDIT','MANUAL BLAST GROUP','row holes (blast row loader)');
    }else if(Number(r.holes)>0){
      setInput('gi.holeCount',Number(r.holes),'holes','PROJECT_INPUT','BLAST_SHEET_ROWS','row holes (blast row loader)');
    }
    updateInputsFromState();
  }
  function editActiveBlastRowField(field,rawValue){
    const groupKey=APP_STATE.simulation.template||'group1', rowNo=Number(APP_STATE.simulation.activeBlastRow||1), base=getBlastRow(groupKey,rowNo);
    if(!base) return false;
    const numericFields=new Set(['holes','spacing','burden','depth','subDepth','an','dn','totalAn','totalDn','charging','stemming','det','fuel','dev','rc','bsr','volume','pf']);
    let value=rawValue;
    if(numericFields.has(field)){
      const raw=String(rawValue??'').trim();
      if(raw===''&&BLAST_SHEET_ROWS[groupKey]?.isManual){ value=null; }
      else {
        value=Number(rawValue);
        if(!Number.isFinite(value)) return false;
        if(field==='holes'||field==='det') value=Math.max(0,Math.round(value)); else value=Math.max(0,value);
        if(['spacing','burden'].includes(field) && value<=0) return false;
      }
    }else{
      value=String(rawValue??'').trim();
      if(!value) return false;
    }
    const old=base[field];
    setBlastRowField(groupKey,rowNo,field,value);
    if(BLAST_SHEET_ROWS[groupKey]?.isManual) syncManualBlastGroupStorage(groupKey);
    const merged=getBlastRow(groupKey,rowNo);
    syncActiveBlastInputsToSimulation(merged);
    if($('blastEditStatus')) $('blastEditStatus').textContent=`EDITED • ROW ${rowNo} • ${field.toUpperCase()}`;
    audit(`Blast plan ${field}`,old,value,'USER INPUT','EDIT ACTIVE ROW');
    refreshGeometry();
    renderBlastTemplateTable(groupKey);
    simHydrate();
    simVisual();
    renderPlanView();
    calculateFinancial();
    try{ markScreeningStale(`rencana baris aktif diubah • ${field.toUpperCase()}`); }catch(_e){}
    persistWorking();
    return true;
  }
  function autoRecalcActiveBlastRow(){
    const groupKey=APP_STATE.simulation.template||'group1', rowNo=Number(APP_STATE.simulation.activeBlastRow||1), r=getBlastRow(groupKey,rowNo);
    if(!r) return;
    const totalAn=Math.max(0,Number(r.holes)||0)*Math.max(0,Number(r.an)||0);
    const totalDn=Math.max(0,Number(r.holes)||0)*Math.max(0,Number(r.dn)||0);
    const det=Math.max(0,Math.round(Number(r.holes)||0));
    const pf=Number(r.volume)>0?totalAn/Number(r.volume):0;
    const key=blastRowOverrideKey(groupKey,rowNo), all=ensureBlastRowOverrides();
    if(!all[key]) all[key]={};
    Object.assign(all[key],{totalAn:Number(totalAn.toFixed(1)),totalDn:Number(totalDn.toFixed(1)),det,pf:Number(pf.toFixed(3))});
    if(BLAST_SHEET_ROWS[groupKey]?.isManual) syncManualBlastGroupStorage(groupKey);
    const merged=getBlastRow(groupKey,rowNo);syncActiveBlastInputsToSimulation(merged);
    if($('blastEditStatus')) $('blastEditStatus').textContent=`AUTO RECALC • ROW ${rowNo}`;
    audit('Blast plan auto totals','',`Row ${rowNo} • Total AN ${totalAn.toFixed(1)} • Total DN ${totalDn.toFixed(1)} • PF ${pf.toFixed(3)}`,'USER ACTION','AUTO TOTAL / PF');
    refreshGeometry();renderBlastTemplateTable(groupKey);simHydrate();simVisual();renderPlanView();calculateFinancial();try{ markScreeningStale('Auto Total / PF dihitung ulang'); }catch(_e){}persistWorking();
  }

  function refreshGeometry(){
    const key=APP_STATE.simulation?.template||'group1';
    const g=BLAST_SHEET_ROWS[key]||BLAST_SHEET_ROWS.group1;
    const rows=g?.rows||[];
    const activeRow=Number(APP_STATE.simulation?.activeBlastRow||1);
    const r=getBlastRow(key,activeRow)||(rows[0]?getBlastRow(key,rows[0].no):null);
    const put=(id,v)=>{const el=$(id);if(!el)return; if(el instanceof HTMLInputElement) el.value=String(v??''); else el.textContent=String(v??'');};
    if(!r){
      /* placeholder "--" (dari HTML) yang menampilkan field kosong; menulis '--' ke input type=number ditolak browser. */
      ['geoHoleCount','geoS','geoB','geoDepthDrill','geoDepthSub','geoUnit','geoAN','geoDN','geoTotalAN','geoTotalDN','geoCharging','geoT','geoDet','geoFuel','geoDEV','geoRC','geoBSR','geoVol','geoPF'].forEach(id=>put(id,''));
      put('blastPlanMeta',`GROUP / LOKASI: ${APP_STATE.simulation.groupLabel||g?.label||'--'} • FREE FACE: ${g?.face||'--'} • TOTAL HOLES GROUP: ${g?.totalHoles??0}`);
      return;
    }
    // IMPORTANT: these are real form inputs. Never inject unit labels into input.value;
    // type=number silently rejects values such as '3.50 m', which makes the field
    // appear populated while actually becoming non-editable/blank in the browser.
    /* field kosong (null/'') tetap kosong — bukan 0 atau 'NaN' yang tampak seperti data */
    const num=(v)=>v==null||String(v).trim()===''?'':(Number.isFinite(Number(v))?Number(v):'');
    put('geoHoleCount',num(r.holes)); put('geoS',num(r.spacing)); put('geoB',num(r.burden));
    put('geoDepthDrill',num(r.depth)); put('geoDepthSub',num(r.subDepth)); put('geoUnit',r.unit);
    put('geoAN',num(r.an)); put('geoDN',num(r.dn)); put('geoTotalAN',num(r.totalAn)); put('geoTotalDN',num(r.totalDn));
    put('geoCharging',num(r.charging)); put('geoT',num(r.stemming)); put('geoDet',num(r.det)); put('geoFuel',num(r.fuel));
    put('geoDEV',num(r.dev)); put('geoRC',num(r.rc)); put('geoBSR',num(r.bsr)); put('geoVol',num(r.volume)); put('geoPF',num(r.pf));
    put('blastPlanMeta',`GROUP / LOKASI: ${APP_STATE.simulation.groupLabel||g.label||'--'} • FREE FACE: ${g.face||'--'} • TOTAL HOLES GROUP: ${(g.totalHoles??0).toLocaleString('id-ID')} • ROW ${r.no}`);
    if($('geometrySource'))$('geometrySource').textContent=`Source: ${g.label} • Row ${r.no}. Data mengikuti template handak.`;
    if($('blastGroupInput'))$('blastGroupInput').value=APP_STATE.simulation.groupLabel||g.label; if($('blastRowSelect'))$('blastRowSelect').value=String(r.no);
    APP_STATE.geometry.result=calculateGeometry(APP_STATE); renderMaeCode();
    /* PHASE A: engineer-actual row no longer overwrites the CALCULATED geometry result */
  }

  function updateInputsFromState(){ const i=APP_STATE.geometry.input; ['diameterIn','benchHeight','explosiveDensity','holeCount','targetX80','airDeckPct'].forEach(k=>{if($(k))$(k).value=i[k]??''}); $('airDeckPct2').value=i.airDeckPct??0; }
  function recalcFromFormInput__legacy(){ const i=APP_STATE.geometry.input; for(const k of Object.keys(i)){const key=k; const id=key; if($(id)) i[key]=Number($(id).value);} APP_STATE.geometry.inputSource='USER INPUT'; APP_STATE.optimizer.airDeckPct=i.airDeckPct; audit('GEOMETRY INPUTS','',JSON.stringify(i),'USER INPUT','GEOMETRY UPDATE'); validateAll(); refreshAll(); }

  function setupFormation(key){
    const old=APP_STATE.formation.key;
    APP_STATE.formation.key=key;
    APP_STATE.formation.label='Gamping / Dolomit';
    const targetQuality=key==='pedel'?'PEDEL':(APP_STATE.material.labSnapshot?.groups?.HG?'HG':(APP_STATE.material.labSnapshot?.groups?.MG?'MG':activeLabQualityKey()));
    if(targetQuality && APP_STATE.material.labSnapshot?.groups?.[targetQuality]){
      APP_STATE.material.qualityKey=targetQuality;
      applyLabSnapshotToWorking(targetQuality);
    }
    audit('Formation',old,key.toUpperCase(),'USER ACTION','FORMATION SWITCH');
    renderFormation();
    renderLab();
    refreshAll();
    persistWorking();
  }
  function renderFormation(){try{syncFormationPick();}catch(_e){}
    const p=APP_STATE.formation.key;
    $('formationPedel').classList.toggle('btn--accent',p==='pedel');
    $('formationLimestone').classList.toggle('btn--accent',p==='limestone');
    const q=activeLabQualityKey();
    const meta=qualityMeta(q);
    const profile=getActiveLabProfile();
    $('formationStatus').textContent=APP_STATE.formation.label+(q?` • LAB ${q}`:'');
    if(profile){
      $('formationNote').textContent=`Lab aktif: ${meta.name} (${meta.description}) • ${profile.sampleCount} sampel. Nilai Density dan parameter kimia ditarik dari kelas Kualitas aktif; tidak ada re-klasifikasi kimia otomatis.`;
    }else{
      $('formationNote').textContent='Belum ada data laboratorium aktif. Import file laboratorium atau pilih kelas Kualitas yang tersedia.';
    }
  }

  /* MAE (Modified Available Energy): Eq.(17)-(29) dari makalah yang dilampirkan. Eq.(6) [LD] dan Eq.(30) TIDAK ada di cuplikan:
     LD diasumsikan = densitas handak x luas lubang (kg/m); jumlah baris N dibulatkan ke atas; rho_RM = densitas batuan dari lab; UCS diasumsikan MPa.
     H pada Eq.26 = tinggi bench (BUKAN faktor kekerasan Hk dari Eq.21). Default input = CONTOH, bukan data lokasi. Output = screening. */
  var MAE_ERR='';
  function maeDefaults(){ return {xi:null,jps:null,jpo:null,ucs:null,cw:null,stf:0.7,sbf:0.3}; }
  function maeState__legacy(){ const f=APP_STATE.formula,d=maeDefaults(); if(!f.mae||typeof f.mae!=='object'||Array.isArray(f.mae)) f.mae={}; for(const k in d) if(!(k in f.mae)) f.mae[k]=d[k]; return f.mae; }
  function maeCalc(Dm,benchH,eSG,rhoRM,m){
    const v=k=>(m&&m[k]!==null&&m[k]!==''&&m[k]!==undefined)?Number(m[k]):NaN; const fail=e=>{MAE_ERR='MAE: '+e;return null;};
    const xi=v('xi'),jps=v('jps'),jpo=v('jpo'),ucs=v('ucs'),cw=v('cw'),stf=v('stf'),sbf=v('sbf');
    if(![xi,jps,jpo,ucs,cw,stf,sbf,Dm,benchH,eSG,rhoRM].every(Number.isFinite)) return fail('ada input kosong / bukan angka');
    if(xi<0||ucs<0||sbf<0||cw<=0||stf<=0||benchH<=0) return fail('x_i, UCS, Sb_f harus >= 0; CW, St_f, tinggi bench harus > 0');
    if(![10,20,50].includes(jps)||![10,20,30,40].includes(jpo)) return fail('kelas JPS/JPO tidak valid');
    const RMD=10+10*xi,RDI=25*rhoRM-50,Hk=(ucs+23.7)/47.6,BI=0.5*(RMD+jps+jpo+RDI+Hk),PF=0.004*BI*rhoRM;
    if(!(PF>0)) return fail('PF_BI <= 0 (BI='+BI.toFixed(1)+'); cek densitas batuan / input geologi');
    const LD=eSG*1000*Math.PI*(Dm/2)**2,AE=LD/PF,Stl=Math.sqrt(AE)*stf,Sb=Stl*sbf,SA=AE*(1-(Stl-Sb)/benchH);
    if(!(SA>0)) return fail('SA <= 0: stemming (St_f x sqrt(AE)) terlalu besar terhadap tinggi bench');
    const N=Math.max(1,Math.ceil(cw/Math.sqrt(SA)-1e-9)),S=cw/N,B=SA/S;
    return {B,S,T:Stl,J:Sb,RMD,RDI,Hk,BI,PF,LD,AE,SA,N,CW:cw};
  }
  function renderMaeCode(){ try{ maeRefRender(); }catch(_e){} const el=$('formulaCode'); if(!el||APP_STATE.formula.key!=='mae') return; const g=APP_STATE.geometry.result,d=(g&&g.method==='mae')?g:null; /* AUDIT v8 fix: field hasil berada di level atas result, tidak pernah ada g.mae */
    const head=formulaUiText('mae');
    el.textContent=head+'\n\n'+(d?`— hasil (screening) —\nBI=${d.BI.toFixed(1)}  PF_BI=${d.PF.toFixed(3)} kg/m³\nLD=${d.LD.toFixed(2)} kg/m  AE=${d.AE.toFixed(1)} m²\nSA=${d.SA.toFixed(1)} m²  N=${d.N} baris\nB=${d.B.toFixed(2)} m  S=${d.S.toFixed(2)} m  T=${d.T.toFixed(2)} m  J=${d.J.toFixed(2)} m\nVALIDITAS: ${d.validity||'OK'}${d.warnings&&d.warnings.length?'\n'+d.warnings.map(w=>'! '+w).join('\n'):''}`:'— tidak dihitung: '+(MAE_ERR||'input belum valid / hasil STALE')); }
  function maeShowInputs(on){ const box=$('maeInputs'); if(!box) return; box.classList.remove('kb-hidden'); if(true){ const m=maeState(); [['xi','maeXi'],['ucs','maeUcs'],['jps','maeJps'],['jpo','maeJpo'],['cw','maeCw'],['stf','maeStf'],['sbf','maeSbf']].forEach(([k,id])=>{ const el=$(id); if(el) el.value=(m[k]===null||m[k]===undefined||Number.isNaN(m[k]))?'':m[k]; }); MAE_EXTRA_FIELDS.forEach(([dom,path])=>{ const el=$(dom),v=m[path.split('.')[1]]; if(el&&document.activeElement!==el) el.value=(v===null||v===undefined||Number.isNaN(v))?'':v; }); } }
  /* ---- MAE helper: kelas JPS/JPO dari data lapangan, preset contoh spreadsheet, pembanding B/S/PF referensi.
     JPO/JPS hasil bantuan tetap masuk lewat event input biasa (provenance USER_EDIT), jadi tetap bisa ditimpa manual. */
  const MAE_EXTRA_FIELDS=[['maeJointSp','mae.jointSp','m'],['maeDip','mae.dip','deg'],['maeDipDir','mae.dipDir','deg'],['maeFaceDir','mae.faceDir','deg'],['maeRefB','mae.refB','m'],['maeRefS','mae.refS','m'],['maeRefPf','mae.refPf','kg/m3']];
  function maeJpsClass(sp){ return !(sp>0)?null:(sp>1?50:(sp>=0.1?20:10)); }
  /* ASUMSI: dip < 10° = horizontal; selisih arah dip kekar vs face <= 45° = miring keluar face; >= 135° = miring ke dalam; sisanya strike tegak lurus face. */
  function maeJpoFromDip(dip,dd,fd){ if(![dip,dd,fd].every(Number.isFinite)) return null; if(dip<10) return 10; let d=Math.abs((((dd-fd)%360)+360)%360); if(d>180) d=360-d; return d<=45?20:(d>=135?40:30); }
  function maeFire(id,val){ const el=$(id); if(!el) return; el.value=String(val); el.dispatchEvent(new Event('input',{bubbles:true})); }
  function maeAutoClass(){
    const num=id=>{ const v=$(id)?.value; return v===''||v==null?NaN:Number(v); };
    const msg=[]; const sp=num('maeJointSp'),jps=maeJpsClass(sp);
    if(jps!=null){ if(Number($('maeJps').value)!==jps) maeFire('maeJps',jps); msg.push('JPS '+jps+' (spasi '+sp+' m)'); }
    const jpo=maeJpoFromDip(num('maeDip'),num('maeDipDir'),num('maeFaceDir'));
    if(jpo!=null){ if(Number($('maeJpo').value)!==jpo) maeFire('maeJpo',jpo); msg.push('JPO '+jpo+' (dip '+num('maeDip')+'°, dip dir '+num('maeDipDir')+'°, face '+num('maeFaceDir')+'°)'); }
    const h=$('maeJpoHint'); if(h) h.textContent=msg.length?'JPS/JPO otomatis: '+msg.join(' • ')+'. Ubah dropdown untuk menimpa manual.':'JPS/JPO otomatis: belum diisi.';
  }
  function maeRefRender(){
    const el=$('maeRefCmp'); if(!el) return; const r=(APP_STATE.geometry.results||{}).mae,m=maeState();
    const f=(x,d)=>Number.isFinite(x)?x.toFixed(d):'--',pairs=[['B','refB','B',2,'m'],['S','refS','S',2,'m'],['PF','refPf','PF',3,'kg/m³']];
    if(!pairs.some(p=>Number.isFinite(Number(m[p[1]])))||m[pairs[0][1]]==null&&m[pairs[1][1]]==null&&m[pairs[2][1]]==null){ el.textContent='Perbandingan B/S/PF: isi referensi, lalu CALCULATE MAE.'; return; }
    if(!r||methodFreshness('mae')!=='FRESH'){ el.textContent='Perbandingan B/S/PF: klik CALCULATE MAE (belum dihitung atau input berubah).'; return; }
    el.textContent='MAE vs referensi • '+pairs.map(([n,k,rk,d,u])=>{ const ref=m[k]==null?NaN:Number(m[k]),v=Number(r[rk]); return n+' '+f(v,d)+' vs '+f(ref,d)+' '+u+(Number.isFinite(ref)&&Number.isFinite(v)?' (Δ '+((v-ref)>=0?'+':'')+f(v-ref,d)+')':''); }).join(' • ');
  }
  function maePresetFromSpreadsheet(){
    const src='Contoh spreadsheet user (gambar 2) — bukan data lapangan terverifikasi',P=(p,v,u)=>{ setInput(p,v,u,'USER_EDIT',src,'maePresetImg2',{notes:'preset contoh; ganti dengan data proyek'}); };
    const ci=APP_STATE.geometry.comparisonInputs||(APP_STATE.geometry.comparisonInputs={}); ci.loaded=true;
    P('ci.diameterIn',4.5,'in'); P('ci.benchHeight',4.5,'m'); P('ci.explosiveDensity',0.82,'SG'); P('ci.rockDensity',2.6,'SG'); ci.densityBasis='custom';
    P('mae.xi',1.2,'m'); P('mae.ucs',35,'MPa'); P('mae.jointSp',1.2,'m'); P('mae.dip',20,'deg'); P('mae.dipDir',135,'deg'); P('mae.faceDir',135,'deg');
    P('mae.jps',maeJpsClass(1.2),'-'); P('mae.jpo',maeJpoFromDip(20,135,135),'-');
    P('mae.refB',2.5,'m'); P('mae.refS',3.5,'m'); P('mae.refPf',0.38,'kg/m3');
    audit('MAE preset','',src,'maePresetImg2','USER ACTION'); persistWorking();
    geometryComparisonInputSync(false); maeShowInputs(true);
    MAE_EXTRA_FIELDS.forEach(([dom,path])=>{ const el=$(dom),v=inputRoot(path)[inputKey(path)]; if(el) el.value=v==null?'':v; });
    maeAutoClass(); maeRefRender(); validateAll(); refreshAll();
    const h=$('maeJpoHint'); if(h) h.textContent+=' • CW (lebar cut) tidak ada di spreadsheet: isi manual sebelum CALCULATE MAE.';
  }
  (function maeHelperWire(){
    MAE_EXTRA_FIELDS.forEach(([dom,path,unit])=>{ const el=$(dom); if(!el) return; const h=()=>{ commitDomField(dom,path,unit,'MAE inputs'); if(/^(maeJointSp|maeDip|maeDipDir|maeFaceDir)$/.test(dom)) maeAutoClass(); maeRefRender(); }; el.addEventListener('input',h); el.addEventListener('change',h); });
    const b=$('maePresetImg2'); if(b) b.addEventListener('click',maePresetFromSpreadsheet);
    ['btnCalcMae','btnCalcAsh','btnCalcKonya','formulaMae'].forEach(id=>$(id)?.addEventListener('click',()=>setTimeout(maeRefRender,0)));
    ['maeXi','maeUcs','maeJps','maeJpo','maeCw','maeStf','maeSbf'].forEach(id=>$(id)?.addEventListener('input',()=>setTimeout(maeRefRender,0)));
  })();
  function setFormula(key){
    if(key!=='mae'){ setFormulaCore(key); maeShowInputs(false); geometryCompareCalculate([key]); return; }
    const old=APP_STATE.formula.key; APP_STATE.formula.key='mae'; audit('Formula',old,'MAE','USER ACTION','FORMULA SWITCH');
    $('formulaAsh').classList.remove('btn--accent'); $('formulaKonya').classList.remove('btn--accent'); $('formulaMae').classList.add('btn--accent'); maeShowInputs(true);
    $('formulaNote').textContent='MAE selected. Eq.(17)-(29) dari formula engine yang sudah ada. Input MAE wajib diisi dari data geologi/lapangan; input MAE kosong sampai diisi dari data proyek atau LOAD DEMO EXAMPLE.';
    $('formulaCode').textContent=formulaUiText('mae');
    validateAll(); refreshAll(); geometryCompareCalculate(['mae']);
  }
  function setFormulaCore(key){
    const old=APP_STATE.formula.key; APP_STATE.formula.key=key; audit('Formula',old,key==='ash'?'R.L. Ash':'Calvin Konya','USER ACTION','FORMULA SWITCH'); $('formulaAsh').classList.toggle('btn--accent',key==='ash'); $('formulaKonya').classList.toggle('btn--accent',key==='konya');
    $('formulaNote').textContent=key==='ash'?'R.L. Ash selected. Formula dihitung sebagai geometry engine.':'Calvin Konya selected. Formula dihitung sebagai geometry engine.';
    $('formulaCode').textContent=formulaUiText(key); validateAll(); refreshAll();
  }

  function loadImageFile(file){
    if(!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) throw new Error('Format harus JPG/JPEG/PNG/WEBP.');
    { const big=kbFileTooBig(file,'image'); if(big) throw new Error(big); }
    const objUrl=URL.createObjectURL(file); const img=new Image(); img.onload=()=>{ URL.revokeObjectURL(objUrl); const maxSide=1600, scale=Math.min(1,maxSide/Math.max(img.naturalWidth,img.naturalHeight)); const w=Math.max(1,Math.round(img.naturalWidth*scale)),h=Math.max(1,Math.round(img.naturalHeight*scale)); const c=document.createElement('canvas'); c.width=w;c.height=h;c.getContext('2d').drawImage(img,0,0,w,h); APP_STATE.image={...APP_STATE.image,file,metadata:{name:file.name,type:file.type,size:file.size,width:img.naturalWidth,height:img.naturalHeight,workingWidth:w,workingHeight:h},sourceCanvas:c,workingCanvas:c,transform:{scale,offsetX:0,offsetY:0},displayTransform:{scaleX:1,scaleY:1,offsetX:0,offsetY:0},qc:null,mode:$('scanMode').value,selectedId:null,selectedIds:[],manualMode:null,roiPolygons:[],roiDraft:[]}; try{roiOnImageLoaded();}catch(_e){} APP_STATE.calibration={points:[],mode:'A',pixelDistanceSource:null,pixelDistanceWorking:null,metersPerSourcePixel:null,centimetersPerSourcePixel:null,metersPerWorkingPixel:null,centimetersPerWorkingPixel:null,status:'NOT CALIBRATED',quality:'POOR',perspectiveWarning:true}; APP_STATE.fragments=[]; APP_STATE.psd={x50:null,x80:null,oversizeCount:null,oversizeFraction:null,xc:null,n:null,rrOversizeFraction:null,r2:null,fitStatus:'INSUFFICIENT SAMPLE',sizeDefinition:$('measurementDef').value}; drawCanvas(); computeImageQC(); renderImageMeta(); renderFragments(); syncMvpPsdControls(); refreshAll(); $('imageUploadStatus').textContent=`Loaded actual image: ${file.name} • ${img.naturalWidth}×${img.naturalHeight}px`; };
    img.onerror=()=>{ URL.revokeObjectURL(objUrl); $('imageUploadStatus').textContent='IMAGE LOAD FAILED'; }; img.src=objUrl;
  }
  function setCalibrationMode(mode){ APP_STATE.calibration.mode=mode; ['A','B'].forEach(k=>{const b=$('btnCalPoint'+k);b?.classList.toggle('is-active',k===mode);b?.setAttribute('aria-pressed',String(k===mode));});const cancel=$('btnCalCancel');cancel?.classList.toggle('is-active',mode==='CANCEL');cancel?.setAttribute('aria-pressed',String(mode==='CANCEL'));const c=$('muckpileCanvas');c.classList.toggle('kb-calibration-active',mode==='A'||mode==='B');$('calibrationModeLabel').textContent=mode==='A'?'Calibration mode: POINT A • klik titik referensi pertama.':mode==='B'?'Calibration mode: POINT B • klik titik referensi kedua.':'Calibration mode: object selection/manual QC.'; }
  function annotateFragment(ctx,f){ const cx=(f.minx+f.maxx)/2,cy=(f.miny+f.maxy)/2; ctx.save(); ctx.strokeStyle=f.review?'#f59e0b':'#22d3ee'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(cx-4,cy);ctx.lineTo(cx+4,cy);ctx.moveTo(cx,cy-4);ctx.lineTo(cx,cy+4);ctx.stroke(); if(f.review){ctx.setLineDash([5,3]);ctx.lineWidth=2;ctx.strokeRect(f.minx,f.miny,f.maxx-f.minx,f.maxy-f.miny);ctx.setLineDash([]);} ctx.fillStyle=f.review?'#fbbf24':'#ffffff'; ctx.font='10px Consolas'; ctx.fillText(`${f.review?'REVIEW ':''}${Math.round((f.confidence||0)*100)}%`,f.minx+2,Math.min(f.maxy-3,f.miny+12)); ctx.restore(); }
  function drawCalibrationOverlay(ctx){ const pts=APP_STATE.calibration.points||[]; if(!pts.length)return; ctx.save();ctx.strokeStyle='#22ff88';ctx.fillStyle='#22ff88';ctx.lineWidth=3;pts.forEach((p,i)=>{ctx.beginPath();ctx.arc(p.x,p.y,7,0,Math.PI*2);ctx.stroke();ctx.font='bold 13px Consolas';ctx.fillText(i===0?'A':'B',p.x+10,p.y-10);}); if(pts.length===2){ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);ctx.lineTo(pts[1].x,pts[1].y);ctx.stroke();} ctx.restore(); }
  function convexHull(points){
    if(!Array.isArray(points)||points.length<4)return points||[];
    const p=points.map(q=>[q[0],q[1]]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
    const cross=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);
    const lo=[]; for(const q of p){while(lo.length>=2&&cross(lo[lo.length-2],lo[lo.length-1],q)<=0)lo.pop();lo.push(q);}
    const hi=[]; for(let i=p.length-1;i>=0;i--){const q=p[i];while(hi.length>=2&&cross(hi[hi.length-2],hi[hi.length-1],q)<=0)hi.pop();hi.push(q);}
    hi.pop(); lo.pop(); return lo.concat(hi);
  }

  function drawCanvas(){
    const c=$('muckpileCanvas'),src=APP_STATE.image.workingCanvas;
    if(!src){
      c.width=1200;c.height=700;const ctx=c.getContext('2d');ctx.fillStyle='#0b1120';ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle='#cbd5e1';ctx.font='16px Segoe UI';ctx.textAlign='center';ctx.fillText('Upload foto fragmentasi aktual untuk memulai.',c.width/2,c.height/2);return;
    }
    c.width=src.width;c.height=src.height;const ctx=c.getContext('2d');ctx.drawImage(src,0,0);roiDrawShade(ctx,c.width,c.height);drawCalibrationOverlay(ctx);updateDisplayTransform();
    const dense=APP_STATE.fragments.length>180;
    APP_STATE.fragments.forEach((f,idx)=>{
      const size=f.measuredSizeCm,over=isPSDOverSize(size),selected=selectedIdList().includes(f.id);ctx.save();ctx.strokeStyle=selected?'#ffffff':(over?'#dc2626':'#22c55e');ctx.fillStyle=selected?'rgba(255,255,255,.07)':(over?'rgba(220,38,38,.05)':'rgba(34,197,94,.04)');ctx.lineWidth=selected?3:(over?1.5:1);if(selected){ctx.shadowColor=APP_STATE.image.manualMode==='delete'?'#ef4444':'#22d3ee';ctx.shadowBlur=12;}
      const poly=fragDrawPoly(f); if(poly.length>=3){ctx.beginPath();ctx.moveTo(poly[0][0],poly[0][1]);for(let i=1;i<poly.length;i++)ctx.lineTo(poly[i][0],poly[i][1]);ctx.closePath();ctx.fill();ctx.stroke();}else{ctx.strokeRect(f.minx,f.miny,f.maxx-f.minx,f.maxy-f.miny);}
      const showLabel=!dense||f.id===APP_STATE.image.selectedId||f.review||idx%25===0;if(showLabel){ctx.fillStyle='#fff';ctx.font='10px Consolas';ctx.fillText(`#${String(f.id).padStart(3,'0')} ${size!=null?size.toFixed(1)+' cm':'--'}`,f.minx+2,Math.max(10,f.miny-3));}ctx.restore();
    });
    try{atDrawPreview(ctx);}catch(_e){}try{editDraw(ctx);}catch(_e){}try{splitDraw(ctx);}catch(_e){}
    if(Array.isArray(APP_STATE.image.manualTrace)&&APP_STATE.image.manualTrace.length>=2){
      ctx.save(); ctx.strokeStyle='#06b6d4'; ctx.fillStyle='rgba(6,182,212,.08)'; ctx.lineWidth=2.5; ctx.setLineDash([8,5]);
      ctx.beginPath(); ctx.moveTo(APP_STATE.image.manualTrace[0].x,APP_STATE.image.manualTrace[0].y);
      for(let i=1;i<APP_STATE.image.manualTrace.length;i++)ctx.lineTo(APP_STATE.image.manualTrace[i].x,APP_STATE.image.manualTrace[i].y);
      ctx.stroke(); ctx.setLineDash([]); const last=APP_STATE.image.manualTrace[APP_STATE.image.manualTrace.length-1];
      ctx.fillStyle='#06b6d4'; ctx.beginPath(); ctx.arc(last.x,last.y,4,0,Math.PI*2); ctx.fill(); ctx.restore();
    }
    roiDrawOutline(ctx,c.width,c.height,true);roiSyncUi();
    drawMvpAnnotatedCanvas();
  }
  function drawMvpAnnotatedCanvas(){
    const out=$('mvpAnnotatedCanvas'),src=APP_STATE.image.workingCanvas;if(!out)return;
    if(!src){out.width=1200;out.height=675;const ctx=out.getContext('2d');ctx.fillStyle='#0b1120';ctx.fillRect(0,0,out.width,out.height);ctx.fillStyle='#cbd5e1';ctx.font='16px Segoe UI';ctx.textAlign='center';ctx.fillText('Upload foto fragmentasi aktual untuk memulai.',out.width/2,out.height/2);if($('mvpAnnotatedStatus'))$('mvpAnnotatedStatus').textContent='Menunggu foto aktual.';return;}
    out.width=src.width;out.height=src.height;const ctx=out.getContext('2d');ctx.drawImage(src,0,0);roiDrawShade(ctx,out.width,out.height);let contourCount=0;const dense=APP_STATE.fragments.length>180;
    APP_STATE.fragments.forEach((f,idx)=>{
      const over=isPSDOverSize(f.measuredSizeCm);ctx.save();ctx.strokeStyle=over?'#dc2626':'#22c55e';ctx.lineWidth=over?2:1.4;ctx.fillStyle=over?'rgba(220,38,38,.07)':'rgba(34,197,94,.05)';
      const poly=fragDrawPoly(f);if(poly.length>=3){ctx.beginPath();ctx.moveTo(poly[0][0],poly[0][1]);for(let i=1;i<poly.length;i++)ctx.lineTo(poly[i][0],poly[i][1]);ctx.closePath();ctx.fill();ctx.stroke();contourCount++;}else{ctx.strokeRect(f.minx,f.miny,f.maxx-f.minx,f.maxy-f.miny);}
      const showLabel=!dense||f.id===APP_STATE.image.selectedId||f.review||idx%40===0;if(showLabel){ctx.fillStyle='#fff';ctx.font='10px Consolas';ctx.fillText(`#${String(f.id).padStart(3,'0')} ${f.measuredSizeCm!=null?f.measuredSizeCm.toFixed(1)+' cm':'--'}`,f.minx+2,Math.max(11,f.miny-3));}ctx.restore();
    });
    roiDrawOutline(ctx,out.width,out.height,false);
    if($('mvpAnnotatedStatus'))$('mvpAnnotatedStatus').textContent=`${APP_STATE.fragments.length} object • ${contourCount} contour polygon • calibration ${psdScaleCm()!==null?'ACTIVE':'NOT CALIBRATED'}`;
  }

  function mvpEdgeToConfig(v){ return .25+(Number(v)/100)*2.75; }
  function mvpSeparationToConfig(v){ return .1+(Number(v)/100)*2.9; }
  function configToMvpEdge(v){ return clamp(Math.round(((Number(v)-.25)/2.75)*100),0,100); }
  function configToMvpSeparation(v){ return clamp(Math.round(((Number(v)-.1)/2.9)*100),0,100); }
  function syncMvpPsdControls(){ const c=getPSDConfig(); const esc=$('mvpThreshold'),ea=$('mvpMinArea'),ee=$('mvpEdgeSensitivity'),ew=$('mvpWatershed'),es=$('mvpScaleCmPx'),ep=$('mvpPolarity'); if(esc)esc.value=c.thresholdPct;if(ea)ea.value=clamp(c.minArea,50,20000);if(ee)ee.value=configToMvpEdge(c.edgeSensitivity);if(ew)ew.value=configToMvpSeparation(c.separationSensitivity);if(es)es.value=psdScaleCm()!==null?psdScaleCm():'';if(ep)ep.value=APP_STATE.image.mode==='high'?'bright':APP_STATE.image.mode==='low'?'dark':'auto'; updateMvpReadouts(); }
  function updateMvpReadouts(){ const q=(id,v)=>{const e=$(id);if(e)e.textContent=v;}; q('mvpThresholdOut',$('mvpThreshold')?.value||'--');q('mvpMinAreaOut',$('mvpMinArea')?.value||'--');q('mvpEdgeSensitivityOut',$('mvpEdgeSensitivity')?.value||'--');q('mvpWatershedOut',$('mvpWatershed')?.value||'--'); const sc=Number($('mvpScaleCmPx')?.value);q('mvpScaleOut',Number.isFinite(sc)&&sc>0?sc.toFixed(5):'--');q('mvpPolarityOut',$('mvpPolarity')?.selectedOptions?.[0]?.textContent||'AUTO'); }
  function applyMvpPsdControls(source='MVP UI'){ const threshold=clamp(Number($('mvpThreshold')?.value||62),1,99); const minArea=Math.max(50,Math.round(Number($('mvpMinArea')?.value||100))); const edge=mvpEdgeToConfig($('mvpEdgeSensitivity')?.value||55); const sep=mvpSeparationToConfig($('mvpWatershed')?.value||35); const scale=Number($('mvpScaleCmPx')?.value); const pol=$('mvpPolarity')?.value||'auto'; const c=normalizePSDConfig({...getPSDConfig(),thresholdPct:threshold,minArea,edgeSensitivity:edge,separationSensitivity:sep}); APP_STATE.psdConfig=c; APP_STATE.image.mode=pol==='bright'?'high':pol==='dark'?'low':'auto'; if(Number.isFinite(scale)&&scale>0){ const workScale=scale; const sourceFactor=Number(APP_STATE.image.transform?.scale)||1; APP_STATE.calibration.centimetersPerWorkingPixel=workScale;APP_STATE.calibration.metersPerWorkingPixel=workScale/100;APP_STATE.calibration.centimetersPerSourcePixel=workScale*sourceFactor;APP_STATE.calibration.metersPerSourcePixel=workScale*sourceFactor/100;APP_STATE.calibration.status='DIRECT SCALE INPUT';APP_STATE.calibration.quality='FAIR'; } syncPSDConfigControls(); recomputeFragmentMeasurements(); if($('mvpPsdStatus'))$('mvpPsdStatus').textContent=`APPLIED • threshold ${threshold} • min area ${minArea} • edge ${Math.round(Number($('mvpEdgeSensitivity')?.value||55))} • separation ${Math.round(Number($('mvpWatershed')?.value||35))} • source ${source}`; scanActualPhoto(); }
  function scheduleMvpRescan(){ updateMvpReadouts(); if(window.__mvpScanTimer)clearTimeout(window.__mvpScanTimer); window.__mvpScanTimer=setTimeout(()=>applyMvpPsdControls('LIVE TUNING'),320); }
  function syncMvpPsdMetrics(){
    const pp=psdPhys(), cal=psdScaleCm()!==null, P=APP_STATE.psd;
    const set=(id,v)=>{const e=$(id);if(e)e.textContent=v;};
    set('mvpFragCount',String((cal?P.sampleCount:P.pixelSampleCount)||0));
    set('mvpD50',pp.x50!=null?fmt(pp.x50,1)+' cm':(P.x50Px!=null?fmt(P.x50Px,1)+' px (NOT CALIBRATED)':'--'));
    set('mvpD80',pp.x80!=null?fmt(pp.x80,1)+' cm':(P.x80Px!=null?fmt(P.x80Px,1)+' px (NOT CALIBRATED)':'--'));
    set('mvpD50A',P.x50Area!=null?fmt(P.x50Area,1)+' cm':(P.x50AreaPx!=null?fmt(P.x50AreaPx,1)+' px (NOT CALIBRATED)':'--'));
    set('mvpD80A',P.x80Area!=null?fmt(P.x80Area,1)+' cm':(P.x80AreaPx!=null?fmt(P.x80AreaPx,1)+' px (NOT CALIBRATED)':'--'));
    set('mvpR2',pp.r2!=null?pp.r2.toFixed(3)+(P.fitStatus==='FIT AVAILABLE'?'':' ('+P.fitStatus+')'):((cal&&P.sampleCount>0)?P.fitStatus:'--'));
  }
  function renderMvpMetrics(){ syncMvpPsdMetrics(); }
  function renderMvpPsdChart(){
    syncMvpPsdMetrics();
    const el=$('mvpPsdChart');
    if(!el||typeof Plotly==='undefined'||typeof Plotly.react!=='function')return;
    const v=el.closest('.kb-view'); if(v && !v.classList.contains('active'))return;
    const cal=psdScaleCm()!==null, sizes=(cal?APP_STATE.fragments.map(f=>f.measuredSizeCm):APP_STATE.fragments.map(psdPxOf)).filter(x=>x!==null&&Number.isFinite(x)&&x>0).sort((a,b)=>a-b);
    const actualX=sizes.slice(),actualY=sizes.map((_,i)=>100*(i+1)/sizes.length),traces=[];
    if(actualX.length){
      traces.push({x:actualX,y:actualY,type:'scatter',mode:'markers+lines',name:'Actual PSD',marker:{size:6},line:{width:1.5}});
      if(cal&&APP_STATE.psd.fitStatus==='FIT AVAILABLE'&&APP_STATE.psd.xc&&APP_STATE.psd.n){
        const xmax=Math.max(...actualX)*1.3,xmin=Math.max(Math.min(...actualX)*.75,.001),fx=[],fy=[];
        for(let i=0;i<220;i++){const xx=xmin*Math.pow(xmax/xmin,i/219);fx.push(xx);fy.push(100*(1-Math.exp(-Math.pow(xx/APP_STATE.psd.xc,APP_STATE.psd.n))));}
        traces.push({x:fx,y:fy,type:'scatter',mode:'lines',name:'Rosin-Rammler',line:{width:3}});
      }
    }
    try{
      const r=Plotly.react(el,traces,{margin:{l:50,r:14,t:10,b:44},paper_bgcolor:'#f4f2eb',plot_bgcolor:'#f4f2eb',xaxis:{type:'log',title:cal?psdDefLabel()+' (cm)':psdDefLabel()+' (px) - pixel-only, NOT CALIBRATED'},yaxis:{title:'Cumulative passing (%)',range:[0,100]},font:{family:'IBM Plex Sans, Arial, sans-serif',size:10},legend:{orientation:'h',y:1.02,x:0},hovermode:'closest'});
      if(r&&typeof r.catch==='function')r.catch(()=>{});
    }catch(e){ /* chart failure must not invalidate PSD data */ }
    syncMvpPsdMetrics();
  }

  function updateDisplayTransform(){ const c=$('muckpileCanvas'); const rect=c.getBoundingClientRect(); APP_STATE.image.displayTransform={scaleX:rect.width?c.width/rect.width:1,scaleY:rect.height?c.height/rect.height:1,offsetX:rect.left,offsetY:rect.top}; }
  function screenToWorking(evt){ updateDisplayTransform(); const t=APP_STATE.image.displayTransform||{scaleX:1,scaleY:1,offsetX:0,offsetY:0}; return {x:(evt.clientX-t.offsetX)*t.scaleX,y:(evt.clientY-t.offsetY)*t.scaleY}; }
  function workingToSource(pt){ const sc=Number(APP_STATE.image.transform?.scale)||1; return {x:pt.x/sc,y:pt.y/sc}; }
  function sourceToWorking(pt){ const sc=Number(APP_STATE.image.transform?.scale)||1; return {x:pt.x*sc,y:pt.y*sc}; }
  function canvasPoint(evt){ return screenToWorking(evt); }
  /* ===== ROI POLIGON (area analisis tak beraturan, ala WipFrag) =====
     Koordinat disimpan di APP_STATE.image.roiPolygons dalam koordinat WORKING CANVAS (bukan koordinat layar). Konversi mouse -> canvas memakai
     canvasPoint() (= screenToWorking), pola yang sama dengan TRACE ROCK. Rasterisasi: piksel (x,y) masuk ROI bila PUSATNYA (x+.5,y+.5) berada di dalam
     poligon (aturan even-odd, scanline); beberapa poligon digabung (union). Pusat fragmen = pusat bounding box (indeks piksel, dibulatkan ke bawah).
     Metrik fragmen (area, Feret, eqDiameter) tetap dihitung dari piksel; ROI hanya membatasi piksel/objek yang dianalisis. */
  function roiRasterize(polys,w,h){
    const m=new Uint8Array(Math.max(0,w*h));
    if(!Array.isArray(polys))return m;
    const xc=[];
    for(const poly of polys){
      if(!Array.isArray(poly)||poly.length<3)continue;
      const n=poly.length,xs=new Float64Array(n),ys=new Float64Array(n);let ok=true,ymin=Infinity,ymax=-Infinity;
      for(let i=0;i<n;i++){const p=poly[i];const x=p?Number(p[0]):NaN,y=p?Number(p[1]):NaN;if(!Number.isFinite(x)||!Number.isFinite(y)){ok=false;break;}xs[i]=x;ys[i]=y;if(y<ymin)ymin=y;if(y>ymax)ymax=y;}
      if(!ok)continue;
      const r0=Math.max(0,Math.ceil(ymin-0.5)),r1=Math.min(h-1,Math.ceil(ymax-0.5)-1);
      for(let y=r0;y<=r1;y++){
        const yc=y+0.5;xc.length=0;
        for(let i=0;i<n;i++){const j=(i+1)%n;if((ys[i]<=yc)!==(ys[j]<=yc))xc.push(xs[i]+(yc-ys[i])*(xs[j]-xs[i])/(ys[j]-ys[i]));}
        xc.sort((a,b)=>a-b);
        for(let k=0;k+1<xc.length;k+=2){const xa=Math.max(0,Math.ceil(xc[k]-0.5)),xb=Math.min(w-1,Math.ceil(xc[k+1]-0.5)-1);for(let x=xa;x<=xb;x++)m[y*w+x]=1;}
      }
    }
    return m;
  }
  function roiMaskCount(mask){let n=0;for(let i=0;i<mask.length;i++)if(mask[i])n++;return n;}
  function roiCenterInside(mask,w,h,f){const cx=Math.floor((f.minx+f.maxx)/2),cy=Math.floor((f.miny+f.maxy)/2);if(!(cx>=0&&cx<w&&cy>=0&&cy<h))return false;return mask[cy*w+cx]===1;}
  function roiFilterByCenter(items,mask,w,h){return items.filter(f=>roiCenterInside(mask,w,h,f));}
  function roiGetMask(){
    const S=APP_STATE.image,c=S.workingCanvas,P=S.roiPolygons;
    if(!c||!Array.isArray(P)||!P.length)return null;
    const w=c.width,h=c.height,mask=roiRasterize(P,w,h),count=roiMaskCount(mask);
    return {mask,w,h,count,frac:count/(w*h),polys:P.length};
  }
  const ROI_CLOSE_PX=12, ROI_DUP_PX=3; /* toleransi klik dalam piksel LAYAR (dikali skala canvas) */
  function roiScreenK(){updateDisplayTransform();return(APP_STATE.image.displayTransform||{}).scaleX||1;}
  function roiInfoText(){
    const g=roiGetMask();
    if(!g)return 'ROI poligon: belum ada • analisis memakai batas atas/bawah di atas.';
    return `ROI poligon aktif: ${g.polys} poligon • luas ${(g.frac*100).toFixed(1)}% foto (gabungan) • batas atas/bawah diabaikan • RESCAN untuk menerapkan.`;
  }
  function roiHint(t){const a=$('scanStatus');if(a)a.textContent=t;const h=$('canvasHint');if(h)h.textContent=t;}
  function roiMsg(t){roiHint(t);const b=$('mvpPsdStatus');if(b)b.textContent=t;}
  function roiSyncUi(){
    const on=APP_STATE.image.manualMode==='roi';
    const b=$('btnRoiDraw');if(b){b.classList.toggle('is-active',on);b.classList.toggle('btn--accent',on);b.setAttribute('aria-pressed',String(on));}
    const f=$('btnRoiFinish');if(f)f.disabled=!on;
    const i=$('mvpRoiInfo');if(i)i.textContent=roiInfoText();
  }
  function roiExit(){
    const S=APP_STATE.image;S.roiDraft=[];if(S.manualMode==='roi')S.manualMode=null;
    const cv=$('muckpileCanvas');if(cv)cv.style.cursor='';
    roiSyncUi();drawCanvas();
  }
  function roiAfterChange(){
    roiSyncUi();drawCanvas();persistWorking();
    const g=roiGetMask();
    const t=g?`ROI POLIGON • ${g.polys} poligon • luas ${(g.frac*100).toFixed(1)}% foto • klik RESCAN NOW untuk menerapkan`:'ROI poligon dihapus • analisis kembali memakai batas atas/bawah • klik RESCAN NOW';
    const b=$('mvpPsdStatus');if(b)b.textContent=t;
  }
  function roiCommitDraft(){
    const S=APP_STATE.image,d=S.roiDraft||[];
    if(d.length<3)return false;
    const old=(S.roiPolygons||[]).length;
    S.roiPolygons=[...(S.roiPolygons||[]),d.map(p=>[p[0],p[1]])];S.roiDraft=[];
    audit('ROI poligon',old,S.roiPolygons.length,'USER ACTION','ROI POLYGON CLOSED');
    roiAfterChange();return true;
  }
  function roiStart(){
    const S=APP_STATE.image;
    if(!S.workingCanvas){roiMsg('GAMBAR ROI: upload foto terlebih dahulu.');return;}
    if(S.manualMode==='roi')return;
    try{if(S.manualMode==='autotrace')atStop();}catch(_e){}
    try{if(S.manualMode==='edit')edToggle(false);}catch(_e){}
    cancelTrace();
    if(APP_STATE.calibration.mode==='A'||APP_STATE.calibration.mode==='B')setCalibrationMode('CANCEL');
    S.manualMode='roi';S.roiDraft=[];
    const cv=$('muckpileCanvas');if(cv)cv.style.cursor='crosshair';
    roiSyncUi();drawCanvas();
    roiMsg('GAMBAR ROI aktif • klik foto untuk menambah titik (titik pertama = penanda kuning besar) • klik dekat titik pertama atau SELESAI ROI untuk menutup (min. 3 titik) • Esc = batal.');
  }
  function roiFinish(){
    const S=APP_STATE.image;
    if(S.manualMode!=='roi'){roiMsg('SELESAI ROI: mode GAMBAR ROI tidak aktif.');return;}
    const n=(S.roiDraft||[]).length;
    if(n>=3){roiCommitDraft();}
    else if(n>0){roiMsg(`SELESAI ROI: poligon butuh minimal 3 titik (baru ${n}). Tambah titik atau tekan Esc untuk membatalkan.`);return;}
    roiExit();
  }
  function roiCancel(){
    const S=APP_STATE.image;if(S.manualMode!=='roi')return;
    roiExit();roiMsg('GAMBAR ROI dibatalkan • poligon yang sudah selesai tetap dipertahankan.');
  }
  function roiClear(){
    const S=APP_STATE.image,old=(S.roiPolygons||[]).length;
    const was=S.manualMode==='roi';
    S.roiPolygons=[];S.roiDraft=[];if(was)S.manualMode=null;
    const cv=$('muckpileCanvas');if(cv&&was)cv.style.cursor='';
    if(old)audit('ROI poligon',old,0,'USER ACTION','ROI CLEARED');
    roiAfterChange();
    if(!old)roiMsg('HAPUS ROI: tidak ada poligon ROI.');
  }
  function roiClick(e){
    const S=APP_STATE.image,c=S.workingCanvas;if(!c)return;
    const raw=canvasPoint(e),pt=[clamp(raw.x,0,c.width),clamp(raw.y,0,c.height)],d=S.roiDraft=S.roiDraft||[],k=roiScreenK();
    if(d.length>=1){
      const f=d[0];
      if(Math.hypot(pt[0]-f[0],pt[1]-f[1])<=ROI_CLOSE_PX*k){
        if(d.length>=3){roiCommitDraft();roiHint('ROI poligon ditutup • klik titik baru untuk poligon tambahan (gabungan), atau SELESAI ROI / Esc untuk keluar.');return;}
        roiMsg(`GAMBAR ROI: poligon butuh minimal 3 titik (baru ${d.length}).`);return;
      }
      const l=d[d.length-1];
      if(Math.hypot(pt[0]-l[0],pt[1]-l[1])<=ROI_DUP_PX*k)return; /* dobel-klik: abaikan titik kembar */
    }
    d.push([+pt[0].toFixed(2),+pt[1].toFixed(2)]);
    roiMsg(`GAMBAR ROI • ${d.length} titik${d.length>=3?' • klik dekat titik pertama atau SELESAI ROI untuk menutup':''}`);
    drawCanvas();
  }
  function roiLeaveForScan(){ /* SCAN saat mode gambar aktif: tutup draft bila >=3 titik, selain itu buang; lalu keluar dari mode */
    const S=APP_STATE.image;if(S.manualMode!=='roi')return;
    if((S.roiDraft||[]).length>=3)roiCommitDraft();
    roiExit();
  }
  function roiImageKey(){const S=APP_STATE.image,m=S.metadata,c=S.workingCanvas;if(!m||!c)return null;return [m.name,m.size,(S.file&&S.file.lastModified)||0,c.width+'x'+c.height].join('|');}
  function roiPersistable(){try{const S=APP_STATE.image,key=roiImageKey();if(key)return(S.roiPolygons&&S.roiPolygons.length)?{key,polygons:S.roiPolygons}:null;return ROI_SAVED;}catch(_e){return null;}}
  function roiSanitizeSaved(r){
    if(!r||typeof r!=='object'||typeof r.key!=='string'||!Array.isArray(r.polygons))return null;
    const polys=r.polygons.filter(p=>Array.isArray(p)&&p.length>=3&&p.every(q=>Array.isArray(q)&&Number.isFinite(Number(q[0]))&&Number.isFinite(Number(q[1])))).slice(0,50).map(p=>p.map(q=>[Number(q[0]),Number(q[1])]));
    return polys.length?{key:r.key,polygons:polys}:null;
  }
  function roiOnImageLoaded(){ /* foto baru: ROI di-reset; hanya foto yang SAMA (nama+ukuran+lastModified+ukuran working) memulihkan ROI tersimpan */
    const S=APP_STATE.image;S.roiPolygons=[];S.roiDraft=[];
    const key=roiImageKey();
    if(ROI_SAVED&&key&&ROI_SAVED.key===key){S.roiPolygons=ROI_SAVED.polygons.map(p=>p.map(q=>[q[0],q[1]]));const b=$('mvpPsdStatus');if(b)b.textContent='ROI poligon dipulihkan untuk foto yang sama • '+roiInfoText();}
    else if(ROI_SAVED){ROI_SAVED=null;persistWorking();} /* foto lain: buang ROI tersimpan dari localStorage juga */
    roiSyncUi();
  }
  function roiOnReset(){ROI_SAVED=null;roiSyncUi();}
  function roiShadeCanvas(w,h){
    const P=APP_STATE.image.roiPolygons;if(!Array.isArray(P)||!P.length)return null;
    const key=w+'x'+h+':'+JSON.stringify(P),C=(window.__kbRoiCache=window.__kbRoiCache||{key:'',cv:null});
    if(C.key===key&&C.cv)return C.cv;
    const m=roiRasterize(P,w,h),cv=document.createElement('canvas');cv.width=w;cv.height=h;
    const x=cv.getContext('2d'),im=x.createImageData(w,h),d=im.data;
    for(let i=0;i<m.length;i++)if(!m[i])d[i*4+3]=80; /* hitam, alpha 80/255 = digelapkan sedikit; sama persis dengan mask yang dipakai scan */
    x.putImageData(im,0,0);C.key=key;C.cv=cv;return cv;
  }
  function roiDrawShade(ctx,w,h){const cv=roiShadeCanvas(w,h);if(cv)ctx.drawImage(cv,0,0);}
  function roiDrawOutline(ctx,w,h,withDraft){
    const S=APP_STATE.image,P=S.roiPolygons||[],lw=Math.max(2,Math.round(w/560));
    const path=(poly,close)=>{ctx.beginPath();poly.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));if(close)ctx.closePath();};
    const stroke=()=>{ctx.setLineDash([]);ctx.strokeStyle='rgba(0,0,0,.55)';ctx.lineWidth=lw+2;ctx.stroke();ctx.setLineDash([lw*4,lw*2.5]);ctx.strokeStyle='#facc15';ctx.lineWidth=lw;ctx.stroke();};
    ctx.save();ctx.lineJoin='round';
    P.forEach(poly=>{if(!poly||poly.length<3)return;path(poly,true);stroke();});
    const d=S.roiDraft;
    if(withDraft&&S.manualMode==='roi'&&Array.isArray(d)&&d.length){
      if(d.length>1){path(d,false);stroke();}
      ctx.setLineDash([]);
      d.forEach((p,i)=>{ctx.beginPath();ctx.arc(p[0],p[1],i===0?lw*3.4:lw*1.8,0,Math.PI*2);ctx.fillStyle='#facc15';ctx.fill();if(i===0){ctx.strokeStyle='#ffffff';ctx.lineWidth=lw;ctx.stroke();}});
    }
    ctx.restore();
  }
  function computeImageQC(){ if(!APP_STATE.image.workingCanvas) return; const c=APP_STATE.image.workingCanvas,ctx=c.getContext('2d'),w=c.width,h=c.height; const sampleW=Math.min(400,w),sampleH=Math.min(300,h); const tmp=document.createElement('canvas');tmp.width=sampleW;tmp.height=sampleH;tmp.getContext('2d').drawImage(c,0,0,sampleW,sampleH); const d=tmp.getContext('2d').getImageData(0,0,sampleW,sampleH).data; const n=sampleW*sampleH; const gray=new Float32Array(n); let sum=0,sum2=0,min=255,max=0; for(let i=0;i<n;i++){const o=i*4,g=.299*d[o]+.587*d[o+1]+.114*d[o+2];gray[i]=g;sum+=g;sum2+=g*g;min=Math.min(min,g);max=Math.max(max,g);} const mean=sum/n,sd=Math.sqrt(Math.max(0,sum2/n-mean*mean)); let edges=0,lap=0; for(let y=1;y<sampleH-1;y++)for(let x=1;x<sampleW-1;x++){const i=y*sampleW+x; const gx=Math.abs(gray[i+1]-gray[i-1]),gy=Math.abs(gray[i+sampleW]-gray[i-sampleW]); if(gx+gy>28)edges++; lap+=Math.abs(gray[i-1]+gray[i+1]+gray[i-sampleW]+gray[i+sampleW]-4*gray[i]); } const edgeDensity=edges/((sampleW-2)*(sampleH-2)); const blur=lap/n; APP_STATE.image.qc={resolution:(Math.max(w,h)>=800?'PASS':Math.max(w,h)>=400?'FAIR':'POOR'),contrast:(sd>=45?'GOOD':sd>=25?'FAIR':'POOR'),brightness:(mean>=55&&mean<=205?'GOOD':mean<55?'DARK':'BRIGHT'),blur:(blur>=12?'LOW':blur>=6?'MEDIUM':'HIGH'),edgeDensity,dynamicRange:max-min,mean,sd};
    $('qcResolution').textContent=APP_STATE.image.qc.resolution; $('qcContrast').textContent=APP_STATE.image.qc.contrast; $('qcBrightness').textContent=APP_STATE.image.qc.brightness; $('qcBlur').textContent=APP_STATE.image.qc.blur; $('qcEdge').textContent=(edgeDensity*100).toFixed(1)+'%'; $('qcRange').textContent=(max-min).toFixed(0); }
  function renderImageMeta(){ const m=APP_STATE.image.metadata; $('imgName').textContent=m?.name||'--';$('imgFormat').textContent=m?.type||'--';$('imgWidth').textContent=m?.width?m.width+' px':'--';$('imgHeight').textContent=m?.height?m.height+' px':'--';$('imgSize').textContent=m?((m.size/1024/1024).toFixed(2)+' MB'):'--';$('imgWorking').textContent=m?`${m.workingWidth} × ${m.workingHeight} px`:'--'; $('physicalSizeLabel').textContent=psdScaleCm()!==null?'PHYSICAL SIZE: CALIBRATED':'PHYSICAL SIZE: NOT CALIBRATED'; }

  function applyScale(){ const p=APP_STATE.calibration.points; const mRaw=$('knownDistance').value, m=(mRaw===''||mRaw===null||mRaw===undefined)?NaN:Number(mRaw); if(p.length!==2){scaleReject('NOT CALIBRATED','Pilih POINT A dan POINT B terlebih dahulu.');return;} if(!Number.isFinite(m)||m<=0){scaleReject('INVALID DISTANCE','Known distance harus > 0.');return;} const pxWorking=Math.hypot(p[1].x-p[0].x,p[1].y-p[0].y); if(!Number.isFinite(pxWorking)||pxWorking<5){scaleReject('INVALID REFERENCE','Jarak Point A–B terlalu kecil; pilih reference yang lebih panjang.');return;} const sourceScale=Number(APP_STATE.image.transform?.scale)||1; const pxSource=pxWorking/sourceScale; const mPerSourcePixel=m/pxSource; const cmPerSourcePixel=m*100/pxSource; if(!(Number.isFinite(cmPerSourcePixel)&&cmPerSourcePixel>0&&Number.isFinite(m*100/pxWorking)&&m*100/pxWorking>0)){scaleReject('INVALID SCALE','Skala hasil kalibrasi tidak valid (bukan bilangan positif terhingga).');return;} APP_STATE.calibration.pixelDistanceWorking=pxWorking; APP_STATE.calibration.pixelDistanceSource=pxSource; APP_STATE.calibration.metersPerSourcePixel=mPerSourcePixel; APP_STATE.calibration.centimetersPerSourcePixel=cmPerSourcePixel; APP_STATE.calibration.metersPerWorkingPixel=m/pxWorking; APP_STATE.calibration.centimetersPerWorkingPixel=m*100/pxWorking; APP_STATE.calibration.status='APPROXIMATE SCALE'; APP_STATE.calibration.knownDistanceM=m; $('knownDistance').value=String(m); const longSide=Math.max(APP_STATE.image.metadata?.workingWidth||0,APP_STATE.image.metadata?.workingHeight||0); const ratio=longSide?pxWorking/longSide:0; const q=ratio>=0.08?'GOOD':ratio>=0.03?'FAIR':'POOR'; APP_STATE.calibration.quality=q; setCalibrationMode('CANCEL'); $('pixelDistance').textContent=fmt(pxSource,1)+' px source';$('mPerPixel').textContent=APP_STATE.calibration.metersPerSourcePixel.toExponential(4)+' m/source-px';$('cmPerPixel').textContent=fmt(APP_STATE.calibration.centimetersPerSourcePixel,4)+' cm/source-px';$('scaleStatus').textContent='APPROXIMATE SCALE';$('scaleQuality').textContent='QUALITY: '+q; audit('Calibration','',JSON.stringify(APP_STATE.calibration),'USER INPUT','APPLY SCALE'); if(APP_STATE.fragments.length) recomputeFragmentMeasurements(); renderImageMeta(); refreshAll(); }

  function grayscaleAndBlur(srcCanvas,radius){ const w=srcCanvas.width,h=srcCanvas.height; const src=srcCanvas.getContext('2d').getImageData(0,0,w,h).data; const gray=new Float32Array(w*h); for(let i=0;i<w*h;i++){const o=i*4;gray[i]=.299*src[o]+.587*src[o+1]+.114*src[o+2];} if(radius<=0) return {w,h,data:gray}; const out=new Float32Array(w*h), r=radius; for(let y=0;y<h;y++)for(let x=0;x<w;x++){let sum=0,cnt=0;for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){const xx=x+dx,yy=y+dy;if(xx>=0&&yy>=0&&xx<w&&yy<h){sum+=gray[yy*w+xx];cnt++;}}out[y*w+x]=sum/cnt;} return {w,h,data:out}; }
  function percentileFloat(arr,p){ const sample=arr.length>500000?Array.from(arr).filter((_,i)=>i%Math.ceil(arr.length/500000)===0):Array.from(arr); sample.sort((a,b)=>a-b); return sample[Math.floor(clamp(p,0,1)*(sample.length-1))]??0; }
  function morphology(bin,w,h,op,passes){ let cur=bin; for(let pass=0;pass<passes;pass++){const out=new Uint8Array(cur.length);for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const i=y*w+x;let n=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)n+=cur[(y+dy)*w+(x+dx)]; out[i]=op==='open'?(n>=5?1:0):(n>=3?1:0);}cur=out;} return cur; }

  function connectedComponents(bin,w,h,minArea,maxArea){
    const visited=new Uint8Array(w*h), comps=[];
    const qx=new Int32Array(Math.min(w*h,3000000));
    const qy=new Int32Array(Math.min(w*h,3000000));
    for(let sy=1;sy<h-1;sy++) for(let sx=1;sx<w-1;sx++){
      const si=sy*w+sx;
      if(!bin[si]||visited[si]) continue;
      let head=0,tail=0;
      qx[tail]=sx; qy[tail]=sy; tail++; visited[si]=1;
      const pixels=[];
      let area=0,minx=sx,maxx=sx,miny=sy,maxy=sy;
      while(head<tail){
        const x=qx[head],y=qy[head]; head++; pixels.push([x,y]); area++;
        if(x<minx)minx=x; if(x>maxx)maxx=x; if(y<miny)miny=y; if(y>maxy)maxy=y;
        for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){
          if(dx===0&&dy===0) continue;
          const nx=x+dx,ny=y+dy;
          if(nx<1||ny<1||nx>=w-1||ny>=h-1) continue;
          const ni=ny*w+nx;
          if(bin[ni]&&!visited[ni]){
            visited[ni]=1;
            if(tail<qx.length){qx[tail]=nx;qy[tail]=ny;tail++;}
          }
        }
      }
      if(area>=minArea && (!maxArea||area<=maxArea)) comps.push({pixels,area,minx,maxx,miny,maxy});
    }
    return comps;
  }

  function gradientMagnitude(g){
    const w=g.w,h=g.h,out=new Float32Array(w*h);
    let max=0;
    for(let y=1;y<h-1;y++) for(let x=1;x<w-1;x++){
      const i=y*w+x;
      const gx=(g.data[i+1]-g.data[i-1])*0.5;
      const gy=(g.data[i+w]-g.data[i-w])*0.5;
      const m=Math.hypot(gx,gy);
      out[i]=m; if(m>max)max=m;
    }
    return {data:out,max};
  }

  class MinHeap{
    constructor(){this.a=[];}
    push(item){
      const a=this.a; let i=a.length; a.push(item);
      while(i>0){ const p=(i-1)>>1; if(a[p][0]<=item[0])break; a[i]=a[p]; i=p; }
      a[i]=item;
    }
    pop(){
      const a=this.a; if(!a.length)return null;
      const root=a[0],last=a.pop();
      if(a.length){ let i=0;
        while(true){let l=i*2+1,r=l+1,b=-1,bv=last[0]; // sift-down must compare against `last`, not the stale slot
          if(l<a.length&&a[l][0]<bv){b=l;bv=a[l][0];}
          if(r<a.length&&a[r][0]<bv)b=r;
          if(b<0)break; a[i]=a[b]; i=b;
        }
        a[i]=last;
      }
      return root;
    }
    get size(){return this.a.length;}
  }

  function splitLargeComponent(comp,g,grad,sepSensitivity,minArea){
    const bw=comp.maxx-comp.minx+1,bh=comp.maxy-comp.miny+1;
    const sc=clamp(Math.sqrt((g.w*g.h)/(1280*720)),0.5,2.5); if(comp.area<Math.max(3*minArea,400*sc*sc) || Math.max(bw,bh)<Math.max(24,32*sc)) return [comp];

    const pad=1,lw=bw+2,lh=bh+2,total=lw*lh;
    const mask=new Uint8Array(total);
    for(const [x,y] of comp.pixels) mask[(y-comp.miny+1)*lw+(x-comp.minx+1)]=1;

    const d=new Float32Array(total); d.fill(1e9); for(let x=0;x<lw;x++){d[x]=0;d[(lh-1)*lw+x]=0;} for(let y=0;y<lh;y++){d[y*lw]=0;d[y*lw+lw-1]=0;} // bbox padding ring is background; without it flush edges got infinite distance
    for(let y=1;y<=bh;y++) for(let x=1;x<=bw;x++){
      const i=y*lw+x; if(!mask[i]){d[i]=0;continue;}
      let v=d[i]; if(d[i-1]+1<v)v=d[i-1]+1; if(d[i-lw]+1<v)v=d[i-lw]+1;
      if(d[i-lw-1]+1.414<v)v=d[i-lw-1]+1.414; if(d[i-lw+1]+1.414<v)v=d[i-lw+1]+1.414; d[i]=v;
    }
    for(let y=bh;y>=1;y--) for(let x=bw;x>=1;x--){
      const i=y*lw+x; if(!mask[i])continue; let v=d[i];
      if(d[i+1]+1<v)v=d[i+1]+1; if(d[i+lw]+1<v)v=d[i+lw]+1;
      if(d[i+lw-1]+1.414<v)v=d[i+lw-1]+1.414; if(d[i+lw+1]+1.414<v)v=d[i+lw+1]+1.414; d[i]=v;
    }
    let maxD=0; for(let y=1;y<=bh;y++) for(let x=1;x<=bw;x++){const i=y*lw+x;if(mask[i]&&d[i]>maxD)maxD=d[i];}
    if(maxD<3)return [comp];

    const norm=clamp((sepSensitivity-.1)/2.9,0,1);
    const seedCut=maxD*(0.58-0.23*norm);
    const nms=Math.max(3,Math.round(9-5*norm));
    const candidates=[];
    for(let y=2;y<bh;y++) for(let x=2;x<bw;x++){
      const i=y*lw+x,di=d[i]; if(!mask[i]||di<seedCut)continue;
      const rr=Math.max(2,Math.floor(nms/2)); let peak=true; for(let yy=-rr;yy<=rr&&peak;yy++){const Y=y+yy; if(Y<0||Y>=lh)continue; for(let xx=-rr;xx<=rr;xx++){const X=x+xx; if((xx===0&&yy===0)||X<0||X>=lw)continue; if(d[Y*lw+X]>di){peak=false;break;}}} // window peak: a noisy neck must not become a seed
      if(peak)candidates.push({x,y,d:di});
    }
    candidates.sort((a,b)=>b.d-a.d);
    const seeds=[];
    const minSeedSep=nms;
    for(const c of candidates){
      let ok=true; for(const s of seeds){if(Math.hypot(c.x-s.x,c.y-s.y)<minSeedSep){ok=false;break;}}
      if(ok)seeds.push(c);
      if(seeds.length>=80)break;
    }
    if(seeds.length<2) return [comp];

    // Multi-source watershed-like propagation. High gradient = high travel cost,
    // so touching rocks preferentially separate along visible intensity edges.
    const bestCost=new Float64Array(total); bestCost.fill(1e20); // Float32 rounding made `cost!==bestCost[idx]` skip most heap items -> most child pixels were lost
    const labels=new Int32Array(total); labels.fill(0);
    const heap=new MinHeap();
    seeds.forEach((s,idx)=>{const i=s.y*lw+s.x;bestCost[i]=0;labels[i]=idx+1;heap.push([0,i,idx+1]);});
    const dirs=[[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[1,-1],[-1,1],[1,1]];
    const edgeBoost=0.8+2.8*norm;
    while(heap.size){
      const it=heap.pop(); if(!it)break; const [cost,idx,lab]=it;
      if(cost!==bestCost[idx]||labels[idx]!==lab)continue;
      const x=idx%lw,y=(idx/lw)|0;
      for(const [dx,dy] of dirs){
        const nx=x+dx,ny=y+dy; if(nx<1||ny<1||nx>bw||ny>bh)continue;
        const ni=ny*lw+nx; if(!mask[ni])continue;
        const gx=comp.minx+nx-1,gy=comp.miny+ny-1,gidx=gy*g.w+gx;
        const gradNorm=Math.min(1,(grad.data[gidx]||0)/80);
        const step=(dx&&dy?1.414:1)*(1+edgeBoost*gradNorm);
        const nc=cost+step;
        if(nc<bestCost[ni]){bestCost[ni]=nc;labels[ni]=lab;heap.push([nc,ni,lab]);}
      }
    }

    // Neck evidence: merge adjacent regions whose shared saddle in the distance map is nearly as thick as
    // their peaks (one rock with several bumps). Only regions joined by a genuine narrow neck stay split.
    const par=seeds.map((_,i)=>i), find=a=>{while(par[a]!==a){par[a]=par[par[a]];a=par[a];}return a;};
    const saddle=new Map(), mergeRatio=0.82-0.22*norm;
    for(let y=1;y<=bh;y++)for(let x=1;x<=bw;x++){const i=y*lw+x;if(!mask[i]||!labels[i])continue;const la=labels[i];
      for(const j of [i+1,i+lw]){if(!mask[j])continue;const lb=labels[j];if(!lb||lb===la)continue;const k=la<lb?la*1000+lb:lb*1000+la,v=Math.min(d[i],d[j]);if(v>(saddle.get(k)||0))saddle.set(k,v);}}
    for(const [k,v] of saddle){const a=Math.floor(k/1000)-1,b=k%1000-1;if(v>=mergeRatio*Math.min(seeds[a].d,seeds[b].d))par[find(a)]=find(b);}
    const groups=Array.from({length:seeds.length},()=>({pixels:[],area:0,minx:Infinity,maxx:-Infinity,miny:Infinity,maxy:-Infinity}));
    for(const [x,y] of comp.pixels){
      const lab=labels[(y-comp.miny+1)*lw+(x-comp.minx+1)]; if(!lab)continue;
      const li=find(lab-1);
      if(!groups[li])continue;
      const q=groups[li]; q.pixels.push([x,y]); q.area++;
      if(x<q.minx)q.minx=x;if(x>q.maxx)q.maxx=x;if(y<q.miny)q.miny=y;if(y>q.maxy)q.maxy=y;
    }
    const out=groups.filter(q=>q.area>=minArea);
    return out.length>=2?out:[comp];
  }

  function recoverLargeFragments(comps,g,grad,sepSensitivity,minArea){
    const out=[]; let splitCount=0;
    for(const c of comps){
      const parts=splitLargeComponent(c,g,grad,sepSensitivity,minArea);
      if(parts.length>1)splitCount+=parts.length-1;
      out.push(...parts);
    }
    return {components:out,splitCount};
  }

  function boundaryPoints(comp){ const set=new Set(comp.pixels.map(([x,y])=>x+','+y)); const b=[]; for(const [x,y] of comp.pixels){ let edge=false; for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){ if(dx===0&&dy===0)continue; if(!set.has((x+dx)+','+(y+dy))){edge=true;break;} } if(edge) b.push([x,y]); } return b; }
  function maxFeret(comp){ const pts=boundaryPoints(comp); if(pts.length<2) return 0; const step=Math.max(1,Math.ceil(pts.length/800)); const p=pts.filter((_,i)=>i%step===0); let max=0; for(let i=0;i<p.length;i++)for(let j=i+1;j<p.length;j++){const dx=p[i][0]-p[j][0],dy=p[i][1]-p[j][1]; const d=Math.hypot(dx,dy); if(d>max)max=d;} return max; }
  function eqDiam(comp){ return 2*Math.sqrt(comp.area/Math.PI); }
  function bboxMax(comp){ return Math.max(comp.maxx-comp.minx+1,comp.maxy-comp.miny+1); }
  function measureComp(comp,id){ const feret=maxFeret(comp), ed=eqDiam(comp), bb=bboxMax(comp); const pxDef=APP_STATE.psd.sizeDefinition==='feret'?feret:APP_STATE.psd.sizeDefinition==='eqdiam'?ed:bb; const scale=psdScaleCm(); const measured=scale?pxDef*scale:null; const aspect=Math.max((comp.maxx-comp.minx+1)/(comp.maxy-comp.miny+1),(comp.maxy-comp.miny+1)/(comp.maxx-comp.minx+1)); const circularity=(4*Math.PI*comp.area)/Math.max(1,(feret*Math.PI)**2); const conf=clamp(0.55+Math.min(.25,comp.area/50000)+Math.min(.15,1/aspect*.15),.35,.95); const rawBoundary=boundaryPoints(comp); const step=Math.max(1,Math.ceil(rawBoundary.length/220)); const boundary=rawBoundary.filter((_,i)=>i%step===0); return {id,area:comp.area,minx:comp.minx,maxx:comp.maxx,miny:comp.miny,maxy:comp.maxy,eqDiameterPx:ed,feretPx:feret,bboxMaxPx:bb,boundary,measuredSizeCm:measured,confidence:conf,circularity,aspect,solidity:1,status:psdStatusFromSize(measured)}; }

  function localContrastBinary(g, thresholdPercentile, polarity, sensitivity){
    const w=g.w,h=g.h, n=w*h; const out=new Uint8Array(n);
    // Use global gray values plus a cheap tile illumination correction.
    const tile=32; const cols=Math.ceil(w/tile), rows=Math.ceil(h/tile); const means=new Float32Array(cols*rows), counts=new Uint32Array(cols*rows);
    for(let y=0;y<h;y++){ const ty=Math.floor(y/tile); for(let x=0;x<w;x++){const tx=Math.floor(x/tile),v=g.data[y*w+x],k=ty*cols+tx; means[k]+=v;counts[k]++;}}
    for(let i=0;i<means.length;i++) means[i]/=Math.max(1,counts[i]);
    const global=percentileFloat(g.data,thresholdPercentile); const sens=clamp(sensitivity,0.25,3);
    for(let y=1;y<h-1;y++){ const ty=Math.floor(y/tile); for(let x=1;x<w-1;x++){ const tx=Math.floor(x/tile), local=means[ty*cols+tx]; const v=g.data[y*w+x]; const corrected=v-(local-128); const cut=global-(local-128); out[y*w+x]=polarity==='dark'?(corrected < cut/sens?1:0):(corrected > cut*sens?1:0); }}
    return out;
  }
  function scoreCandidate(comps,w,h){ if(!comps.length)return -1e9; const areas=comps.map(c=>c.area); const total=w*h; const coverage=areas.reduce((a,b)=>a+b,0)/total; const med=median(areas)||0; const usable=comps.filter(c=>{const bw=c.maxx-c.minx+1,bh=c.maxy-c.miny+1;return bw>=5&&bh>=5&&bw<w*.65&&bh<h*.65}).length; const coverageScore=coverage>0.03&&coverage<0.75?1:coverage>0.01&&coverage<0.9?.6:0; const countScore=usable>=12?1:usable>=5?.65:usable>=3?.35:0; const sizeScore=med>20?1:med>8?.65:.2; return countScore*.45+coverageScore*.35+sizeScore*.20; }

  // Segmentation core (pure: gray image + gradient + config). Order: threshold -> morphology -> connected
  // components -> recovery/split -> post-split classification. Nothing is rejected before recovery.
  function componentEdgeScore(comp,g,grad){
    if(!comp?.pixels?.length) return 0;
    const pts=boundaryPoints(comp); if(!pts.length) return 0;
    const step=Math.max(1,Math.ceil(pts.length/220));
    let sum=0,n=0;
    for(let i=0;i<pts.length;i+=step){const [x,y]=pts[i]; const idx=y*g.w+x; sum+=grad.data[idx]||0; n++;}
    return n?sum/n:0;
  }
  function bboxOverlapRatio(a,b){
    const ix=Math.max(0,Math.min(a.maxx,b.maxx)-Math.max(a.minx,b.minx)+1);
    const iy=Math.max(0,Math.min(a.maxy,b.maxy)-Math.max(a.miny,b.miny)+1);
    const inter=ix*iy;
    const aa=Math.max(1,(a.maxx-a.minx+1)*(a.maxy-a.miny+1));
    const ab=Math.max(1,(b.maxx-b.minx+1)*(b.maxy-b.miny+1));
    return inter/Math.max(1,Math.min(aa,ab));
  }

  // Visual rock photos often contain mid-tone fragments that disappear under one polarity /
  // threshold. Keep the primary engine unchanged, then add a conservative second-pass recovery
  // from alternate thresholds/polarities. Recovery only contributes spatially distinct regions.
  function recoverUnseenCandidates(best,g,grad,cfg,minA,run){
    const recovered=[];
    const basePol=best.polarity==='PERMISSIVE' ? (APP_STATE.image.mode==='high'?'bright':APP_STATE.image.mode==='low'?'dark':'dark') : best.polarity;
    const variants=[];
    const push=(pol,p,sn)=>variants.push({pol,p:clamp(p,.06,.94),sn:clamp(sn,.25,3)});
    if(basePol==='dark') push('dark',Number(cfg.thresholdPct)/100+.08,Number(cfg.edgeSensitivity)*.72);
    else push('bright',Number(cfg.thresholdPct)/100-.08,Number(cfg.edgeSensitivity)*.72);
    push(basePol==='dark'?'bright':'dark',Number(cfg.thresholdPct)/100,Number(cfg.edgeSensitivity)*.68);
    push(basePol==='dark'?'dark':'bright',Number(cfg.thresholdPct)/100+(basePol==='dark'?.13:-.13),Number(cfg.edgeSensitivity)*.58);
    const existing=best.comps.slice();
    for(const v of variants){
      const rr=run(v.pol,v.p,v.sn,Math.max(20,Math.floor(minA*.75)),0,1);
      for(const c of rr.comps){
        const bw=c.maxx-c.minx+1,bh=c.maxy-c.miny+1;
        if(c.area<Math.max(24,Math.floor(minA*.9))||bw<5||bh<5)continue;
        if((bw/g.w)>0.86&&(bh/g.h)>0.86)continue;
        const edge=componentEdgeScore(c,g,grad);
        if(edge<Math.max(2.5,(grad.max||0)*.03))continue;
        if(existing.some(e=>bboxOverlapRatio(c,e)>.68))continue;
        if(recovered.some(e=>bboxOverlapRatio(c,e)>.68))continue;
        recovered.push({...c,review:false,reviewReason:'RECOVERED ALTERNATE CONTRAST',recovered:true});
        if(recovered.length>=250)break;
      }
      if(recovered.length>=250)break;
    }
    return recovered;
  }

  // Segmentation core (pure: gray image + gradient + config). Order: threshold -> morphology -> connected
  // components -> recovery/split -> post-split classification. Nothing is rejected before recovery.
  function segmentFragments(g,grad,cfg,mode){
    const sens=Number(cfg.edgeSensitivity)||1, sepSens=Number(cfg.separationSensitivity)||1;
    const minA=Math.max(20,Math.round(Number(cfg.minArea)||100)), maxA=Math.max(0,Math.round(Number(cfg.maxArea)||0));
    const pct=clamp(Number(cfg.thresholdPct)/100,.05,.95), total=g.w*g.h;
    const openP=clamp(Math.round(Number(cfg.morphologyOpenPasses)||0),0,5), closeP=clamp(Math.round(Number(cfg.morphologyClosePasses)||0),0,5);
    const wPct=(Number(cfg.maxObjectWidthPct)||70)/100, hPct=(Number(cfg.maxObjectHeightPct)||70)/100;
    const polarities=mode==='low'?['dark']:mode==='high'?['bright']:['dark','bright'];
    const classify=(comps,mn)=>{
      const list=[],dropped={maxArea:0,background:0};
      for(const c of comps){
        const bw=c.maxx-c.minx+1,bh=c.maxy-c.miny+1;
        if(bw<5||bh<5||c.area<mn)continue;
        if(maxA&&c.area>maxA){dropped.maxArea++;continue;}           // maxArea = final-object validation only
        const cov=c.area/total;
        if(cov>0.6||(bw>=g.w*.92&&bh>=g.h*.92&&cov>0.35)){dropped.background++;continue;} // background slab after recovery
        const why=[]; if(bw>=g.w*wPct)why.push(`width>=${cfg.maxObjectWidthPct}%`); if(bh>=g.h*hPct)why.push(`height>=${cfg.maxObjectHeightPct}%`); if(cov>0.25)why.push(`coverage ${(cov*100).toFixed(0)}%`);
        c.review=why.length>0; c.reviewReason=why.join(', '); list.push(c);   // LARGE_FRAGMENT_CANDIDATE -> flagged REVIEW, never silently dropped
      }
      return {list,dropped};
    };
    const run=(polarity,p,sn,mn,openOverride=openP,closeOverride=closeP)=>{
      let bin=localContrastBinary(g,p,polarity,sn);
      bin=morphology(bin,g.w,g.h,'open',openOverride); bin=morphology(bin,g.w,g.h,'close',closeOverride);
      const raw=connectedComponents(bin,g.w,g.h,mn,0).filter(c=>c.maxx-c.minx>=4&&c.maxy-c.miny>=4);
      const rec=recoverLargeFragments(raw,g,grad,sepSens,mn), cl=classify(rec.components,mn);
      return {polarity,comps:cl.list,dropped:cl.dropped,splitCount:rec.splitCount,score:scoreCandidate(cl.list,g.w,g.h)+rec.splitCount*0.004};
    };
    const cands=polarities.map(pl=>run(pl,pct,sens,minA)).sort((a,b)=>b.score-a.score);
    let best=cands[0];
    if(best.comps.length<Math.max(1,Number(cfg.minValidObjects)||1)){
      const perm=polarities.map(pl=>run(pl,Math.max(.35,pct-.12),Math.max(.35,sens*.8),Math.max(20,Math.floor(minA*.35)))).sort((a,b)=>b.score-a.score)[0];
      if(perm.comps.length>best.comps.length) best={...perm,polarity:'PERMISSIVE'};
    }
    const recovered=recoverUnseenCandidates(best,g,grad,cfg,minA,run);
    if(recovered.length){
      best={...best,comps:best.comps.concat(recovered),recoveredCount:recovered.length};
    } else best={...best,recoveredCount:0};
    return best;
  }
  /* Ordered outline (Moore-neighbour trace) of a pixel component, used ONLY for drawing. boundaryPoints() returns edge pixels in raster order,
     and drawing those as a polygon produced the long zig-zag lines across the photo. Metrics keep using the pixel set, not this outline. */
  function rkTraceOutline(c,maxPts){
    maxPts=maxPts||140;
    const bw=c.maxx-c.minx+3,bh=c.maxy-c.miny+3,m=new Uint8Array(bw*bh);
    for(const [x,y] of c.pixels)m[(y-c.miny+1)*bw+(x-c.minx+1)]=1;
    let sx=-1,sy=-1;
    for(let y=0;y<bh&&sx<0;y++)for(let x=0;x<bw;x++)if(m[y*bw+x]){sx=x;sy=y;break;}
    if(sx<0)return [];
    const DX=[1,1,0,-1,-1,-1,0,1],DY=[0,1,1,1,0,-1,-1,-1];
    const dirOf=(ax,ay)=>{for(let i=0;i<8;i++)if(DX[i]===ax&&DY[i]===ay)return i;return 4;};
    let cx=sx,cy=sy,back=4;const pts=[[cx,cy]];
    for(let it=0,lim=bw*bh*2;it<lim;it++){
      let moved=false;
      for(let k=1;k<=8;k++){const d=(back+k)%8,nx=cx+DX[d],ny=cy+DY[d];
        if(nx>=0&&ny>=0&&nx<bw&&ny<bh&&m[ny*bw+nx]){
          const pd=(d+7)%8, bgx=cx+DX[pd], bgy=cy+DY[pd];
          back=dirOf(bgx-nx,bgy-ny); cx=nx;cy=ny;moved=true;break;}}
      if(!moved)break;
      if(cx===sx&&cy===sy)break;
      pts.push([cx,cy]);
    }
    const step=Math.max(1,Math.ceil(pts.length/maxPts)),out=[];
    for(let i=0;i<pts.length;i+=step)out.push([pts[i][0]+c.minx-1,pts[i][1]+c.miny-1]);
    return out;
  }
  /* polygon used to DRAW an object: traced outline for automatic objects, exact polygon for manual ones, convex hull otherwise */
  function fragDrawPoly(f){
    if(Array.isArray(f.outline)&&f.outline.length>=3&&!f.source&&!f.manual&&!f.estimate&&!f.exactPolygon)return f.outline;
    if(f.exactPolygon&&Array.isArray(f.boundary))return f.boundary;
    return convexHull(f.boundary||[]);
  }
  /* ======================= SEGMENTATION ENGINE V5 (edge/valley watershed + region merge) =======================
     Why: the legacy engine thresholds brightness. On sand-coloured rock piles the sky, the berm and the sandy floor have the
     same brightness as rocks, so they become giant "fragments" and the X50/X80 error explodes (measured +318% D50 vs WipFrag
     outlines on HH-8). V5 separates rocks the way a person does: along dark crevices and edges, normalised for lighting.
     Pipeline: gray -> local-brightness-normalised edge + dark-valley map -> marker-controlled watershed (over-segmentation)
     -> region-adjacency merge (weakest boundary first, size-aware so slabs cannot chain together) -> area filter.
     Sky (blue-dominant region connected to the top border) and the optional analysis ROI are excluded BEFORE segmentation. */
  function rkGauss(src,w,h,sigma){
    if(sigma<=0)return Float32Array.from(src);
    const r=Math.max(1,Math.ceil(sigma*3)),k=new Float32Array(2*r+1);let s=0;
    for(let i=-r;i<=r;i++){k[i+r]=Math.exp(-i*i/(2*sigma*sigma));s+=k[i+r];}
    for(let i=0;i<k.length;i++)k[i]/=s;
    const tmp=new Float32Array(w*h),out=new Float32Array(w*h);
    for(let y=0;y<h;y++){const o=y*w;for(let x=0;x<w;x++){let a=0;for(let i=-r;i<=r;i++){let xx=x+i;xx=xx<0?0:xx>=w?w-1:xx;a+=src[o+xx]*k[i+r];}tmp[o+x]=a;}}
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){let a=0;for(let i=-r;i<=r;i++){let yy=y+i;yy=yy<0?0:yy>=h?h-1:yy;a+=tmp[yy*w+x]*k[i+r];}out[y*w+x]=a;}
    return out;
  }
  function rkBoxMean(src,w,h,r){
    const W1=w+1,I=new Float64Array(W1*(h+1));
    for(let y=0;y<h;y++){let row=0;for(let x=0;x<w;x++){row+=src[y*w+x];I[(y+1)*W1+x+1]=I[y*W1+x+1]+row;}}
    const out=new Float32Array(w*h);
    for(let y=0;y<h;y++){const y0=Math.max(0,y-r),y1=Math.min(h-1,y+r);for(let x=0;x<w;x++){const x0=Math.max(0,x-r),x1=Math.min(w-1,x+r);
      out[y*w+x]=(I[(y1+1)*W1+x1+1]-I[y0*W1+x1+1]-I[(y1+1)*W1+x0]+I[y0*W1+x0])/((x1-x0+1)*(y1-y0+1));}}
    return out;
  }
  function rkMorph(src,w,h,r,isMax){
    const tmp=new Float32Array(w*h),out=new Float32Array(w*h);
    for(let y=0;y<h;y++){const o=y*w;for(let x=0;x<w;x++){let m=src[o+x];const a=Math.max(0,x-r),b=Math.min(w-1,x+r);for(let xx=a;xx<=b;xx++){const v=src[o+xx];if(isMax?v>m:v<m)m=v;}tmp[o+x]=m;}}
    for(let y=0;y<h;y++){const a=Math.max(0,y-r),b=Math.min(h-1,y+r);for(let x=0;x<w;x++){let m=tmp[y*w+x];for(let yy=a;yy<=b;yy++){const v=tmp[yy*w+x];if(isMax?v>m:v<m)m=v;}out[y*w+x]=m;}}
    return out;
  }
  function rkQuantile(arr,p,step){const a=[];step=step||1;for(let i=0;i<arr.length;i+=step)a.push(arr[i]);a.sort((x,y)=>x-y);return a.length?a[Math.min(a.length-1,Math.max(0,Math.floor(p*(a.length-1))))]:0;}
  function rkDetectSky(rgb,w,h){
    const cand=new Uint8Array(w*h);
    for(let i=0;i<w*h;i++){const r=rgb[i*4],g=rgb[i*4+1],b=rgb[i*4+2];cand[i]=(b>=r-2&&b>=g-4)?1:0;}
    const sky=new Uint8Array(w*h),q=new Int32Array(w*h);let t=0,hd=0;
    for(let x=0;x<w;x++){if(cand[x]&&!sky[x]){sky[x]=1;q[t++]=x;}}
    while(hd<t){const i=q[hd++],x=i%w,y=(i/w)|0;
      if(x>0&&cand[i-1]&&!sky[i-1]){sky[i-1]=1;q[t++]=i-1;}
      if(x<w-1&&cand[i+1]&&!sky[i+1]){sky[i+1]=1;q[t++]=i+1;}
      if(y>0&&cand[i-w]&&!sky[i-w]){sky[i-w]=1;q[t++]=i-w;}
      if(y<h-1&&cand[i+w]&&!sky[i+w]){sky[i+w]=1;q[t++]=i+w;}}
    return {mask:sky,count:t};
  }
  /* rgba: Uint8ClampedArray from getImageData (4 bytes/pixel). opt: markerRadius, mergeTau, minArea, maxAreaFrac, sizePenalty, valleyWeight, roiTop, roiBottom (0..1 of height), roiMask (optional Uint8Array w*h, 1=inside polygon ROI; overrides roiTop/roiBottom) */
  function segmentRocksV5(rgba,w,h,opt){
    opt=opt||{};
    const N=w*h,scale=Math.sqrt(N/(1280*960)),sc8=Math.max(.8,scale);
    const markerR=Math.max(3,Math.round((opt.markerRadius||7)*scale));
    const minArea=Math.max(20,Math.round(opt.minArea||150));
    const tau=opt.mergeTau!=null?opt.mergeTau:1.15, sizePen=opt.sizePenalty!=null?opt.sizePenalty:.45, maxA=(opt.maxAreaFrac||.02)*N;
    const gray=new Float32Array(N);
    for(let i=0;i<N;i++)gray[i]=.299*rgba[i*4]+.587*rgba[i*4+1]+.114*rgba[i*4+2];
    const G1=rkGauss(gray,w,h,(opt.baseSigma!=null?opt.baseSigma:1.2)*sc8), Lm=rkBoxMean(G1,w,h,Math.round(20*scale));
    const vr=Math.max(2,Math.round(4*scale)), cl=rkMorph(rkMorph(G1,w,h,vr,true),w,h,vr,false);
    const E=new Float32Array(N), vw=opt.valleyWeight!=null?opt.valleyWeight:1.5;
    for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const i=y*w+x;
      const gx=(G1[i-w+1]+2*G1[i+1]+G1[i+w+1])-(G1[i-w-1]+2*G1[i-1]+G1[i+w-1]);
      const gy=(G1[i+w-1]+2*G1[i+w]+G1[i+w+1])-(G1[i-w-1]+2*G1[i-w]+G1[i-w+1]);
      E[i]=100*(Math.hypot(gx,gy)/8+vw*Math.max(0,cl[i]-G1[i]))/(Lm[i]+30);}
    // excluded area = sky + outside the analysis ROI
    const sk=rkDetectSky(rgba,w,h), excl=sk.mask;
    const y0=Math.round(clamp(Number(opt.roiTop)||0,0,1)*h), y1=opt.roiBottom!=null&&Number(opt.roiBottom)<1?Math.round(clamp(Number(opt.roiBottom),0,1)*h):h;
    // opt.roiMask (Uint8Array w*h, 1 = di dalam ROI poligon pengguna) menggantikan pita atas/bawah; di luar ROI => excl=1
    const rm=opt.roiMask; if(rm&&rm.length!==N)throw new Error('roiMask length '+rm.length+' != '+N);
    if(rm){for(let i=0;i<N;i++)if(!rm[i])excl[i]=1;}
    else for(let y=0;y<h;y++)if(y<y0||y>=y1)for(let x=0;x<w;x++)excl[y*w+x]=1;
    if(opt.flatFrac>0){
      const Tm=rkBoxMean(E,w,h,Math.max(6,Math.round((opt.flatWin||30)*scale))),v=[];
      for(let i=0;i<N;i+=5)if(!excl[i])v.push(Tm[i]);
      if(v.length>50){v.sort((a,b)=>a-b);const thr=opt.flatFrac*v[Math.floor(v.length*.8)];
        for(let i=0;i<N;i++)if(Tm[i]<thr)excl[i]=1;}
    }
    // markers = minima of a heavily smoothed edge map
    const Es=rkGauss(E,w,h,Math.max(2,2.5*scale));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++)Es[y*w+x]+=((x*7919+y*104729)%1000)*1e-6;
    const Emin=rkMorph(Es,w,h,markerR,false), lab=new Int32Array(N), cut=rkQuantile(Es,.75,7);
    let nm=0; for(let i=0;i<N;i++)if(!excl[i]&&Es[i]===Emin[i]&&Es[i]<cut)lab[i]=++nm;
    if(nm<2)return {comps:[],meta:{markers:nm,reason:'NO MARKERS (ROI/sky removed everything?)'}};
    // bucket-queue watershed
    const Ew=rkGauss(E,w,h,opt.wsSigma!=null?opt.wsSigma:1.6*sc8), emax=rkQuantile(Ew,.995,3)||1, L=1024;
    const lev=i=>{const v=Ew[i]/emax;return v>=1?L-1:(v*(L-1))|0;};
    const head=new Int32Array(L).fill(-1), next=new Int32Array(N), done=new Uint8Array(N);
    for(let i=0;i<N;i++)if(lab[i]){const l=lev(i);next[i]=head[l];head[l]=i;}
    for(let cur=0;cur<L;){const i=head[cur];if(i<0){cur++;continue;}head[cur]=next[i];if(done[i])continue;done[i]=1;
      const x=i%w,y=(i/w)|0,l=lab[i];
      for(let k=0;k<4;k++){const j=k===0?(x>0?i-1:-1):k===1?(x<w-1?i+1:-1):k===2?(y>0?i-w:-1):(y<h-1?i+w:-1);
        if(j<0||lab[j]||excl[j])continue;lab[j]=l;let lv=lev(j);if(lv<cur)lv=cur;next[j]=head[lv];head[lv]=j;}}
    // region adjacency + merge
    const area=new Float64Array(nm+1),mx=new Float64Array(nm+1),my=new Float64Array(nm+1),mxx=new Float64Array(nm+1),myy=new Float64Array(nm+1),mxy=new Float64Array(nm+1);
    for(let i=0;i<N;i++){const l=lab[i];if(!l)continue;const x=i%w,y=(i/w)|0;area[l]++;mx[l]+=x;my[l]+=y;mxx[l]+=x*x;myy[l]+=y*y;mxy[l]+=x*y;}
    // elongation (sqrt of eigenvalue ratio of the covariance) of a region described by raw moments
    const elong=(n,sx,sy,sxx,syy,sxy)=>{const cx=sx/n,cy=sy/n,a=sxx/n-cx*cx+1/12,b=syy/n-cy*cy+1/12,c=sxy/n-cx*cy,t=Math.sqrt(Math.max(0,((a-b)/2)**2+c*c)),l1=(a+b)/2+t,l2=Math.max(1e-6,(a+b)/2-t);return Math.sqrt(l1/l2);};
    const maxElong=opt.maxElongation||2.4, elongFrom=opt.elongFromArea||600*scale*scale;
    const adj=Array.from({length:nm+1},()=>new Map());
    const addPair=(a,b,v)=>{if(a===b||!a||!b)return;let m=adj[a].get(b);if(!m){m={s:0,c:0};adj[a].set(b,m);adj[b].set(a,m);}m.s+=v;m.c++;};
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x,a=lab[i];if(!a)continue;
      if(x<w-1)addPair(a,lab[i+1],(Ew[i]+Ew[i+1])/2); if(y<h-1)addPair(a,lab[i+w],(Ew[i]+Ew[i+w])/2);}
    const all=[];for(let a=1;a<=nm;a++)for(const [b,m] of adj[a])if(b>a)all.push(m.s/m.c);
    all.sort((p,q)=>p-q);const medB=all[all.length>>1]||1, thr=tau*medB;
    const par=new Int32Array(nm+1);for(let i=0;i<=nm;i++)par[i]=i;const find=a=>{while(par[a]!==a){par[a]=par[par[a]];a=par[a];}return a;};
    const heap=new MinHeap();
    for(let a=1;a<=nm;a++)for(const [b,m] of adj[a])if(b>a)heap.push([m.s/m.c,a,b]);
    while(heap.size){const it=heap.pop();if(!it)break;const wt=it[0];if(wt>thr)break;
      const ra=find(it[1]),rb=find(it[2]);if(ra===rb)continue;
      const live=adj[ra].get(rb);if(!live)continue;const lw=live.s/live.c;if(Math.abs(lw-wt)>1e-9){heap.push([lw,ra,rb]);continue;}
      const mA=area[ra]+area[rb];if(mA>maxA)continue;
      if(wt>thr*(1-sizePen*Math.min(1,mA/maxA)))continue;       // bigger merged region => needs weaker boundary
      {const n=mA,sx=mx[ra]+mx[rb],sy=my[ra]+my[rb],sxx=mxx[ra]+mxx[rb],syy=myy[ra]+myy[rb],sxy=mxy[ra]+mxy[rb];
       if(mA>elongFrom&&elong(n,sx,sy,sxx,syy,sxy)>maxElong)continue;}   // rocks are compact: a long thin merge is a chain of two rocks / a crack, not one fragment
      par[rb]=ra;area[ra]=mA;mx[ra]+=mx[rb];my[ra]+=my[rb];mxx[ra]+=mxx[rb];myy[ra]+=myy[rb];mxy[ra]+=mxy[rb];
      for(const [c,mm] of adj[rb]){if(c===ra)continue;adj[c].delete(rb);const ex=adj[ra].get(c);
        if(ex){ex.s+=mm.s;ex.c+=mm.c;}else{adj[ra].set(c,mm);adj[c].set(ra,mm);}}
      adj[ra].delete(rb);adj[rb]=new Map();
      for(const [c,mm] of adj[ra])heap.push([mm.s/mm.c,ra,c]);}
    const minReg=opt.minRegion||0;
    if(minReg>0){
      for(let pass=0;pass<5;pass++){
        let changed=false;const roots=[];
        for(let a=1;a<=nm;a++)if(find(a)===a&&area[a]>0&&area[a]<minReg)roots.push(a);
        roots.sort((p,q)=>area[p]-area[q]);
        for(const r0 of roots){const rb=find(r0);if(rb!==r0||area[rb]>=minReg)continue;
          let ra=-1,bw=1e18;
          for(const [c,m] of adj[rb]){const wv=m.s/m.c;if(area[rb]+area[c]<=maxA*1.5&&wv<bw){bw=wv;ra=c;}}
          if(ra<0)continue;
          par[rb]=ra;area[ra]+=area[rb];mx[ra]+=mx[rb];my[ra]+=my[rb];mxx[ra]+=mxx[rb];myy[ra]+=myy[rb];mxy[ra]+=mxy[rb];
          for(const [c,mm] of adj[rb]){if(c===ra)continue;adj[c].delete(rb);const ex=adj[ra].get(c);
            if(ex){ex.s+=mm.s;ex.c+=mm.c;}else{adj[ra].set(c,mm);adj[c].set(ra,mm);}}
          adj[ra].delete(rb);adj[rb]=new Map();changed=true;}
        if(!changed)break;}
    }
    // collect: pass 1 stats only, pass 2 pixel lists only for kept regions (memory)
    const st=new Map();
    for(let i=0;i<N;i++){const l=lab[i];if(!l)continue;const r=find(l);let g=st.get(r);const x=i%w,y=(i/w)|0;
      if(!g){g={pixels:null,area:0,minx:1e9,maxx:-1,miny:1e9,maxy:-1};st.set(r,g);}
      g.area++;if(x<g.minx)g.minx=x;if(x>g.maxx)g.maxx=x;if(y<g.miny)g.miny=y;if(y>g.maxy)g.maxy=y;}
    const comps=[];
    for(const g of st.values()){if(g.area>=minArea&&g.maxx-g.minx>=4&&g.maxy-g.miny>=4){g.pixels=[];comps.push(g);}}
    for(let i=0;i<N;i++){const l=lab[i];if(!l)continue;const g=st.get(find(l));if(g.pixels){g.pixels.push([i%w,(i/w)|0]);}}
    return {comps,meta:{markers:nm,regions:st.size,kept:comps.length,skyPx:sk.count,medB,thr}};
  }
  const PSD_CONFIG_DEFAULTS = Object.freeze({ thresholdPct:62, minArea:100, maxArea:0, smoothRadius:1, edgeSensitivity:1, separationSensitivity:1, morphologyOpenPasses:1, morphologyClosePasses:1, maxObjectWidthPct:70, maxObjectHeightPct:70, minValidObjects:3, oversizeThresholdCm:80, rrMinSamples:8, rrMinDistinct:3, rrMinLogSpread:0.05, rrMinR2:0.9 });
  function normalizePSDConfig(raw={}){
    const n=(v,d,min,max)=>{ const x=Number(v); if(!Number.isFinite(x)) return d; return clamp(x,min,max); };
    return {
      thresholdPct:n(raw.thresholdPct,62,1,99), minArea:Math.round(n(raw.minArea,100,4,100000000)), maxArea:Math.round(n(raw.maxArea,0,0,100000000)),
      smoothRadius:Math.round(n(raw.smoothRadius,1,0,3)), edgeSensitivity:n(raw.edgeSensitivity,1,.1,3), separationSensitivity:n(raw.separationSensitivity,1,.1,3),
      morphologyOpenPasses:Math.round(n(raw.morphologyOpenPasses,1,0,5)), morphologyClosePasses:Math.round(n(raw.morphologyClosePasses,1,0,5)),
      maxObjectWidthPct:n(raw.maxObjectWidthPct,70,5,99), maxObjectHeightPct:n(raw.maxObjectHeightPct,70,5,99), minValidObjects:Math.round(n(raw.minValidObjects,3,1,100)),
      oversizeThresholdCm:n(raw.oversizeThresholdCm,80,.01,100000), rrMinSamples:Math.round(n(raw.rrMinSamples,8,2,500)), rrMinDistinct:Math.round(n(raw.rrMinDistinct,3,2,500)), rrMinLogSpread:n(raw.rrMinLogSpread,0.05,1e-6,5), rrMinR2:n(raw.rrMinR2,0.9,0,1)
    };
  }
  function getPSDConfig(){ APP_STATE.psdConfig=normalizePSDConfig(APP_STATE.psdConfig||PSD_CONFIG_DEFAULTS); return APP_STATE.psdConfig; }
  function psdOversizeThresholdCm(){ return getPSDConfig().oversizeThresholdCm; }
  function psdRrMinSamples(){ return getPSDConfig().rrMinSamples; }
  /* P0.1 unit-integrity helpers. x50/x80/oversize/RR in APP_STATE.psd are PHYSICAL (cm) ONLY and are null unless a valid scale exists.
     Pixel-only statistics live in x50Px/x80Px. Number(null)===0 must never be treated as a size. */
  function psdNum(v){ return (v===null||v===undefined||v===''||typeof v==='boolean')?NaN:Number(v); }
  function psdScaleCm(){ const s=APP_STATE.calibration&&APP_STATE.calibration.centimetersPerWorkingPixel; return (typeof s==='number'&&Number.isFinite(s)&&s>0)?s:null; }
  function psdPxOf(f){ if(f&&f.sizeOverride){ const sc=psdScaleCm(), v=psdOverrideCm(f); return (sc!==null&&v!==null)?v/sc:null; } return psdGeomPx(f); }
  function psdDefLabel(){ const d=APP_STATE.psd.sizeDefinition; return d==='eqdiam'?'Equivalent diameter':d==='bbox'?'Bounding-box max dimension':'Max Feret diameter'; }
  function psdPhys(){ const p=APP_STATE.psd; if(psdScaleCm()!==null) return p; return {...p,x50:null,x80:null,oversizeCount:null,oversizeFraction:null,xc:null,n:null,rrOversizeFraction:null,r2:null,fitStatus:'NOT AVAILABLE',physicalStatus:'NOT AVAILABLE - NOT CALIBRATED'}; }
  function psdUncalWithObjects(){ return psdScaleCm()===null && APP_STATE.fragments.length>0; }
  function isPSDOverSize(cm){ const x=psdNum(cm); return Number.isFinite(x)&&x>psdOversizeThresholdCm(); }
  function psdStatusFromSize(cm){ return Number.isFinite(psdNum(cm)) ? (isPSDOverSize(cm)?`BOULDER >${fmt(psdOversizeThresholdCm(),1)} CM`:'PASS') : 'NOT CALIBRATED'; }
  function syncPSDConfigControls(){
    const c=getPSDConfig();
    const map={thresholdPct:'cfgThresholdPct',minArea:'cfgMinArea',maxArea:'cfgMaxArea',smoothRadius:'cfgSmoothRadius',edgeSensitivity:'cfgEdgeSensitivity',separationSensitivity:'cfgSeparationSensitivity',morphologyOpenPasses:'cfgMorphOpen',morphologyClosePasses:'cfgMorphClose',maxObjectWidthPct:'cfgMaxWidthPct',maxObjectHeightPct:'cfgMaxHeightPct',minValidObjects:'cfgMinValidObjects',oversizeThresholdCm:'cfgOversizeCm',rrMinSamples:'cfgRrMinSamples',rrMinDistinct:'cfgRrMinDistinct',rrMinLogSpread:'cfgRrMinLogSpread',rrMinR2:'cfgRrMinR2'};
    Object.entries(map).forEach(([k,id])=>{ if($(id)) $(id).value=c[k]; });
    const main={thresholdPct:'thresholdPct',minArea:'minArea',maxArea:'maxArea',smoothRadius:'smoothRadius',edgeSensitivity:'edgeSensitivity',separationSensitivity:'separationSensitivity'};
    Object.entries(main).forEach(([k,id])=>{ if($(id)) $(id).value=c[k]; });
    if($('psdConfigOversizeSummary')) $('psdConfigOversizeSummary').textContent=`${fmt(c.oversizeThresholdCm,1)} cm`;
    if($('psdConfigRrSummary')) $('psdConfigRrSummary').textContent=`${c.rrMinSamples} samples`;
  }
  function openPSDConfig(){ syncPSDConfigControls(); $('psdConfigStatus').textContent='READY • REVIEW PARAMETERS'; $('psdConfigStatus').className='psd-config-status'; $('psdConfigModal').classList.add('is-open'); $('psdConfigModal').setAttribute('aria-hidden','false'); setTimeout(()=>$('cfgThresholdPct')?.focus(),20); }
  function closePSDConfig(){ $('psdConfigModal')?.classList.remove('is-open'); $('psdConfigModal')?.setAttribute('aria-hidden','true'); }
  function applyPSDConfigFromUI(source='USER ACTION'){
    const old=JSON.stringify(getPSDConfig());
    const values={};
    const map={thresholdPct:'cfgThresholdPct',minArea:'cfgMinArea',maxArea:'cfgMaxArea',smoothRadius:'cfgSmoothRadius',edgeSensitivity:'cfgEdgeSensitivity',separationSensitivity:'cfgSeparationSensitivity',morphologyOpenPasses:'cfgMorphOpen',morphologyClosePasses:'cfgMorphClose',maxObjectWidthPct:'cfgMaxWidthPct',maxObjectHeightPct:'cfgMaxHeightPct',minValidObjects:'cfgMinValidObjects',oversizeThresholdCm:'cfgOversizeCm',rrMinSamples:'cfgRrMinSamples',rrMinDistinct:'cfgRrMinDistinct',rrMinLogSpread:'cfgRrMinLogSpread',rrMinR2:'cfgRrMinR2'};
    Object.entries(map).forEach(([k,id])=>{ values[k]=$(id)?.value; });
    APP_STATE.psdConfig=normalizePSDConfig(values);
    syncPSDConfigControls();
    APP_STATE.psd.sizeDefinition=$('measurementDef')?.value||APP_STATE.psd.sizeDefinition||'feret';
    APP_STATE.image.mode=$('scanMode')?.value||APP_STATE.image.mode||'auto';
    APP_STATE.fragments=APP_STATE.fragments.map(f=>({...f,status:psdStatusFromSize(f.measuredSizeCm)}));
    recomputePSD(); renderFragments(); drawCanvas(); refreshAll(); persistWorking();
    audit('PSD CONFIG',old,JSON.stringify(APP_STATE.psdConfig),source,'PSD CONFIG UPDATE');
    $('psdConfigStatus').textContent='APPLIED • ENGINE UPDATED'; $('psdConfigStatus').className='psd-config-status is-ok';
  }
  function resetPSDConfig(){
    const old=JSON.stringify(getPSDConfig()); APP_STATE.psdConfig={...PSD_CONFIG_DEFAULTS}; syncPSDConfigControls(); recomputeFragmentMeasurements(); persistWorking(); audit('PSD CONFIG RESET',old,JSON.stringify(APP_STATE.psdConfig),'USER ACTION','RESET PSD CONFIG');
    $('psdConfigStatus').textContent='RESET TO DEFAULTS'; $('psdConfigStatus').className='psd-config-status is-warn';
  }

  /* ===== PHOTO WORKSPACE JS HELPERS ===== */
  function nextFrame(){return new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));}
  function selectedIdList(){
    const a=Array.isArray(APP_STATE.image?.selectedIds)?APP_STATE.image.selectedIds:[];
    if(APP_STATE.image?.selectedId!=null&&!a.includes(APP_STATE.image.selectedId)) a.push(APP_STATE.image.selectedId);
    return a.filter(id=>APP_STATE.fragments.some(f=>f.id===id));
  }
  function syncSelectionState(){
    const ids=selectedIdList();
    APP_STATE.image.selectedIds=ids;
    APP_STATE.image.selectedId=ids.length?ids[ids.length-1]:null;
    const f=APP_STATE.fragments.find(x=>x.id===APP_STATE.image.selectedId);
    const oid=$('selectedObjectId'); if(oid)oid.value=f?String(f.id):'';
    const label=$('selectedLabel'); if(label)label.textContent=ids.length?(ids.length===1?`Selected #${ids[0]} • ${f?.measuredSizeCm!=null?f.measuredSizeCm.toFixed(1)+' cm':'not calibrated'}`:`Selected ${ids.length} objects`):'No object selected';
    const count=$('selectionCount');if(count)count.textContent=String(ids.length);
    const del=$('btnDeleteSelected');if(del){del.disabled=!ids.length;del.textContent=`DELETE SELECTED (${ids.length})`;}
    const qs=$('quickActionStatus');if(qs)qs.textContent=APP_STATE.image.manualMode==='delete'?`DELETE MODE • klik batu untuk tambah/kurangi pilihan • ${ids.length} selected`:(ids.length?`${ids.length} object selected • Shift/Ctrl untuk multi-select`:'Klik batu untuk memilih • Shift/Ctrl = multi-select');
    $('manualQcPanel')?.classList.toggle('is-mode-delete',APP_STATE.image.manualMode==='delete');
    $('manualQcPanel')?.classList.toggle('is-mode-trace',APP_STATE.image.manualMode==='trace');
    $('btnDeleteMode')?.classList.toggle('is-active',APP_STATE.image.manualMode==='delete');
    $('btnDeleteMode')?.classList.toggle('btn--accent',APP_STATE.image.manualMode==='delete');
    $('btnTraceObject')?.classList.toggle('is-active',APP_STATE.image.manualMode==='trace');
    $('btnTraceObject')?.classList.toggle('btn--accent',APP_STATE.image.manualMode==='trace');
    const qt=$('btnQuickTrace');if(qt){qt.textContent=APP_STATE.image.manualMode==='trace'?'TRACE MULTI • ON':'TRACE MULTI';qt.classList.toggle('btn--accent',APP_STATE.image.manualMode==='trace');}
    const cv=$('muckpileCanvas');cv?.classList.toggle('kb-delete-active',APP_STATE.image.manualMode==='delete');try{roiSyncUi();}catch(_e){}
  }
  function hitFragmentAtPoint(pt){
    return APP_STATE.fragments.slice().reverse().filter(f=>{
      const poly=(Array.isArray(f.boundary)&&f.boundary.length>=3)?f.boundary:null;
      return poly?pointInPolygon(pt,poly):pt.x>=f.minx&&pt.x<=f.maxx&&pt.y>=f.miny&&pt.y<=f.maxy;
    }).sort((a,b)=>a.area-b.area)[0]||null;
  }
  function toggleSelectedFragment(id){
    let ids=selectedIdList();
    const i=ids.indexOf(id);
    if(i>=0)ids.splice(i,1);else ids.push(id);
    APP_STATE.image.selectedIds=ids;syncSelectionState();drawCanvas();
  }
  function selectSingleOrMulti(id,multi=false){
    if(id==null)return;
    const current=selectedIdList();
    APP_STATE.image.selectedIds=multi?(current.includes(id)?current.filter(x=>x!==id):[...current,id]):[id];
    syncSelectionState();drawCanvas();
  }
  function clearSelection(){APP_STATE.image.selectedIds=[];APP_STATE.image.selectedId=null;syncSelectionState();drawCanvas();}
  function toggleDeleteMode(){
    if(APP_STATE.image.manualMode==='delete'){APP_STATE.image.manualMode=null;syncSelectionState();drawCanvas();return;}
    cancelTrace();AT.pending=null;atPanel();
    APP_STATE.image.manualMode='delete';
    $('scanStatus').textContent='DELETE MODE aktif • klik beberapa batu untuk memilih • klik DELETE SELECTED setelah selesai.';
    $('canvasHint').textContent='DELETE MODE • klik batu untuk tambah/kurangi pilihan • Shift/Ctrl juga bisa untuk multi-select.';
    syncSelectionState();drawCanvas();
  }
  function deleteSelectedBatch(){
    const ids=selectedIdList();
    if(!ids.length){$('scanStatus').textContent='Pilih minimal satu object terlebih dahulu.';return;}
    const idSet=new Set(ids),old=APP_STATE.fragments.length;
    APP_STATE.fragments=APP_STATE.fragments.filter(f=>!idSet.has(f.id));
    audit(`Fragments ${ids.join(',')}`,old,APP_STATE.fragments.length,'MANUAL QC','REMOVE MULTIPLE OBJECTS');
    APP_STATE.image.selectedIds=[];APP_STATE.image.selectedId=null;
    $('scanStatus').textContent=`${ids.length} object dihapus • DELETE MODE tetap aktif untuk object berikutnya.`;
    $('canvasHint').textContent='DELETE MODE tetap aktif • klik batu lain untuk lanjut.';
    recomputePSD();renderFragments();syncSelectionState();drawCanvas();
  }
  function setScanBusy(on,stage='Preparing actual image...'){
    const wrap=document.querySelector('#view-image .kb-canvas-wrap');
    const ov=$('scanOverlay');
    if(wrap){wrap.classList.toggle('is-scanning',!!on);wrap.classList.toggle('is-trace-ready',!on && APP_STATE.image.manualMode==='trace');}
    if(ov){
      ov.classList.toggle('is-visible',!!on);
      ov.classList.remove('is-complete');
      ov.setAttribute('aria-hidden',String(!on));
    }
    ['btnScanMuckpile','btnRescan','btnQuickScan','btnQuickRescan','btnApplyMvpPsd','btnMvpRescan','btnScanTraceRock','btnScanAutoTraceRock'].forEach(id=>{const e=$(id);if(e)e.disabled=!!on;});
    if(on){
      const os=$('scanOverlayStage');if(os)os.textContent=stage;
      const op=$('scanOverlayPct');if(op)op.textContent='0%';
      const ob=$('scanOverlayBar');if(ob)ob.style.width='0%';
      const title=$('scanOverlayTitle');if(title)title.textContent='SCANNING ACTUAL PHOTO';
      const center=$('scanOverlayCenterLabel');if(center)center.textContent='ANALYZING ROCK FRAGMENTS';
      const eta=$('scanOverlayEta');if(eta)eta.textContent='PLEASE WAIT';
    }
  }

  async function showScanComplete(){
    const ov=$('scanOverlay');
    if(!ov)return;
    const wrap=document.querySelector('#view-image .kb-canvas-wrap');
    ov.classList.add('is-visible','is-complete');
    ov.setAttribute('aria-hidden','false');
    const title=$('scanOverlayTitle');if(title)title.textContent='SCAN COMPLETE';
    const center=$('scanOverlayCenterLabel');if(center)center.textContent=`${APP_STATE.fragments.length} ROCK OBJECTS READY • TRACE NOW`;
    const pct=$('scanOverlayPct');if(pct)pct.textContent='100%';
    const stage=$('scanOverlayStage');if(stage)stage.textContent='Rock segmentation finished • manual tracing is ready';
    const eta=$('scanOverlayEta');if(eta)eta.textContent='READY';
    if(wrap)wrap.classList.add('is-trace-ready');
    await new Promise(resolve=>setTimeout(resolve,900));
  }

  async function scanActualPhoto(){
    if(!APP_STATE.image.workingCanvas){ $('scanStatus').textContent='SCAN FAILED: no actual image. Upload JPG/JPEG/PNG/WEBP.'; return; }
    if(APP_STATE.image.manualMode==='trace'||APP_STATE.image.manualMode==='delete')cancelTrace();
    try{roiLeaveForScan();}catch(_e){}
    setScanBusy(true,'Preparing actual image...');
    try{
      APP_STATE.image.mode=$('scanMode').value; APP_STATE.psd.sizeDefinition=$('measurementDef').value;
      ensureLabWorking(); if(!APP_STATE.image.workingCanvas){$('scanStatus').textContent='SCAN FAILED: actual image belum siap.';return;}
      const src=APP_STATE.image.workingCanvas;
      const w=src.width,h=src.height;
      const maxSide=1600,scaleWork=Math.min(1,maxSide/Math.max(w,h));
      const wc=document.createElement('canvas');
      wc.width=Math.max(1,Math.round(w*scaleWork)); wc.height=Math.max(1,Math.round(h*scaleWork));
      wc.getContext('2d').drawImage(src,0,0,wc.width,wc.height);
      APP_STATE.image.workingCanvas=wc; APP_STATE.image.metadata.workingWidth=wc.width; APP_STATE.image.metadata.workingHeight=wc.height;
      /* ROI poligon: koordinatnya milik working canvas; bila canvas di-resample (tidak terjadi untuk foto <=1600 px) poligon ikut diskalakan */
      if(Array.isArray(APP_STATE.image.roiPolygons)&&APP_STATE.image.roiPolygons.length&&(wc.width!==w||wc.height!==h)){const rx=wc.width/w,ry=wc.height/h;APP_STATE.image.roiPolygons=APP_STATE.image.roiPolygons.map(p=>p.map(q=>[q[0]*rx,q[1]*ry]));}
      const roiInfo=roiGetMask();
      if(roiInfo&&roiInfo.count===0){
        $('scanStatus').textContent='SCAN DIBATALKAN: ROI poligon tidak mencakup piksel foto (luas 0%). Gambar ulang ROI atau klik HAPUS ROI.';
        if($('mvpPsdStatus'))$('mvpPsdStatus').textContent='ROI KOSONG • luas 0.0% foto • scan tidak dijalankan';
        setProgress(100,'SCAN FAILED'); return;
      }

      setProgress(4,'PREPARING ACTUAL IMAGE'); await nextFrame();
      const cfg=getPSDConfig();
      const radius=clamp(Math.round(Number(cfg.smoothRadius)||1),0,3);
      setProgress(8,'NORMALIZING IMAGE'); await nextFrame();
      const g=grayscaleAndBlur(wc,radius);
      setProgress(14,'GRAYSCALE + MULTI-SCALE GRADIENT'); await nextFrame();
      const grad=gradientMagnitude(g);
      setProgress(28,'BUILDING EDGE / REGION MAP'); await nextFrame();

      const mode=APP_STATE.image.mode;
      const minA=Math.max(20,Math.round(Number(cfg.minArea)||100));
      setProgress(40,'SEGMENTING ROCK REGIONS'); await nextFrame();
      const engine=($('mvpEngine')&&$('mvpEngine').value)||'v5';
      let best;
      if(engine==='legacy'){ best=segmentFragments(g,grad,cfg,mode); }
      else{
        const px=wc.getContext('2d').getImageData(0,0,wc.width,wc.height).data;
        const sepV=Number($('mvpWatershed')?.value||31), edgV=Number($('mvpEdgeSensitivity')?.value||27);
        const roiT=clamp(Number($('mvpRoiTop')?.value||0),0,95)/100, roiB=clamp(Number($('mvpRoiBottom')?.value||100),5,100)/100;
        const v5opt={minArea:Math.max(150,minA),mergeTau:clamp(1.15-(sepV-31)*0.02,0.7,1.6),valleyWeight:clamp(1.5*edgV/27,0.5,3),roiTop:roiT,roiBottom:roiB,baseSigma:clamp(Number($('mvpBaseSigma')?.value||2.5),0.8,6),flatFrac:clamp(Number($('mvpFlatFrac')?.value??0.5),0,1)};
        if(roiInfo)v5opt.roiMask=roiInfo.mask;   // ROI poligon menggantikan pita atas/bawah
        const r5=segmentRocksV5(px,wc.width,wc.height,v5opt);
        best={comps:r5.comps,dropped:{background:0,maxArea:0},splitCount:0,recoveredCount:0,polarity:'V5',v5:r5.meta};
        audit('Segmentation engine','legacy','V5','AUTO SCAN','V5 '+JSON.stringify(r5.meta));
      }
      /* ROI: objek yang titik pusatnya di luar ROI tidak boleh masuk dataset (berlaku untuk V5 dan LEGACY) */
      let roiDropped=0;
      if(roiInfo){const n0=best.comps.length;best.comps=roiFilterByCenter(best.comps,roiInfo.mask,roiInfo.w,roiInfo.h);roiDropped=n0-best.comps.length;}
      const roiTxt=roiInfo?` • ROI POLIGON ${roiInfo.polys} • luas ${(roiInfo.frac*100).toFixed(1)}% foto${roiDropped?` • ${roiDropped} objek berpusat di luar ROI dibuang`:''}`:'';
      setProgress(57,'LARGE-FRAGMENT RECOVERY + WATERSHED-LIKE SPLIT'); await nextFrame();

      if(!best.comps.length){
        APP_STATE.fragments=[]; recomputePSD(); renderFragments(); drawCanvas(); setProgress(100,'SCAN FAILED');
        $('scanStage').textContent='SCAN FAILED';
        $('scanStatus').textContent='SCAN FAILED: no fragment regions. Turunkan Min Area / Threshold atau ubah polarity.'+(roiInfo?` ROI poligon aktif (luas ${(roiInfo.frac*100).toFixed(1)}% foto, ${roiDropped} objek berpusat di luar ROI dibuang): perbesar ROI atau klik HAPUS ROI.`:'');
        $('scanModelStatus').textContent='SCAN FAILED'; refreshAll(); return;
      }

      setProgress(70,'MEASURING FRAGMENT GEOMETRY'); await nextFrame();
      const fragments=best.comps.map((c,i)=>{const m=measureComp(c,i+1); try{m.outline=rkTraceOutline(c);}catch(_e){m.outline=null;} m.review=!!c.review; m.reviewReason=c.reviewReason||''; if(m.review)m.confidence=Math.min(m.confidence,0.5); return m;});
      const valid=fragments.filter(f=>{
        const bw=f.maxx-f.minx+1,bh=f.maxy-f.miny+1;
        if(f.area<minA) return false;
        if(f.aspect>12 && f.area<minA*15) return false;
        return bw>=5&&bh>=5;
      });

      valid.sort((a,b)=>b.area-a.area);
      APP_STATE.fragments=valid.map((f,i)=>({...f,id:i+1}));
      APP_STATE.image.selectedIds=[];APP_STATE.image.selectedId=null;
      setProgress(84,'CALCULATING PHYSICAL SIZE + PSD'); await nextFrame();
      recomputePSD();
      renderFragments();
      drawCanvas();
      renderMvpPsdChart();
      renderMvpMetrics();
      setProgress(100,'COMPLETE');
      $('scanStage').textContent='COMPLETE';
      await showScanComplete();
      $('scanStatus').textContent=`Scan selesai • ${APP_STATE.fragments.length} fragment valid (${APP_STATE.fragments.filter(f=>f.review).length} REVIEW) • ${best.splitCount||0} large region split • ${best.dropped.background} background-suspect & ${best.dropped.maxArea} >maxArea excluded • ${best.recoveredCount||0} recovered • engine ${engine==='legacy'?'LEGACY THRESHOLD':'V5 EDGE-WATERSHED'}${roiTxt}`;
      $('scanModelStatus').textContent='COMPUTER VISION SCREENING';
      if($('mvpPsdStatus')) $('mvpPsdStatus').textContent=`ENGINE: ${engine==='legacy'?'LEGACY THRESHOLD':'V5 EDGE/VALLEY WATERSHED + REGION MERGE'} • ${APP_STATE.fragments.length} valid objects • ${best.splitCount||0} split • ${best.recoveredCount||0} recovered${roiTxt}`;
      if(roiInfo)audit('ROI scan',0,`${roiInfo.polys} poligon • ${(roiInfo.frac*100).toFixed(1)}% foto • ${roiDropped} dibuang`,'AUTO SCAN','ROI POLYGON APPLIED');
      audit('Fragment dataset',0,APP_STATE.fragments.length,'MEASURED IMAGE','SCAN MULTI-SCALE');
      refreshAll(); syncSelectionState();
    }catch(err){
      console.error(err);
      const hasDataset=Array.isArray(APP_STATE.fragments)&&APP_STATE.fragments.length>0;
      $('scanStage').textContent=hasDataset?'COMPLETE WITH UI WARNING':'SCAN ERROR';
      $('scanStatus').textContent=hasDataset
        ? `PSD dataset ${APP_STATE.fragments.length} fragment tetap dipertahankan • UI warning: ${err?.message||String(err)}`
        : 'SCAN ERROR: '+(err?.message||String(err));
      $('scanModelStatus').textContent=hasDataset?'COMPUTER VISION SCREENING':'SCAN ERROR';
      setProgress(100,hasDataset?'COMPLETE WITH UI WARNING':'SCAN ERROR');
      try{ renderMvpMetrics(); renderFragments(); drawCanvas(); refreshAll(); syncSelectionState(); }catch(_e){}
    }finally{
      setScanBusy(false);
    }
  }
  
  function setProgress(pct,stage){
    const n=clamp(Number(pct)||0,0,100);
    const p=Math.round(n);
    $('scanProgressBar').style.width=p+'%';$('scanProgressPct').textContent=p+'%';$('scanStage').textContent=stage;
    const ob=$('scanOverlayBar');if(ob)ob.style.width=p+'%';
    const op=$('scanOverlayPct');if(op)op.textContent=p+'%';
    const os=$('scanOverlayStage');if(os)os.textContent=stage;
    const wrap=document.querySelector('#view-image .kb-canvas-wrap');
    if(wrap && p>=100 && !APP_STATE.image.manualMode)wrap.classList.add('is-trace-ready');
  }
  function recomputeFragmentMeasurements(){ recomputePSD(); drawCanvas(); renderFragments(); refreshAll(); }
  function recomputePSD(){
    /* Single source of truth = measured geometry px (selected size definition) x VALIDATED scale, or an explicit manual cm override with provenance.
       measuredSizeCm is a derived cache rebuilt here. P0.2: estimate objects (merge hull / split of a hull) are excluded from final PSD statistics until
       review-approved; invalid-size and uncalibrated objects are excluded too. X50/X80 use HF7 linear quantiles (see PSD_QUANTILE_METHOD). */
    const cfg=getPSDConfig(), P=APP_STATE.psd, sc=psdScaleCm(), asc=(a,b)=>a-b;
    APP_STATE.fragments.forEach(f=>{ const m=psdMeasuredCm(f,sc); f.measuredSizeCm=m; f.status=m!==null?psdStatusFromSize(m):(sc===null?'NOT CALIBRATED':'INVALID SIZE'); f.psdInclusion=psdInclusionOf(f,sc,m); });
    const inc=APP_STATE.fragments.filter(f=>f.psdInclusion==='INCLUDED');
    const s=inc.map(f=>f.measuredSizeCm).sort(asc);
    const ps=APP_STATE.fragments.filter(f=>!psdEstimatePending(f)).map(psdPxOf).filter(x=>x!==null).sort(asc);
    P.x50=null;P.x80=null;P.oversizeCount=null;P.oversizeFraction=null;P.xc=null;P.n=null;P.rrOversizeFraction=null;P.r2=null;P.fitStatus='INSUFFICIENT SAMPLE';
    P.quantileMethod=PSD_QUANTILE_METHOD; P.rrCriteria=rrCriteriaFromConfig(); P.rrReason=sc===null?'NOT CALIBRATED':(s.length?'':'NO VALID OBJECTS');
    P.x50Px=ps.length?psdQuantile(ps,.5):null; P.x80Px=ps.length?psdQuantile(ps,.8):null; P.pixelSampleCount=ps.length; P.sampleCount=s.length; P.calibrationCmPerPx=sc;
    P.includedCount=inc.length; P.excludedEstimateCount=APP_STATE.fragments.filter(f=>f.psdInclusion==='EXCLUDED - ESTIMATE PENDING REVIEW').length;
    P.physicalStatus=sc===null?'NOT AVAILABLE - NOT CALIBRATED':(s.length?'AVAILABLE':'NOT AVAILABLE - NO VALID OBJECTS');
    if(sc!==null && s.length){
      P.x50=psdQuantile(s,.5); P.x80=psdQuantile(s,.8); P.oversizeCount=s.filter(x=>x>cfg.oversizeThresholdCm).length; P.oversizeFraction=P.oversizeCount/s.length;
      const fit=fitRR(s,P.rrCriteria); P.fitStatus=fit.status; P.rrReason=fit.reason; P.rrDistinctCount=fit.distinctCount; P.rrLogSpread=fit.logSpread;
      if(fit.status==='FIT AVAILABLE'||fit.status==='FIT POOR'){ P.xc=fit.xc; P.n=fit.n; P.r2=fit.r2; }
      P.rrOversizeFraction=rrOversizeFraction(fit,cfg.oversizeThresholdCm);
    }
    /* Area-weighted (WipFrag-style) cumulative distribution: each fragment counts by its AREA, not as one. Count-based X50 is dominated by
       the many tiny fragments and is NOT comparable to WipFrag, whose % passing is surface/volume weighted. Kept additional to the count-based values. */
    const awq=(items,p)=>{ const a=items.filter(o=>Number.isFinite(o.x)&&o.x>0&&Number.isFinite(o.w)&&o.w>0).sort((u,v)=>u.x-v.x); if(!a.length)return null; const tot=a.reduce((t,o)=>t+o.w,0); let c=0; for(const o of a){c+=o.w; if(c/tot>=p)return o.x;} return a[a.length-1].x; };
    const pxItems=APP_STATE.fragments.filter(f=>!psdEstimatePending(f)).map(f=>({x:psdPxOf(f),w:f.area}));
    P.x50AreaPx=awq(pxItems,.5); P.x80AreaPx=awq(pxItems,.8); P.x50Area=null; P.x80Area=null;
    if(sc!==null&&inc.length){ const cmItems=inc.map(f=>({x:f.measuredSizeCm,w:f.area})); P.x50Area=awq(cmItems,.5); P.x80Area=awq(cmItems,.8); }
    psdRefreshThresholdLabels();
  }
  /* ======================= P0.2 QC FIX : statistics + geometry + export core =======================
     QUANTILE METHOD (X50/X80, cm and px): Hyndman & Fan (1996) type 7 = linear interpolation between order statistics:
       h=(N-1)p ; Q = x[floor(h)] + (h-floor(h))*(x[floor(h)+1]-x[floor(h)])  (== numpy.percentile 'linear' == Excel PERCENTILE.INC).
       Baseline P0 used x[floor(p(N-1))] (no interpolation, biased low). The legacy rule is kept ONLY as psdQuantileLegacyFloor()
       so the impact of the change can be reported; it is never used for results.
     ROSIN-RAMMLER: F(x)=1-exp(-(x/Xc)^n). Linearised: y=ln(-ln(1-p)) = n*ln(x) - n*ln(Xc).
       Plotting position p_i=(i+0.5)/N (Hazen; unchanged from baseline), sizes sorted ascending, OLS of y on x=ln(size).
       Xc=exp(-intercept/n). R2 = 1-SSE/SST on the linearised (log-log) data. The slope is NEVER coerced.
     STATUS CRITERIA (project configuration in APP_STATE.psdConfig; the defaults are starting values, NOT universal acceptance limits):
       INSUFFICIENT SAMPLE : valid sample count N < rrMinSamples (default 8, same as baseline).
       FIT FAILED          : any invalid input (non-number, NaN, +-Infinity, <=0); distinct sizes < rrMinDistinct (default 3);
                             SD of ln(size) < rrMinLogSpread (default 0.05, i.e. ~5 % geometric spread; hard floor 1e-6) = identical /
                             near-identical data; non-finite regression; slope <= 0; non-finite Xc or R2.
       FIT POOR            : regression is valid but R2 < rrMinR2 (default 0.90, a project choice that should be calibrated against
                             reference data). Xc/n/R2 are kept as DIAGNOSTIC values only; no predicted oversize fraction is produced.
       FIT AVAILABLE       : none of the above. Only this status may feed Xc, n, R2 and the predicted oversize fraction downstream. */
  const PSD_QUANTILE_METHOD='HF7_LINEAR';
  function psdQuantile(sorted,p){ const n=sorted.length; if(!n) return null; if(n===1) return sorted[0]; const h=(n-1)*p, lo=Math.floor(h), hi=Math.min(n-1,lo+1); return sorted[lo]+(h-lo)*(sorted[hi]-sorted[lo]); }
  function psdQuantileLegacyFloor(sorted,p){ return sorted.length?sorted[Math.floor(p*(sorted.length-1))]:null; }
  function rrCriteriaFromConfig(){ const c=getPSDConfig(); return {minSamples:c.rrMinSamples,minDistinct:c.rrMinDistinct,minLogSpread:c.rrMinLogSpread,minR2:c.rrMinR2}; }
  function rrJudgeRegression(reg,crit){
    const bad=(status,reason)=>({status,reason,ok:false,xc:null,n:null,r2:null});
    if(!reg||![reg.slope,reg.intercept,reg.r2].every(v=>Number.isFinite(v))) return bad('FIT FAILED','NON-FINITE REGRESSION (slope, intercept or R2 is NaN/Infinity)');
    if(!(reg.slope>0)) return bad('FIT FAILED','NON-POSITIVE SLOPE n='+reg.slope+' (never coerced)');
    const xc=Math.exp(-reg.intercept/reg.slope); if(!(Number.isFinite(xc)&&xc>0)) return bad('FIT FAILED','NON-FINITE Xc');
    if(reg.r2<crit.minR2) return {status:'FIT POOR',reason:'R2='+reg.r2.toFixed(4)+' < minimum '+crit.minR2+' (diagnostic only)',ok:false,xc,n:reg.slope,r2:reg.r2};
    return {status:'FIT AVAILABLE',reason:'R2='+reg.r2.toFixed(4)+' >= minimum '+crit.minR2,ok:true,xc,n:reg.slope,r2:reg.r2};
  }
  function fitRR(sizes,critOverride){
    const crit=Object.assign(rrCriteriaFromConfig(),critOverride||{});
    const out={status:'FIT FAILED',reason:'',ok:false,xc:null,n:null,r2:null,sampleCount:0,invalidCount:0,distinctCount:0,logSpread:null,criteria:crit};
    if(!Array.isArray(sizes)){out.reason='INPUT IS NOT AN ARRAY';return out;}
    out.sampleCount=sizes.length;
    const invalid=sizes.filter(v=>!(typeof v==='number'&&Number.isFinite(v)&&v>0)).length; out.invalidCount=invalid;
    if(invalid>0){out.reason='INVALID VALUES: '+invalid+' of '+sizes.length+' are not finite numbers > 0';return out;}
    const s=sizes.slice().sort((a,b)=>a-b), N=s.length;
    if(N<crit.minSamples){out.status='INSUFFICIENT SAMPLE';out.reason='N='+N+' < minimum '+crit.minSamples;return out;}
    out.distinctCount=new Set(s).size;
    const x=s.map(Math.log), xm=x.reduce((a,b)=>a+b,0)/N, sd=Math.sqrt(x.reduce((a,b)=>a+(b-xm)*(b-xm),0)/N); out.logSpread=sd;
    if(out.distinctCount<crit.minDistinct){out.reason='DEGENERATE DATA: '+out.distinctCount+' distinct size value(s) < minimum '+crit.minDistinct;return out;}
    const spreadMin=Math.max(crit.minLogSpread,1e-6);
    if(!(sd>=spreadMin)){out.reason='DEGENERATE DATA: SD(ln size)='+sd.toPrecision(3)+' < minimum '+spreadMin;return out;}
    const y=s.map((_,i)=>Math.log(-Math.log(1-(i+0.5)/N))), ym=y.reduce((a,b)=>a+b,0)/N;
    let sxx=0,sxy=0; for(let i=0;i<N;i++){sxx+=(x[i]-xm)*(x[i]-xm);sxy+=(x[i]-xm)*(y[i]-ym);}
    const slope=sxx>0?sxy/sxx:NaN, intercept=ym-slope*xm; let sse=0,sst=0;
    for(let i=0;i<N;i++){const e=y[i]-(intercept+slope*x[i]);sse+=e*e;sst+=(y[i]-ym)*(y[i]-ym);}
    const r2=sst>0?1-sse/sst:NaN;
    return Object.assign(out,rrJudgeRegression({slope,intercept,r2},crit));
  }
  function rrOversizeFraction(fit,thr){ if(!fit||fit.status!=='FIT AVAILABLE') return null; const v=Math.exp(-Math.pow(thr/fit.xc,fit.n)); return Number.isFinite(v)?v:null; }
  function psdRrStatusText(p){ const st=p.fitStatus||'INSUFFICIENT SAMPLE'; if(st==='FIT POOR'&&p.xc!=null) return 'FIT POOR \u2022 diagnostic only: Xc '+p.xc.toFixed(2)+' cm \u2022 n '+p.n.toFixed(3)+' \u2022 R\u00B2 '+p.r2.toFixed(3)+(p.rrReason?' \u2022 '+p.rrReason:''); return st+(p.rrReason?' \u2022 '+p.rrReason:''); }
  function psdRrFracLabel(p,na){ if(p.rrOversizeFraction!=null) return (p.rrOversizeFraction*100).toFixed(2)+'%'; return (psdScaleCm()!==null&&p.sampleCount>0)?(p.fitStatus||na):na; }
  function psdR2Label(p,na){ if(p.r2!=null) return p.r2.toFixed(3)+(p.fitStatus==='FIT AVAILABLE'?'':' ('+p.fitStatus+')'); return (psdScaleCm()!==null&&p.sampleCount>0)?(p.fitStatus||na):na; }

  /* ---- measurement provenance helpers (override / estimate / inclusion) ---- */
  function psdGeomPx(f){ const d=APP_STATE.psd.sizeDefinition; const x=psdNum(d==='feret'?f.feretPx:d==='eqdiam'?f.eqDiameterPx:f.bboxMaxPx); return (Number.isFinite(x)&&x>0)?x:null; }
  function psdOverrideCm(f){ if(!f||!f.sizeOverride) return null; const v=psdNum(f.sizeOverride.valueCm); return (Number.isFinite(v)&&v>0)?v:null; }
  function psdMeasuredCm(f,sc){ if(sc===null) return null; if(f.sizeOverride) return psdOverrideCm(f); const px=psdGeomPx(f), m=px!==null?px*sc:null; return (m!==null&&Number.isFinite(m)&&m>0)?m:null; }
  function psdEstimatePending(f){ return !!f&&f.estimate===true&&f.reviewApproved!==true; }
  function psdInclusionOf(f,sc,m){
    if(psdEstimatePending(f)) return 'EXCLUDED - ESTIMATE PENDING REVIEW';
    const geomOk=f.sizeOverride?psdOverrideCm(f)!==null:psdGeomPx(f)!==null;
    if(!geomOk) return 'EXCLUDED - INVALID SIZE';
    if(sc===null) return 'EXCLUDED - NOT CALIBRATED';
    return (m!==null&&Number.isFinite(m)&&m>0)?'INCLUDED':'EXCLUDED - INVALID SIZE';
  }
  function psdThrStr(){ return String(+psdOversizeThresholdCm().toFixed(6)); }
  function psdThrTag(){ return 'GT'+psdThrStr().replace('.','_'); }
  function psdRefreshThresholdLabels(){ const T=psdThrStr(); [['actualBoulderCount','Actual >'+T+' cm'],['rrOversize','RR estimated fraction >'+T],['boulder80','>'+T+' cm']].forEach(([id,txt])=>{ const b=$(id), s=b&&b.previousElementSibling; if(s&&s.tagName==='SPAN') s.textContent=txt; }); }

  /* ---- polygon geometry: every metric of a child/merged/edited object is derived from ITS OWN contour ---- */
  function polyAreaXY(poly){ return polygonArea(poly.map(p=>({x:p[0],y:p[1]}))); }
  function measurePolygon(poly){
    const pts=poly.map(p=>({x:p[0],y:p[1]})), area=polygonArea(pts), b=bboxFromPoints(pts), feret=maxFeretFromXY(poly), ed=eqDiam({area}), bb=Math.max(b.maxx-b.minx,b.maxy-b.miny), hull=convexHull(poly), hullArea=hull.length>=3?polygonArea(hull.map(p=>({x:p[0],y:p[1]}))):area;
    return {area,minx:b.minx,maxx:b.maxx,miny:b.miny,maxy:b.maxy,eqDiameterPx:ed,feretPx:feret,bboxMaxPx:bb,
      circularity:(4*Math.PI*area)/Math.max(1,(feret*Math.PI)**2),
      aspect:Math.max((b.maxx-b.minx+1)/(b.maxy-b.miny+1),(b.maxy-b.miny+1)/(b.maxx-b.minx+1)),
      solidity:Math.min(1,area/Math.max(1,hullArea)),hullAreaPx:hullArea};
  }
  function fragPolygon(f){
    const b=Array.isArray(f&&f.boundary)?f.boundary:[];
    if(f&&f.exactPolygon&&b.length>=3) return {poly:b.map(p=>[p[0],p[1]]),basis:(f.geometryBasis&&f.geometryBasis!=='HULL_ESTIMATE'&&f.geometryBasis!=='NONE')?f.geometryBasis:'EXACT_POLYGON'};
    const h=convexHull(b); if(h.length>=3) return {poly:h.map(p=>[p[0],p[1]]),basis:'HULL_ESTIMATE'};
    return {poly:null,basis:'NONE'};
  }
  function validateFragmentGeometry(f){
    const poly=Array.isArray(f&&f.boundary)?f.boundary:[]; if(poly.length<3) return {ok:false,errors:['NO CONTOUR'],derived:null};
    const m=measurePolygon(poly), errs=[], near=(x,y)=>Number.isFinite(x)&&Math.abs(x-y)<=1e-6*Math.max(1,Math.abs(y));
    ['area','minx','maxx','miny','maxy','eqDiameterPx','feretPx','bboxMaxPx'].forEach(k=>{ if(!near(f[k],m[k])) errs.push(k+': stored '+f[k]+' vs contour '+m[k]); });
    return {ok:errs.length===0,errors:errs,derived:m};
  }
  function splitPolygonByLine(poly,a,b){
    const fail=reason=>({ok:false,reason});
    if(!Array.isArray(poly)||poly.length<3) return fail('PARENT CONTOUR HAS < 3 VERTICES');
    if(![a&&a[0],a&&a[1],b&&b[0],b&&b[1]].every(v=>Number.isFinite(v))) return fail('SPLIT LINE IS NOT FINITE');
    const dx=b[0]-a[0], dy=b[1]-a[1], len=Math.hypot(dx,dy); if(!(len>1e-6)) return fail('SPLIT LINE IS DEGENERATE (zero length)');
    const EPS=1e-9*Math.max(1,len), dist=p=>(dx*(p[1]-a[1])-dy*(p[0]-a[0]))/len, d=poly.map(dist), cls=d.map(v=>v<-EPS?-1:1), n=poly.length;
    const A=[],B=[],cuts=[];
    for(let i=0;i<n;i++){ const j=(i+1)%n; (cls[i]>0?A:B).push(poly[i].slice());
      if(cls[i]!==cls[j]){ const t=d[i]/(d[i]-d[j]), I=[poly[i][0]+t*(poly[j][0]-poly[i][0]),poly[i][1]+t*(poly[j][1]-poly[i][1])]; A.push(I.slice()); B.push(I.slice()); cuts.push(I); } }
    if(cuts.length===0) return fail('SPLIT LINE DOES NOT INTERSECT THE OBJECT');
    if(cuts.length!==2) return fail('SPLIT LINE CROSSES THE CONTOUR '+cuts.length+' TIMES; a split must give exactly 2 parts');
    const tp=I=>((I[0]-a[0])*dx+(I[1]-a[1])*dy)/(len*len);
    if(cuts.some(I=>tp(I)<-1e-9||tp(I)>1+1e-9)) return fail('SPLIT LINE SEGMENT DOES NOT FULLY CROSS THE OBJECT (extend it past both edges)');
    const clean=P=>{ const o=[]; P.forEach(p=>{ const q=o[o.length-1]; if(!q||Math.hypot(p[0]-q[0],p[1]-q[1])>1e-9) o.push(p); }); if(o.length>1&&Math.hypot(o[0][0]-o[o.length-1][0],o[0][1]-o[o.length-1][1])<=1e-9) o.pop(); return o; };
    const pa=clean(A), pb=clean(B); if(pa.length<3||pb.length<3) return fail('SPLIT PRODUCED A DEGENERATE PART (< 3 distinct vertices)');
    const aa=polyAreaXY(pa), ab=polyAreaXY(pb), ap=polyAreaXY(poly);
    if(!(aa>0&&ab>0)) return fail('SPLIT PRODUCED A ZERO-AREA PART');
    if(Math.abs(aa+ab-ap)>1e-6*Math.max(1,ap)) return fail('AREA NOT CONSERVED: '+aa+' + '+ab+' != '+ap);
    return {ok:true,pieces:[pa,pb],cuts,areas:[aa,ab],parentAreaPx:ap};
  }
  function fragNextId(){ return APP_STATE.fragments.reduce((m,x)=>Math.max(m,Number(x.id)||0),0)+1; }
  function fragLineage(){ if(!Array.isArray(APP_STATE.fragmentLineage)) APP_STATE.fragmentLineage=[]; return APP_STATE.fragmentLineage; }
  function applySplit(id,a,b){
    const F=APP_STATE.fragments, f=F.find(x=>x.id===id);
    if(!f) return {ok:false,reason:'NO SELECTED OBJECT; nothing changed'};
    const g=fragPolygon(f); if(!g.poly) return {ok:false,reason:'OBJECT HAS NO CONTOUR GEOMETRY; split cancelled, parent kept'};
    const r=splitPolygonByLine(g.poly,a,b); if(!r.ok) return {ok:false,reason:r.reason+'; split cancelled, parent kept'};
    const minA=Math.max(8,Number(getPSDConfig().minArea)||100);
    if(r.areas.some(x=>x<minA)) return {ok:false,reason:'A CHILD AREA ('+r.areas.map(x=>x.toFixed(1)).join(' / ')+' px) IS BELOW MIN AREA '+minA+' px; split cancelled, parent kept'};
    const est=g.basis==='HULL_ESTIMATE'||f.estimate===true, id1=fragNextId(), stamp=now();
    const mk=(poly,cid)=>Object.assign({id:cid},measurePolygon(poly),{boundary:poly.map(p=>[p[0],p[1]]),exactPolygon:!est,measuredSizeCm:null,confidence:f.confidence,status:'NOT CALIBRATED',manual:true,
      review:true,reviewStatus:'PENDING',reviewReason:est?'SPLIT ESTIMATE (parent contour = convex hull)':'SPLIT BY USER LINE',
      source:'SPLIT',operation:'SPLIT',parentIDs:[f.id],geometryBasis:est?'HULL_ESTIMATE':g.basis,estimate:est,splitLine:{x1:a[0],y1:a[1],x2:b[0],y2:b[1]},createdAt:stamp});
    const kids=[mk(r.pieces[0],id1),mk(r.pieces[1],id1+1)];
    const bad=kids.map(validateFragmentGeometry).find(v=>!v.ok); if(bad) return {ok:false,reason:'CHILD GEOMETRY INCONSISTENT: '+bad.errors.join('; ')+'; split cancelled, parent kept'};
    APP_STATE.fragments=F.filter(x=>x.id!==id).concat(kids);
    fragLineage().push({op:'SPLIT',timestamp:stamp,parentId:id,childIds:kids.map(k=>k.id),line:kids[0].splitLine,parentBasis:g.basis,parentSnapshot:{id:f.id,area:f.area,boundary:(f.boundary||[]).map(p=>[p[0],p[1]]),measuredSizeCm:f.measuredSizeCm}});
    APP_STATE.image.selectedId=kids[0].id; APP_STATE.image.selectedIds=[kids[0].id];
    audit('Fragment '+id,'1 object','2 objects ('+kids.map(k=>k.id).join(',')+')','MANUAL QC','SPLIT OBJECT by user line; basis='+kids[0].geometryBasis);
    return {ok:true,children:kids,parentId:id,cuts:r.cuts};
  }
  function mergeFragmentsEstimate(src,tgt){
    const A=fragPolygon(src), B=fragPolygon(tgt); if(!A.poly||!B.poly) return {ok:false,reason:'ONE OBJECT HAS NO CONTOUR GEOMETRY; merge cancelled'};
    const hull=convexHull([...A.poly,...B.poly]); if(!Array.isArray(hull)||hull.length<3) return {ok:false,reason:'MERGED HULL IS DEGENERATE; merge cancelled'};
    const m=measurePolygon(hull), sum=polyAreaXY(A.poly)+polyAreaXY(B.poly);
    return {ok:true,fragment:Object.assign({id:fragNextId()},m,{boundary:hull.map(p=>[p[0],p[1]]),exactPolygon:false,measuredSizeCm:null,confidence:Math.min(Number(src.confidence)||.6,Number(tgt.confidence)||.6),status:'NOT CALIBRATED',manual:true,
      review:true,reviewStatus:'PENDING',reviewReason:'MERGE ESTIMATE (convex hull, may include gap area)',source:'MERGED',operation:'MERGE',parentIDs:[src.id,tgt.id],
      geometryBasis:'HULL_ESTIMATE',estimate:true,partsAreaPx:sum,hullGapAreaPx:m.area-sum,createdAt:now()})};
  }
  function applyMerge(srcId,tgtId){
    const s=APP_STATE.fragments.find(x=>x.id===srcId), t=APP_STATE.fragments.find(x=>x.id===tgtId);
    if(!s||!t||s.id===t.id) return {ok:false,reason:'MERGE NEEDS TWO DIFFERENT OBJECTS; nothing changed'};
    const r=mergeFragmentsEstimate(s,t); if(!r.ok) return r;
    APP_STATE.fragments=APP_STATE.fragments.filter(x=>x.id!==s.id&&x.id!==t.id).concat([r.fragment]);
    fragLineage().push({op:'MERGE',timestamp:r.fragment.createdAt,parentIds:[s.id,t.id],childId:r.fragment.id,basis:'HULL_ESTIMATE',hullGapAreaPx:r.fragment.hullGapAreaPx});
    APP_STATE.image.selectedId=r.fragment.id; APP_STATE.image.selectedIds=[r.fragment.id];
    audit('Fragment merge',s.id+'+'+t.id,r.fragment.id,'MANUAL QC','MERGE OBJECT as ESTIMATE (convex hull; excluded from PSD until reviewed)');
    return {ok:true,fragment:r.fragment};
  }
  function applySizeOverride(id,sizeCm){
    const f=APP_STATE.fragments.find(x=>x.id===id), sc=psdScaleCm();
    if(!f) return {ok:false,reason:'NO SELECTED OBJECT'};
    const v=psdNum(sizeCm); if(!(Number.isFinite(v)&&v>0)) return {ok:false,reason:'SIZE MUST BE A FINITE NUMBER > 0 cm; object unchanged'};
    if(sc===null) return {ok:false,reason:'NO VALID SCALE: a size in cm needs calibration; object unchanged'};
    const prev=f.measuredSizeCm;
    f.sizeOverride={valueCm:v,previousMeasuredCm:prev,sizeDefinition:APP_STATE.psd.sizeDefinition,geometryPxAtEntry:psdGeomPx(f),scaleCmPerPxAtEntry:sc,source:'MANUAL EDIT SIZE',createdAt:now()};
    f.sizeSource='MANUAL_OVERRIDE'; f.review=true; if(!/MANUAL SIZE OVERRIDE/.test(f.reviewReason||'')) f.reviewReason=(f.reviewReason?f.reviewReason+' | ':'')+'MANUAL SIZE OVERRIDE';
    audit('Fragment '+f.id+' size',prev,v,'MANUAL QC','EDIT SIZE as OVERRIDE (contour/area/Feret/bbox NOT modified)');
    return {ok:true,fragment:f};
  }
  function clearSizeOverride(id){
    const f=APP_STATE.fragments.find(x=>x.id===id); if(!f||!f.sizeOverride) return {ok:false,reason:'NO SIZE OVERRIDE ON SELECTED OBJECT'};
    const old=f.sizeOverride.valueCm; delete f.sizeOverride; f.sizeSource='GEOMETRY'; audit('Fragment '+f.id+' size',old,'GEOMETRY','MANUAL QC','CLEAR SIZE OVERRIDE'); return {ok:true,fragment:f};
  }
  function approveEstimates(ids){
    const done=[]; APP_STATE.fragments.forEach(f=>{ if(ids.includes(f.id)&&psdEstimatePending(f)){ f.reviewApproved=true; f.reviewStatus='APPROVED'; f.review=false; f.reviewedAt=now(); f.reviewedBy='USER (UI)'; done.push(f.id); audit('Fragment '+f.id,'ESTIMATE PENDING','APPROVED','MANUAL QC','REVIEW APPROVED (geometryBasis stays '+f.geometryBasis+')'); } });
    return done;
  }

  /* ---- UI wrappers (split by user line / merge / size override) ---- */
  function splitCancel(msg){ APP_STATE.image.manualMode=null; APP_STATE.image.splitPts=[]; APP_STATE.image.splitTargetId=null; if(msg)$('scanStatus').textContent=msg; syncSelectionState(); drawCanvas(); }
  function splitClick(pt){
    const S=APP_STATE.image; S.splitPts=S.splitPts||[]; S.splitPts.push({x:pt.x,y:pt.y});
    if(S.splitPts.length<2){ $('scanStatus').textContent='SPLIT #'+S.splitTargetId+': titik 1 diset. Klik titik 2 (garis harus melewati object dari tepi ke tepi). ESC = batal.'; drawCanvas(); return; }
    const a=S.splitPts[0], b=S.splitPts[1], id=S.splitTargetId; S.splitPts=[]; S.splitTargetId=null; S.manualMode=null;
    const r=applySplit(id,[a.x,a.y],[b.x,b.y]);
    $('scanStatus').textContent=r.ok?('SPLIT OK: object #'+id+' menjadi #'+r.children[0].id+' dan #'+r.children[1].id+' ('+r.children[0].geometryBasis+'; REVIEW '+(r.children[0].estimate?'wajib, dikeluarkan dari PSD sampai di-approve':'pending')+').'):('SPLIT DIBATALKAN: '+r.reason);
    recomputeFragmentMeasurements(); syncSelectionState(); drawCanvas();
  }
  function splitDraw(ctx){
    const S=APP_STATE.image; if(S.manualMode!=='split') return; const pts=S.splitPts||[];
    ctx.save(); ctx.strokeStyle='#f43f5e'; ctx.fillStyle='#f43f5e'; ctx.lineWidth=2; ctx.setLineDash([6,4]);
    if(pts.length===2){ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);ctx.lineTo(pts[1].x,pts[1].y);ctx.stroke();}
    ctx.setLineDash([]); pts.forEach(p=>{ctx.beginPath();ctx.arc(p.x,p.y,4,0,7);ctx.fill();}); ctx.restore();
  }
  function approveSelectedEstimate(){
    const ids=(typeof selectedIdList==='function'?selectedIdList():[]).concat(APP_STATE.image.selectedId?[APP_STATE.image.selectedId]:[]); const done=approveEstimates(ids);
    $('scanStatus').textContent=done.length?('ESTIMATE di-approve: #'+done.join(', #')+' kini masuk statistik PSD (geometryBasis tetap HULL_ESTIMATE).'):'Tidak ada object ESTIMATE yang menunggu review pada pilihan saat ini.';
    recomputeFragmentMeasurements();
  }
  function clearSelectedOverride(){ const r=clearSizeOverride(APP_STATE.image.selectedId); $('scanStatus').textContent=r.ok?'Size override dihapus; ukuran kembali dari geometri kontur.':r.reason; if(r.ok)recomputeFragmentMeasurements(); }
  function scaleKnownDistanceM(){ const c=APP_STATE.calibration||{}; if(Number.isFinite(c.knownDistanceM)&&c.knownDistanceM>0) return c.knownDistanceM; if(psdScaleCm()!==null&&Number.isFinite(c.pixelDistanceWorking)) return c.pixelDistanceWorking*c.centimetersPerWorkingPixel/100; return null; }
  /* SCALE INPUT CONTRACT (P0.2): Apply with an invalid distance (empty, 0, negative, non-finite) or invalid reference NEVER silently
     keeps a stale scale. If a scale is active it stays active, the input field is restored to the distance that scale uses, and the
     status line says so explicitly. If no scale is active the state stays NOT CALIBRATED. Field and state agree after every Apply. */
  function scaleReject(label,msg){
    const act=psdScaleCm()!==null, kd=scaleKnownDistanceM();
    if(act){ if(kd!==null) $('knownDistance').value=String(kd); $('scaleStatus').textContent=label+' \u2022 skala aktif sebelumnya dipertahankan'; $('scanStatus').textContent=msg+' Skala aktif TIDAK berubah: '+(kd!==null?kd+' m':'?')+' = '+fmt(APP_STATE.calibration.centimetersPerWorkingPixel,4)+' cm/px; input dikembalikan ke nilai yang sedang dipakai.'; }
    else { $('scaleStatus').textContent=label; $('scanStatus').textContent=msg+' Belum ada skala aktif (NOT CALIBRATED).'; }
    try{ audit('Calibration',act?'ACTIVE SCALE':'NONE','REJECTED: '+label,'USER INPUT','APPLY SCALE REJECTED'); }catch(_e){}
  }
  function scaleInputDirty(){
    const kd=scaleKnownDistanceM(); if(psdScaleCm()===null||kd===null) return; const raw=$('knownDistance').value, v=raw===''?NaN:Number(raw);
    if(!(Number.isFinite(v)&&v>0)) $('scaleStatus').textContent='INPUT TIDAK VALID \u2022 skala aktif tetap '+kd+' m (tekan APPLY SCALE untuk memulihkan input)';
    else if(v!==kd) $('scaleStatus').textContent='APPROXIMATE SCALE \u2022 input '+v+' belum di-Apply (skala aktif memakai '+kd+' m)';
    else $('scaleStatus').textContent='APPROXIMATE SCALE';
  }

  /* ---- export builders (all labels follow the CURRENT oversize threshold; no hard-coded 80) ---- */
  function csvCell(v){ const s=(v===null||v===undefined)?'':String(v); return /[",\n\r]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s; }
  function fragmentPhysicalStatus(f,sc){ if(sc===null) return 'NOT CALIBRATED'; const m=psdNum(f.measuredSizeCm); return (Number.isFinite(m)&&m>0)?'AVAILABLE':'INVALID SIZE'; }
  function buildFragmentCsv(){
    recomputePSD(); const sc=psdScaleCm(), def=APP_STATE.psd.sizeDefinition, T=psdOversizeThresholdCm();
    const HDR=['id','measuredSizeCm','areaPx','feretPx','bboxMaxPx','eqDiameterPx','sizeDefinition','sizePx','physicalStatus','oversizeThresholdCm','oversizeStatus','psdInclusion','sizeSource','geometryBasis','source','operation','parentIDs','reviewStatus'];
    const rows=(APP_STATE.fragments||[]).map(f=>{ const m=psdNum(f.measuredSizeCm), ok=sc!==null&&Number.isFinite(m)&&m>0, px=psdPxOf(f);
      return {id:f.id,measuredSizeCm:ok?f.measuredSizeCm:'',areaPx:f.area??'',feretPx:f.feretPx??'',bboxMaxPx:f.bboxMaxPx??'',eqDiameterPx:f.eqDiameterPx??'',sizeDefinition:def,sizePx:px??'',physicalStatus:fragmentPhysicalStatus(f,sc),
        oversizeThresholdCm:T,oversizeStatus:ok?(m>T?'OVERSIZE':'WITHIN LIMIT'):'',psdInclusion:f.psdInclusion||'',sizeSource:f.sizeOverride?'MANUAL_OVERRIDE':'GEOMETRY',geometryBasis:f.geometryBasis||(f.exactPolygon?'EXACT_POLYGON':(Array.isArray(f.boundary)&&f.boundary.length?'EDGE_SAMPLES_HULL':'NONE')),
        source:f.source||'',operation:f.operation||'',parentIDs:(f.parentIDs||[]).join('|'),reviewStatus:f.reviewStatus||(f.review?'PENDING':'')}; });
    return {header:HDR,rows,csv:HDR.join(',')+'\n'+rows.map(r=>HDR.map(k=>csvCell(r[k])).join(',')).join('\n')};
  }
  function buildPSDRows(){
    recomputePSD(); const p=psdPhys(), P=APP_STATE.psd, T=psdThrStr(), c=getPSDConfig(), F=APP_STATE.fragments, cnt=k=>F.filter(f=>f.psdInclusion===k).length;
    return [['x50_cm',p.x50??''],['x80_cm',p.x80??''],['quantile_method',PSD_QUANTILE_METHOD],['oversize_threshold_cm',T],
      ['oversize_count_gt_'+T+'cm',p.oversizeCount??''],['oversize_fraction_gt_'+T+'cm',p.oversizeFraction??''],
      ['rr_xc_cm',p.xc??''],['rr_n',p.n??''],['rr_r2',p.r2??''],['rr_estimated_fraction_gt_'+T+'cm',p.rrOversizeFraction??''],
      ['fit_status',p.fitStatus??''],['fit_reason',p.rrReason??''],['rr_min_samples',c.rrMinSamples],['rr_min_distinct',c.rrMinDistinct],['rr_min_log_spread',c.rrMinLogSpread],['rr_min_r2',c.rrMinR2],
      ['physical_status',p.physicalStatus??''],['size_definition',P.sizeDefinition??''],['calibration_cm_per_px',psdScaleCm()??''],['x50_px',P.x50Px??''],['x80_px',P.x80Px??''],['pixel_object_count',P.pixelSampleCount??''],
      ['included_object_count',cnt('INCLUDED')],['excluded_estimate_pending_count',cnt('EXCLUDED - ESTIMATE PENDING REVIEW')],['invalid_size_object_count',cnt('EXCLUDED - INVALID SIZE')],['not_calibrated_object_count',cnt('EXCLUDED - NOT CALIBRATED')]];
  }
  function buildPSDCsv(){ return 'metric,value\n'+buildPSDRows().map(r=>csvCell(r[0])+','+csvCell(r[1])).join('\n'); }
  function psdReportHtml(){
    recomputePSD(); const p=psdPhys(), P=APP_STATE.psd, T=psdThrStr(), na='NOT AVAILABLE', cm=v=>v==null?na:fmt(v,1)+' cm', pct=v=>v==null?na:(v*100).toFixed(2)+'%';
    return '<h2>Fragmentation (PSD)</h2><table><tr><th>Metric</th><th>Value</th></tr>'
      +'<tr><td>Physical status</td><td>'+htmlEscape(P.physicalStatus)+'</td></tr>'
      +'<tr><td>X50 ('+PSD_QUANTILE_METHOD+')</td><td>'+cm(p.x50)+'</td></tr><tr><td>X80 ('+PSD_QUANTILE_METHOD+')</td><td>'+cm(p.x80)+'</td></tr>'
      +'<tr><td>Oversize threshold</td><td>'+T+' cm</td></tr>'
      +'<tr><td>Objects &gt;'+T+' cm</td><td>'+(p.oversizeCount==null?na:p.oversizeCount)+'</td></tr><tr><td>Fraction &gt;'+T+' cm</td><td>'+pct(p.oversizeFraction)+'</td></tr>'
      +'<tr><td>Rosin-Rammler status</td><td>'+htmlEscape(psdRrStatusText(p))+'</td></tr>'
      +'<tr><td>Xc / n / R&sup2;</td><td>'+(p.xc==null?na:fmt(p.xc,2)+' cm / '+p.n.toFixed(3)+' / '+p.r2.toFixed(3))+'</td></tr>'
      +'<tr><td>RR predicted fraction &gt;'+T+' cm</td><td>'+pct(p.rrOversizeFraction)+'</td></tr></table>';
  }

  /* ======================= P0.2 TEST SUITE =======================
     Every test reports actual / expected / reason. Oracles are INDEPENDENT of the code under test:
       - RR + quantile reference values were computed offline with numpy (lstsq on y=ln(-ln(1-p)) vs ln x, p=(i+0.5)/N; numpy.percentile 'linear').
       - Weibull oracle: sizes generated from the closed-form quantile x=Xc*(-ln(1-p))^(1/n) must return exactly Xc and n.
       - Geometry oracles use brute-force vertex-pair distances and hand-computed areas (not measurePolygon / maxFeretFromXY).
       Tests never delete or weaken a failing assertion. State is snapshotted and restored. */
  function runP02Tests(pass){
    const js=v=>{ try{ const s=JSON.stringify(v,(k,x)=>(typeof x==='number'&&!Number.isFinite(x))?String(x):x); return s===undefined?'undefined':(s.length>260?s.slice(0,260)+'...':s); }catch(e){ return String(v); } };
    const chk=(name,actual,expected,reason,cmp)=>{ let ok=false; try{ ok=cmp?!!cmp(actual,expected):JSON.stringify(actual)===JSON.stringify(expected); }catch(e){ ok=false; } pass('P0.2 '+name,ok,'actual='+js(actual)+' | expected='+js(expected)+' | reason='+reason); return ok; };
    const near=tol=>(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=tol*Math.max(1,Math.abs(b));
    const nullFit=f=>f.xc===null&&f.n===null&&f.r2===null;
    const brute=poly=>{ let m=0; for(let i=0;i<poly.length;i++)for(let j=i+1;j<poly.length;j++)m=Math.max(m,Math.hypot(poly[i][0]-poly[j][0],poly[i][1]-poly[j][1])); return m; };
    const shoelace=poly=>{ let s=0; for(let i=0;i<poly.length;i++){const j=(i+1)%poly.length; s+=poly[i][0]*poly[j][1]-poly[j][0]*poly[i][1];} return Math.abs(s)/2; };
    const rect=(x0,y0,x1,y1)=>[[x0,y0],[x1,y0],[x1,y1],[x0,y1]];
    const mkFrag=(id,poly,over)=>Object.assign({id},measurePolygon(poly),{boundary:poly.map(p=>p.slice()),exactPolygon:true,measuredSizeCm:null,confidence:.9,status:'X',source:'MANUAL',operation:'TRACE',parentIDs:[],review:false,reviewReason:''},over||{});
    const setCal=cm=>{ APP_STATE.calibration={...APP_STATE.calibration,points:[],centimetersPerWorkingPixel:cm,metersPerWorkingPixel:cm/100,knownDistanceM:null}; };
    const clearCal=()=>{ APP_STATE.calibration={...APP_STATE.calibration,points:[],centimetersPerWorkingPixel:null,metersPerWorkingPixel:null,knownDistanceM:null,pixelDistanceWorking:null,status:'NOT CALIBRATED'}; };
    const setCfg=o=>{ APP_STATE.psdConfig={...getPSDConfig(),...o}; };
    const sizedFrags=(sizes)=>sizes.map((s,i)=>({id:i+1,area:Math.PI*(s/2)**2,minx:0,maxx:s,miny:0,maxy:s,eqDiameterPx:s,feretPx:s,bboxMaxPx:s,boundary:[[0,0],[s,0],[s,s],[0,s]],measuredSizeCm:null,confidence:.9,circularity:1,aspect:1,solidity:1,status:'X'}));
    const parseCsv=t=>{ const rows=[]; let cur=[],cell='',q=false; for(let i=0;i<t.length;i++){ const c=t[i]; if(q){ if(c==='"'){ if(t[i+1]==='"'){cell+='"';i++;} else q=false; } else cell+=c; } else if(c==='"') q=true; else if(c===','){cur.push(cell);cell='';} else if(c==='\n'){cur.push(cell);rows.push(cur);cur=[];cell='';} else cell+=c; } cur.push(cell); rows.push(cur); return rows; };
    const snap={frags:deepClone(APP_STATE.fragments),cal:deepClone(APP_STATE.calibration),psd:deepClone(APP_STATE.psd),cfg:deepClone(APP_STATE.psdConfig),lin:deepClone(APP_STATE.fragmentLineage||[]),
      img:{m:APP_STATE.image.manualMode,s:APP_STATE.image.selectedId,ss:APP_STATE.image.selectedIds,sp:APP_STATE.image.splitPts,st:APP_STATE.image.splitTargetId},kd:$('knownDistance').value,ms:$('manualSizeCm').value,au:APP_STATE.audit.entries.length,
      ss:$('scaleStatus').textContent,sc:$('scanStatus').textContent};
    try{
      setCfg({rrMinSamples:8,rrMinDistinct:3,rrMinLogSpread:0.05,rrMinR2:0.90,oversizeThresholdCm:80});
      /* ---------- A. quantile (reference method) ---------- */
      const A=[5,8,12,15,20,27,35,50], B=[3,7,9,14,18,22,31,40,66];
      chk('Quantile HF7 X50 [n=8] vs numpy',psdQuantile(A,.5),17.5,'numpy.percentile(A,50,linear)=17.5',near(1e-12));
      chk('Quantile HF7 X80 [n=8] vs numpy',psdQuantile(A,.8),31.8,'numpy.percentile(A,80,linear)=31.8',near(1e-12));
      chk('Quantile HF7 X50/X80 [n=9] vs numpy',[psdQuantile(B,.5),psdQuantile(B,.8)],[18,34.6],'numpy linear on odd N',(a,e)=>near(1e-12)(a[0],e[0])&&near(1e-12)(a[1],e[1]));
      chk('Quantile legacy floor rule differs (impact documented)',[psdQuantileLegacyFloor(A,.5),psdQuantileLegacyFloor(A,.8)],[15,27],'baseline floor(p(N-1)) rule kept only to quantify the impact (HF7 gives 17.5 / 31.8)');
      /* ---------- A. RR fit ---------- */
      const ident=[10,10,10,10,10,10,10,10];
      const f1=fitRR(ident); chk('RR 8 identical sizes: never FIT AVAILABLE, no forced slope',{st:f1.status,xc:f1.xc,n:f1.n,r2:f1.r2},{st:'FIT FAILED',xc:null,n:null,r2:null},'identical data = degenerate regression; baseline forced slope=1 and reported FIT AVAILABLE',(a,e)=>a.st===e.st&&a.xc===null&&a.n===null&&a.r2===null);
      chk('RR 8 identical sizes: reason names degeneracy',f1.reason,'DEGENERATE DATA',f1.reason,(a,e)=>a.startsWith(e));
      const near8=[10,10.0001,10,10.0001,10,10.0001,10,10.0001], f2=fitRR(near8);
      chk('RR near-identical sizes: FIT FAILED',{st:f2.status,ok:f2.ok,nullFit:nullFit(f2)},{st:'FIT FAILED',ok:false,nullFit:true},'baseline reported n=183561 FIT AVAILABLE',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      const jit=[10,10.001,10.002,10.003,10.004,10.005,10.006,10.007], f2b=fitRR(jit);
      chk('RR 8 distinct but ~0.07 % spread: FIT FAILED (SD ln size below minimum)',f2b.status,'FIT FAILED','logSpread='+f2b.logSpread+' < '+f2b.criteria.minLogSpread);
      const f3=fitRR([5,8,12,15,20,27,35]); chk('RR 7 samples (< 8): INSUFFICIENT SAMPLE, no parameters',{st:f3.status,nullFit:nullFit(f3)},{st:'INSUFFICIENT SAMPLE',nullFit:true},'N=7 below rrMinSamples=8',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      const f3b=fitRR([5,8,12,15,20,27,35],{minSamples:5}); chk('RR minimum sample count is project-configurable (min=5 allows N=7)',f3b.status,'FIT AVAILABLE','criteria override minSamples=5; '+f3b.reason);
      [['NaN',NaN],['Infinity',Infinity],['-Infinity',-Infinity],['zero',0],['negative',-5],['string "10"','10'],['null',null],['undefined',undefined],['boolean',true]].forEach(([lab,bad])=>{
        const arr=[5,8,12,15,20,27,35,bad], r=fitRR(arr); chk('RR invalid value ('+lab+') rejected',{st:r.status,inv:r.invalidCount,nullFit:nullFit(r)},{st:'FIT FAILED',inv:1,nullFit:true},'invalid entries must fail the fit, never be skipped silently',(a,e)=>JSON.stringify(a)===JSON.stringify(e)); });
      chk('RR non-array input rejected',fitRR(null).status,'FIT FAILED','null instead of array');
      const crit=getPSDConfig(), good={slope:1.5,intercept:-4,r2:0.99};
      [['slope negative',{...good,slope:-0.7}],['slope zero',{...good,slope:0}],['slope NaN',{...good,slope:NaN}],['slope Infinity',{...good,slope:Infinity}],['intercept NaN',{...good,intercept:NaN}],['R2 NaN',{...good,r2:NaN}]].forEach(([lab,reg])=>{
        const j=rrJudgeRegression(reg,rrCriteriaFromConfig()); chk('RR guard: '+lab+' -> FIT FAILED, parameters null',{st:j.status,nullFit:nullFit(j)},{st:'FIT FAILED',nullFit:true},'slope<=0 / non-finite is never coerced to 1',(a,e)=>JSON.stringify(a)===JSON.stringify(e)); });
      const jOverflow=rrJudgeRegression({slope:1e-300,intercept:-1e5,r2:.99},rrCriteriaFromConfig()); chk('RR guard: Xc overflow (Infinity) -> FIT FAILED',jOverflow.status,'FIT FAILED','exp(-intercept/slope) is not finite');
      const fa=fitRR(A); chk('RR varied data vs numpy: Xc',fa.xc,24.007413014748064,'numpy lstsq reference; status '+fa.status,near(1e-9));
      chk('RR varied data vs numpy: n',fa.n,1.5616918007109002,'numpy lstsq reference',near(1e-9));
      chk('RR varied data vs numpy: R2',fa.r2,0.9824660283097572,'numpy lstsq reference',near(1e-9));
      chk('RR varied data: FIT AVAILABLE',fa.status,'FIT AVAILABLE','R2 0.982 >= 0.90');
      const fb=fitRR(B,{minSamples:8}); chk('RR varied n=9 vs numpy (Xc,n,R2)',[fb.xc,fb.n,fb.r2],[25.211619785897348,1.272623637560633,0.9907046778839111],'numpy lstsq reference',(a,e)=>a.every((v,i)=>near(1e-9)(v,e[i])));
      const W=[...Array(8)].map((_,i)=>30*Math.pow(-Math.log(1-(i+.5)/8),1/2)), fw=fitRR(W);
      chk('RR Weibull oracle: closed-form quantiles recover Xc=30, n=2, R2=1',[fw.xc,fw.n,fw.r2],[30,2,1],'sizes built from x=Xc*(-ln(1-p))^(1/n) at p=(i+.5)/8',(a,e)=>a.every((v,i)=>near(1e-9)(v,e[i])));
      const bim=[1,1.1,1.2,1.3,50,51,52,53], fp=fitRR(bim);
      chk('RR poor linearity -> FIT POOR with diagnostic parameters',{st:fp.status,diag:fp.xc!==null&&fp.n>0&&fp.r2<0.9},{st:'FIT POOR',diag:true},'numpy R2=0.6904 < 0.90; reason='+fp.reason,(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      chk('RR FIT POOR R2 matches numpy',fp.r2,0.6903925792067704,'numpy lstsq reference',near(1e-9));
      const fp2=fitRR(bim,{minR2:0.5}); chk('RR R2 limit is configurable (minR2=0.5 makes the same data FIT AVAILABLE)',fp2.status,'FIT AVAILABLE','criterion is a project setting, not a universal constant');
      chk('RR oversize fraction only from FIT AVAILABLE',[rrOversizeFraction(fa,80),rrOversizeFraction(fp,80),rrOversizeFraction(f1,80)],[Math.exp(-Math.pow(80/24.007413014748064,1.5616918007109002)),null,null],'closed form exp(-(T/Xc)^n); null for POOR/FAILED',(a,e)=>near(1e-9)(a[0],e[0])&&a[1]===null&&a[2]===null);
      /* ---------- A. through the app pipeline (recomputePSD) ---------- */
      setCal(1); APP_STATE.fragments=sizedFrags(ident); recomputePSD(); let P=APP_STATE.psd;
      chk('Pipeline: 8 identical sizes -> no FIT AVAILABLE, no Xc/n/R2/RR fraction',{st:P.fitStatus,xc:P.xc,n:P.n,r2:P.r2,rr:P.rrOversizeFraction},{st:'FIT FAILED',xc:null,n:null,r2:null,rr:null},'regression test for forced-slope bug; reason='+P.rrReason,(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      chk('Pipeline: X50/X80 still reported for identical sizes (data are valid, only the RR fit is not)',[P.x50,P.x80],[10,10],'quantile of constant data',(a,e)=>a[0]===e[0]&&a[1]===e[1]);
      APP_STATE.fragments=sizedFrags(A); recomputePSD(); P=APP_STATE.psd;
      chk('Pipeline: varied data -> FIT AVAILABLE with numpy Xc and HF7 X50/X80',[P.fitStatus,P.xc,P.x50,P.x80],['FIT AVAILABLE',24.007413014748064,17.5,31.8],'independent reference',(a,e)=>a[0]===e[0]&&near(1e-9)(a[1],e[1])&&near(1e-9)(a[2],e[2])&&near(1e-9)(a[3],e[3]));
      chk('Pipeline: predicted oversize fraction equals closed form at threshold 80',P.rrOversizeFraction,Math.exp(-Math.pow(80/24.007413014748064,1.5616918007109002)),'exp(-(80/Xc)^n)',near(1e-9));
      APP_STATE.fragments=sizedFrags(bim); recomputePSD(); P=APP_STATE.psd;
      chk('Pipeline: FIT POOR keeps diagnostics but produces NO predicted fraction',{st:P.fitStatus,xcSet:P.xc!==null,rr:P.rrOversizeFraction},{st:'FIT POOR',xcSet:true,rr:null},'POOR must not feed decisions',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      APP_STATE.fragments=sizedFrags([5,8,12,15,20,27,35]); recomputePSD(); P=APP_STATE.psd;
      chk('Pipeline: 7 valid objects -> INSUFFICIENT SAMPLE, all RR fields null',{st:P.fitStatus,xc:P.xc,rr:P.rrOversizeFraction},{st:'INSUFFICIENT SAMPLE',xc:null,rr:null},'below rrMinSamples',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      const withBad=sizedFrags(A); withBad.push({...sizedFrags([9])[0],id:99,feretPx:NaN,eqDiameterPx:NaN,bboxMaxPx:NaN}); APP_STATE.fragments=withBad; recomputePSD(); P=APP_STATE.psd;
      chk('Pipeline: invalid-size object is excluded from PSD stats and labelled INVALID SIZE',{n:P.sampleCount,x50:P.x50,st:withBad[8].status,inc:withBad[8].psdInclusion},{n:8,x50:17.5,st:'INVALID SIZE',inc:'EXCLUDED - INVALID SIZE'},'object 99 has NaN size and must not enter X50/RR',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      const nc=sizedFrags(A); clearCal(); APP_STATE.fragments=nc; recomputePSD(); P=APP_STATE.psd;
      chk('Pipeline: no calibration -> physical RR/X50 null, pixel stats only',{x50:P.x50,xc:P.xc,fit:P.fitStatus,x50Px:P.x50Px,inc:nc[0].psdInclusion},{x50:null,xc:null,fit:'INSUFFICIENT SAMPLE',x50Px:17.5,inc:'EXCLUDED - NOT CALIBRATED'},'NOT CALIBRATED never yields cm results',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      /* config normalisation */
      const nc2=normalizePSDConfig({rrMinR2:5,rrMinLogSpread:-1,rrMinDistinct:0,rrMinSamples:'x'}); chk('Config normalisation clamps RR criteria into valid ranges',[nc2.rrMinR2,nc2.rrMinLogSpread,nc2.rrMinDistinct,nc2.rrMinSamples],[1,1e-6,2,8],'R2 limit<=1, spread floor 1e-6, distinct>=2, invalid sample count falls back to 8');
      /* ---------- B. split object ---------- */
      setCal(2); setCfg({oversizeThresholdCm:80});
      const sq=rect(0,0,100,100); APP_STATE.fragments=[mkFrag(1,sq),mkFrag(2,rect(300,300,340,340))]; APP_STATE.fragmentLineage=[]; const before=deepClone(APP_STATE.fragments);
      const r=applySplit(1,[50,-20],[50,120]);
      chk('Split: operation succeeds on a valid contour and full-crossing line',r.ok,true,r.reason||'ok');
      const kids=APP_STATE.fragments.filter(f=>f.source==='SPLIT'), L=kids.find(k=>k.maxx<=50+1e-9), R=kids.find(k=>k.minx>=50-1e-9);
      chk('Split: two children exist, left of x=50 and right of x=50',[kids.length,!!L,!!R],[2,true,true],'children found by geometry, not by id',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      if(L&&R){
        chk('Split: child contours are different polygons (not just different numbers)',JSON.stringify(L.boundary)!==JSON.stringify(R.boundary)&&L.minx!==R.minx,true,'left '+js(L.boundary)+' right '+js(R.boundary));
        chk('Split: left contour exact vertices',L.boundary,[[0,0],[50,0],[50,100],[0,100]],'hand-computed intersection with x=50');
        chk('Split: right contour exact vertices',R.boundary,[[50,0],[100,0],[100,100],[50,100]],'hand-computed intersection with x=50');
        chk('Split: contours are separated by the cut (left max x = right min x = 50; only the 2 cut vertices are shared)',[Math.max(...L.boundary.map(p=>p[0])),Math.min(...R.boundary.map(p=>p[0])),L.boundary.filter(p=>R.boundary.some(q=>q[0]===p[0]&&q[1]===p[1]))],[50,50,[[50,0],[50,100]]],'interiors are disjoint, shared boundary = cut segment only');
        chk('Split: area conserved (sum of child polygon areas = parent polygon area)',shoelace(L.boundary)+shoelace(R.boundary),shoelace(sq),'10000 px^2 parent',near(1e-12));
        chk('Split: child area = 5000 px^2 each (from own contour)',[L.area,R.area],[5000,5000],'hand-computed 50x100',(a,e)=>a[0]===e[0]&&a[1]===e[1]);
        const fe=Math.hypot(50,100); chk('Split: child Feret derived from child contour (brute force sqrt(50^2+100^2)), not 0.72 x parent',[L.feretPx,R.feretPx,brute(L.boundary)],[fe,fe,fe],'baseline used parent Feret x 0.72 = '+(brute(sq)*.72).toFixed(3),(a,e)=>a.every((v,i)=>near(1e-9)(v,e[i])));
        chk('Split: child equivalent diameter = 2*sqrt(A/pi) of its own area',L.eqDiameterPx,2*Math.sqrt(5000/Math.PI),'child area 5000',near(1e-12));
        chk('Split: child bounding boxes',[[L.minx,L.maxx,L.miny,L.maxy],[R.minx,R.maxx,R.miny,R.maxy]],[[0,50,0,100],[50,100,0,100]],'from child contours');
        chk('Split: child bbox max px (50x100 boxes)',[L.bboxMaxPx,R.bboxMaxPx],[100,100],'max(50,100)=100 for each child');
        chk('Split: child geometry fully consistent with its contour',[validateFragmentGeometry(L).ok,validateFragmentGeometry(R).ok],[true,true],js(validateFragmentGeometry(L).errors.concat(validateFragmentGeometry(R).errors)));
        chk('Split: unique new IDs, parent id retired, other object untouched',[L.id,R.id,APP_STATE.fragments.some(f=>f.id===1),APP_STATE.fragments.filter(f=>f.id===2).length],[3,4,false,1],'max id was 2',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        chk('Split: provenance (parent, source, operation, line, status)',[L.parentIDs,R.parentIDs,L.source,L.operation,L.review,L.reviewStatus,L.splitLine],[[1],[1],'SPLIT','SPLIT',true,'PENDING',{x1:50,y1:-20,x2:50,y2:120}],'parent/line recorded',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        chk('Split: geometry basis of an exact parent is exact, child counted in PSD',[L.geometryBasis,L.estimate,L.exactPolygon],['EXACT_POLYGON',false,true],'exact parent -> exact children');
        chk('Split: lineage keeps the parent snapshot',[fragLineage().length,fragLineage()[0].parentId,fragLineage()[0].childIds,fragLineage()[0].parentSnapshot.boundary],[1,1,[3,4],sq],'audit trail of the retired parent',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        /* definisi ukuran adalah pengaturan pengguna yang ikut tersimpan; tes ini mengunci 'feret' agar harapan
           sqrt(50^2+100^2) x 2 cm/px valid, lalu mengembalikan pilihan pengguna. */
        const sdBak=APP_STATE.psd.sizeDefinition; try{ APP_STATE.psd.sizeDefinition='feret'; recomputePSD();
          const ex=2*fe; chk('Split: physical size derived from child geometry x scale 2 cm/px',[L.measuredSizeCm,R.measuredSizeCm],[ex,ex],'Feret 111.803 px x 2 cm/px',(a,e)=>a.every((v,i)=>near(1e-9)(v,e[i])));
        } finally { APP_STATE.psd.sizeDefinition=sdBak; recomputePSD(); }
      }
      /* split failures leave everything unchanged */
      const failCase=(name,polyOrFrag,a,b,expectRe)=>{ APP_STATE.fragments=[polyOrFrag]; const snapF=JSON.stringify(APP_STATE.fragments), lin=fragLineage().length; const rr=applySplit(polyOrFrag.id,a,b); chk('Split fails safely: '+name,[rr.ok,JSON.stringify(APP_STATE.fragments)===snapF,fragLineage().length===lin,expectRe.test(rr.reason||'')],[false,true,true,true],'reason='+rr.reason,(x,e)=>JSON.stringify(x)===JSON.stringify(e)); };
      failCase('line misses the object',mkFrag(1,sq),[200,-20],[200,120],/DOES NOT INTERSECT/);
      failCase('segment too short (does not fully cross)',mkFrag(1,sq),[50,10],[50,90],/DOES NOT FULLY CROSS/);
      failCase('zero-length line',mkFrag(1,sq),[50,50],[50,50],/DEGENERATE/);
      failCase('non-finite line',mkFrag(1,sq),[NaN,0],[50,100],/NOT FINITE/);
      const U=[[0,0],[90,0],[90,100],[60,100],[60,30],[30,30],[30,100],[0,100]];
      failCase('concave object cut into 3 parts (4 crossings)',mkFrag(1,U),[-10,60],[100,60],/CROSSES THE CONTOUR 4 TIMES/);
      failCase('child below Min Area',mkFrag(1,sq),[0.5,-20],[0.5,120],/BELOW MIN AREA/);
      const noGeo={id:1,area:100,minx:0,maxx:10,miny:0,maxy:10,eqDiameterPx:10,feretPx:10,bboxMaxPx:10,measuredSizeCm:20}; failCase('object without contour geometry',noGeo,[5,-5],[5,15],/NO CONTOUR GEOMETRY/);
      /* concave but exactly 2 crossings: L shape split gives 2 simple polygons with conserved area */
      const Lp=[[0,0],[100,0],[100,40],[40,40],[40,100],[0,100]], rl=splitPolygonByLine(Lp,[-10,20],[110,20]);
      chk('Split: concave L-shape with 2 crossings -> two parts, area conserved',[rl.ok,rl.ok&&(shoelace(rl.pieces[0])+shoelace(rl.pieces[1]))],[true,shoelace(Lp)],'L area = '+shoelace(Lp),(a,e)=>a[0]===true&&near(1e-12)(a[1],e[1]));
      const dg=splitPolygonByLine(sq,[-10,-10],[110,110]); chk('Split: diagonal through two vertices gives two triangles of 5000',[dg.ok,dg.ok&&dg.areas],[true,[5000,5000]],'line through opposite corners',(a,e)=>a[0]===true&&near(1e-9)(a[1][0],5000)&&near(1e-9)(a[1][1],5000));
      /* auto-scan style object: only edge samples, no exact contour -> estimate */
      const edgeSamples=[[0,0],[40,0],[80,0],[100,10],[100,60],[100,100],[60,100],[20,100],[0,100],[0,50]]; const auto=mkFrag(1,rect(0,0,100,100),{boundary:edgeSamples,exactPolygon:false,area:9000,source:undefined,operation:undefined});
      APP_STATE.fragments=[auto,mkFrag(2,rect(300,300,340,340))]; const ra=applySplit(1,[50,-20],[50,120]); const ak=APP_STATE.fragments.filter(f=>f.source==='SPLIT');
      chk('Split on edge-sample object works only as HULL ESTIMATE, flagged and excluded from PSD',[ra.ok,ak.map(k=>k.geometryBasis),ak.map(k=>k.estimate),ak.map(k=>(recomputePSD(),k.psdInclusion))],[true,['HULL_ESTIMATE','HULL_ESTIMATE'],[true,true],['EXCLUDED - ESTIMATE PENDING REVIEW','EXCLUDED - ESTIMATE PENDING REVIEW']],'no exact parent contour exists; result must not count as an actual measurement',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      chk('Split estimate: excluded objects do not enter X50 (only object 2 counts)',[APP_STATE.psd.sampleCount,APP_STATE.psd.excludedEstimateCount],[1,2],'1 included + 2 excluded estimates',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      const apr=approveEstimates(ak.map(k=>k.id)); recomputePSD(); chk('Split estimate: review approval moves children into PSD, basis stays HULL_ESTIMATE',[apr.length,APP_STATE.psd.sampleCount,ak[0].geometryBasis,ak[0].reviewStatus],[2,3,'HULL_ESTIMATE','APPROVED'],'declared valid through review; provenance preserved',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      /* ---------- C. merge ---------- */
      setCal(1); const m1=mkFrag(1,rect(0,0,10,10)), m2=mkFrag(2,rect(20,0,30,10)), m3=mkFrag(3,rect(100,100,110,110)); APP_STATE.fragments=[m1,m2,m3]; APP_STATE.fragmentLineage=[];
      const rm=applyMerge(1,2); const mg=APP_STATE.fragments.find(f=>f.source==='MERGED'); recomputePSD();
      chk('Merge: result flagged ESTIMATE (convex hull), not an actual contour',[rm.ok,mg&&mg.geometryBasis,mg&&mg.estimate,mg&&mg.exactPolygon,mg&&mg.parentIDs],[true,'HULL_ESTIMATE',true,false,[1,2]],'hull may cover empty space between objects',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      chk('Merge: hull area and gap (hand computed 300 - 200 = 100 gap)',[mg.area,mg.partsAreaPx,mg.hullGapAreaPx],[300,200,100],'two 10x10 squares 10 px apart',(a,e)=>a.every((v,i)=>near(1e-9)(v,e[i])));
      chk('Merge: metrics consistent with the merged contour',[validateFragmentGeometry(mg).ok,mg.feretPx],[true,Math.hypot(30,10)],'Feret of 30x10 rectangle = sqrt(1000)',(a,e)=>a[0]===true&&near(1e-9)(a[1],e[1]));
      chk('Merge: new unique id, parents removed, excluded from PSD until reviewed',[mg.id,APP_STATE.fragments.some(f=>f.id===1||f.id===2),mg.psdInclusion,APP_STATE.psd.sampleCount],[4,false,'EXCLUDED - ESTIMATE PENDING REVIEW',1],'only object 3 remains a measurement',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      chk('Merge: lineage recorded',[fragLineage()[0].op,fragLineage()[0].parentIds,fragLineage()[0].childId],['MERGE',[1,2],4],'audit trail',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      chk('Merge: guards (same object, missing object)',[applyMerge(3,3).ok,applyMerge(3,999).ok],[false,false],'nothing changes');
      /* ---------- C. edit size ---------- */
      setCal(2); const ef=mkFrag(7,rect(0,0,60,40)); APP_STATE.fragments=[ef,mkFrag(8,rect(0,0,20,20))]; recomputePSD(); const geo0=JSON.stringify({a:ef.area,fe:ef.feretPx,eq:ef.eqDiameterPx,bb:ef.bboxMaxPx,x0:ef.minx,x1:ef.maxx,y0:ef.miny,y1:ef.maxy,b:ef.boundary}), cm0=ef.measuredSizeCm;
      const ro=applySizeOverride(7,55); recomputePSD();
      chk('Edit Size: override stored with provenance',[ro.ok,ef.sizeOverride&&ef.sizeOverride.valueCm,ef.sizeOverride&&ef.sizeOverride.source,ef.sizeOverride&&ef.sizeOverride.previousMeasuredCm,ef.sizeOverride&&ef.sizeOverride.scaleCmPerPxAtEntry,ef.sizeSource],[true,55,'MANUAL EDIT SIZE',cm0,2,'MANUAL_OVERRIDE'],'who/what/when/previous value are kept',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      chk('Edit Size: contour, area, Feret, eq. diameter, bbox are NOT silently modified',JSON.stringify({a:ef.area,fe:ef.feretPx,eq:ef.eqDiameterPx,bb:ef.bboxMaxPx,x0:ef.minx,x1:ef.maxx,y0:ef.miny,y1:ef.maxy,b:ef.boundary})===geo0,true,'baseline overwrote Feret, eqDiam and bbox with one value');
      chk('Edit Size: geometry stays consistent with its contour',validateFragmentGeometry(ef).ok,true,js(validateFragmentGeometry(ef).errors));
      chk('Edit Size: PSD uses the override (cm) and px follows the scale',[ef.measuredSizeCm,psdPxOf(ef)],[55,27.5],'55 cm / 2 cm/px',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      setCal(4); recomputePSD(); chk('Edit Size: override is a physical (cm) value and survives a scale change; geometry px unchanged',[ef.measuredSizeCm,ef.feretPx],[55,Math.hypot(60,40)],'user-entered cm is authoritative',(a,e)=>a[0]===e[0]&&near(1e-12)(a[1],e[1])); setCal(2); recomputePSD();
      const csvO=buildFragmentCsv(), rowsO=parseCsv(csvO.csv), hO=rowsO[0], rO=rowsO.find(x=>x[0]==='7');
      chk('Edit Size: export marks the size source',[rO[hO.indexOf('sizeSource')],rO[hO.indexOf('measuredSizeCm')]],['MANUAL_OVERRIDE','55'],'Fragment_List.csv row for #7',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      chk('Edit Size: rejected inputs leave the object unchanged',[applySizeOverride(7,0).ok,applySizeOverride(7,-3).ok,applySizeOverride(7,NaN).ok,applySizeOverride(7,Infinity).ok,applySizeOverride(7,'').ok,applySizeOverride(999,5).ok,ef.sizeOverride.valueCm],[false,false,false,false,false,false,55],'invalid size values',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      clearCal(); const nr=applySizeOverride(8,40); chk('Edit Size: refused without a valid scale',[nr.ok,APP_STATE.fragments.find(f=>f.id===8).sizeOverride===undefined],[false,true],nr.reason,(a,e)=>JSON.stringify(a)===JSON.stringify(e)); setCal(2);
      const cl=clearSizeOverride(7); recomputePSD(); chk('Edit Size: clearing the override restores the geometry-derived size',[cl.ok,ef.measuredSizeCm,ef.sizeSource],[true,cm0,'GEOMETRY'],'Feret(60x40)=72.11 px x 2',(a,e)=>a[0]===e[0]&&near(1e-9)(a[1],e[1])&&a[2]===e[2]);
      /* outline edit invalidates an override and an estimate */
      const og=mkFrag(11,rect(0,0,60,40),{estimate:true,geometryBasis:'HULL_ESTIMATE',sizeOverride:{valueCm:99,source:'MANUAL EDIT SIZE'},sizeSource:'MANUAL_OVERRIDE'}); APP_STATE.fragments=[og]; setCal(2); edRefit(og); recomputePSD();
      chk('Edit Outline: refit clears the stale override and the estimate flag',[og.sizeOverride,og.estimate,og.geometryBasis,og.psdInclusion],[undefined,false,'USER_EDITED_POLYGON','INCLUDED'],'geometry changed by the user, so a size override or hull estimate no longer applies',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      /* ---------- D. export labels: two thresholds ---------- */
      const sizesCm=[20,45,62.5,70,79.9,80,85,120,200,31]; const gen=sizedFrags(sizesCm.map(x=>x/2));
      [[80,'80'],[62.5,'62.5'],[100,'100']].forEach(([thr,ts])=>{
        setCal(2); setCfg({oversizeThresholdCm:thr}); APP_STATE.fragments=sizedFrags(sizesCm.map(x=>x/2)); APP_STATE.fragments.push({...sizedFrags([5])[0],id:50,feretPx:NaN,eqDiameterPx:NaN,bboxMaxPx:NaN}); recomputePSD();
        const exp=sizesCm.filter(x=>x>thr).length, expFrac=exp/sizesCm.length, rows=buildPSDRows(), get=k=>{ const r=rows.find(q=>q[0]===k); return r?r[1]:undefined; }, names=rows.map(q=>q[0]);
        chk('Export PSD_Result [thr='+ts+']: threshold row',get('oversize_threshold_cm'),ts,'must equal the configured threshold');
        chk('Export PSD_Result [thr='+ts+']: oversize count column name carries the threshold and value is right',[names.includes('oversize_count_gt_'+ts+'cm'),get('oversize_count_gt_'+ts+'cm')],[true,exp],'independent count of sizes > '+ts+' = '+exp,(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        chk('Export PSD_Result [thr='+ts+']: oversize fraction value',get('oversize_fraction_gt_'+ts+'cm'),expFrac,'count/valid objects (invalid object #50 excluded)',near(1e-12));
        chk('Export PSD_Result [thr='+ts+']: RR fraction column named for the same threshold',[names.includes('rr_estimated_fraction_gt_'+ts+'cm'),names.some(n=>/gt80/i.test(n)&&ts!=='80')],[true,false],'no stale gt80 label when threshold is '+ts,(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        const rrExp=(APP_STATE.psd.fitStatus==='FIT AVAILABLE')?Math.exp(-Math.pow(thr/APP_STATE.psd.xc,APP_STATE.psd.n)):'';
        chk('Export PSD_Result [thr='+ts+']: RR fraction value matches closed form (or blank if no valid fit)',get('rr_estimated_fraction_gt_'+ts+'cm'),rrExp,'status='+APP_STATE.psd.fitStatus,(a,e)=>e===''?a==='':near(1e-9)(a,e));
        chk('Export PSD_Result [thr='+ts+']: quantile method + fit status rows',[get('quantile_method'),get('fit_status')],['HF7_LINEAR',APP_STATE.psd.fitStatus],'documented method is exported',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        const fc=buildFragmentCsv(), fr=parseCsv(fc.csv), fh=fr[0], body=fr.slice(1).filter(x=>x.length===fh.length);
        chk('Export Fragment_List [thr='+ts+']: header has threshold + status + provenance columns',['oversizeThresholdCm','oversizeStatus','physicalStatus','psdInclusion','sizeSource','geometryBasis','parentIDs'].every(h=>fh.includes(h)),true,'header='+fh.join('|'));
        chk('Export Fragment_List [thr='+ts+']: threshold column on every row',body.every(x=>x[fh.indexOf('oversizeThresholdCm')]===ts),true,'rows='+body.length);
        const over=body.filter(x=>x[fh.indexOf('oversizeStatus')]==='OVERSIZE').length; chk('Export Fragment_List [thr='+ts+']: OVERSIZE rows',over,exp,'independent count');
        const st=body.map(x=>x[fh.indexOf('physicalStatus')]); chk('Export Fragment_List [thr='+ts+']: AVAILABLE vs INVALID SIZE',[st.filter(s=>s==='AVAILABLE').length,st.filter(s=>s==='INVALID SIZE').length,st.filter(s=>s==='NOT CALIBRATED').length],[10,1,0],'object #50 has NaN size',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        const blw=exportBridgeText('blw'), r3d=exportBridgeText('r3d'), tag='GT'+ts.replace('.','_'), stale=ts!=='80';
        chk('Export Mock_BLW [thr='+ts+']: keys carry the threshold and its value',[blw.includes('BOULDER_'+tag+'_COUNT='+exp),blw.includes('OVERSIZE_THRESHOLD_CM='+ts),blw.includes('RR_ESTIMATED_'+tag+'='),stale?/GT80/.test(blw):false],[true,true,true,false],'no GT80 label unless threshold is 80',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        chk('Export Mock_R3D [thr='+ts+']: keys carry the threshold and its value',[r3d.includes('BOULDER_'+tag+'_COUNT: '+exp),r3d.includes('OVERSIZE_THRESHOLD_CM: '+ts),stale?/GT80/.test(r3d):false],[true,true,false],'R3D uses "key: value" form',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        const rep=buildExecutiveReportHtml(); chk('Export Executive_Report [thr='+ts+']: labels follow the threshold',[rep.includes('Objects &gt;'+ts+' cm'),rep.includes('Fraction &gt;'+ts+' cm'),stale?rep.includes('&gt;80 cm'):false,rep.includes('&quot;oversizeThresholdCm&quot;: '+ts)],[true,true,false,true],'PSD section + JSON snapshot',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
        psdRefreshThresholdLabels(); const lab=[$('actualBoulderCount').previousElementSibling.textContent,$('boulder80').previousElementSibling.textContent,$('rrOversize').previousElementSibling.textContent];
        chk('UI labels [thr='+ts+']: static ">80" captions follow the threshold',lab,['Actual >'+ts+' cm','>'+ts+' cm','RR estimated fraction >'+ts],'dynamic captions',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      });
      setCfg({oversizeThresholdCm:80}); clearCal(); APP_STATE.fragments=sizedFrags([10,20,30]); recomputePSD(); { const fr=parseCsv(buildFragmentCsv().csv), h=fr[0]; chk('Export Fragment_List: NOT CALIBRATED status when no scale',fr.slice(1).filter(x=>x.length===h.length).map(x=>x[h.indexOf('physicalStatus')]),['NOT CALIBRATED','NOT CALIBRATED','NOT CALIBRATED'],'no scale -> never AVAILABLE',(a,e)=>JSON.stringify(a)===JSON.stringify(e)); const rows=buildPSDRows(); chk('Export PSD_Result: NOT CALIBRATED yields blank cm values',[rows.find(q=>q[0]==='x50_cm')[1],rows.find(q=>q[0]==='physical_status')[1]],['','NOT AVAILABLE - NOT CALIBRATED'],'blank, not 0',(a,e)=>JSON.stringify(a)===JSON.stringify(e)); }
      /* ---------- E. scale input ---------- */
      const setIn=v=>{ $('knownDistance').value=v; }, apply=()=>$('btnApplyScale').click(), st=()=>({inp:$('knownDistance').value,sc:APP_STATE.calibration.centimetersPerWorkingPixel,kd:APP_STATE.calibration.knownDistanceM,label:$('scaleStatus').textContent,scan:$('scanStatus').textContent});
      clearCal(); APP_STATE.calibration.points=[{x:0,y:0},{x:100,y:0}]; APP_STATE.fragments=sizedFrags([10]); setIn('2'); apply(); let s=st();
      chk('Scale: valid input -> scale 2 m / 100 px = 2 cm/px, state remembers 2 m',[s.sc,s.kd,s.inp],[2,2,'2'],'cm/px = m*100/px',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      chk('Scale: valid input recomputes PSD (10 px x 2 = 20 cm)',APP_STATE.fragments[0].measuredSizeCm,20,'recomputeFragmentMeasurements ran');
      [['empty',''],['zero','0'],['negative','-3'],['non-numeric','abc']].forEach(([lab,v])=>{ setIn(v); apply(); s=st();
        chk('Scale: valid -> input '+lab+' -> Apply: input restored to the active distance',s.inp,'2','field must never be empty while a scale is active; got label='+s.label);
        chk('Scale: '+lab+' input keeps the old scale AND says so explicitly',[s.sc,/INVALID DISTANCE/.test(s.label),/dipertahankan/.test(s.label),/TIDAK berubah/.test(s.scan)],[2,true,true,true],'label='+s.label+' scan='+s.scan,(a,e)=>JSON.stringify(a)===JSON.stringify(e)); });
      setIn('4'); apply(); s=st(); chk('Scale: valid new input replaces the scale (4 m / 100 px = 4 cm/px)',[s.sc,s.kd,s.inp,APP_STATE.fragments[0].measuredSizeCm],[4,4,'4',40],'new scale recomputes objects',(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      setIn('7'); $('knownDistance').dispatchEvent(new Event('input')); s=st(); chk('Scale: typing a different value shows "not applied" while the old scale is active',[/belum di-Apply/.test(s.label),s.sc],[true,4],'label='+s.label,(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      setIn(''); $('knownDistance').dispatchEvent(new Event('input')); s=st(); chk('Scale: emptying the field shows an explicit warning before Apply',[/INPUT TIDAK VALID/.test(s.label),s.sc],[true,4],'label='+s.label,(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      clearCal(); APP_STATE.calibration.points=[{x:0,y:0},{x:100,y:0}]; setIn(''); apply(); s=st(); chk('Scale: no active scale + empty input stays NOT CALIBRATED (nothing hidden)',[s.sc,/INVALID DISTANCE/.test(s.label),/NOT CALIBRATED/.test(s.scan)],[null,true,true],'label='+s.label+' scan='+s.scan,(a,e)=>JSON.stringify(a)===JSON.stringify(e));
      clearCal(); APP_STATE.calibration.points=[{x:0,y:0},{x:100,y:0}]; setIn('3'); apply(); setIn('5'); APP_STATE.calibration.points=[{x:0,y:0},{x:1,y:0}]; apply(); s=st(); chk('Scale: invalid REFERENCE (points 1 px apart) keeps scale 3 m and restores the field',[s.sc,s.inp,/INVALID REFERENCE/.test(s.label),/dipertahankan/.test(s.label)],[3,'3',true,true],'label='+s.label,(a,e)=>JSON.stringify(a)===JSON.stringify(e));
    } finally {
      try{ APP_STATE.fragments=snap.frags; APP_STATE.calibration=snap.cal; APP_STATE.psd=snap.psd; APP_STATE.psdConfig=snap.cfg; APP_STATE.fragmentLineage=snap.lin;
        APP_STATE.image.manualMode=snap.img.m; APP_STATE.image.selectedId=snap.img.s; APP_STATE.image.selectedIds=snap.img.ss; APP_STATE.image.splitPts=snap.img.sp; APP_STATE.image.splitTargetId=snap.img.st;
        $('knownDistance').value=snap.kd; $('manualSizeCm').value=snap.ms; $('scaleStatus').textContent=snap.ss; $('scanStatus').textContent=snap.sc;
        const extra=APP_STATE.audit.entries.length-snap.au; if(extra>0) APP_STATE.audit.entries.splice(0,extra); recomputePSD(); }catch(e){ pass('P0.2 test sandbox restore',false,'actual='+String(e)+' | expected=state restored | reason=restore must not throw'); }
    }
  }

  function renderFragments(){ const b=$('fragmentTableBody'); b.innerHTML=''; APP_STATE.fragments.slice(0,500).forEach(f=>{const tr=document.createElement('tr'); const cells=[f.id,Math.round(f.area),fmt(f.eqDiameterPx,1),fmt(f.feretPx,1),f.measuredSizeCm!=null?fmt(f.measuredSizeCm,1)+(f.sizeOverride?' (OVERRIDE)':''):(psdScaleCm()===null?'NOT CALIBRATED':'INVALID SIZE'),(f.confidence*100).toFixed(0)+'%',(f.status+(f.psdInclusion&&f.psdInclusion!=='INCLUDED'&&f.psdInclusion!=='EXCLUDED - NOT CALIBRATED'?' ['+f.psdInclusion+']':''))+(f.review?' • REVIEW ('+f.reviewReason+')':'')];cells.forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.appendChild(td)}); const q=document.createElement('td'); const rm=document.createElement('button');rm.className='btn';rm.style.width='auto';rm.style.marginTop='0';rm.textContent='SELECT';rm.addEventListener('click',()=>selectFragment(f.id));q.appendChild(rm);tr.appendChild(q);b.appendChild(tr);}); $('fragCount').textContent=APP_STATE.fragments.length||'0'; $('validFragCount').textContent=APP_STATE.fragments.filter(f=>f.psdInclusion!=='EXCLUDED - INVALID SIZE'&&!psdEstimatePending(f)).length||'0'; { const pp=psdPhys(), na=psdUncalWithObjects()?'NOT AVAILABLE':'--'; $('boulder80').textContent=pp.oversizeCount==null?na:pp.oversizeCount; $('oversizeFraction').textContent=pp.oversizeFraction==null?na:(pp.oversizeFraction*100).toFixed(2)+'%'; } const conf=overallConfidence(); $('overallConfidence').textContent=conf?Math.round(conf*100)+'%':'--'; $('confidenceLabel').textContent='CONFIDENCE: '+confidenceBand(conf); }
  function polygonArea(points){ let a=0; for(let i=0;i<points.length;i++){const j=(i+1)%points.length;a+=points[i].x*points[j].y-points[j].x*points[i].y;} return Math.abs(a)/2; }
  function bboxFromPoints(points){ return points.reduce((b,p)=>({minx:Math.min(b.minx,p.x),maxx:Math.max(b.maxx,p.x),miny:Math.min(b.miny,p.y),maxy:Math.max(b.maxy,p.y)}),{minx:Infinity,maxx:-Infinity,miny:Infinity,maxy:-Infinity}); }
  function simplifyTrace(points,tol=1.75){ if(points.length<=2)return points.slice(); const sqTol=tol*tol; function getSqSegDist(p,a,b){let x=a.x,y=a.y,dx=b.x-x,dy=b.y-y;if(dx!==0||dy!==0){const t=((p.x-x)*dx+(p.y-y)*dy)/(dx*dx+dy*dy);if(t>1){x=b.x;y=b.y;}else if(t>0){x+=dx*t;y+=dy*t;}}dx=p.x-x;dy=p.y-y;return dx*dx+dy*dy;} const keep=new Array(points.length).fill(false);keep[0]=keep[points.length-1]=true;const stack=[[0,points.length-1]];while(stack.length){const [a,b]=stack.pop();let max=sqTol,idx=-1;for(let i=a+1;i<b;i++){const d=getSqSegDist(points[i],points[a],points[b]);if(d>max){idx=i;max=d;}}if(idx>=0){keep[idx]=true;stack.push([a,idx],[idx,b]);}}return points.filter((_,i)=>keep[i]); }
  function pointInPolygon(pt,poly){ let inside=false; for(let i=0,j=poly.length-1;i<poly.length;j=i++){const xi=poly[i][0],yi=poly[i][1],xj=poly[j][0],yj=poly[j][1];const inter=((yi>pt.y)!=(yj>pt.y))&&(pt.x<(xj-xi)*(pt.y-yi)/(yj-yi+1e-12)+xi);if(inter)inside=!inside;} return inside; }
  function maxFeretFromXY(points){ if(points.length<2)return 0; const hull=convexHull(points.map(p=>Array.isArray(p)?p:[p.x,p.y])); let max=0; for(let i=0;i<hull.length;i++)for(let j=i+1;j<hull.length;j++)max=Math.max(max,Math.hypot(hull[i][0]-hull[j][0],hull[i][1]-hull[j][1])); return max; }
  function finalizeManualTrace(){ const raw=Array.isArray(APP_STATE.image.manualTrace)?APP_STATE.image.manualTrace:[]; if(raw.length<12){$('scanStatus').textContent='TRACE ULANG: outline terlalu pendek • TRACE MULTI tetap aktif.';APP_STATE.image.manualTrace=[];drawCanvas();return;} const simplified=simplifyTrace(raw,1.75); if(simplified.length<6){$('scanStatus').textContent='TRACE ULANG: outline belum cukup detail • TRACE MULTI tetap aktif.';APP_STATE.image.manualTrace=[];drawCanvas();return;} const area=polygonArea(simplified),cfg=getPSDConfig(); if(area<Math.max(8,Number(cfg.minArea)||100)){ $('scanStatus').textContent=`TRACE ULANG: area ${Math.round(area)} px < Min Area • TRACE MULTI tetap aktif.`;APP_STATE.image.manualTrace=[];drawCanvas();return;} const b=bboxFromPoints(simplified),xy=simplified.map(p=>[p.x,p.y]),feret=maxFeretFromXY(xy),ed=eqDiam({area}),bb=Math.max(b.maxx-b.minx,b.maxy-b.miny),pxDef=APP_STATE.psd.sizeDefinition==='feret'?feret:APP_STATE.psd.sizeDefinition==='eqdiam'?ed:bb,sc=APP_STATE.calibration.centimetersPerWorkingPixel,measured=sc?pxDef*sc:null,nextId=APP_STATE.fragments.length?Math.max(...APP_STATE.fragments.map(f=>Number(f.id)||0))+1:1,hull=convexHull(xy); const f={id:nextId,area,minx:b.minx,maxx:b.maxx,miny:b.miny,maxy:b.maxy,eqDiameterPx:ed,feretPx:feret,bboxMaxPx:bb,boundary:xy,measuredSizeCm:measured,confidence:1,circularity:(4*Math.PI*area)/Math.max(1,(feret*Math.PI)**2),aspect:Math.max((b.maxx-b.minx+1)/(b.maxy-b.miny+1),(b.maxy-b.miny+1)/(b.maxx-b.minx+1)),solidity:hull.length>=3?area/Math.max(1,polygonArea(hull.map(p=>({x:p[0],y:p[1]})))):1,status:psdStatusFromSize(measured),manual:true,exactPolygon:true,geometryBasis:'EXACT_POLYGON',review:false,reviewReason:'MANUAL OUTLINE',source:'MANUAL',operation:'TRACE',parentIDs:[],createdAt:now()}; APP_STATE.fragments.push(f); APP_STATE.image.selectedIds=[nextId]; APP_STATE.image.selectedId=nextId; $('canvasHint').textContent=`Manual outline #${nextId} ditambahkan • TRACE MULTI tetap aktif.`; audit('Fragment '+nextId,'NONE','ADDED','MANUAL QC','TRACE ROCK OUTLINE'); APP_STATE.image.manualTrace=[]; $('muckpileCanvas').classList.add('kb-trace-active'); $('btnFinishTrace').disabled=false; recomputePSD();renderFragments();syncSelectionState();drawCanvas();$('scanStatus').textContent=`TRACE #${nextId} selesai • TRACE MULTI tetap aktif • gambar batu berikutnya.`; }
  function startTrace(){
    if(!APP_STATE.image.workingCanvas){$('scanStatus').textContent='TRACE ROCK: upload foto terlebih dahulu.';return;}
    if(APP_STATE.image.manualMode==='delete')APP_STATE.image.manualMode=null;
    if(APP_STATE.calibration.mode==='A'||APP_STATE.calibration.mode==='B')setCalibrationMode('CANCEL');
    APP_STATE.image.manualMode='trace';APP_STATE.image.manualTrace=[];
    $('muckpileCanvas').classList.add('kb-trace-active');
    const wrap=document.querySelector('#view-image .kb-canvas-wrap');if(wrap)wrap.classList.add('is-trace-ready');
    $('btnFinishTrace').disabled=false;
    $('canvasHint').textContent='TRACE MULTI ACTIVE • tahan mouse dan ikuti tepi SATU batu • lepas untuk selesai • lanjut trace batu berikutnya.';
    $('scanStatus').textContent='TRACE MULTI aktif. Setiap outline selesai, mode tetap ON.';
    const hint=$('scanTraceDockHint');if(hint)hint.textContent='TRACE AKTIF • gambar outline satu batu langsung pada foto. Setelah selesai, lanjut ke batu berikutnya tanpa menekan tombol lagi.';
    syncSelectionState();drawCanvas();
    $('muckpileCanvas')?.scrollIntoView({behavior:'smooth',block:'center'});
  }
  function cancelTrace(){
    APP_STATE.image.manualMode=null;APP_STATE.image.manualTrace=[];$('muckpileCanvas')?.classList.remove('kb-trace-active');$('btnFinishTrace').disabled=true;
    const wrap=document.querySelector('#view-image .kb-canvas-wrap');if(wrap)wrap.classList.remove('is-trace-ready');
    const hint=$('scanTraceDockHint');if(hint)hint.textContent='Scan hanya membuat/menyegarkan object. Setelah selesai, klik TRACE ROCK lalu gambar outline batu langsung pada foto di atas.';
    syncSelectionState();drawCanvas();
  }
  function selectFragment(id){APP_STATE.image.selectedIds=[id];APP_STATE.image.selectedId=id;syncSelectionState();drawCanvas();}
  function overallConfidence(){ if(!APP_STATE.image.qc) return null; const q=APP_STATE.image.qc; let img=0; img+=(q.resolution==='PASS'?1:.6); img+=(q.contrast==='GOOD'?1:.7); img+=(q.brightness==='GOOD'?1:.7); img+=(q.blur==='LOW'?1:q.blur==='MEDIUM'?.7:.4); const scale=APP_STATE.calibration.quality==='GOOD'?1:APP_STATE.calibration.quality==='FAIR'?.75:APP_STATE.calibration.metersPerWorkingPixel?.5:0; const seg=APP_STATE.fragments.length>=20?1:APP_STATE.fragments.length>=8?.75:APP_STATE.fragments.length>=3?.5:0; const objSep=APP_STATE.fragments.length?Math.min(1,APP_STATE.fragments.filter(f=>f.aspect<4).length/APP_STATE.fragments.length):0; return clamp((img/4*.3)+(scale*.2)+(seg*.25)+(objSep*.15)+(APP_STATE.calibration.points.length===2?.1:0),0,1); }
  function confidenceBand(c){ return c==null?'--':c>=.8?'HIGH':c>=.6?'MEDIUM':'LOW'; }

  function editSize(){ const f=APP_STATE.fragments.find(x=>x.id===APP_STATE.image.selectedId); const raw=$('manualSizeCm').value; const r=applySizeOverride(f?f.id:null,raw===''?NaN:Number(raw)); $('scanStatus').textContent=r.ok?('Size override #'+f.id+' = '+fmt(Number(raw),1)+' cm disimpan (provenance MANUAL EDIT SIZE). Kontur, area, Feret, bbox TIDAK diubah.'):('EDIT SIZE ditolak: '+r.reason); if(r.ok)recomputeFragmentMeasurements(); }
  function removeSelected(){const ids=selectedIdList();if(ids.length>1){deleteSelectedBatch();return;}const id=APP_STATE.image.selectedId;if(!id)return;const old=APP_STATE.fragments.length;APP_STATE.fragments=APP_STATE.fragments.filter(f=>f.id!==id);APP_STATE.image.selectedId=null;APP_STATE.image.selectedIds=[];audit('Fragment '+id,old,APP_STATE.fragments.length,'MANUAL QC','REMOVE OBJECT');recomputePSD();syncSelectionState();}
  function addObjectAtPoint(pt){ const size=Number($('manualSizeCm').value); const cmPerPx=psdScaleCm(); if(cmPerPx===null||!Number.isFinite(size)||size<=0){$('scanStatus').textContent=cmPerPx===null?'Tambah object berukuran cm memerlukan kalibrasi skala yang valid; object tidak ditambahkan.':'Ukuran object harus > 0 cm.';return;} const px=Math.max(4,size/cmPerPx); const half=px/2; const id=APP_STATE.fragments.length?Math.max(...APP_STATE.fragments.map(f=>f.id))+1:1; const f={id,area:Math.PI*(px/2)**2,minx:clamp(pt.x-half,0,$('muckpileCanvas').width),maxx:clamp(pt.x+half,0,$('muckpileCanvas').width),miny:clamp(pt.y-half,0,$('muckpileCanvas').height),maxy:clamp(pt.y+half,0,$('muckpileCanvas').height),eqDiameterPx:px,feretPx:px,bboxMaxPx:px,measuredSizeCm:size,confidence:.6,circularity:1,aspect:1,solidity:1,status:psdStatusFromSize(size),source:'MANUAL_SIZE_ENTRY',operation:'ADD',parentIDs:[],geometryBasis:'NONE',sizeSource:'MANUAL_OVERRIDE',sizeOverride:{valueCm:size,previousMeasuredCm:null,sizeDefinition:APP_STATE.psd.sizeDefinition,geometryPxAtEntry:null,scaleCmPerPxAtEntry:cmPerPx,source:'MANUAL ADD OBJECT',createdAt:now()},review:true,reviewReason:'MANUAL SIZE ENTRY (no contour)',createdAt:now()};APP_STATE.fragments.push(f);audit('Fragment '+id,'NONE','ADDED','MANUAL QC','ADD OBJECT');APP_STATE.image.manualMode=null;recomputePSD();}
  function mergeSelected(){ const id=APP_STATE.image.selectedId; if(!id)return; const f=APP_STATE.fragments.find(x=>x.id===id); if(!f)return; $('scanStatus').textContent='MERGE MODE: klik object target. Hasil = ESTIMASI convex hull (bisa menutup ruang kosong), dikeluarkan dari PSD sampai di-approve.'; APP_STATE.image.manualMode='merge'; }
  function splitSelected(){ const id=APP_STATE.image.selectedId; const f=APP_STATE.fragments.find(x=>x.id===id); if(!f){$('scanStatus').textContent='SPLIT: pilih object terlebih dahulu.';return;} if(!fragPolygon(f).poly){$('scanStatus').textContent='SPLIT dibatalkan: object tidak punya kontur untuk dibagi.';return;} cancelTrace(); if(APP_STATE.calibration.mode==='A'||APP_STATE.calibration.mode==='B')setCalibrationMode('CANCEL'); APP_STATE.image.manualMode='split'; APP_STATE.image.splitTargetId=id; APP_STATE.image.splitPts=[]; $('scanStatus').textContent='SPLIT MODE #'+id+': klik 2 titik untuk garis pemisah (garis harus melewati object dari tepi ke tepi). ESC = batal.'; syncSelectionState(); drawCanvas(); }

  function calculateFinancial__legacy(){ const g=APP_STATE.geometry.result; const f=APP_STATE.financial; const validPrice=f.anfoIdrKg>0; const validSec=f.secondaryIdrUnit>0; const secondaryUnits=Math.max(0,Number(f.secondaryBaselineUnits)||0); const air=clamp(Number(APP_STATE.geometry.input.airDeckPct)||0,0,100);
    /* AUDIT v8: tonase & charge harus berasal dari HASIL kalkulasi geometry (g.totalTonnage/g.totalCharge/g.holeCount),
       bukan dari input design gi.holeCount yang bisa berbeda dari holeCount yang dipakai engine. */
    const materialTonnage=(g&&Number(g.totalTonnage)>0)?g.totalTonnage:0;
    $('finMaterialValue').textContent=(Number(f.limestonePriceIdrTon)>0&&materialTonnage>0)?moneyIDR(f.limestonePriceIdrTon*materialTonnage):'--'; if(!g || !validPrice || !validSec || secondaryUnits<0){APP_STATE.financial.result=null; $('financeStatus').textContent='STATUS: FINANCIAL INPUT INCOMPLETE'; $('finBaseExp').textContent=$('finOptExp').textContent=$('finExpSaving').textContent=$('finBaseSec').textContent=$('finOptSec').textContent=$('finTotalSaving').textContent='--'; return; }
    if(g.validity==='INVALID'){APP_STATE.financial.result=null; $('financeStatus').textContent='STATUS: GEOMETRY INVALID — '+(g.warnings||[]).join(' • '); $('financeStatus').className='kb-warning'; $('finBaseExp').textContent=$('finOptExp').textContent=$('finExpSaving').textContent=$('finBaseSec').textContent=$('finOptSec').textContent=$('finTotalSaving').textContent='--'; return; }
    const baseKg=(Number(g.totalCharge)>0)?g.totalCharge:g.chargeMass*Math.max(1,Math.round(Number(g.holeCount)||0)); /* kg, konsisten dengan engine */
    const optKg=baseKg*(1-air/100); const baseExp=baseKg*f.anfoIdrKg,optExp=optKg*f.anfoIdrKg,expSave=baseExp-optExp; const boulderCount=psdPhys().oversizeCount!=null?psdPhys().oversizeCount:secondaryUnits; const baseSec=boulderCount*f.secondaryIdrUnit; const optSec=baseSec*(1-clamp(f.secondaryReductionPct,0,100)/100); const total=expSave+(baseSec-optSec); APP_STATE.financial.result={baseExp,optExp,expSave,baseSec,optSec,total}; $('financeStatus').textContent=(APP_STATE.psd.oversizeCount==null?'STATUS: SCREENING ESTIMATE • uses demo baseline secondary units':'STATUS: SCREENING ESTIMATE')+(g.validity==='WARNING'?' • GEOMETRY WARNING: '+(g.warnings||[]).join(' • '):'');$('financeStatus').className=g.validity==='WARNING'?'kb-warning':'kb-success'; $('finBaseExp').textContent=moneyIDR(baseExp);$('finOptExp').textContent=moneyIDR(optExp);$('finExpSaving').textContent=moneyIDR(expSave);$('finBaseSec').textContent=moneyIDR(baseSec);$('finOptSec').textContent=moneyIDR(optSec);$('finTotalSaving').textContent=moneyIDR(total); }

  function renderPPVTemplateTable(){
    const box=$('ppvTemplateWrap');if(!box)return;let html='<table class="ppv-template-table"><thead><tr><th>Tgl</th><th>Lokasi/Block</th><th>Kedalaman (m)</th><th>Jarak (m)</th><th>Isian (kg)</th><th>Trans</th><th>Vert</th><th>Long</th><th>PPV Max (mm/s)</th><th>PF (kg/ton)</th><th>Hole</th><th>SD</th></tr></thead><tbody>';
    SEISMIC_TEMPLATE_ROWS.forEach(r=>{html+=`<tr><td>${htmlEscape(r.date)}</td><td>${htmlEscape(r.block)}</td><td>${r.depth==null?'--':r.depth.toFixed(1)}</td><td>${htmlEscape(r.distance)}</td><td>${htmlEscape(r.charge)}</td><td>${r.trans.toFixed(2)}</td><td>${r.vert.toFixed(2)}</td><td>${r.long.toFixed(2)}</td><td>${r.ppv.toFixed(2)}</td><td>${r.pf==null?'--':r.pf.toFixed(2)}</td><td>${r.hole==null?'--':htmlEscape(r.hole)}</td><td>${htmlEscape(r.sd)}</td></tr>`});html+='</tbody></table>';box.innerHTML=html;
  }
  function fitSeismicRows(rows){
    const valid=rows.filter(r=>Number(r.distance)>0&&Number(r.charge)>0&&Number(r.ppv)>0);if(valid.length<3)throw new Error('dataset kurang dari 3 valid rows');
    const xs=valid.map(r=>Math.log(r.distance/Math.sqrt(r.charge))),ys=valid.map(r=>Math.log(r.ppv)),n=xs.length,sx=xs.reduce((a,b)=>a+b,0),sy=ys.reduce((a,b)=>a+b,0),sxx=xs.reduce((a,b)=>a+b*b,0),sxy=xs.reduce((a,b,i)=>a+b*ys[i],0),den=n*sxx-sx*sx,slope=(n*sxy-sx*sy)/(den||1),intercept=(sy-slope*sx)/n,K=Math.exp(intercept),nn=-slope;
    let sse=0,st=0,ym=sy/n;ys.forEach((y,i)=>{const yp=intercept+slope*xs[i];sse+=(y-yp)**2;st+=(y-ym)**2});return{K,n:nn,residual:Math.sqrt(sse/Math.max(1,n-2)),r2:st?1-sse/st:0,rows:valid};
  }
  function fitSeismicTemplate__legacy(){try{const f=fitSeismicRows(SEISMIC_TEMPLATE_ROWS);APP_STATE.seismic.K=f.K;APP_STATE.seismic.n=f.n;APP_STATE.seismic.fit={status:'TEMPLATE SITE FIT',residual:f.residual,r2:f.r2,rows:f.rows};$('ppvK').value=f.K.toFixed(4);$('ppvN').value=f.n.toFixed(4);$('seismicFitStatus').textContent=`TEMPLATE FIT: ${f.rows.length} rows • K ${f.K.toFixed(4)} • n ${f.n.toFixed(4)} • R² ${f.r2.toFixed(3)}`;updateSeismic();audit('PPV K/n','',''+f.K.toFixed(4)+' / '+f.n.toFixed(4),'USER TEMPLATE','FIT TEMPLATE DATA')}catch(e){$('seismicFitStatus').textContent='FIT FAILED: '+e.message}}
  function downloadSeismicTemplate(){const headers=['Tanggal','Lokasi_Block','Kedalaman_m','Jarak_m','Isian_kg','Trans_mm_s','Vert_mm_s','Long_mm_s','PPV_Max_mm_s','PF_kg_ton','Hole','SD'];const lines=SEISMIC_TEMPLATE_ROWS.map(r=>[r.date,r.block,r.depth,r.distance,r.charge,r.trans,r.vert,r.long,r.ppv,r.pf,r.hole,r.sd].map(v=>v??''));downloadText('Template_PPV_Site_2026.csv',headers.join(',')+'\n'+lines.map(a=>a.join(',')).join('\n'),'text/csv')}

  function renderPPVRangeWarn(){
    const el=$('ppvRangeWarn');if(!el)return;const R=SEISMIC_REF,s=APP_STATE.seismic,isRef=Math.abs((s.K||0)-R.K)<1e-6&&Math.abs((s.n||0)-R.n)<1e-6;
    const sd=(s.D>0&&s.W>0)?s.D/Math.sqrt(s.W):null;let t='';
    if(isRef){
      t=`PERHATIAN: regresi ${R.file} memakai garis 95% (batas atas, konservatif) dengan R² = ${R.r2.toFixed(3).replace('.',',')} (rendah: hanya sekitar ${Math.round(R.r2*100)}% variasi PPV dijelaskan oleh jarak-terskala). `;
      if(sd!=null&&(sd<R.sdMin||sd>R.sdMax))t+=`EKSTRAPOLASI: SD = ${sd.toFixed(1)} m/kg^½ di luar rentang data (${R.sdMin}–${R.sdMax}); hasil PPV tidak didukung data. `;
      t+='Screening, bukan validasi lapangan.';
    }
    el.textContent=t;el.classList.toggle('kb-hidden',!t);
  }
  function applySeismicRef__legacy(){
    const R=SEISMIC_REF;$('ppvK').value=R.K.toFixed(1);$('ppvN').value=R.n.toFixed(3);
    APP_STATE.seismic.fit={status:R.label,residual:R.sigma,r2:R.r2};
    audit('PPV K/n','',`${R.K} / ${R.n}`,'USER TEMPLATE','PAKAI REGRESI GETARAN.SDF');updateSeismic();
  }
  function updateSeismic__legacy(){ const K=Number($('ppvK').value)||null,n=Number($('ppvN').value)||null,D=Number($('ppvD').value),W=Number($('ppvW').value); APP_STATE.seismic.K=K;APP_STATE.seismic.n=n;APP_STATE.seismic.D=D;APP_STATE.seismic.W=W; if(K&&n&&D>0&&W>0){APP_STATE.seismic.ppv=K*Math.pow(D/Math.sqrt(W),-n);APP_STATE.seismic.fit.status=APP_STATE.seismic.fit.status==='NO SITE FIT'?'MANUAL SCREENING PARAMETERS':APP_STATE.seismic.fit.status;}else APP_STATE.seismic.ppv=null; $('ppvValue').textContent=APP_STATE.seismic.ppv==null?'--':fmt(APP_STATE.seismic.ppv,3)+' mm/s';$('ppvKOut').textContent=K?fmt(K,3):'--';$('ppvNOut').textContent=n?fmt(n,3):'--';$('telemetryStatus').textContent=APP_STATE.seismic.ppv==null?'NO FIT':APP_STATE.seismic.fit.status; if(APP_STATE.seismic.fit.status==='DEMO SCREENING PARAMETERS') $('seismicFitStatus').textContent='STATUS: DEMO SCREENING PARAMETERS • replace with measured site dataset'; else if(APP_STATE.seismic.fit.status===SEISMIC_REF.label) $('seismicFitStatus').textContent=`STATUS: ${SEISMIC_REF.label} • K ${SEISMIC_REF.K.toFixed(1)} • n ${SEISMIC_REF.n.toFixed(3)} • R² ${SEISMIC_REF.r2.toFixed(3)} • σ ${SEISMIC_REF.sigma.toFixed(3)} (95% line)`;renderPPVRangeWarn();renderPPVChart();refreshAll(); }
  function fitSeismicCsv__legacy(file){ { const big=kbFileTooBig(file,'csv'); if(big){ $('seismicFitStatus').textContent='IMPORT FAILED: '+big; return; } } if(typeof Papa==='undefined'){ $('seismicFitStatus').textContent='PapaParse unavailable';return;} Papa.parse(file,{header:true,skipEmptyLines:true,complete:res=>{ try{const rows=res.data.map(r=>({D:Number(r.distance_m),W:Number(r.charge_kg),ppv:Number(r.ppv_mm_s),delay:Number(r.delay_ms)})).filter(r=>r.D>0&&r.W>0&&r.ppv>0); if(rows.length<3) throw new Error('dataset kurang dari 3 valid rows'); const xs=rows.map(r=>Math.log(r.D/Math.sqrt(r.W))),ys=rows.map(r=>Math.log(r.ppv)); const n=xs.length,sx=xs.reduce((a,b)=>a+b,0),sy=ys.reduce((a,b)=>a+b,0),sxx=xs.reduce((a,b)=>a+b*b,0),sxy=xs.reduce((a,b,i)=>a+b*ys[i],0); const den=n*sxx-sx*sx; const slope=(n*sxy-sx*sy)/(den||1); const intercept=(sy-slope*sx)/n; const K=Math.exp(intercept),nn=-slope; let sse=0,st=0,ym=sy/n;ys.forEach((y,i)=>{const yp=intercept+slope*xs[i];sse+=(y-yp)**2;st+=(y-ym)**2}); APP_STATE.seismic.K=K;APP_STATE.seismic.n=nn;APP_STATE.seismic.fit={status:'SITE FIT',residual:Math.sqrt(sse/Math.max(1,n-2)),r2:st?1-sse/st:0,rows};$('ppvK').value=K.toFixed(4);$('ppvN').value=nn.toFixed(4);$('seismicFitStatus').textContent=`SITE FIT: ${rows.length} rows • R² ${APP_STATE.seismic.fit.r2.toFixed(3)} • residual ${APP_STATE.seismic.fit.residual.toFixed(3)}`;audit('PPV K/n','',`${K.toFixed(4)} / ${nn.toFixed(4)}`,'MEASURED DATASET','FIT K/N');updateSeismic();}catch(e){$('seismicFitStatus').textContent='FIT FAILED: '+e.message;} }}); }
  function chartIsActive(id){ const el=$(id); if(!el)return false; const v=el.closest('.kb-view'); return !v || v.classList.contains('active'); }
  function renderPPVChart(){
    if(typeof Plotly==='undefined' || typeof Plotly.react!=='function') return;
    const el=$('ppvChart'); if(!el) return;
    const v=el.closest('.kb-view'); if(v && !v.classList.contains('active')) return;
    try{
      if(!APP_STATE.seismic.K||!APP_STATE.seismic.n){Plotly.react(el,[],{margin:{l:55,r:18,t:20,b:42},xaxis:{title:'Distance (m)'},yaxis:{title:'PPV (mm/s)'},annotations:[{text:'NO SITE FIT',showarrow:false}]});return;}
      const xs=[],ys=[];for(let d=25;d<=1000;d+=10){xs.push(d);ys.push(APP_STATE.seismic.K*Math.pow(d/Math.sqrt(APP_STATE.seismic.W),-APP_STATE.seismic.n));}
      Plotly.react(el,[{x:xs,y:ys,type:'scatter',mode:'lines',name:'PPV model'},{x:[APP_STATE.seismic.D],y:[APP_STATE.seismic.ppv],type:'scatter',mode:'markers',name:'Selected point'}],{margin:{l:55,r:18,t:20,b:42},xaxis:{title:'Distance (m)'},yaxis:{title:'PPV (mm/s)'},paper_bgcolor:'#f4f2eb',plot_bgcolor:'#f4f2eb',font:{family:'IBM Plex Sans, Arial, sans-serif',size:11}});
    }catch(e){ el.textContent='Grafik PPV tidak tersedia pada konfigurasi browser ini.'; }
  }

  function renderPsdMainChart(){ if(typeof Plotly==='undefined'||typeof Plotly.react!=='function'||!chartIsActive('psdChart')) return; const cal=psdScaleCm()!==null, u=cal?'cm':'px'; const sizes=(cal?APP_STATE.fragments.map(f=>f.measuredSizeCm):APP_STATE.fragments.map(psdPxOf)).filter(x=>x!==null&&Number.isFinite(x)&&x>0).sort((a,b)=>a-b); const xt=cal?psdDefLabel()+' (cm)':psdDefLabel()+' (px) - pixel-only, NOT CALIBRATED'; if(!sizes.length){Plotly.react('psdChart',[],{margin:{l:55,r:18,t:20,b:42},annotations:[{text:'WAITING FOR ACTUAL FIELD IMAGE',showarrow:false}],xaxis:{title:xt},yaxis:{title:'Cumulative passing (%)',range:[0,100]}});return;} const x=sizes,y=sizes.map((_,i)=>100*(i+1)/sizes.length); const tr=[{x,y,type:'scatter',mode:'markers',name:cal?'Actual PSD':'Actual PSD (pixel-only)'}]; if(cal){ const fitX=[],fitY=[]; if(APP_STATE.psd.xc&&APP_STATE.psd.n){const mx=Math.max(...sizes);for(let i=1;i<=100;i++){const xx=Math.max(0.1,mx*i/100);fitX.push(xx);fitY.push(100*(1-Math.exp(-Math.pow(xx/APP_STATE.psd.xc,APP_STATE.psd.n))));}} tr.push({x:fitX,y:fitY,type:'scatter',mode:'lines',name:'Rosin-Rammler fit'},{x:[psdOversizeThresholdCm(),psdOversizeThresholdCm()],y:[0,100],type:'scatter',mode:'lines',name:`${fmt(psdOversizeThresholdCm(),1)} cm threshold`}); } Plotly.react('psdChart',tr,{margin:{l:55,r:18,t:20,b:42},xaxis:{title:xt},yaxis:{title:'Cumulative passing (%)',range:[0,100]},paper_bgcolor:'#f4f2eb',plot_bgcolor:'#f4f2eb',font:{family:'IBM Plex Sans, Arial, sans-serif',size:11}}); }
  function updateCharts(){ if(typeof Plotly==='undefined' || typeof Plotly.react!=='function') return; renderMvpPsdChart(); renderPsdMainChart(); const cats=['Fragmentation','Oversize','Seismic','Data Quality','Traceability']; const pp=psdPhys(),frag=pp.x80?clamp(100*80/pp.x80,0,100):null,over=pp.oversizeFraction!=null?100*(1-pp.oversizeFraction):null,sev=APP_STATE.seismic.ppv?clamp(100-APP_STATE.seismic.ppv*2,0,100):0,dq=overallConfidence()?overallConfidence()*100:0,tr=APP_STATE.audit.entries.length?100:0; if(chartIsActive('radarChart')) Plotly.react('radarChart',[{type:'scatterpolar',r:[frag,over,sev,dq,tr],a:cats,fill:'toself'}],{margin:{l:30,r:30,t:20,b:20},polar:{radialaxis:{range:[0,100],showticklabels:false}},paper_bgcolor:'#f4f2eb',font:{family:'IBM Plex Sans, Arial, sans-serif',size:10},showlegend:false}); }

  function refreshDesignMetrics(){ psdRefreshThresholdLabels(); const p=psdPhys(), na=psdUncalWithObjects()?'NOT AVAILABLE':'--'; $('actualX50').textContent=p.x50!=null?fmt(p.x50,1)+' cm':na;$('actualX80').textContent=p.x80!=null?fmt(p.x80,1)+' cm':na;$('actualBoulderCount').textContent=p.oversizeCount==null?na:String(p.oversizeCount);$('actualOversize').textContent=p.oversizeFraction==null?na:(p.oversizeFraction*100).toFixed(2)+'%';$('rrOversize').textContent=psdRrFracLabel(p,na);$('rrR2').textContent=psdR2Label(p,na); const t=APP_STATE.geometry.input.targetX80; if(p.x80==null){$('targetStatus').textContent=psdUncalWithObjects()?`STATUS: NOT AVAILABLE • photo not calibrated${APP_STATE.psd.x80Px!=null?' (pixel-only X80 '+fmt(APP_STATE.psd.x80Px,1)+' px, not comparable with the cm target)':''}`:'STATUS: WAITING FOR ACTUAL FIELD IMAGE';$('targetStatus').className='kb-warning';} else if(!Number.isFinite(t)||t<=0){$('targetStatus').textContent=`STATUS: TARGET X80 NOT SET • Actual X80 ${p.x80.toFixed(1)} cm`;$('targetStatus').className='kb-warning';} else {const st=p.x80<=t?'PASS':p.x80<=t*1.15?'WATCH':'FAIL';$('targetStatus').textContent=`STATUS: ${st} • Actual X80 ${p.x80.toFixed(1)} cm • Target ${t.toFixed(1)} cm`;$('targetStatus').className=st==='PASS'?'kb-success':st==='WATCH'?'kb-warning':'kb-danger';} }
  function refreshReport(){
    const q=activeLabQualityKey(), meta=qualityMeta(q), lp=getActiveLabProfile();
    $('rProject').textContent=APP_STATE.project.id||'--';
    $('rFormation').textContent=APP_STATE.formation.label;
    $('rLabQuality').textContent=lp?`${q} • ${meta.name} • ${meta.description} • ${lp.sampleCount} rows`:'NO LAB QUALITY';
    $('rMaterialSource').textContent=lp?`LAB • ${lp.source||'embedded'} • ${lp.sheetName||'Analisa Sample'} • ACTIVE ${q}`:'LAB: NOT AVAILABLE';
    $('rFormula').textContent=APP_STATE.formula.key==='ash'?'R.L. Ash':APP_STATE.formula.key==='mae'?'MAE (Modified Available Energy)':'Calvin Konya';
    const g=APP_STATE.geometry.result;
    $('rGeometry').textContent=g?`B ${g.B.toFixed(2)} m • S ${g.S.toFixed(2)} m • T ${g.T.toFixed(2)} m • J ${g.J.toFixed(2)} m • Charge ${g.chargeMass.toFixed(2)} kg/hole`:'NOT CALCULATED';
    const pp=psdPhys(), uc=psdUncalWithObjects(); $('rImage').textContent=pp.x50!=null?`X50 ${pp.x50.toFixed(1)} cm • X80 ${pp.x80.toFixed(1)} cm`:(uc?`NOT AVAILABLE • photo not calibrated${APP_STATE.psd.x50Px!=null?` (pixel-only: X50 ${APP_STATE.psd.x50Px.toFixed(1)} px • X80 ${APP_STATE.psd.x80Px.toFixed(1)} px — not physical)`:''}`:'No actual image result');
    $('rBoulder').textContent=pp.oversizeCount==null?(uc?'NOT AVAILABLE • photo not calibrated':'NOT AVAILABLE'):`${pp.oversizeCount} detected actual >${fmt(psdOversizeThresholdCm(),1)} cm • fraction ${(pp.oversizeFraction*100).toFixed(2)}%`;
    $('rRR').textContent=pp.rrOversizeFraction==null?(uc?'NOT AVAILABLE • photo not calibrated':psdRrStatusText(pp)):`Xc ${pp.xc.toFixed(2)} cm • n ${pp.n.toFixed(3)} • R² ${pp.r2.toFixed(3)} • estimated >${fmt(psdOversizeThresholdCm(),1)} cm ${(pp.rrOversizeFraction*100).toFixed(2)}%`;
    $('rSeismic').textContent=APP_STATE.seismic.ppv==null?'NO SITE FIT':`PPV ${APP_STATE.seismic.ppv.toFixed(3)} mm/s • K ${APP_STATE.seismic.K.toFixed(4)} • n ${APP_STATE.seismic.n.toFixed(4)} • ${APP_STATE.seismic.fit.status}`;
    $('rFinancial').textContent=APP_STATE.financial.result?`Total saving ${moneyIDR(APP_STATE.financial.result.total)} • screening estimate${APP_STATE.financial.result.demo?' • DEMO EXAMPLE – NOT PROJECT COST':''}`:'COST STATUS: WAITING FOR QUOTATION';
    const sim=APP_STATE.simulation.result, rec=[];
    if(lp) rec.push(`Material aktif ${q} — ${meta.description}.`);
    if(pp.oversizeCount!=null) rec.push(pp.oversizeCount>0?`Oversize >${fmt(psdOversizeThresholdCm(),1)} cm terdeteksi; lakukan review blast geometry dan image QC.`:`Tidak terdeteksi fragmen >${fmt(psdOversizeThresholdCm(),1)} cm pada dataset yang dianalisis.`);
    if(!uc&&APP_STATE.psd.fitStatus==='INSUFFICIENT SAMPLE') rec.push('Rosin-Rammler tidak boleh dipaksakan; tambah jumlah fragment valid.'); if(!uc&&(APP_STATE.psd.fitStatus==='FIT FAILED'||APP_STATE.psd.fitStatus==='FIT POOR')) rec.push('Rosin-Rammler '+APP_STATE.psd.fitStatus+': '+(APP_STATE.psd.rrReason||'')+'. Fraksi oversize prediksi tidak dipakai.');
    if(psdScaleCm()===null) rec.push('Ukuran fisik dinonaktifkan sampai skala dikalibrasi.');
    $('rRecommendation').textContent=rec.join(' ');
    $('rDataQuality').textContent=confidenceBand(overallConfidence());
    $('rModelStatus').textContent=(APP_STATE.fragments.length?'COMPUTER VISION SCREENING + CALCULATED':'WAITING FOR ACTUAL FIELD IMAGE')+(sim?` • Charging simulation: ${sim.level}/${sim.technique}`:'');
    renderKzReport();
    try{ renderWipComparisonPanel('rKzWipCompare'); }catch(_e){} /* Phase 2: Wipfrag comparison in report tab */
  }

  function renderAudit(){ const b=$('auditTableBody');b.innerHTML=''; APP_STATE.audit.entries.slice(0,500).forEach(e=>{const tr=document.createElement('tr');[e.timestamp,e.parameter,e.oldValue,e.newValue,e.source,e.action].forEach(v=>{const td=document.createElement('td');td.textContent=String(v??'');tr.appendChild(td)});b.appendChild(tr)}); }

  function validateHtmlIntegrity(){ const parser=new DOMParser(); const doc=parser.parseFromString(document.documentElement.outerHTML,'text/html'); const ids=[...doc.querySelectorAll('[id]')].map(x=>x.id); const dup=ids.filter((x,i)=>ids.indexOf(x)!==i); /* REQ-02: kecualikan ID milik vendor (Plotly) yang memang duplikat by design */ const VENDOR_ID_PREFIXES=['plotly','js-','cartesianlayer','geo','scene','polar','ternary','gl','legend','colorbar','hover','draglayer','infolayer']; const VENDOR_EXACT_IDS=new Set(['symbol']); const isVendor=id=>{ const lo=id.toLowerCase(); return VENDOR_EXACT_IDS.has(lo)||VENDOR_ID_PREFIXES.some(p=>lo.startsWith(p)); }; const appDup=dup.filter(id=>!isVendor(id)); return {ok:appDup.length===0,duplicateIds:[...new Set(appDup)],vendorDuplicateIds:[...new Set(dup.filter(id=>isVendor(id)))]}; }
  /* Tes parser tempel Wipfrag (data nyata dari lembar BB-6: persen campur, header, desimal koma, 4 kolom) */
  function runWipParseTests(pass){
    const sz=[0.1,0.15,0.22,0.32,0.46,0.68,1,1.47,2.15,3.16,4.64,6.81,10,14.7,21.5,31.6,46.4,68.1,100,147,215,316,464,681,1000];
    const pc=Array(15).fill('0%').concat(['1%','1%','2%','5%','25%','70%','0.908','1','1','1']);
    const mk=(f,e,h)=>(h?'Percent Passing\tSize (mm)'+e:'')+pc.map((p,i)=>p.replace('.',f)+'\t'+String(sz[i]).replace('.',f)).join(e)+e;
    const q=kzParseWip(mk('.','\r\n',true)), at=(r,x)=>{ const z=r.rows.find(v=>v[1]===x); return z?z[0]:null; };
    pass('Wipfrag parser: 25 baris + header dilewati',!!q.rows&&q.rows.length===25&&q.headers===1,'actual='+(q.rows?q.rows.length:q.err)+' | expected=25 baris, 1 header');
    pass('Wipfrag parser: persen campur (1% vs 1 = 100%)',!!q.rows&&Math.abs(at(q,31.6)-0.01)<1e-9&&Math.abs(at(q,316)-0.908)<1e-9&&at(q,464)===1&&at(q,1000)===1,'actual=31.6mm:'+(q.rows&&at(q,31.6))+' 316mm:'+(q.rows&&at(q,316))+' 464mm:'+(q.rows&&at(q,464))+' | expected=0.01, 0.908, 1');
    const k=kzParseWip(mk(',','\r\n',false));
    pass('Wipfrag parser: desimal koma = desimal titik',!!k.rows&&k.rows.length===25&&k.rows.every((v,i)=>v[1]===q.rows[i][1]&&Math.abs(v[0]-q.rows[i][0])<1e-9),'actual='+(k.rows?k.rows.length:k.err)+' | expected=25 baris identik');
    const w=kzParseWip('0%\t50\t0%\t0.1\r\n5%\t100\t1%\t31.6\r\n12%\t150\t25%\t147\r\n21%\t200\t70%\t215');
    pass('Wipfrag parser: tempelan 4 kolom ditolak',!!w.err&&!w.rows,'actual='+(w.err||('terbaca '+(w.rows&&w.rows.length)+' baris'))+' | expected=err');
  }
  function runKzReportTests(pass){
    const W={'g|1':{rows:KZ_WIP_SAMPLE.map(q=>[q[0],q[1]]),label:'uji',t:1},'tanpa':{rows:[[0,1],[1,2],[1,3]]},'h|2':{rows:[[0,1],[1,2]]}}, a=kzSanitize({wipBy:W}).wipBy, b=kzSanitize({wipBy:a}).wipBy;
    pass('Wipfrag: kzSanitize idempoten & menolak entri tak valid',JSON.stringify(a)===JSON.stringify(b)&&Object.keys(a).join()==='g|1','actual='+Object.keys(a).join()+' | expected=g|1 (dua kali sanitasi identik)');
    const st=APP_STATE.kuzram,id=kzWipId(),ta=$('kzWipTxt'); if(!id||!$('rKzModel')||!$('kzPanel')){ pass('Laporan Kuz-Ram mengikuti Wipfrag blast aktif',true,'dilewati: tidak ada blast aktif / panel belum ada'); return; }
    const bak={wipBy:st.wipBy,simSrc:st.simSrc,txt:ta?ta.value:null};
    try{
      st.wipBy=Object.assign({},bak.wipBy); delete st.wipBy[id.key]; st.simSrc='kuzram'; const r0=kzRender();
      if(!r0||r0.blocked){ pass('Laporan Kuz-Ram mengikuti Wipfrag blast aktif',true,'dilewati: geometri blast aktif belum lengkap'); return; }
      const m0=$('rKzModel').textContent,x0=$('rKzResult').textContent;
      st.wipBy[id.key]={rows:KZ_WIP_SAMPLE.map(q=>[q[0],q[1]]),label:id.label,t:0}; st.simSrc='wipfrag'; kzRender();
      const m1=$('rKzModel').textContent,x1=$('rKzResult').textContent;
      pass('Laporan Kuz-Ram mengikuti Wipfrag blast aktif',m0.includes('PSD simulasi: KUZ-RAM')&&!/Wipfrag: /.test(x0)&&m1.includes('PSD simulasi: WIPFRAG '+id.label)&&/Wipfrag: X50=[\d.]+ cm, X80=[\d.]+ cm/.test(x1),'actual=tanpa data: "'+m0.slice(-30)+'" | dengan data: "'+m1.slice(-40)+'" / "'+x1.slice(-44)+'" | expected=KUZ-RAM lalu WIPFRAG + kalimat Wipfrag');
    } finally { st.wipBy=bak.wipBy; st.simSrc=bak.simSrc; if(ta&&bak.txt!=null) ta.value=bak.txt; kzRender(); }
  }
  /* ===== TAHAP-1 HARDENING: regression cover untuk seleksi baris blast, screening stale, hapus baris manual, sanitasi payload ===== */
  function runTahap1HardeningTests(pass){
    const sim=APP_STATE.simulation;
    const bak={t:sim.template,r:sim.activeBlastRow,g:sim.groupLabel,ov:JSON.stringify(sim.rowOverrides||{}),cb:JSON.stringify(sim.customBlocks||[]),rec:JSON.stringify(APP_STATE.geometry.actualRecord||{}),wip:JSON.stringify((APP_STATE.kuzram&&APP_STATE.kuzram.wipBy)||{})};
    const confirmBak=window.confirm;
    try{
      /* 1 • mengetik di field simulator tidak boleh menulis kunci template palsu yang lalu ikut dipersist */
      const el=$('simHoleCount'), keyBefore=sim.template;
      if(el){
        const vBak=el.value; el.value=String((Number(el.value)||4)+1); el.dispatchEvent(new Event('input',{bubbles:true}));
        pass('Simulator tidak menulis kunci template palsu', !!BLAST_SHEET_ROWS[sim.template]&&sim.template===keyBefore, `actual=${sim.template} | expected=${keyBefore} (group aktif tetap terikat ke Blast Plan)`);
        el.value=vBak; el.dispatchEvent(new Event('input',{bubbles:true}));
      } else pass('Simulator tidak menulis kunci template palsu',false,'actual=field #simHoleCount tidak ditemukan');
      /* 2 • pemilih baris tidak boleh dibiarkan kosong untuk group aktif */
      const rows=(BLAST_SHEET_ROWS[sim.template]&&BLAST_SHEET_ROWS[sim.template].rows)||[], sel=$('blastRowSelect');
      populateBlastRowSelect();
      if(!sel||!rows.length) pass('Pemilih baris sinkron dengan group aktif',true,'dilewati: group aktif tidak punya baris / select tidak ada');
      else pass('Pemilih baris sinkron dengan group aktif', sel.options.length===rows.length&&Number(sel.value)===Number(sim.activeBlastRow), `actual=${sel.options.length} opsi, value=${sel.value} | expected=${rows.length} opsi, row ${sim.activeBlastRow}`);
      /* 3 • hasil screening wajib ditandai STALE (bukan CALCULATED) begitu baris blast aktif berubah */
      const badge=$('screeningStatus');
      if(!badge) pass('Screening ditandai STALE setelah baris blast berubah',true,'dilewati: panel screening tidak ada');
      else{
        runScreeningCalculation();
        if(String(badge.textContent||'').trim()!=='CALCULATED') pass('Screening ditandai STALE setelah baris blast berubah',true,'dilewati: screening terblokir '+badge.textContent);
        else{
          const first=rows.length?rows[0].no:1, alt=rows.map(r=>Number(r.no)).find(n=>n!==first);
          if(alt==null) pass('Screening ditandai STALE setelah baris blast berubah',true,'dilewati: group aktif hanya punya satu baris');
          else{
            loadBlastSheetRow(sim.template,alt); const after=String(badge.textContent||'').trim(); const isStale=after.indexOf('STALE')>=0;
            const radar=$('radarFlyrockValue'), radarOk=!radar||radar.textContent==='--';
            loadBlastSheetRow(sim.template,first); runScreeningCalculation();
            pass('Screening ditandai STALE setelah baris blast berubah', isStale&&radarOk, `actual=${after}${radarOk?'':' (radar masih menunjukkan run lama)'}`);
          }
        }
      }
      /* 4 • hapus baris manual bekerja dan membersihkan turunan datanya */
      const mk=getOrCreateManualBlastGroup('UJI TAHAP1 HAPUS BARIS');
      if(!mk||!BLAST_SHEET_ROWS[mk.key]) pass('Hapus baris manual + bersih-bersih turunannya',false,'actual=blok manual uji gagal dibuat');
      else{
        const key=mk.key; let ok4=true, msg=[];
        try{
          while((BLAST_SHEET_ROWS[key].rows||[]).length<2) addManualBlastRow(key);
          const g=BLAST_SHEET_ROWS[key], n0=g.rows.length, delNo=Number(g.rows[n0-1].no), rk=blastRowOverrideKey(key,delNo);
          sim.template=key; sim.groupLabel=g.label; sim.activeBlastRow=delNo;
          pdRecStore()[rk]={depth:9.9,_sources:{depth:'INPUT MANUAL'}};
          ensureBlastRowOverrides()[rk]={holes:5};
          (APP_STATE.kuzram.wipBy=APP_STATE.kuzram.wipBy||{})[key+'|'+delNo]={rows:[[0,1],[1,2]],label:'uji',t:0};
          window.confirm=()=>true;
          $('pdBtnDeleteManualRow')?$('pdBtnDeleteManualRow').click():(deleteManualBlastRow(key,delNo));
          ok4 = ok4 && g.rows.length===n0-1 && !g.rows.some(r=>Number(r.no)===delNo);
          ok4 = ok4 && !(rk in pdRecStore()) && !(rk in (sim.rowOverrides||{})) && !(key+'|'+delNo in (APP_STATE.kuzram.wipBy||{}));
          ok4 = ok4 && Number(sim.activeBlastRow)!==delNo;
          if(g.rows.length!==n0-1) msg.push(`sisa baris ${g.rows.length}/${n0-1}`);
          if((rk in pdRecStore())||(rk in (sim.rowOverrides||{}))||(key+'|'+delNo in (APP_STATE.kuzram.wipBy||{}))) msg.push('data turunan masih ada');
          while(g.rows.length>1) deleteManualBlastRow(key,Number(g.rows[g.rows.length-1].no));
          sim.activeBlastRow=Number(g.rows[0].no); const info=$('pdSourceInfo');
          $('pdBtnDeleteManualRow')?$('pdBtnDeleteManualRow').click():(deleteManualBlastRow(key,g.rows[0].no));
          ok4 = ok4 && g.rows.length===1;
          if(g.rows.length!==1) msg.push(`baris terakhir ikut terhapus (${g.rows.length})`);
          pass('Hapus baris manual + bersih-bersih turunannya', ok4, msg.length?('actual='+msg.join(', ')):`actual=${n0}→${n0-1} baris, catatan/override/Wipfrag baris ${delNo} dibersihkan, baris terakhir ditolak`);
          /* 4b • baris template bawaan tidak dapat dihapus */
          const beforeKeys=Object.keys(BLAST_SHEET_ROWS).length, g1=(BLAST_SHEET_ROWS.group1&&BLAST_SHEET_ROWS.group1.rows||[]).length;
          sim.template='group1'; sim.activeBlastRow=Number((BLAST_SHEET_ROWS.group1.rows||[])[0]?.no||1);
          const btn=$('pdBtnDeleteManualRow'); if(btn) btn.click(); else ok4=false;
          pass('Baris template bawaan dilindungi dari penghapusan', Object.keys(BLAST_SHEET_ROWS).length===beforeKeys && (BLAST_SHEET_ROWS.group1.rows||[]).length===g1 && (!info||/MANUAL/i.test(String(info.textContent||''))), `actual=${(BLAST_SHEET_ROWS.group1.rows||[]).length} baris group1, pesan="${info?String(info.textContent||'').slice(0,40):'-'}"`);
          if(!btn) pass('Tombol HAPUS BARIS MANUAL tersedia',false,'actual=#pdBtnDeleteManualRow tidak ada');
          else pass('Tombol HAPUS BARIS MANUAL tersedia',true,'id=pdBtnDeleteManualRow');
        } finally { delete BLAST_SHEET_ROWS[key]; sim.customBlocks=(sim.customBlocks||[]).filter(x=>x&&x.key!==key); }
      }
      /* 5 • payload lama dengan projectBlasts rusak disanitasi, tidak ditelan mentah-mentah */
      const bad=migratePersistedState({version:11,projectBlasts:{blasts:[{id:'X',burden:Number.NaN,name:'n'.repeat(500)},'bukan-objek',{burden:2.5}],activeId:'TIDAK-ADA',runMode:'batch',mapping:'rusak'}});
      const pb=bad&&bad.projectBlasts;
      pass('Payload lama: projectBlasts rusak disanitasi', !!pb&&Array.isArray(pb.blasts)&&pb.blasts.length===2&&pb.blasts[0].burden===undefined&&pb.blasts[1].burden===2.5&&String(pb.activeId)===String(pb.blasts[0].id)&&pb.runMode==='single'&&!!pb.mapping&&typeof pb.mapping==='object'&&!Array.isArray(pb.mapping)&&(pb.blasts[0].name||'').length<=120, pb?`actual=${pb.blasts.length} blast, active=${pb.activeId}, mode=${pb.runMode}`:'actual=migrate menolak payload');
      pass('Payload lama: projectBlasts bukan array → fallback default', (()=>{const m=migratePersistedState({version:11,projectBlasts:{blasts:'bukan-array'}});return !!m&&Array.isArray(m.projectBlasts.blasts)&&m.projectBlasts.blasts.length>0&&m.projectBlasts.activeId===String(m.projectBlasts.blasts[0].id);})(),'expected=initProjectBlastsState() dipakai lagi');
      const polluted=migratePersistedState(JSON.parse('{"version":11,"projectBlasts":{"blasts":[{"__proto__":{"kbPolluted":1},"burden":2.5}]}}'));
      const it=polluted&&polluted.projectBlasts&&polluted.projectBlasts.blasts&&polluted.projectBlasts.blasts[0];
      const clean=!!it&&Object.getPrototypeOf(it)===Object.prototype&&it.burden===2.5&&({}).kbPolluted===undefined&&!Object.getOwnPropertyNames(it).includes('__proto__');
      pass('Prototype tidak tercemar dari payload lama', clean, `actual=proto bersih=${it?Object.getPrototypeOf(it)===Object.prototype:'n/a'}, own __proto__=${it?Object.getOwnPropertyNames(it).includes('__proto__'):'n/a'}, global kbPolluted=${({}).kbPolluted}, burden=${it&&it.burden}`);
    }catch(e){
      pass('Tahap-1 hardening suite selesai',false,'actual='+String(e&&e.stack||e));
    }finally{
      window.confirm=confirmBak;
      try{ APP_STATE.geometry.actualRecord=JSON.parse(bak.rec); sim.rowOverrides=JSON.parse(bak.ov); sim.customBlocks=JSON.parse(bak.cb); sim.template=bak.t; sim.activeBlastRow=bak.r; sim.groupLabel=bak.g; APP_STATE.kuzram.wipBy=JSON.parse(bak.wip); populateBlastRowSelect(); loadBlastSheetRow(bak.t,bak.r); try{ runScreeningCalculation(); }catch(_e){} }catch(_e){}
    }
  }
  /* ===== TAHAP 2 Wipfrag Comparison Tests =====
     Tests snapshot storage, sanitization, delta calculation, % error, MAE, and report integration.
     All state changes are isolated and restored in the finally block.
     Assertions use the convention: ΔX = Wipfrag − Kuz-Ram snapshot. */
  function runTahap2WipCompareTests(pass){
    const T=(n,ok,m)=>pass('TAHAP 2 WIP-COMPARE • '+n,!!ok,m||'');
    const bakWip=JSON.stringify(APP_STATE.kuzram&&APP_STATE.kuzram.wipBy||{});
    const bakEl=($('rKzWipCompare'))?$('rKzWipCompare').innerHTML:null;
    try{
      /* T1: kzWipDelta — correct ΔX = Wipfrag − snapshot, no fabrication when snapshot missing */
      const synthEntry={rows:[[0,50],[0.25,75],[0.5,100],[0.75,140],[1,200]],label:'test',t:0,kzX50:90.0,kzX80:133.0,kzN:1.5};
      const d=kzWipDelta(synthEntry);
      const wc=kzWipCurve(synthEntry.rows); const mX50=kzWipSize(wc,0.5)*100; const mX80=kzWipSize(wc,0.8)*100;
      const okDelta=d!=null&&Math.abs(d.dX50-(mX50-90.0))<0.01&&Math.abs(d.dX80-(mX80-133.0))<0.01;
      T('kzWipDelta: ΔX50 = measX50 − snapX50, ΔX80 = measX80 − snapX80',okDelta,`dX50=${d&&d.dX50!=null?d.dX50.toFixed(3):'null'} (meas=${mX50.toFixed(3)}-snap=90.0) dX80=${d&&d.dX80!=null?d.dX80.toFixed(3):'null'}`);
      /* T2: % error = |Δ| / |kz snapshot| × 100, only when reference is valid and nonzero */
      const okPct=d!=null&&d.pctX50!=null&&Math.abs(d.pctX50-Math.abs(d.dX50)/90.0*100)<0.001&&d.pctX80!=null;
      T('kzWipDelta: % error = |Δ|/|kz_snapshot| × 100 (nonzero valid snapshot only)',okPct,`pctX50=${d&&d.pctX50!=null?d.pctX50.toFixed(3):'null'} formula=${d&&d.dX50!=null?(Math.abs(d.dX50)/90.0*100).toFixed(3):'n/a'}`);
      /* T3: missing snapshot → delta is null, no fabricated value */
      const noSnapEntry={rows:[[0,50],[0.25,75],[0.5,100],[0.75,140],[1,200]],label:'test-nosnap',t:0,kzX50:null,kzX80:null,kzN:null};
      const dNoSnap=kzWipDelta(noSnapEntry);
      T('kzWipDelta: null snapshot → dX50=null, dX80=null, pctX50=null (no fabricated value)',dNoSnap!=null&&dNoSnap.dX50===null&&dNoSnap.dX80===null&&dNoSnap.pctX50===null,`dX50=${dNoSnap&&dNoSnap.dX50} dX80=${dNoSnap&&dNoSnap.dX80} pctX50=${dNoSnap&&dNoSnap.pctX50}`);
      /* T3b (bugfix): kurva Wipfrag berhenti di 60% → X80 TIDAK boleh dikarang (sebelumnya di-clamp ke ukuran terbesar) */
      const dShort=kzWipDelta({rows:[[0.1,50],[0.3,100],[0.5,150],[0.6,200]],label:'t-short',t:0,kzX50:20,kzX80:30,kzN:1.2});
      T('kzWipDelta: kurva tidak mencapai 80% → measX80/dX80/pctX80=null, X50 tetap dihitung',dShort!=null&&dShort.measX80===null&&dShort.dX80===null&&dShort.pctX80===null&&dShort.measX50!=null&&dShort.dX50!=null,`measX80=${dShort&&dShort.measX80} dX80=${dShort&&dShort.dX80} measX50=${dShort&&dShort.measX50}`);
      /* T4: kzSanitize preserves valid snapshot fields, rejects out-of-range (negative, >10000, non-finite) */
      const raw4={wipBy:{
        'g|1':{rows:[[0,50],[0.25,100],[0.5,150],[0.75,200],[1,300]],label:'s4',t:1,kzX50:31.3,kzX80:52.1,kzN:1.46},
        'g|2':{rows:[[0,50],[0.25,100],[0.5,150],[0.75,200],[1,300]],label:'s4b',t:1,kzX50:-5,kzX80:20000,kzN:50}}};
      const san=kzSanitize(raw4);
      const okSan=san.wipBy['g|1']&&Math.abs(san.wipBy['g|1'].kzX50-31.3)<0.001&&Math.abs(san.wipBy['g|1'].kzX80-52.1)<0.001
               &&san.wipBy['g|2']&&san.wipBy['g|2'].kzX50===null&&san.wipBy['g|2'].kzX80===null;
      T('kzSanitize: preserves valid kzX50/kzX80, rejects out-of-range (negative, >10000)',okSan,`g|1 kzX50=${san.wipBy['g|1']?.kzX50} | g|2 kzX50=${san.wipBy['g|2']?.kzX50}`);
      /* T5: kzSanitize idempotent on snapshot fields */
      const san2=kzSanitize(kzSanitize(raw4));
      T('kzSanitize: snapshot fields preserved through double sanitization (idempotent)',san2.wipBy['g|1']&&Math.abs(san2.wipBy['g|1'].kzX50-31.3)<0.001,`kzX50=${san2.wipBy['g|1']?.kzX50}`);
      /* T6: kzPersistable serializes snapshot fields */
      const bakKz=JSON.parse(JSON.stringify(APP_STATE.kuzram.wipBy));
      APP_STATE.kuzram.wipBy={'test|1':{rows:[[0,50],[0.25,100],[0.5,150],[0.75,200],[1,300]],label:'persist-test',t:1,kzX50:28.5,kzX80:47.3,kzN:1.38}};
      const pers=kzPersistable();
      T('kzPersistable: serializes kzX50/kzX80/kzN in wipBy output',pers.wipBy['test|1']&&Math.abs(pers.wipBy['test|1'].kzX50-28.5)<0.001&&Math.abs(pers.wipBy['test|1'].kzX80-47.3)<0.001,`kzX50=${pers.wipBy['test|1']?.kzX50} kzX80=${pers.wipBy['test|1']?.kzX80}`);
      APP_STATE.kuzram.wipBy=bakKz;
      /* T7: kzWipCompareData — empty wipBy yields empty rows, maeX50=null, no crash */
      APP_STATE.kuzram.wipBy={};
      const empty=kzWipCompareData();
      T('kzWipCompareData: empty wipBy → rows=[], maeX50=null, no crash',Array.isArray(empty.rows)&&empty.rows.length===0&&empty.maeX50===null&&empty.nX50===0,`rows=${empty.rows.length} maeX50=${empty.maeX50}`);
      /* T8: kzWipCompareData — two valid entries with snapshots → rows=2, maeX50 finite, nX50=2 */
      APP_STATE.kuzram.wipBy={
        'a|1':{rows:[[0,50],[0.25,100],[0.5,150],[0.75,200],[1,300]],label:'A-1',t:1,kzX50:90,kzX80:130,kzN:1.4},
        'b|2':{rows:[[0,50],[0.25,100],[0.5,160],[0.75,210],[1,310]],label:'B-2',t:2,kzX50:95,kzX80:140,kzN:1.4}
      };
      const two=kzWipCompareData();
      T('kzWipCompareData: two valid entries → rows.length=2, maeX50 finite, nX50=2',two.rows.length===2&&Number.isFinite(two.maeX50)&&two.nX50===2,`rows=${two.rows.length} maeX50=${two.maeX50!=null?two.maeX50.toFixed(3):'null'} nX50=${two.nX50}`);
      /* T9: renderWipComparisonPanel — empty wipBy → placeholder text present, no crash */
      APP_STATE.kuzram.wipBy={};
      if($('rKzWipCompare')){
        renderWipComparisonPanel('rKzWipCompare');
        T('renderWipComparisonPanel: empty wipBy → placeholder text, no crash, no "undefined" in output',($('rKzWipCompare').innerHTML||'').length>0&&!($('rKzWipCompare').innerHTML||'').includes('undefined'),`len=${($('rKzWipCompare').innerHTML||'').length}`);
      } else { pass('TAHAP 2 WIP-COMPARE • renderWipComparisonPanel: empty wipBy → placeholder text, no crash, no "undefined" in output',true,'dilewati: #rKzWipCompare tidak ada di DOM (diperlukan server HTTP)'); }
      /* T10: renderWipComparisonPanel — two entries → tbody has two data rows */
      APP_STATE.kuzram.wipBy={
        'a|1':{rows:[[0,50],[0.25,100],[0.5,150],[0.75,200],[1,300]],label:'A-1',t:1,kzX50:90,kzX80:130,kzN:1.4},
        'b|2':{rows:[[0,50],[0.25,100],[0.5,160],[0.75,210],[1,310]],label:'B-2',t:2,kzX50:95,kzX80:140,kzN:1.4}
      };
      if($('rKzWipCompare')){
        renderWipComparisonPanel('rKzWipCompare');
        const rows=($('rKzWipCompare').querySelectorAll('tbody tr')||[]).length;
        T('renderWipComparisonPanel: two wipBy entries → tbody has exactly two rows',rows===2,`tbody rows=${rows}`);
      } else { pass('TAHAP 2 WIP-COMPARE • renderWipComparisonPanel: two wipBy entries → tbody has exactly two rows',true,'dilewati: #rKzWipCompare tidak ada'); }
      /* T11: kzReportHtml — with wipBy data → contains Wipfrag comparison section */
      APP_STATE.kuzram.wipBy={'t|1':{rows:[[0,50],[0.25,100],[0.5,150],[0.75,200],[1,300]],label:'T-1',t:1,kzX50:90,kzX80:130,kzN:1.4}};
      const html=kzReportHtml();
      T('kzReportHtml: with wipBy data → HTML contains Wipfrag comparison section and delta column',html.includes('Wipfrag')&&html.includes('ΔX50'),`hasWip=${html.includes('Wipfrag')} hasDelta=${html.includes('ΔX50')}`);
      /* T12: kzReportHtml MAE row — no TypeError if maeX50/maeX80 present (null-guard fix verification) */
      APP_STATE.kuzram.wipBy={
        'u|1':{rows:[[0,50],[0.25,100],[0.5,150],[0.75,200],[1,300]],label:'U-1',t:1,kzX50:88,kzX80:128,kzN:1.4},
        'u|2':{rows:[[0,50],[0.25,105],[0.5,158],[0.75,208],[1,308]],label:'U-2',t:2,kzX50:92,kzX80:135,kzN:1.4}
      };
      let noThrow=true; let htmlMae='';
      try{ htmlMae=kzReportHtml(); }catch(_ex){ noThrow=false; }
      T('kzReportHtml: MAE row renders without TypeError (null-guard fix)',noThrow&&htmlMae.includes('MAE'),`noThrow=${noThrow} hasMAE=${htmlMae.includes('MAE')}`);
    }catch(e){
      T('Tahap-2 suite selesai',false,'actual='+String(e&&e.stack||e));
    }finally{
      APP_STATE.kuzram.wipBy=JSON.parse(bakWip);
      if($('rKzWipCompare')&&bakEl!=null) $('rKzWipCompare').innerHTML=bakEl;
    }
  }
  /* ===== END TAHAP 2 ===== */


  /* ===== ROI POLIGON tests. Hitungan tangan dijelaskan di tiap nama tes; golden hash dihitung dari engine V5 SEBELUM perubahan ROI. ===== */
  function runRoiTests(pass){
    const eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
    const cnt=m=>roiMaskCount(m);
    const rowCounts=(m,w,h)=>{const r=[];for(let y=0;y<h;y++){let n=0;for(let x=0;x<w;x++)n+=m[y*w+x];r.push(n);}return r;};
    const at=(m,w,x,y)=>m[y*w+x];
    /* 1. segi empat (2,1)-(6,4): pusat piksel x+.5 in [2,6) -> x=2..5 (4 kolom); y+.5 in [1,4) -> y=1..3 (3 baris) => 12 = luas poligon 4x3 */
    const R=[[2,1],[6,1],[6,4],[2,4]],mR=roiRasterize([R],10,6);
    pass('ROI raster: segi empat (2,1)-(6,4) pada grid 10x6 = 12 piksel (4 kolom x 3 baris, hitung tangan)',cnt(mR)===12&&eq(rowCounts(mR,10,6),[0,4,4,4,0,0]),`count=${cnt(mR)} rows=${rowCounts(mR,10,6)}`);
    pass('ROI raster: tepi segi empat (kiri/atas masuk, kanan/bawah keluar)',at(mR,10,2,1)===1&&at(mR,10,5,3)===1&&at(mR,10,6,1)===0&&at(mR,10,2,4)===0&&at(mR,10,1,1)===0&&at(mR,10,2,0)===0,'(2,1)=1 (5,3)=1 (6,1)=0 (2,4)=0 (1,1)=0 (2,0)=0');
    /* 2. segitiga siku (0,0),(8,0),(0,8) pada 8x8: baris y: x+.5 < 7.5-y -> x=0..6-y => 7-y piksel; y=0..7 => 7,6,5,4,3,2,1,0 = 28 (luas poligon 32) */
    const T=[[0,0],[8,0],[0,8]],mT=roiRasterize([T],8,8);
    pass('ROI raster: segitiga (0,0),(8,0),(0,8) pada grid 8x8 = 28 piksel, per baris 7,6,5,4,3,2,1,0 (hitung tangan)',cnt(mT)===28&&eq(rowCounts(mT,8,8),[7,6,5,4,3,2,1,0]),`count=${cnt(mT)} rows=${rowCounts(mT,8,8)}`);
    pass('ROI raster: titik uji segitiga (6,0) masuk, (7,0) keluar, (0,6) masuk, (1,6) keluar',at(mT,8,6,0)===1&&at(mT,8,7,0)===0&&at(mT,8,0,6)===1&&at(mT,8,1,6)===0,'diagonal x+y<7');
    /* 3. union: A=(0,0)-(4,4) 16 piksel, B=(2,2)-(6,6) 16 piksel, irisan (2,2)-(4,4) 4 piksel => 16+16-4 = 28 */
    const mU=roiRasterize([[[0,0],[4,0],[4,4],[0,4]],[[2,2],[6,2],[6,6],[2,6]]],8,8);
    pass('ROI raster: gabungan dua segi empat tumpang tindih = 16+16-4 = 28 piksel',cnt(mU)===28&&at(mU,8,3,3)===1&&at(mU,8,5,1)===0,`count=${cnt(mU)}`);
    /* 4. input buruk / terpotong tepi */
    const mBad=roiRasterize([[[1,1],[5,5]],[[0,0],[NaN,3],[4,4]],null,'x'],10,10);
    pass('ROI raster: poligon <3 titik, koordinat NaN, dan entri non-array diabaikan (0 piksel)',cnt(mBad)===0,`count=${cnt(mBad)}`);
    const mClip=roiRasterize([[[-5,-5],[3,-5],[3,3],[-5,3]]],10,10);
    pass('ROI raster: segi empat (-5,-5)-(3,3) terpotong tepi canvas 10x10 = 3x3 = 9 piksel',cnt(mClip)===9&&at(mClip,10,2,2)===1&&at(mClip,10,3,2)===0,`count=${cnt(mClip)}`);
    pass('ROI raster: poligon sepenuhnya di luar canvas = 0 piksel',cnt(roiRasterize([[[20,20],[30,20],[30,30],[20,30]]],10,10))===0,'tidak error, tidak ada piksel');
    pass('ROI luas: 12 piksel dari grid 10x6 = 20,0 %',Math.abs(cnt(mR)/(10*6)-0.2)<1e-12,'12/60=0.2');
    /* 5. filter fragmen berdasarkan pusat bbox: floor((minx+maxx)/2), floor((miny+maxy)/2) terhadap mask segi empat di atas */
    const frs=[{id:1,minx:2,maxx:5,miny:1,maxy:3},{id:2,minx:7,maxx:9,miny:1,maxy:3},{id:3,minx:0,maxx:3,miny:1,maxy:3},{id:4,minx:4,maxx:7,miny:2,maxy:2},{id:5,minx:NaN,maxx:5,miny:1,maxy:3},{id:6,minx:2,maxx:5,miny:50,maxy:60}];
    const kept=roiFilterByCenter(frs,mR,10,6).map(f=>f.id);
    pass('ROI filter: fragmen berpusat di luar ROI dibuang (#1 pusat (3,2) masuk, #2 (8,2) luar, #3 (1,2) luar, #4 (5,2) masuk, NaN/di luar canvas dibuang)',eq(kept,[1,4]),`kept=${kept}`);
    /* 6. engine V5: gambar deterministik 160x120 (kotak 20 px dengan celah gelap) */
    const mkImg=(w,h)=>{const d=new Uint8ClampedArray(w*h*4),hs=(a,b)=>{let t=(Math.imul(a,374761393)+Math.imul(b,668265263))>>>0;t=Math.imul(t^(t>>>13),1274126177)>>>0;return(t^(t>>>16))>>>0;},cs=20;
      for(let y=0;y<h;y++)for(let x=0;x<w;x++){const cx=(x/cs)|0,cy=(y/cs)|0,ex=Math.min(x%cs,cs-1-x%cs),ey=Math.min(y%cs,cs-1-y%cs),e=Math.min(ex,ey),base=90+hs(cx,cy)%110,v=e<2?25:(e<4?base-25:base),i=(y*w+x)*4;d[i]=v;d[i+1]=v;d[i+2]=Math.max(0,v-6);d[i+3]=255;}
      return d;};
    const sigHash=comps=>{const sig=comps.map(c=>[c.area,c.minx,c.maxx,c.miny,c.maxy]).sort((a,b)=>a[1]-b[1]||a[3]-b[3]||a[0]-b[0]);let hh=2166136261;sig.forEach(s=>s.forEach(v=>{hh^=(v|0);hh=Math.imul(hh,16777619)>>>0;}));return hh;};
    const W=160,H=120,PX=mkImg(W,H),N=W*H;
    const r0=segmentRocksV5(PX,W,H,{minArea:60});
    pass('ROI engine: TANPA roiMask hasil identik dengan engine sebelum perubahan (golden: 48 komponen, hash 2466760277 dari versi asli)',r0.comps.length===48&&sigHash(r0.comps)===2466760277,`n=${r0.comps.length} hash=${sigHash(r0.comps)}`);
    const r1=segmentRocksV5(PX,W,H,{minArea:60,roiMask:new Uint8Array(N).fill(1)});
    pass('ROI engine: roiMask semua-1 menghasilkan komponen identik dengan tanpa mask',r1.comps.length===r0.comps.length&&sigHash(r1.comps)===sigHash(r0.comps),`n=${r1.comps.length} hash=${sigHash(r1.comps)}`);
    const half=new Uint8Array(N);for(let y=0;y<H;y++)for(let x=0;x<W/2;x++)half[y*W+x]=1;
    const r2=segmentRocksV5(PX,W,H,{minArea:60,roiMask:half,roiTop:0.95,roiBottom:1});
    let outside=0;r2.comps.forEach(c=>c.pixels.forEach(p=>{if(!half[p[1]*W+p[0]])outside++;}));
    pass('ROI engine: dengan roiMask separuh kiri tidak ada piksel komponen di luar mask, dan roiTop/roiBottom diabaikan',r2.comps.length>0&&r2.comps.length<r0.comps.length&&outside===0,`comps=${r2.comps.length} (tanpa ROI ${r0.comps.length}) pikselLuar=${outside}`);
    let thrown=null;try{segmentRocksV5(PX,W,H,{minArea:60,roiMask:new Uint8Array(N-1)});}catch(e){thrown=String(e&&e.message||e);}
    pass('ROI engine: panjang roiMask salah ditolak dengan error eksplisit (bukan diam-diam menganalisis seluruh foto)',!!thrown&&/roiMask/.test(thrown),String(thrown));
    /* 7. persistensi + state + DOM */
    const sv=roiSanitizeSaved(JSON.parse(JSON.stringify({key:'a|1|2|100x50',polygons:[[[1,1],[5,1],[5,5]],[[0,0],[1,1]]]})));
    pass('ROI persist: sanitasi menjaga poligon valid, membuang poligon <3 titik, menolak payload rusak',!!sv&&sv.polygons.length===1&&eq(sv.polygons[0],[[1,1],[5,1],[5,5]])&&roiSanitizeSaved({key:5,polygons:[]})===null&&roiSanitizeSaved(null)===null&&roiSanitizeSaved({key:'k',polygons:[[[NaN,1],[2,2],[3,3]]]})===null,JSON.stringify(sv));
    pass('ROI state: APP_STATE.image.roiPolygons dan roiDraft adalah array',Array.isArray(APP_STATE.image.roiPolygons)&&Array.isArray(APP_STATE.image.roiDraft),'roiPolygons='+JSON.stringify(APP_STATE.image.roiPolygons));
    pass('ROI UI: tombol GAMBAR ROI / SELESAI ROI / HAPUS ROI masing-masing tepat satu dan ada #mvpRoiInfo',['btnRoiDraw','btnRoiFinish','btnRoiClear','mvpRoiInfo'].every(id=>document.querySelectorAll('#'+id).length===1),'id unik');
  }
  function runTests(){ const results=[]; const pass=(name,ok,msg)=>results.push({name,status:ok?'PASS':'FAIL',msg}); runPhaseATests(pass); runStage3Tests(pass); runStage4Tests(pass); runStage41Tests(pass); try{ runWipParseTests(pass); }catch(e){ pass('Wipfrag parser test suite crashed',false,'actual='+String(e&&e.stack||e)); } try{ runKzReportTests(pass); }catch(e){ pass('Kuz-Ram report test suite crashed',false,'actual='+String(e&&e.stack||e)); } try{ runTahap1HardeningTests(pass); }catch(e){ pass('Tahap-1 hardening suite crashed',false,'actual='+String(e&&e.stack||e)+' | expected=suite completes | reason=exception in runTahap1HardeningTests'); } try{ runTahap2WipCompareTests(pass); }catch(e){ pass('Tahap-2 Wip-Compare suite crashed',false,'actual='+String(e&&e.stack||e)+' | expected=suite completes | reason=exception in runTahap2WipCompareTests'); } try{ runP02Tests(pass); }catch(e){ pass('P0.2 test suite crashed',false,'actual='+String(e&&e.stack||e)+' | expected=suite completes | reason=exception in runP02Tests'); } try{ runRoiTests(pass); }catch(e){ pass('ROI polygon test suite crashed',false,'actual='+String(e&&e.stack||e)+' | expected=suite completes | reason=exception in runRoiTests'); } try{ const r=maeCalc(0.1651,10,0.85,2.6,{xi:1,jps:20,jpo:30,ucs:60,cw:24,stf:0.7,sbf:0.3}); const E={BI: 43.379201681, PF: 0.451143697, AE: 40.33555704, SA: 27.783116625, N: 5, S: 4.8, B: 5.788149297}; const okv=!!r&&['BI','PF','AE','SA','S','B'].every(k=>Math.abs(r[k]-E[k])<1e-6*Math.max(1,Math.abs(E[k])))&&r.N===E.N; pass('MAE Eq.17-29 = hitung tangan (Python)',okv,r?`BI=${r.BI.toFixed(3)} AE=${r.AE.toFixed(3)} N=${r.N} B=${r.B.toFixed(3)}`:'null'); const bad=maeCalc(0.1651,10,0.85,2.6,{xi:NaN,jps:20,jpo:30,ucs:60,cw:24,stf:0.7,sbf:0.3}); const bad2=maeCalc(0.1651,10,0.85,2.6,{xi:1,jps:20,jpo:30,ucs:60,cw:24,stf:0.7,sbf:null}); pass('MAE menolak input kosong (bukan dianggap 0)',bad===null&&bad2===null,'NaN/null ditolak'); MAE_ERR=''; }catch(e){ pass('MAE self-test',false,e.message); } pass('Lab baseline separation',APP_STATE.material.labSnapshot!==APP_STATE.material.labWorking||!APP_STATE.material.labSnapshot,'Baseline is immutable or unavailable.'); pass('Single APP_STATE exposed',window.APP_STATE===APP_STATE,'Single source of truth object exists.'); pass('Geometry deterministic',calculateGeometry(APP_STATE)===null || JSON.stringify(calculateGeometry(APP_STATE))===JSON.stringify(calculateGeometry(APP_STATE)),'Repeated geometry calculation matches exactly.'); const hc=document.querySelectorAll('#btnScanMuckpile').length; pass('Single scan button',hc===1,`count=${hc}`); pass('Single image-processing engine',document.querySelectorAll('script').length>=4,'UI/UX helper scripts do not add a second image-processing engine.'); pass('HTML duplicate IDs',validateHtmlIntegrity().ok,validateHtmlIntegrity().duplicateIds.join(', ')||'none'); pass('Physical >80 gating',!APP_STATE.psd.x80 || !!APP_STATE.calibration.metersPerWorkingPixel,'Physical size derives from calibration.'); pass('RR sample gate',APP_STATE.psd.fitStatus==='INSUFFICIENT SAMPLE' || APP_STATE.fragments.length>=psdRrMinSamples(),'RR fit is sample-gated by configurable minimum sample count.');
    pass('PSD config valid',!!APP_STATE.psdConfig && getPSDConfig().oversizeThresholdCm>0 && getPSDConfig().rrMinSamples>=2,'PSD configuration normalizes to valid engineering ranges.');
    pass('PSD config entry point',document.querySelectorAll('#btnOpenPSDConfig').length===1 && document.querySelectorAll('#psdConfigModal').length===1,'Single PSD config entry point and modal exist.'); const qg=APP_STATE.material.labSnapshot?.groups||{}; pass('Lab quality coverage',LAB_QUALITY_ORDER.every(k=>!qg || qg[k]),'HG/MG/DOL/PEDEL keys accepted when present.'); pass('Active lab quality validity',!APP_STATE.material.labSnapshot || !APP_STATE.material.qualityKey || !!APP_STATE.material.labSnapshot.groups?.[APP_STATE.material.qualityKey],'Active quality exists in lab groups.');
    (function testFreeFaceIsGeometryDriven(){
      const oldMode=APP_STATE.freeFace.mode;
      recalcFreeFace(); const dirFront=JSON.stringify(currentBlastDir());
      APP_STATE.freeFace.mode = oldMode==='right' ? 'left' : 'right';
      recalcFreeFace(); const dirOther=JSON.stringify(currentBlastDir());
      const changed = dirFront !== dirOther;
      APP_STATE.freeFace.mode=oldMode; recalcFreeFace();
      pass('Free-face vector is geometry-driven (not hardcoded)', changed, changed?'Switching free-face side changes the computed blast vector.':'FAIL: blast direction did not change when free-face side changed.');
    })();
    pass('Free-face custom mode requires 2 points',(function(){ const m=APP_STATE.freeFace.mode, p=APP_STATE.freeFace.points; APP_STATE.freeFace.mode='custom'; APP_STATE.freeFace.points=[]; const errs=validateSimulationInputs(); APP_STATE.freeFace.mode=m; APP_STATE.freeFace.points=p; return errs.some(e=>e.includes('Custom Free Face')); })(),'validateSimulationInputs blocks custom mode with <2 points.');
    const tb=$('testTableBody');tb.innerHTML='';results.forEach(r=>{const tr=document.createElement('tr');[r.name,r.status,r.msg].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.appendChild(td)});tb.appendChild(tr)}); $('testSummary').textContent=`${results.filter(r=>r.status==='PASS').length}/${results.length} PASS`;  runPhase0Tests(results).catch(e=>console.error(e)); }

  // Phase-0 behavioural regression tests (each exercises real behaviour; none only checks that a function exists).
  async function runPhase0Tests(results){
    const add=(name,ok,msg)=>{results.push({name,status:ok?'PASS':'FAIL',msg});};
    const flush=()=>{const tb=$('testTableBody');tb.innerHTML='';results.forEach(r=>{const tr=document.createElement('tr');[r.name,r.status,r.msg].forEach(v=>{const td=document.createElement('td');td.textContent=v;tr.appendChild(td)});tb.appendChild(tr)});$('testSummary').textContent=`${results.filter(r=>r.status==='PASS').length}/${results.length} PASS`;};
    // 1 CSS integrity: rules after .btn--reset-sim and its @media breakpoints must exist in the parsed CSSOM
    try{const rules=[...document.styleSheets].flatMap(s=>{try{return [...s.cssRules];}catch(e){return [];}}); add('CSS: rules after .btn--reset-sim are parsed (.sim-notif)',rules.some(r=>r.selectorText==='.sim-notif'),'CSSOM contains .sim-notif'); add('CSS: layout @media (max-width:980px) is active',rules.some(r=>r.type===4&&/980px/.test(r.conditionText||r.media?.mediaText||'')),'media rule present'); add('CSS: .btn--reset-sim has width',(rules.find(r=>r.selectorText==='.btn--reset-sim')?.style.width)==='100%','width=100%');}catch(e){add('CSS integrity',false,String(e));}
    // 2 Lab import XSS: hostile Kualitas must render as text only
    try{const bak=APP_STATE.material.labSnapshot, bakQ=APP_STATE.material.qualityKey; const evil='<IMG SRC=X ONERROR=WINDOW.__KB_XSS=1>'; delete window.__KB_XSS;
      const snap=buildLabSnapshot([{Kualitas:evil,Density:2.6,CaO:50},{Kualitas:'HG',Density:2.7,CaO:52}],'test','t'); APP_STATE.material.labSnapshot=snap; APP_STATE.material.qualityKey=evil.toUpperCase().replace(/\s+/g,' ').trim(); renderLab();
      await new Promise(r=>setTimeout(r,50)); const root=$('labQualitySelector').parentElement||document;
      add('Lab import XSS: hostile Kualitas rendered as text, no injected element',!$('labQualitySelector').querySelector('img')&&!$('labQualitySummary').querySelector('img')&&window.__KB_XSS===undefined,'no <img>, no script side-effect');
      APP_STATE.material.labSnapshot=bak; APP_STATE.material.qualityKey=bakQ; renderLab();}catch(e){add('Lab import XSS',false,String(e));}
    // 3-7 segmentation behaviour on synthetic gray images
    const mk=(shapes,w=320,h=240)=>{const d=new Float32Array(w*h).fill(200);shapes.forEach(([cx,cy,rx,ry])=>{for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(((x-cx)/rx)**2+((y-cy)/ry)**2<=1)d[y*w+x]=60;});return {w,h,data:d};};
    const seg=(g,o,mode='low')=>segmentFragments(g,gradientMagnitude(g),normalizePSDConfig({...PSD_CONFIG_DEFAULTS,...o}),mode);
    try{const big=seg(mk([[160,120,140,100]]),{thresholdPct:60}); add('Large fragment (>40% of image) is preserved, flagged REVIEW',big.comps.length===1&&big.comps[0].review===true,`comps=${big.comps.length}`);
      const pair=mk([[130,120,22,22],[166,120,22,22]]); const p1=seg(pair,{thresholdPct:8}); add('Touching medium fragments are separated',p1.comps.length===2,`comps=${p1.comps.length}`);
      const p2=seg(pair,{thresholdPct:8,maxArea:2200}); add('maxArea is applied to child objects, not to the raw blob',p2.comps.length===2&&p2.dropped.maxArea===0,`comps=${p2.comps.length}`);
      const one=mk([[160,120,50,40]]); /* 10.2% of pixels: clears the 12% percentile tie so maxObjectWidthPct (20%) actually flags */ const lo=seg(one,{thresholdPct:12,maxObjectWidthPct:20,maxObjectHeightPct:20}),hi=seg(one,{thresholdPct:12,maxObjectWidthPct:99,maxObjectHeightPct:99});
      add('maxObjectWidth/HeightPct are consumed (flag, object kept)',lo.comps.length===1&&lo.comps[0].review&&hi.comps.length===1&&!hi.comps[0].review,`lo=${lo.comps[0]?.reviewReason}`);
      const bin=localContrastBinary(mk([[160,120,40,40]]),.14,'dark',1); {let s=987654321;for(let i=0;i<bin.length;i++){s=(s*1103515245+12345)%2147483648;if(!bin[i]&&s%100<8)bin[i]=1;}} const ones=[0,1,3,5].map(n=>morphology(bin,320,240,'open',n).reduce((a,b)=>a+b,0)); add('Morphology passes 0/1/3/5 produce different processing results',new Set(ones).size>1&&ones[1]!==ones[3],`ones=${ones}`);
    }catch(e){add('Segmentation regression',false,String(e));}
    // 8 + 9 same-file re-upload and blob URL lifecycle (junk PNG -> onerror path; no app state touched)
    try{const inp=$('imageInput'); const c0=URL.createObjectURL, r0=URL.revokeObjectURL; let made=0,rev=0; URL.createObjectURL=function(...a){made++;return c0.apply(URL,a);}; URL.revokeObjectURL=function(...a){rev++;return r0.apply(URL,a);};
      let fired=0; const cnt=()=>fired++; inp.addEventListener('change',cnt); const mkFiles=()=>{const dt=new DataTransfer(); dt.items.add(new File([new Uint8Array([1,2,3])],'same.png',{type:'image/png'})); return dt.files;}; // fresh FileList per dispatch: input.value='' clears the shared DataTransfer list, so reusing one dt leaves the 2nd dispatch fileless
      const before=made; inp.files=mkFiles(); inp.dispatchEvent(new Event('change')); const clearedAfterFirst=inp.value===''; inp.files=mkFiles(); inp.dispatchEvent(new Event('change'));
      await new Promise(r=>setTimeout(r,400)); inp.removeEventListener('change',cnt); URL.createObjectURL=c0; URL.revokeObjectURL=r0;
      add('Same-file re-upload: input cleared after handling, change fires again',clearedAfterFirst&&fired===2,`cleared=${clearedAfterFirst} fired=${fired}`);
      add('Blob URL lifecycle: every createObjectURL is revoked',(made-before)>=2&&(rev>=made-before),`created=${made-before} revoked=${rev}`); $('imageUploadStatus').textContent=APP_STATE.image.metadata?'Loaded actual image: '+APP_STATE.image.metadata.name:'WAITING FOR ACTUAL FIELD IMAGE';
    }catch(e){add('Reupload/blob lifecycle',false,String(e));}
    // 10 resetWorkspace must re-sync PSD/MVP controls (state snapshot restored afterwards)
    try{const keys=['geometry','formula','psdConfig','financial','seismic','simulation','freeFace','karst','kuzram']; const snap=deepClone(Object.fromEntries(keys.map(k=>[k,APP_STATE[k]]))); const lab=deepClone(APP_STATE.material.labWorking);
      APP_STATE.psdConfig={...APP_STATE.psdConfig,thresholdPct:31}; syncMvpPsdControls(); syncPSDConfigControls(); const pre=$('mvpThreshold').value==='31'; resetWorkspace();
      add('resetWorkspace re-syncs MVP slider and Segmentation Controls to defaults',pre&&$('mvpThreshold').value==='62'&&$('thresholdPct').value==='62'&&APP_STATE.psdConfig.thresholdPct===62,`mvp=${$('mvpThreshold').value} field=${$('thresholdPct').value}`);
      keys.forEach(k=>{APP_STATE[k]=snap[k];}); APP_STATE.material.labWorking=lab; persistWorking(); hydrateUI(); syncPSDConfigControls(); syncMvpPsdControls(); simHydrate(); simVisual(); recalcFreeFaceAndRender(); kzHydrate(); refreshAll();
    }catch(e){add('resetWorkspace sync',false,String(e));}
    // KUZ-RAM in-app checks
    try{ const st=APP_STATE.kuzram,ex=kzCompute(KZ_BASE_TEST,'excel'),cc=kzCompute(KZ_BASE_TEST,'corrected');
      add('KUZRAM: state ter-sanitasi (mode, field manual lengkap)',['corrected','excel'].includes(st.mode)&&KZ_FIELDS.every(([k])=>k in st.manual),`mode=${st.mode}`);
      add('KUZRAM: mode Excel = BB-6 (n 1.46168, X50 31.2416 cm)',Math.abs(ex.n-1.46168)<2e-5&&Math.abs(ex.x50cm-31.2416)<2e-3,`n=${ex.n} x50=${ex.x50cm}`);
      add('KUZRAM: P(X50)=50% dan P(X80)=80% (mode Koreksi)',Math.abs(cc.passFn(cc.x50m)-0.5)<1e-12&&Math.abs(cc.passFn(cc.x80)-0.8)<1e-12,`x80=${cc.x80}`);
      add('KUZRAM: input kosong / W>=B diblokir',!kzCompute({...KZ_BASE_TEST,burdenM:null},'corrected').ok&&!kzCompute({...KZ_BASE_TEST,driftSdM:2.5},'corrected').ok,'blokir');
      add('KUZRAM: payload lama berisi gas tetap terbaca (gas dibuang, kuzram default)',(()=>{const m=migratePersistedState({version:10,gas:{blowoutFactor:1}});return !!m&&m.version===PERSIST_VERSION&&!('gas' in m)&&m.kuzram.mode==='excel';})(),'migrate');
      add('KUZRAM: kzSanitize menolak nilai non-numerik',(()=>{const s=kzSanitize({mode:'x',source:'zzz',dv:2,manual:{driftSdM:'abc',rockSG:2.6}});return s.mode==='excel'&&s.source===null&&s.manual.driftSdM===null&&s.manual.rockSG===2.6&&s.manual.bclMinusCclM===0;})(),'sanitize');
      add('KUZRAM: panel, grafik SVG, kanvas animasi terpasang',!!$('kzChart')&&!!$('kzCanvas')&&!!$('kzPanel'),'DOM');
    }catch(e){add('KUZRAM in-app checks',false,String(e));}
    flush();
  }
  function resetWorkspace(){
    const old=JSON.stringify(APP_STATE.geometry.input);
    phaseAResetInputs();
    APP_STATE.formula.key='ash'; APP_STATE.psdConfig={...PSD_CONFIG_DEFAULTS};
    /* TAHAP-1: purge manual blocks from BLAST_SHEET_ROWS before resetting simulation state */
    Object.keys(BLAST_SHEET_ROWS).forEach(k=>{if(BLAST_SHEET_ROWS[k]?.isManual)delete BLAST_SHEET_ROWS[k];});
    APP_STATE.simulation={levelIndex:1,technique:'standar',animating:false,template:'group1',groupLabel:'GROUP I • J-13',activeBlastRow:1,rowOverrides:{},parameters:{holeCount:4,anPerHoleKg:11.7,dnPerHoleKg:0.20,stemmingM:1.32,burdenM:2.5,spacingM:3.5,depthM:3.0,deckPct:0},result:null,holePattern:[],activeView:'cross',customBlocks:[]};
    try{simFX();}catch(_e){} /* FIX v11: batalkan animasi/timer lama & bebaskan tombol */
    APP_STATE.freeFace={mode:'front',points:[],manualAzimuthDeg:0,normalVector:null,tangentVector:null,azimuthDeg:null,distanceToHole:null,burdenVector:null,referenceHoleId:null,linePoints:null,confidence:'MEDIUM'};
    APP_STATE.karst={cavities:[],autoLevel:true,placementMode:false,counts:{none:0,near:0,intersect:0,central:0},worstSeverity:'NONE',fractionAffected:0,weightedExposure:0,holeSeverity:{}};
    APP_STATE.kuzram=kzDefaultState(); kzResetAnim();
    applyLabSnapshotToWorking();
    audit('Workspace reset',old,JSON.stringify(APP_STATE.geometry.input),'SYSTEM','RESET WORKSPACE');
    persistWorking(); hydrateUI(); syncPSDConfigControls(); syncMvpPsdControls(); simHydrate(); simVisual(); updateSeismic(); kzHydrate(); refreshAll();
    renderFreeFaceModeButtons(); setSimView('cross'); recalcFreeFaceAndRender();
  }
  // ---- Derived PSD summary reset (used by restoreWorking; see PERSISTENCE DESIGN DECISION in migratePersistedState)
  function resetDerivedPSD(){ const p=APP_STATE.psd; p.x50=null;p.x80=null;p.oversizeCount=null;p.oversizeFraction=null;p.xc=null;p.n=null;p.rrOversizeFraction=null;p.r2=null;p.fitStatus='INSUFFICIENT SAMPLE';p.rrReason='';p.includedCount=0;p.excludedEstimateCount=0;p.x50Px=null;p.x80Px=null;p.pixelSampleCount=0;p.sampleCount=0;p.calibrationCmPerPx=null;p.physicalStatus='NOT AVAILABLE - NOT CALIBRATED'; }

  // ========================================================================
  // KUZ-RAM: input (APP_STATE.kuzram + geometri sumber) -> kzCompute() -> render. Hasil selalu dihitung ulang dari input saat ini.
  // ========================================================================
  const KZ_UI={bound:false,raf:0,anim:null,detail:false,res:null,undoSnap:null,undoKey:null}; /* REQ-10: undo state */
  const KZ_LABEL=Object.fromEntries(KZ_FIELDS.map(([k,l])=>[k,l]));
  Object.assign(KZ_LABEL,{pfKgM3:'Powder factor',burdenM:'Burden',spacingM:'Spacing',benchM:'Tinggi jenjang',holeDiaMm:'Diameter lubang',chargeLenM:'Panjang charge',chargeKg:'Charge weight'});
  const kzFrac=x=>{x=x*9301.7+0.4937;return x-Math.floor(x);};
  function kzBuild(){
    const st=APP_STATE.kuzram,key=st.source||'actual',ci=APP_STATE.geometry.comparisonInputs||{},reasons=[],srcReasons=[];
    const ov=st.geo||{}, has=k=>Number.isFinite(ov[k])&&ov[k]>0;
    const info={key,label:'—',srcText:'',demo:false,fresh:null,rockSrc:''};
    const diaSrc=Number(ci.diameterIn)>0?Number(ci.diameterIn)*25.4:null;
    const act=getActiveBlastRowForComparison(); info.label=act?`${act.groupLabel} • baris ${act.row.no}`:'—';
    let g={B:null,S:null,H:null,L:null,Q:null};
    if(key==='actual'){
      const ag=act?actualEngineerGeometry():null;
      if(!ag) srcReasons.push('Tidak ada baris blast aktif.');
      else{ info.srcText='ACTUAL • '+(ag.sourceType==='USER_EDIT'?'MANUAL':'PROJECT_INPUT'); g={B:ag.B,S:ag.S,H:Number(act.row.depth),L:ag.chargeLength,Q:ag.chargeMass}; }
    }else{
      const fr=methodFreshness(key),r=(APP_STATE.geometry.results||{})[key],K=key.toUpperCase(); info.fresh=fr; info.srcText=K+' • '+fr;
      if(fr!=='FRESH') srcReasons.push(`Hasil ${K} berstatus ${fr}${fr==='NOT CALCULATED'?' — hitung di modul geometri':' — hitung ulang di modul geometri'}.`);
      if(r){ if(['INVALID','STALE','NOT CALCULATED'].includes(r.validity)) srcReasons.push(`Validitas ${K} = ${r.validity}: ${(r.warnings||[]).join(' • ')||'tanpa detail'}`);
        info.demo=!!r.demoContaminated; g={B:r.B,S:r.S,H:r.benchH,L:r.chargeLength,Q:r.chargeMass}; }
    }
    const pos=v=>(v!=null&&v!==''&&Number.isFinite(Number(v))&&Number(v)>0)?Number(v):null;
    const diaDef=!has('holeDiaMm')&&!diaSrc; info.diaDefault=diaDef;   // diameter tidak ada di baris blok: bila modul geometri kosong, pakai default lembar Excel (114,3 mm)
    const blk={B:pos(g.B),S:pos(g.S),H:pos(g.H),L:pos(g.L),Q:pos(g.Q),D:diaSrc||KZ_DIA_DEFAULT};   // nilai blok/sumber SEBELUM override
    blk.PF=(blk.B&&blk.S&&blk.H&&blk.Q)?blk.Q/(blk.B*blk.S*blk.H):null;
    const dia=has('holeDiaMm')?ov.holeDiaMm:(diaSrc||KZ_DIA_DEFAULT);
    if(has('burdenM')) g.B=ov.burdenM; if(has('spacingM')) g.S=ov.spacingM; if(has('benchM')) g.H=ov.benchM; if(has('chargeLenM')) g.L=ov.chargeLenM;
    if(has('pfKgM3')&&pos(g.B)&&pos(g.S)&&pos(g.H)) g.Q=ov.pfKgM3*Number(g.B)*Number(g.S)*Number(g.H);   // PF di-override => Q diturunkan
    if(!(has('burdenM')&&has('spacingM')&&has('benchM')&&has('chargeLenM')&&has('pfKgM3'))) srcReasons.forEach(x=>reasons.push(x));   // sumber hanya memblokir bila nilainya benar-benar dipakai
    const nm={B:'Burden',S:'Spacing',H:'Tinggi jenjang',L:'Panjang charge (bukan kedalaman lubang)',Q:'Charge weight (kg/lubang)'};
    Object.keys(g).forEach(k=>{ const v=Number(g[k]); if(!(g[k]!=null&&g[k]!==''&&Number.isFinite(v)&&v>0)){ g[k]=null; if(!reasons.length||key==='actual'||(APP_STATE.geometry.results||{})[key]) reasons.push(`Geometri tidak lengkap: ${nm[k]}.`); } else g[k]=v; });
    const pf=(g.B&&g.S&&g.H&&g.Q)?g.Q/(g.B*g.S*g.H):null;
    const rd=Number(ci.rockDensity), userSG=st.manualSrc.rockSG==='USER'&&Number(st.manual.rockSG)>0;
    const rockSG=userSG?st.manual.rockSG:(rd>0?rd:st.manual.rockSG); info.rockSrc=userSG?'USER':(rd>0?'comparisonInputs.rockDensity':(rockSG!=null?'INPUT MANUAL':'—'));
    const i={burdenM:g.B,spacingM:g.S,benchM:g.H,holeDiaMm:dia,chargeLenM:g.L,chargeKg:g.Q,...st.manual,rockSG};
    let r=null,rOther=null;
    if(!reasons.length){
      r=kzCompute(i,st.mode); if(!r.ok) r.errors.forEach(e=>reasons.push(e.replace(/Input wajib kosong\/tidak valid: (\w+)/,(m,k)=>'Input wajib kosong/tidak valid: '+(KZ_LABEL[k]||k))));
      else rOther=kzCompute(i,st.mode==='excel'?'corrected':'excel');
    }
    const blocked=reasons.length>0, ovKeys=KZ_GEO_KEYS.filter(has);
    return {blocked,reasons,info,i,g,blk,ovKeys,pf,r:blocked?null:r,rOther:(rOther&&rOther.ok)?rOther:null,mode:st.mode,key,hash:JSON.stringify([key,st.mode,i,st.simSrc,kzWipId(),kzActiveWip()])};
  }
  const kzF=(v,d=2)=>Number.isFinite(v)?v.toFixed(d):'—', kzPct=v=>Number.isFinite(v)?(v*100).toFixed(1)+'%':'—';
  function kzBadge(t,c){ return `<span class="kz-badge${c?' kz-badge--'+c:''}">${htmlEscape(t)}</span>`; }
  function kzBuildTable(){
    const body=$('kzInputBody'); if(!body||body.dataset.built) return; body.dataset.built='1';
    const geo=[['B','Burden','m','burdenM'],['S','Spacing','m','spacingM'],['H','Tinggi jenjang','m','benchM'],['D','Diameter lubang','mm','holeDiaMm'],['L','Panjang charge','m','chargeLenM'],['PF','Powder factor','kg/m³','pfKgM3']];
    body.innerHTML=geo.map(([k,l,u,ok])=>`<tr><td>${l}</td><td><input id="kzg_${k}" data-g="${ok}" type="number" step="any" min="0" inputmode="decimal"></td><td>${u}</td><td class="kz-src" id="kzs_${k}"></td></tr>`).join('')+
      `<tr><td>Charge weight</td><td class="kz-v" id="kzv_Q">—</td><td>kg/lubang</td><td class="kz-src" id="kzs_Q"></td></tr>`+
      KZ_FIELDS.map(([k,l,u])=>`<tr><td>${l}</td><td><input id="kzi_${k}" data-k="${k}" type="number" step="any" inputmode="decimal"></td><td>${u}</td><td class="kz-src" id="kzs_${k}"></td></tr>`).join('');
    body.addEventListener('input',e=>{ const k=e.target?.dataset?.k; if(!k) return; const st=APP_STATE.kuzram,v=parseFloat(e.target.value);
      st.manual[k]=Number.isFinite(v)?v:(k==='bclMinusCclM'?0:null); st.manualSrc[k]=(k==='bclMinusCclM'&&!Number.isFinite(v))?'ASUMSI':'USER'; persistWorking(); kzRender(); });
    body.addEventListener('change',e=>{ const k=e.target?.dataset?.k; if(k) audit('Kuz-Ram '+k,null,APP_STATE.kuzram.manual[k],'USER','KUZRAM INPUT'); });
    body.addEventListener('input',e=>{ const gk=e.target?.dataset?.g; if(!gk) return; const st=APP_STATE.kuzram,v=parseFloat(e.target.value); st.geo=st.geo||{}; st.geo[gk]=(Number.isFinite(v)&&v>0)?v:null; persistWorking(); kzRender(); });
    body.addEventListener('change',e=>{ const gk=e.target?.dataset?.g; if(gk) audit('Kuz-Ram override '+gk,null,(APP_STATE.kuzram.geo||{})[gk]??null,'USER','KUZRAM OVERRIDE'); });
  }
  const kzSrcText=k=>{ const s=APP_STATE.kuzram.manualSrc[k]; return s==='DEFAULT'?'DEFAULT lembar Excel BB-6 (bukan data proyek)':s==='CONTOH'?'CONTOH (bukan data proyek)':s==='ASUMSI'?'ASUMSI (default 0, bisa diedit)':APP_STATE.kuzram.manual[k]==null?'INPUT MANUAL — belum diisi':'INPUT MANUAL'; };
  /*KZ-WIP:PURE:BEGIN*/
  function kzWipCurve(w){ const a=(w||[]).filter(q=>Array.isArray(q)&&q[0]>=0&&q[0]<=1&&q[1]>0).map(q=>({p:q[0],x:q[1]/1000})).sort((u,v)=>u.x-v.x); if(a.length<3) return null; for(let k=1;k<a.length;k++) if(a[k].p<a[k-1].p) a[k].p=a[k-1].p; return a; }
  function kzWipSize(c,u){ if(u<=c[0].p) return c[0].p>0?c[0].x*u/c[0].p:c[0].x; for(let k=1;k<c.length;k++) if(c[k].p>=u){ const d=c[k].p-c[k-1].p; return d>0?c[k-1].x+(c[k].x-c[k-1].x)*(u-c[k-1].p)/d:c[k].x; } return c[c.length-1].x; }
  /* BUGFIX: kzWipSize meng-clamp ke ukuran terbesar bila kurva Wipfrag tidak mencapai persentil u (mis. data berhenti di 60% → X80 palsu). kzWipSizeIn mengembalikan null agar ΔX/%error/MAE tidak memakai angka karangan. */
  function kzWipSizeIn(c,u){ if(!c||!c.length||!(u<=c[c.length-1].p+1e-9)) return null; const v=kzWipSize(c,u); return Number.isFinite(v)?v:null; }
  function kzWipPass(c,x){ if(x<=c[0].x) return c[0].p*(x/c[0].x); for(let k=1;k<c.length;k++) if(c[k].x>=x){ const d=c[k].x-c[k-1].x; return d>0?c[k-1].p+(c[k].p-c[k-1].p)*(x-c[k-1].x)/d:c[k].p; } return c[c.length-1].p; }
  /* Angka dari Excel: "25%", "0,908", "0.908", "1.234,5", "1,234.5". Mengembalikan {x,amb} atau null. */
  function kzWipNum(s){ s=String(s==null?'':s).trim().replace(/\s/g,'').replace(/%$/,''); if(!s) return null; let amb=false;
    if(s.includes('.')&&s.includes(',')){ s=s.lastIndexOf(',')>s.lastIndexOf('.')?s.replace(/\./g,'').replace(',','.'):s.replace(/,/g,''); }
    else if(s.includes(',')){ if(/^\d{1,3}(,\d{3}){2,}$/.test(s)) s=s.replace(/,/g,''); else { if(/^[1-9]\d{0,2},\d{3}$/.test(s)) amb=true; s=s.replace(',','.'); } }
    else if(/^\d{1,3}(\.\d{3}){2,}$/.test(s)) s=s.replace(/\./g,'');
    else if(/^[1-9]\d{0,2}\.\d{3}$/.test(s)) amb=true;
    if(!/^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i.test(s)) return null; const x=Number(s); return Number.isFinite(x)?{x,amb}:null; }
  /* Tempel dari Excel: kolom 1 = Percent Passing, kolom 2 = Size (mm). pm = 'auto' | 'pct' | 'frac'.
     Auto: sel ber-"%" = persen; sel tanpa "%" = pecahan bila SEMUA sel tanpa-% <= 1, selain itu persen. */
  function kzParseWip(t,pm){ pm=(pm==='pct'||pm==='frac')?pm:'auto'; const raw=[],bad=[],warnings=[]; let headers=0,amb=0,extra=false,wide=0;
    String(t==null?'':t).split(/\r?\n/).forEach((line,li)=>{ const l=line.trim(); if(!l) return;
      let c; if(l.includes('\t')) c=l.split('\t').map(v=>v.trim()); else if(l.includes(';')) c=l.split(';').map(v=>v.trim()); else if(/\s/.test(l)) c=l.split(/\s+/); else if((l.match(/,/g)||[]).length===1) c=l.split(','); else c=[l];
      const a=kzWipNum(c[0]),b=kzWipNum(c[1]);
      if(!a&&!b&&/[A-Za-z]/.test(l)){ headers++; return; }
      if(c.filter(v=>v!=='').length>=4) wide++;
      if(!a||!b){ bad.push('baris '+(li+1)+': bukan angka'); return; }
      if(c.length>2&&c.slice(2).some(v=>v!=='')) extra=true;
      raw.push({p:a.x,pc:/%/.test(c[0]),x:b.x,ln:li+1}); if(b.amb) amb++; });
    if(wide) return {err:'Terdeteksi ≥4 kolom: salin hanya 2 kolom Wipfrag (Percent Passing, Size) — bukan kolom Kuz-Ram.'};
    if(raw.length>500) return {err:'Maksimal 500 baris.'};
    const np=raw.filter(r=>!r.pc), asPct=pm==='pct'||(pm==='auto'&&np.some(r=>r.p>1.0000001)), hasPc=raw.some(r=>r.pc);
    const det=pm!=='auto'?(pm==='pct'?'dipaksa: persen':'dipaksa: pecahan 0–1'):hasPc&&np.length?('campuran: sel ber-% = persen, sel lain = '+(asPct?'persen':'pecahan 0–1')):hasPc?'persen (tanda %)':(asPct?'persen 0–100':'pecahan 0–1');
    const m=new Map(); let dup=0;
    raw.forEach(r=>{ const f=(r.pc||asPct)?r.p/100:r.p;
      if(!(f>=-1e-9&&f<=1.0000001)){ bad.push('baris '+r.ln+': persen di luar 0–100'); return; }
      if(!(r.x>0)||r.x>=1e7){ bad.push('baris '+r.ln+': ukuran harus > 0'); return; }
      if(m.has(r.x)) dup++; m.set(r.x,[Math.min(1,Math.max(0,f)),r.x]); });
    let rows=[...m.values()]; if(rows.length<3) return {err:'Minimal 3 baris valid: kolom 1 = Percent Passing, kolom 2 = Size (mm).'+(bad.length?' Ditolak: '+bad.slice(0,3).join('; ')+'.':'')};
    const inOrder=rows.every((q,k)=>k===0||q[1]>=rows[k-1][1]); if(!inOrder){ rows.sort((u,v)=>u[1]-v[1]); warnings.push('Ukuran tidak berurutan naik — diurutkan otomatis.'); }
    let drops=0; for(let k=1;k<rows.length;k++) if(rows[k][0]<rows[k-1][0]-1e-9) drops++;
    if(drops) warnings.push(drops+' titik persen lebih kecil dari titik sebelumnya (kurva tidak monoton) — periksa data; saat dihitung kurva dipaksa naik.');
    if(dup) warnings.push(dup+' ukuran duplikat — dipakai baris terakhir.');
    if(amb) warnings.push(amb+' sel ukuran ambigu (mis. "1.000" / "1,000"): dibaca sebagai DESIMAL (1,0 mm), bukan ribuan. Periksa bila ukuran seharusnya 1000 mm.');
    if(extra) warnings.push('Kolom ke-3 dan seterusnya diabaikan (hanya kolom 1 dan 2 yang dipakai).');
    return {rows,dropped:bad.length,bad:bad.slice(0,5),warnings,det,headers}; }
  /* ID blast aktif = grup + nomor baris (yang dipakai geometri Kuz-Ram). Data Wipfrag disimpan per ID ini. */
  function kzWipId(){ const a=getActiveBlastRowForComparison(); return a?{key:a.groupKey+'|'+a.row.no,label:a.groupLabel+' • baris '+a.row.no}:null; }
  function kzActiveWip(){ const id=kzWipId(),e=id&&((APP_STATE.kuzram.wipBy||{})[id.key]); return e?e.rows:[]; }
  /*KZ-WIP:PURE:END*/
  const KZ_WIP_SAMPLE=[[0,.1],[0,.15],[0,.22],[0,.32],[0,.46],[0,.68],[0,1],[0,1.47],[0,2.15],[0,3.16],[0,4.64],[0,6.81],[.000486,10],[.00162,14.7],[.0038,21.5],[.00581,31.6],[.011,46.4],[.0196,68.1],[.0506,100],[.251,147],[.703,215],[.908,316],[1,464],[1,681],[1,1000]];
  function kzEnsureWipBox(){ if($('kzWipBox')) return; const tb=$('kzPsdTable'); if(!tb) return; const b=document.createElement('div'); b.id='kzWipBox'; b.style.margin='.6rem 0';
    b.innerHTML='<b>Tabel Kuz-Ram vs Wipfrag</b> <small>— data Wipfrag untuk blast: <b id="kzWipFor">—</b></small>'+
      '<div class="kz-cmp-grid"><div class="kz-cmp-col"><h4>Kuz-Ram <small>(otomatis dari geometri &amp; parameter)</small></h4><div class="kz-cmp-scroll" id="kzCmpKz"></div></div>'+
      '<div class="kz-cmp-col"><h4>Wipfrag <small>(tempel dari Excel)</small></h4>'+
      '<textarea id="kzWipTxt" rows="4" class="kz-cmp-txt" aria-label="Tempel tabel Wipfrag dari Excel: kolom 1 Percent Passing, kolom 2 Size mm" placeholder="Klik di sini lalu Ctrl+V dari Excel&#10;kolom 1 = Percent Passing, kolom 2 = Size (mm)&#10;0.0506&#9;100&#10;0.251&#9;147&#10;0.703&#9;215"></textarea>'+
      '<div class="kz-cmp-scroll" id="kzWipTbl"></div></div></div>'+
      '<div class="kz-row"><button class="btn" id="kzWipApply" type="button">TERAPKAN WIPFRAG</button><button class="btn" id="kzWipSample" type="button">CONTOH BB-6</button><button class="btn" id="kzWipClear" type="button">HAPUS</button><button class="btn" id="kzWipUndo" type="button" disabled>BATALKAN</button><button class="btn" id="kzWipExp" type="button">EKSPOR JSON</button><button class="btn" id="kzWipImp" type="button">IMPOR JSON</button><input id="kzWipImpFile" class="kb-hidden" type="file" accept=".json,application/json" aria-label="Pilih berkas cadangan Wipfrag (JSON)" tabindex="-1">'+ /* REQ-10 */
      '<label class="kz-help" style="margin:0">Persen Passing: <select id="kzWipPm" class="kz-sel"><option value="auto">Auto</option><option value="pct">Persen (0–100)</option><option value="frac">Pecahan (0–1)</option></select></label></div>'+
      '<div class="kz-help">Tempel (Ctrl+V) langsung dari Excel akan MENIMPA seluruh data Wipfrag blast ini dan langsung diterapkan. Data tiap blast/baris disimpan terpisah.</div>'+
      '<div id="kzWipLegacy" class="kz-row" style="display:none"><small>Ada data Wipfrag versi lama (tanpa ID blast).</small><button class="btn" id="kzWipLegUse" type="button">PAKAI UNTUK BLAST INI</button><button class="btn" id="kzWipLegDrop" type="button">BUANG</button></div>'+
      '<div id="kzWipMsg" role="status" aria-live="polite" class="kz-help"></div><div class="kz-row kz-seg"><b>Simulasi pakai:</b><button class="btn" id="kzSimKz" type="button">KUZ-RAM</button><button class="btn" id="kzSimWip" type="button">WIPFRAG</button></div><div id="kzCmp" style="overflow:auto"></div>';
    tb.parentNode.insertBefore(b,tb.nextSibling); const st=()=>APP_STATE.kuzram, msg=t=>{ $('kzWipMsg').textContent=t; }, rerun=()=>{ persistWorking(); kzRender(); if(KZ_UI.anim) kzRun(); };
    const snapUndo=()=>{ const id=kzWipId(); if(!id){ KZ_UI.undoSnap=null; KZ_UI.undoKey=null; return; } KZ_UI.undoKey=id.key; const e=st().wipBy&&st().wipBy[id.key]; KZ_UI.undoSnap=e?JSON.parse(JSON.stringify(e)):null; const ub=$('kzWipUndo'); if(ub) ub.disabled=false; }; /* REQ-10 */
    const updateUndoBtn=()=>{ const ub=$('kzWipUndo'),id=kzWipId(); if(ub) ub.disabled=!(KZ_UI.undoSnap!==undefined&&KZ_UI.undoKey&&id&&id.key===KZ_UI.undoKey); };
    const noBlast=()=>{ msg('Tidak ada blast aktif — pilih blok/baris di Data Proyek dulu.'); };
    const put=(rows,det,extraMsg)=>{ const id=kzWipId(); if(!id){ noBlast(); return false; } snapUndo(); /* REQ-10 */
      /* Capture Kuz-Ram snapshot at paste time for traceability. Uses current KZ_UI.res (already computed)
         or falls back to kzBuild(). If blocked/unavailable, snapshot fields remain null — comparison
         will show "—" rather than fabricating values. */
      let snapX50=null,snapX80=null,snapN=null;
      try{ const cur=KZ_UI.res&&!KZ_UI.res.blocked?KZ_UI.res:kzBuild();
        if(cur&&cur.r&&!cur.blocked){ snapX50=cur.r.x50cm; snapX80=cur.r.x80*100; snapN=cur.r.n; } }catch(_e){}
      st().wipBy=st().wipBy||{}; st().wipBy[id.key]={rows,label:id.label,t:Date.now(),kzX50:snapX50,kzX80:snapX80,kzN:snapN};
      audit('Kuz-Ram Wipfrag '+id.label,null,rows.length+' titik'+(snapX50!=null?' • snapshot X50='+kzF(snapX50,1)+' cm':''),'USER','KUZRAM WIPFRAG'); return true; };
    const apply=txt=>{ const id=kzWipId(); if(!id){ noBlast(); return; } const q=kzParseWip(txt,$('kzWipPm').value); if(q.err){ msg(q.err+' (data Wipfrag sebelumnya tidak diubah)'); return; }
      if(q.rows.length>KZ_MAX_WIP_ROWS){ msg('Tempelan berisi '+q.rows.length+' baris valid — melebihi batas '+KZ_MAX_WIP_ROWS+'. Data tidak diubah.'); return; } /* REQ-01 AC-01c */
      put(q.rows); msg(q.rows.length+' titik Wipfrag diterapkan ke '+id.label+' • Persen Passing terbaca: '+q.det+(q.headers?' • '+q.headers+' baris header dilewati':'')+(q.dropped?` • ${q.dropped} baris ditolak (${q.bad.join('; ')})`:'')+(q.warnings.length?' • PERINGATAN: '+q.warnings.join(' ')+'':'')); rerun(); };
    $('kzWipApply').addEventListener('click',()=>apply($('kzWipTxt').value));
    $('kzWipTxt').addEventListener('paste',e=>{ const t=e.clipboardData&&e.clipboardData.getData('text/plain'); if(!t) return; e.preventDefault(); $('kzWipTxt').value=t; apply(t); });
    $('kzWipSample').addEventListener('click',()=>{ const id=kzWipId(); if(!id){ noBlast(); return; } if(kzActiveWip().length&&!window.confirm('Timpa data Wipfrag '+id.label+' dengan contoh BB-6?')) return; $('kzWipPm').value='auto'; $('kzWipTxt').value=KZ_WIP_SAMPLE.map(q=>q[0]+'\t'+q[1]).join('\n'); apply($('kzWipTxt').value); });
    $('kzWipClear').addEventListener('click',()=>{ const id=kzWipId(); snapUndo(); /* REQ-10 */ if(id&&st().wipBy) delete st().wipBy[id.key]; st().simSrc='kuzram'; $('kzWipTxt').value=''; msg('Data Wipfrag '+(id?id.label:'')+' dihapus (blast lain tidak terpengaruh).'); rerun(); });
    $('kzWipUndo').addEventListener('click',()=>{ const id=kzWipId(); if(!id||!KZ_UI.undoKey||id.key!==KZ_UI.undoKey){ msg('Tidak ada yang bisa dibatalkan.'); return; } st().wipBy=st().wipBy||{}; if(KZ_UI.undoSnap) st().wipBy[KZ_UI.undoKey]=JSON.parse(JSON.stringify(KZ_UI.undoSnap)); else delete st().wipBy[KZ_UI.undoKey]; KZ_UI.undoSnap=null; KZ_UI.undoKey=null; updateUndoBtn(); msg('Aksi terakhir dibatalkan.'); rerun(); }); /* REQ-10 */
    /* cadangan: ekspor seluruh wipBy ke JSON; impor menggabungkan lewat kzSanitize (aturan sama dengan restore), menolak entri tak valid, tidak menimpa tanpa konfirmasi */
    $('kzWipExp').addEventListener('click',()=>{ const n=Object.keys(st().wipBy||{}).length; if(!n){ msg('Belum ada data Wipfrag untuk diekspor.'); return; }
      downloadText('karstblast_wipfrag_'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify({app:'KarstBlast',type:'wipfrag-backup',v:1,exported:new Date().toISOString(),wipBy:kzPersistable().wipBy},null,1),'application/json'); msg(n+' blast diekspor ke berkas JSON.'); });
    $('kzWipImp').addEventListener('click',()=>$('kzWipImpFile').click());
    $('kzWipImpFile').addEventListener('change',e=>{ const f=e.target.files&&e.target.files[0]; e.target.value=''; if(!f) return;
      if(f.size>5e6){ msg('Berkas terlalu besar (maks 5 MB). Data tidak diubah.'); return; }
      const fr=new FileReader(); fr.onerror=()=>msg('Berkas tidak bisa dibaca. Data tidak diubah.');
      fr.onload=()=>{ let raw=String(fr.result); if(raw.charCodeAt(0)===0xFEFF) raw=raw.slice(1); /* REQ-07 AC-07d: BOM */ let j; try{ j=JSON.parse(raw); }catch(_e){ msg('Berkas bukan JSON yang valid. Data tidak diubah.'); return; }
        if(!j||typeof j!=='object'||Array.isArray(j)){ msg('Format tidak dikenali (butuh objek JSON). Data tidak diubah.'); return; } /* REQ-07 AC-07c */
        const src=(j.wipBy&&typeof j.wipBy==='object'&&!Array.isArray(j.wipBy))?j.wipBy:null; if(!src){ msg('Format tidak dikenali (butuh objek "wipBy"). Data tidak diubah.'); return; }
        const total=Object.keys(src).length, san=kzSanitize({wipBy:src}), ok=san.wipBy, keys=Object.keys(ok), ri=san._rejectInfo||{}; /* REQ-01 */
        if(!keys.length){ const parts=[]; if(ri.overLimit) parts.push(ri.overLimit+' melebihi batas '+KZ_MAX_WIP_ENTRIES); if(ri.invalidEntries) parts.push(ri.invalidEntries+' tidak valid'); msg('Tidak ada entri valid di berkas ('+parts.join(', ')+'). Data tidak diubah.'); return; }
        const cur=st().wipBy=st().wipBy||{}, clash=keys.filter(k=>cur[k]&&JSON.stringify(cur[k].rows)!==JSON.stringify(ok[k].rows));
        let skip=[]; if(clash.length&&!window.confirm(clash.length+' blast sudah punya data Wipfrag yang berbeda. Timpa dengan isi berkas?\n\nOK = timpa, Batal = lewati yang sudah ada.')) skip=clash;
        const use=keys.filter(k=>!skip.includes(k)); use.forEach(k=>{ cur[k]=ok[k]; }); audit('Kuz-Ram Wipfrag impor JSON',null,use.length+' blast','USER','KUZRAM WIPFRAG');
        const rejParts=[]; if(ri.overLimit) rejParts.push(ri.overLimit+' melebihi batas '+KZ_MAX_WIP_ENTRIES); if(ri.invalidEntries) rejParts.push(ri.invalidEntries+' tidak valid'); /* REQ-01 */
        const orphans=use.filter(k=>k.startsWith('manual_')&&!BLAST_SHEET_ROWS[k.split('|')[0]]); /* REQ-06 AC-06d */
        msg(use.length+' blast diimpor'+(skip.length?' • '+skip.length+' dilewati (data lama dipertahankan)':'')+(rejParts.length?' • '+rejParts.join(', '):'')+(orphans.length?' • '+orphans.length+' entri manual tanpa blok pasangan (akan terpasang otomatis saat blok dibuat)':'')+'.'); rerun(); };
      fr.readAsText(f); });
    $('kzWipLegUse').addEventListener('click',()=>{ const id=kzWipId(); if(!id){ noBlast(); return; } if(put(st().wipLegacy)){ st().wipLegacy=[]; msg('Data lama dipindahkan ke '+id.label+'.'); rerun(); } });
    $('kzWipLegDrop').addEventListener('click',()=>{ st().wipLegacy=[]; msg('Data Wipfrag versi lama dibuang.'); rerun(); });
    $('kzSimKz').addEventListener('click',()=>{ st().simSrc='kuzram'; rerun(); });
    $('kzSimWip').addEventListener('click',()=>{ if(!kzWipCurve(kzActiveWip())){ msg('Blast ini belum punya data Wipfrag — tempel dari Excel dulu.'); return; } st().simSrc='wipfrag'; rerun(); }); }
  /* REQ-04: sumber efektif = preferensi pengguna ∧ ketersediaan data */
  function kzEffectiveSrc(){ const pref=APP_STATE.kuzram.simSrc; if(pref==='wipfrag'&&kzWipCurve(kzActiveWip())) return 'wipfrag'; return 'kuzram'; }
  function kzSyncBox(wc){ const st=APP_STATE.kuzram, eff=kzEffectiveSrc(); const a=$('kzSimKz'),w=$('kzSimWip'); if(a) a.classList.toggle('is-active',eff!=='wipfrag'); if(w){ w.classList.toggle('is-active',eff==='wipfrag'); w.disabled=!wc; w.title=wc?'':'Blast aktif belum punya data Wipfrag'; }
    const id=kzWipId(),f=$('kzWipFor'); if(f) f.textContent=id?id.label:'— (tidak ada blast aktif)';
    const t=$('kzWipTxt'),key=id?id.key:'',rows=kzActiveWip(); if(t&&document.activeElement!==t&&(KZ_UI.wipKey!==key||(!t.value&&rows.length))){ t.value=rows.map(q=>q[0]+'\t'+q[1]).join('\n'); if(KZ_UI.wipKey!==key){ const m=$('kzWipMsg'); if(m) m.textContent=''; KZ_UI.undoSnap=null; KZ_UI.undoKey=null; const ub=$('kzWipUndo'); if(ub) ub.disabled=true; } /* REQ-10: reset undo saat pindah blast */ } KZ_UI.wipKey=key;
    const lg=$('kzWipLegacy'); if(lg) lg.style.display=(st.wipLegacy&&st.wipLegacy.length>=3)?'':'none'; }
  /* tabel berdampingan: Kuz-Ram (otomatis) | Wipfrag (hasil tempel). rows = grid Kuz-Ram dari kzDrawChart, null bila diblokir */
  function kzRenderTbls(rows){ const k=$('kzCmpKz'),w=$('kzWipTbl'); const pc=v=>(v*100).toFixed(v>0&&v<0.01?3:1)+'%';
    if(k) k.innerHTML=rows?'<table class="kz-tbl"><thead><tr><th>Percent Passing</th><th>Size (mm)</th></tr></thead><tbody>'+rows.map(q=>`<tr><td>${pc(q.p)}</td><td>${q.mm}</td></tr>`).join('')+'</tbody></table>':'<small>Tabel Kuz-Ram tidak tersedia: input diblokir / belum lengkap.</small>';
    const wr=kzActiveWip().slice().sort((u,v)=>u[1]-v[1]);
    if(w) w.innerHTML=wr.length?'<table class="kz-tbl"><thead><tr><th>Percent Passing</th><th>Size (mm)</th></tr></thead><tbody>'+wr.map(q=>`<tr><td>${pc(q[0])}</td><td>${q[1]}</td></tr>`).join('')+'</tbody></table>':'<small>Belum ada data Wipfrag untuk blast ini.</small>'; }
  /* ---- Kuz-Ram vs Wipfrag comparison helpers (Phase 2) ---- */

  /* kzWipDelta: compute comparison metrics for one wipBy entry.
     Convention (confirmed by user):
       ΔX50 = Wipfrag X50 − Kuz-Ram snapshot X50
       ΔX80 = Wipfrag X80 − Kuz-Ram snapshot X80
       % error = |Δ| / |kz snapshot| × 100, only when kz snapshot is nonzero and valid.
     Returns null for any field that cannot be computed safely. */
  function kzWipDelta(entry){
    const wc=kzWipCurve(entry.rows); if(!wc) return null;
    const _m50=kzWipSizeIn(wc,0.5); const measX50=_m50!=null&&Number.isFinite(_m50*100)?_m50*100:null; // cm; guard NaN from kzWipSize
    const _m80=kzWipSizeIn(wc,0.8); const measX80=_m80!=null&&Number.isFinite(_m80*100)?_m80*100:null; // cm
    const snapX50=(typeof entry.kzX50==='number'&&Number.isFinite(entry.kzX50)&&entry.kzX50>0)?entry.kzX50:null;
    const snapX80=(typeof entry.kzX80==='number'&&Number.isFinite(entry.kzX80)&&entry.kzX80>0)?entry.kzX80:null;
    const dX50=(measX50!=null&&snapX50!=null)?measX50-snapX50:null;
    const dX80=(measX80!=null&&snapX80!=null)?measX80-snapX80:null;
    const pctX50=(dX50!=null&&snapX50>0)?Math.abs(dX50)/snapX50*100:null;
    const pctX80=(dX80!=null&&snapX80>0)?Math.abs(dX80)/snapX80*100:null;
    return {measX50,measX80,snapX50,snapX80,dX50,dX80,pctX50,pctX80};
  }

  /* kzDeltaClass: CSS class name for a percentage error value.
     Thresholds are defined here for transparency and displayed in the UI legend.
     These are application-defined display thresholds, NOT established engineering standards. */
  const KZ_DELTA_THRESHOLDS={good:10,warn:20}; // % — displayed in legend
  function kzDeltaClass(pct){
    if(pct==null) return '';
    if(pct<=KZ_DELTA_THRESHOLDS.good) return 'kz-delta-good';
    if(pct<=KZ_DELTA_THRESHOLDS.warn) return 'kz-delta-warn';
    return 'kz-delta-bad';
  }

  /* kzWipCompareData: build cross-blast comparison array from all wipBy entries.
     Returns array of row objects; each row has label, measX50/80, snapX50/80, dX50/80, pctX50/80.
     Also returns maeX50, maeX80, biasX50, biasX80 summary (mean absolute error and mean signed error)
     calculated over entries where both snapshot and measured values are valid. */
  function kzWipCompareData(){
    const wb=APP_STATE.kuzram&&APP_STATE.kuzram.wipBy||{};
    const rows=[]; let sumAbsX50=0,sumAbsX80=0,sumSignedX50=0,sumSignedX80=0,nX50=0,nX80=0;
    Object.entries(wb).forEach(([key,entry])=>{
      if(!entry||!Array.isArray(entry.rows)||entry.rows.length<3) return;
      const d=kzWipDelta(entry); if(!d) return;
      rows.push({key,label:entry.label||key,t:entry.t||0,...d});
      if(d.dX50!=null){ sumAbsX50+=Math.abs(d.dX50); sumSignedX50+=d.dX50; nX50++; }
      if(d.dX80!=null){ sumAbsX80+=Math.abs(d.dX80); sumSignedX80+=d.dX80; nX80++; }
    });
    rows.sort((a,b)=>a.label.localeCompare(b.label));
    const maeX50=nX50>0?sumAbsX50/nX50:null;
    const maeX80=nX80>0?sumAbsX80/nX80:null;
    const biasX50=nX50>0?sumSignedX50/nX50:null; // positive = Wipfrag > Kuz-Ram (model under-predicts)
    const biasX80=nX80>0?sumSignedX80/nX80:null;
    return {rows,maeX50,maeX80,biasX50,biasX80,nX50,nX80};
  }

  /* renderWipComparisonPanel: render cross-blast comparison table into a target element.
     targetId must be an element id (e.g. 'kzWipCompareSummary' or 'rKzWipCompare').
     No-op if element does not exist. */
  function renderWipComparisonPanel(targetId){
    const el=$(targetId); if(!el) return;
    const {rows,maeX50,maeX80,biasX50,biasX80,nX50,nX80}=kzWipCompareData();
    if(!rows.length){
      el.innerHTML='<p class="kz-help">Belum ada data Wipfrag tersimpan. Tempel data Wipfrag di panel Kuz-Ram untuk blast aktif.</p>';
      return;
    }
    const sign=v=>(v>0?'+':'')+kzF(v,1);
    const cell=(v,cls)=>`<td class="${cls}">${v}</td>`;
    const snap=(v)=>v!=null?kzF(v,1)+' cm':'—';
    const meas=(v)=>kzF(v,1)+' cm';
    const delta=(d,pct)=>{ if(d==null||!Number.isFinite(d)) return '<td class="kz-delta-na">—<br><small>snapshot tidak ada</small></td>'; return `<td class="${kzDeltaClass(pct)}">${sign(d)} cm<br><small>${kzF(pct,1)}%</small></td>`; };
    let html='<table class="kz-wip-cmp-tbl"><thead><tr>'
      +'<th>Blast</th>'
      +'<th>X50 Kuz-Ram*</th><th>X50 Wipfrag</th><th>ΔX50 (W−K)</th>'
      +'<th>X80 Kuz-Ram*</th><th>X80 Wipfrag</th><th>ΔX80 (W−K)</th>'
      +'</tr></thead><tbody>';
    rows.forEach(r=>{
      html+='<tr>'
        +'<td>'+htmlEscape(r.label)+'</td>'
        +cell(snap(r.snapX50),'')
        +cell(meas(r.measX50),'')
        +delta(r.dX50,r.pctX50)
        +cell(snap(r.snapX80),'')
        +cell(meas(r.measX80),'')
        +delta(r.dX80,r.pctX80)
        +'</tr>';
    });
    html+='</tbody>';
    if(nX50>0||nX80>0){
      const biasDir=(b)=>b==null?'—':b>0.5?'model cenderung prediksi lebih kecil (+Wipfrag)':b<-0.5?'model cenderung prediksi lebih besar (−Wipfrag)':'prediksi seimbang';
      html+='<tfoot><tr class="kz-wip-cmp-summary">'
        +'<td><b>MAE ('+Math.max(nX50,nX80)+' dari '+rows.length+' blast)</b></td>'
        +'<td colspan="2"></td>'
        +(nX50>0?`<td><b>${kzF(maeX50,1)} cm</b><br><small>${biasDir(biasX50)}</small></td>`:'<td>—</td>')
        +'<td colspan="2"></td>'
        +(nX80>0?`<td><b>${kzF(maeX80,1)} cm</b></td>`:'<td>—</td>')
        +'</tr></tfoot>';
    }
    html+='</table>';
    html+='<p class="kz-help kz-wip-cmp-legend">Legenda: '
      +'<span class="kz-delta-good">≤'+KZ_DELTA_THRESHOLDS.good+'%</span> '
      +'<span class="kz-delta-warn">'+KZ_DELTA_THRESHOLDS.good+'–'+KZ_DELTA_THRESHOLDS.warn+'%</span> '
      +'<span class="kz-delta-bad">&gt;'+KZ_DELTA_THRESHOLDS.warn+'%</span> '
      +'— Ambang batas tampilan aplikasi, bukan standar teknik baku. '
      +'ΔX = Wipfrag − Kuz-Ram. *Kuz-Ram diambil saat Wipfrag ditempel (snapshot).</p>';
    el.innerHTML=html;
  }

  /* ---- End Phase 2 helpers ---- */

  function kzRenderCmp(res,wc){ const el=$('kzCmp'); if(!el) return; if(!res||!res.r){ el.innerHTML=''; return; }
    const r=res.r,i=res.i,K={x50:r.x50cm,x80:r.x80*100,pt:r.passAtTarget,ov:r.oversize,wi:r.within,un:r.undersize}; let W=null;
    if(wc){ const P=x=>kzWipPass(wc,x),ov=1-P(i.oversizeM),un=P(i.undersizeM); const _w50=kzWipSizeIn(wc,.5),_w80=kzWipSizeIn(wc,.8); W={x50:_w50==null?null:_w50*100,x80:_w80==null?null:_w80*100,pt:P(i.passingM),ov,wi:1-ov-un,un}; }
    const row=(l,k,f)=>`<tr><td>${l}</td><td>${f(K[k])}</td><td>${W?f(W[k]):'—'}</td></tr>`,cm=v=>kzF(v,1)+' cm',pc=v=>kzPct(v);
    /* Delta rows (Phase 2): ΔX = Wipfrag − Kuz-Ram, % error = |Δ|/|Kuz-Ram| × 100.
       Convention confirmed by user. Only shown when Wipfrag data is present. */
    let deltaRows='';
    if(W){
      const dX50=W.x50==null?null:W.x50-K.x50, dX80=W.x80==null?null:W.x80-K.x80;
      const pX50=(dX50!=null&&K.x50>0)?Math.abs(dX50)/K.x50*100:null;
      const pX80=(dX80!=null&&K.x80>0)?Math.abs(dX80)/K.x80*100:null;
      const fmt=(d,p)=>{ if(d==null) return '<td class="kz-delta-na">— (kurva Wipfrag tidak mencapai persentil ini)</td>'; const cls=kzDeltaClass(p); const sign=d>0?'+':''; return `<td class="${cls}">${sign+kzF(d,1)} cm (${p!=null?kzF(p,1)+'%':'—'})</td>`; };
      deltaRows=`<tr><td>ΔX50 (Wipfrag − Kuz-Ram)</td>${fmt(dX50,pX50)}<td></td></tr>`
               +`<tr><td>ΔX80 (Wipfrag − Kuz-Ram)</td>${fmt(dX80,pX80)}<td></td></tr>`;
    }
    el.innerHTML='<table><tr><th>Perbandingan</th><th>Kuz-Ram</th><th>Wipfrag</th></tr>'+row('X50','x50',cm)+row('X80','x80',cm)+row(`Lolos @ ${i.passingM} m`,'pt',pc)+row(`Oversize (≥ ${i.oversizeM} m)`,'ov',pc)+row('Dalam rentang','wi',pc)+row(`Undersize (≤ ${i.undersizeM} m)`,'un',pc)+deltaRows+'</table>'+(W?'<small>Wipfrag: interpolasi linear antar titik tabel. ΔX = Wipfrag − Kuz-Ram; % = |Δ|/|Kuz-Ram|. Ambang batas tampilan: hijau ≤'+KZ_DELTA_THRESHOLDS.good+'%, kuning ≤'+KZ_DELTA_THRESHOLDS.warn+'%, merah >'+KZ_DELTA_THRESHOLDS.warn+'% — bukan standar teknik baku.</small>':'<small>Isi data Wipfrag untuk membandingkan.</small>'); }
  function kzDrawChart(res){
    // Grafik meniru lembar BB-6: X = Percent passing (0-100%), Y = ukuran (mm, linear), titik tiap 50 mm, garis target (F22).
    const svg=$('kzChart'); if(!svg) return; const W=640,H=320,L=54,R=16,T=32,B=40; svg.setAttribute('viewBox','0 0 '+W+' '+H);
    let tb=$('kzPsdTable'); if(!tb){ tb=document.createElement('details'); tb.id='kzPsdTable'; svg.parentNode.insertBefore(tb,svg.nextSibling); }
    kzEnsureWipBox(); const wc=kzWipCurve(kzActiveWip()); kzSyncBox(wc);
    if(!res||!res.r){ svg.innerHTML='<text x="320" y="160" text-anchor="middle" font-size="12" fill="currentColor">Grafik tidak tersedia: input diblokir / belum lengkap</text>'; ['xc','n','x80','x50'].forEach(k=>delete svg.dataset[k]); tb.innerHTML=''; kzRenderTbls(null); kzRenderCmp(null,wc); return; }
    const wMax=wc?Math.max(...wc.map(q=>q.x*1000)):0,r=res.r,tgt=res.i.passingM*1000,maxMm=Math.max(1100,wMax,Math.ceil(Math.max(res.i.oversizeM*1000,tgt)/50)*50),yMax=Math.ceil((maxMm+100)/200)*200;
    const rows=[]; for(let mm=0;mm<=maxMm;mm+=50) rows.push({mm,p:r.passFn(mm/1000)});
    const X=p=>L+p*(W-L-R),Y=mm=>T+(1-mm/yMax)*(H-T-B);
    let s=`<text x="${(L+W-R)/2}" y="18" text-anchor="middle" font-size="13" font-weight="700" fill="currentColor">Percent passing vs target ${kzF(tgt,0)} (mm)</text><rect x="${L}" y="${T}" width="${W-L-R}" height="${H-T-B}" fill="none" stroke="currentColor" opacity=".35"/>`;
    for(let k=0;k<=5;k++){ const p=k/5; s+=`<line x1="${X(p)}" x2="${X(p)}" y1="${T}" y2="${H-B}" stroke="currentColor" opacity=".12"/><text x="${X(p)}" y="${H-B+14}" text-anchor="middle" font-size="10" fill="currentColor">${k*20}.0%</text>`; }
    for(let v=0;v<=yMax;v+=200) s+=`<line x1="${L}" x2="${W-R}" y1="${Y(v)}" y2="${Y(v)}" stroke="currentColor" opacity=".12"/><text x="${L-6}" y="${Y(v)+3.5}" text-anchor="end" font-size="10" fill="currentColor">${v}</text>`;
    s+=`<polyline fill="none" stroke="#4472c4" stroke-width="2" points="${rows.map(q=>X(q.p).toFixed(1)+','+Y(q.mm).toFixed(1)).join(' ')}"/>`+rows.map(q=>`<circle cx="${X(q.p).toFixed(1)}" cy="${Y(q.mm).toFixed(1)}" r="3" fill="#4472c4"/>`).join('');
    const tgtLabelY=Y(tgt)-6<T+14?Y(tgt)+16:Y(tgt)-6; /* REQ-09: hindari tumpang-tindih label di tepi atas */
    s+=`<line x1="${L}" x2="${W-R}" y1="${Y(tgt)}" y2="${Y(tgt)}" stroke="#c0392b" stroke-width="1.6" stroke-dasharray="5 3"/><circle cx="${X(r.passAtTarget)}" cy="${Y(tgt)}" r="4.5" fill="#c0392b"/><text x="${W-R-4}" y="${tgtLabelY}" text-anchor="end" font-size="10.5" fill="#c0392b">target ${kzF(tgt,0)} mm • lolos ${kzPct(r.passAtTarget)}</text>`;
    s+=`<text x="${(L+W-R)/2}" y="${H-5}" text-anchor="middle" font-size="10.5" fill="currentColor">Percent passing</text><text x="13" y="${(T+H-B)/2}" font-size="10.5" fill="currentColor" transform="rotate(-90 13 ${(T+H-B)/2})" text-anchor="middle">Size (mm)</text>`;
    if(wc) s+=`<polyline fill="none" stroke="#e07b00" stroke-width="2" points="${wc.map(q=>X(q.p).toFixed(1)+','+Y(q.x*1000).toFixed(1)).join(' ')}"/>`+wc.map(q=>`<circle cx="${X(q.p).toFixed(1)}" cy="${Y(q.x*1000).toFixed(1)}" r="3" fill="#e07b00"/>`).join('');
    s+=`<g font-size="10.5" fill="currentColor"><line x1="${L+10}" x2="${L+30}" y1="${T+14}" y2="${T+14}" stroke="#4472c4" stroke-width="2"/><text x="${L+35}" y="${T+18}">Kuz-Ram</text>${wc?`<line x1="${L+10}" x2="${L+30}" y1="${T+30}" y2="${T+30}" stroke="#e07b00" stroke-width="2"/><text x="${L+35}" y="${T+34}">Wipfrag</text>`:''}</g>`;
    svg.innerHTML=s; Object.assign(svg.dataset,{xc:String(r.xc),n:String(r.n),x80:String(r.x80),x50:String(r.x50m)});
    tb.innerHTML='<summary>Tabel distribusi (kelas 50 mm, seperti lembar BB-6)</summary><div style="overflow:auto;max-height:260px"><table><tr><th>Size (mm)</th><th>Percent passing</th><th>% dalam kelas</th></tr>'+rows.slice(1).map((q,k)=>`<tr><td>${q.mm}</td><td>${(q.p*100).toFixed(2)}%</td><td>${((q.p-rows[k].p)*100).toFixed(2)}%</td></tr>`).join('')+'</table></div>'; kzRenderTbls(rows); kzRenderCmp(res,wc);
  }
  function kzFormulaText(res){
    if(!res||!res.r) return 'Rumus tidak ditampilkan: input diblokir. Lengkapi/perbaiki input terlebih dahulu.';
    const r=res.r,b=r.bi,i=res.i,ex=res.mode==='excel',f=(v,d=4)=>kzF(v,d);
    return [`MODE: ${ex?'EXCEL (rumus sumber apa adanya)':'KOREKSI (lihat catatan audit)'}`,
      `A = 0,06·(RMD+JPS+JPO+RDI+HF) = 0,06·(${f(b.rmd,2)}+${f(b.jps,0)}+${f(b.jpo,0)}+${f(b.rdi,2)}+${f(b.hf,2)}) = ${f(b.A)}`,
      `PF = Q/(B·S·H) = ${f(r.pfKgM3)} kg/m³   (Q = charge weight per lubang)`,
      `E% = ((VODef/VODnom)²·RWS)·100 = ${f(r.Eperc,2)}`,
      `X50 = A·PF^−0,8·Q^(1/6)·(115/E%)^(19/30) = ${f(r.x50cm)} cm`,
      `n = (2,2−14·B/D)·√(0,5·(1+S/B))·(1−W/B)·${ex?'(0,1+L/L)^0,1':'(|BCL−CCL|/L+0,1)^0,1'}·(L/H)·fpola = ${f(r.n)}   [faktor panjang = ${f(r.lenFactor)}]`,
      `Xc = X50/(${ex?'0,693':'ln 2'})^(1/n) = ${f(r.xc*100)} cm`,
      `P(x) = 1 − exp[−(x/Xc)^n];  X80 = Xc·(−ln 0,2)^(1/n) = ${f(r.x80*100)} cm`,
      `Oversize = exp[−(${i.oversizeM}/Xc)^n] = ${kzPct(r.oversize)};  Undersize = P(${i.undersizeM}) = ${kzPct(r.undersize)};  Passing F22 = P(${i.passingM}) = ${kzPct(r.passAtTarget)}`,
      `Catatan audit: koreksi mengganti 0,1<B13<F21 (selalu FALSE di Excel), sudut JPO dilipat 0–180°, HF=UCS/5 bila E≥50 GPa, 0,693→ln2, faktor panjang memakai |BCL−CCL| (default 0 = ASUMSI). Parameter RMD spesifik spreadsheet; ambang JPO 30/60 perlu verifikasi geoteknik.`,
      ...(r.warnings.length?['PERINGATAN: '+r.warnings.join(' • ')]:[])].join('\n');
  }
  function kzRender(){
    if(!$('kzPanel')) return null; kzBuildTable();
    const st=APP_STATE.kuzram,res=kzBuild(); KZ_UI.res=res; const key=res.key;
    $('kzDefaultKey').textContent=APP_STATE.formula.key; $('kzSource').value=key; $('kzBlockLabel').textContent='Blok/baris: '+res.info.label;
    $('kzModeCorr').classList.toggle('is-active',st.mode==='corrected'); $('kzModeExcel').classList.toggle('is-active',st.mode==='excel');
    const ovk=res.ovKeys, nd=Object.values(st.manualSrc).filter(x=>x==='DEFAULT').length+(res.info.diaDefault&&!res.ovKeys.includes('holeDiaMm')?1:0), bc=Object.values(st.manualSrc).includes('CONTOH'), as=st.manualSrc.bclMinusCclM==='ASUMSI';
    $('kzBadges').innerHTML=kzBadge(res.blocked?'BLOKIR':'FRESH',res.blocked?'bad':'ok')+kzBadge('SUMBER: '+(res.info.srcText||key.toUpperCase()))+(res.info.demo?kzBadge('DEMO','warn'):'')+kzBadge('MODE '+(st.mode==='excel'?'EXCEL':'KOREKSI'))+(bc?kzBadge('CONTOH','warn'):'')+(as?kzBadge('ASUMSI |BCL−CCL|=0','warn'):'')+(ovk.length?kzBadge('OVERRIDE: '+ovk.map(k=>KZ_LABEL[k]||k).join(', '),'warn'):'')+(nd?kzBadge('DEFAULT EXCEL: '+nd+' param','warn'):'');
    const set=(id,t)=>{const el=$(id); if(el) el.textContent=t;}, g=res.g, i=res.i;
    const blk=res.blk, isO=k=>ovk.includes(k);
    const gRow=(k,ok,bv,dec,txt)=>{ const inp=$('kzg_'+k); if(!inp) return; inp.placeholder=bv==null?'—':kzF(bv,dec); if(document.activeElement!==inp) inp.value=isO(ok)?String((st.geo||{})[ok]):''; set('kzs_'+k,isO(ok)?'OVERRIDE (USER) • nilai blok: '+(bv==null?'—':kzF(bv,dec)):txt); };
    gRow('B','burdenM',blk.B,2,res.info.srcText); gRow('S','spacingM',blk.S,2,res.info.srcText); gRow('H','benchM',blk.H,2,key==='actual'?'ACTUAL • kedalaman baris (bench)':res.info.srcText);
    gRow('D','holeDiaMm',blk.D,1,res.info.diaDefault?'DEFAULT lembar Excel BB-6 (diameter belum diisi di modul geometri)':'comparisonInputs.diameterIn × 25,4'); gRow('L','chargeLenM',blk.L,3,res.info.srcText+' • panjang charge');
    gRow('PF','pfKgM3',blk.PF,4,'BLOK • Q/(B×S×H) per lubang');
    if(res.pf&&i.rockSG){ const e=$('kzs_PF'); if(e) e.textContent+=' • efektif '+kzF(res.pf,4)+' kg/m³ ≈ '+kzF(res.pf/i.rockSG,3)+' kg/ton'; }
    set('kzv_Q',kzF(g.Q,3)); set('kzs_Q',isO('pfKgM3')?'DERIVED • PF×B×S×H (PF di-override)':res.info.srcText+' • kg per lubang');
    KZ_FIELDS.forEach(([k])=>{ const inp=$('kzi_'+k),srcEl=$('kzs_'+k); if(!inp) return;
      if(k==='rockSG'&&res.info.rockSrc==='comparisonInputs.rockDensity'){ srcEl.textContent='Mengikuti densitas lab/geometri (isi untuk menimpa)'; inp.placeholder=kzF(i.rockSG,3); if(document.activeElement!==inp) inp.value=''; }
      else{ srcEl.textContent=(k==='rockSG'&&res.info.rockSrc==='USER')?'OVERRIDE (USER)':kzSrcText(k); if(document.activeElement!==inp){ const v=st.manual[k]; inp.value=v==null?'':String(v); } } });
    const bm=$('kzBlockMsg'); bm.style.display=res.blocked?'':'none'; bm.innerHTML=res.blocked?'<b>HASIL DIBLOKIR</b><br>'+res.reasons.map(x=>'• '+htmlEscape(x)).join('<br>'):'';
    const r=res.r, K=(l,v)=>`<div class="kz-kpi"><span>${l}</span><b>${v}</b></div>`;
    $('kzKpis').innerHTML=r?K('X50',kzF(r.x50cm,1)+' cm')+K('Xc',kzF(r.xc*100,1)+' cm')+K('X80',kzF(r.x80*100,1)+' cm')+K('n',kzF(r.n,3))+K(`Passing @ F22 (${i.passingM} m)`,kzPct(r.passAtTarget))+K(`Oversize (≥ ${i.oversizeM} m)`,kzPct(r.oversize))+K(`Undersize (≤ ${i.undersizeM} m)`,kzPct(r.undersize))+K('Dalam rentang',kzPct(r.within)):K('X50','—')+K('Xc','—')+K('X80','—')+K('n','—');
    const o=res.rOther; if(r&&o){ const cR=st.mode==='corrected'?r:o,eR=st.mode==='excel'?r:o; $('kzModeDiff').textContent=`Koreksi − Excel: Δn = ${(cR.n-eR.n).toFixed(4)} (Excel ${eR.n.toFixed(4)} → Koreksi ${cR.n.toFixed(4)}) • ΔX80 = ${((cR.x80-eR.x80)*100).toFixed(2)} cm (Excel ${(eR.x80*100).toFixed(2)} → Koreksi ${(cR.x80*100).toFixed(2)})`; } else $('kzModeDiff').textContent='Selisih mode: — (input belum lengkap / diblokir)';
    kzDrawChart(res); const fe=$('kzFormula'); fe.style.display=KZ_UI.detail?'':'none'; if(KZ_UI.detail) fe.textContent=kzFormulaText(res);
    const stale=!!KZ_UI.anim&&KZ_UI.anim.hash!==res.hash; $('kzStale').style.display=stale?'':'none';
    try{ renderKzReport(); }catch(_e){}
    try{ renderWipComparisonPanel('kzWipCompareSummary'); }catch(_e){} /* Phase 2: cross-blast accuracy panel */
    return res;
  }
  /* ---------- animasi canvas: partikel representatif dari kzParticles ---------- */
  const KZ_N=220,KZ_W=720,KZ_H=340,KZ_GROUND=285,KZ_END=5600;
  const kzHeap=x=>Math.max(0,x<390?95*(x-250)/140:95*(660-x)/270);
  function kzMakeAnim(res){
    const r=res.r,wc=kzEffectiveSrc()==='wipfrag'?kzWipCurve(kzActiveWip()):null,over=res.i.oversizeM; /* REQ-04 */
    let P=kzParticles(r,KZ_N,20260617); if(wc) P=P.map(q=>({...q,sizeM:kzWipSize(wc,q.u)}));
    const parts=P.map(p=>{ const a=p.seed,b=kzFrac(a+.13),c=kzFrac(a*7+.31),d=kzFrac(a*13+.57),boulder=p.sizeM>=over,rad=2.5+10.5*Math.sqrt(Math.min(1,p.sizeM/(over*1.3)));
      const x0=boulder?205+a*45:80+a*170,y0=KZ_GROUND-14-b*120; let xf,yf;
      if(boulder){ xf=x0+25+c*55; yf=KZ_GROUND-rad-kzHeap(xf)*(.5+.5*d); }
      else{ xf=262+(.05+.95*c)*390; yf=KZ_GROUND-rad-d*Math.max(0,kzHeap(xf)-2*rad); }
      const nv=5+Math.floor(a*3),rr=[]; for(let k=0;k<nv;k++) rr.push(.62+.38*kzFrac(a*(k+3)*17.3));
      return {size:p.sizeM,boulder,rad,x0,y0,xf,yf,t0:1500+b*600+(boulder?350:0),dur:boulder?1900:1300+c*1000,arc:boulder?18+20*d:40+90*(1-p.u)*d+25,rot:a*6.28,spin:(a-.5)*8,rr}; });
    return {src:wc?'WIPFRAG':'KUZ-RAM',hash:res.hash,xc:r.xc,n:r.n,x80:r.x80,count:KZ_N,boulders:parts.filter(q=>q.boulder).length,parts,t:0,start:null,done:false,over,phase:'inisiasi'};
  }
  function kzDraw(A){
    const cv=$('kzCanvas'); if(!cv) return; const c=cv.getContext('2d'); if(!c) return; c.clearRect(0,0,KZ_W,KZ_H); c.fillStyle='#17202a'; c.fillRect(0,0,KZ_W,KZ_H);
    c.fillStyle='#3b3f45'; c.fillRect(0,KZ_GROUND,KZ_W,KZ_H-KZ_GROUND);
    if(!A){ c.fillStyle='#9aa7b4'; c.font='13px sans-serif'; c.textAlign='center'; c.fillText('Tekan "HITUNG + SIMULASIKAN PELEDAKAN" untuk menjalankan animasi',KZ_W/2,150); c.textAlign='left'; return; }
    const t=A.t, hx=150;
    const rockA=Math.max(0,1-Math.max(0,t-1500)/1700); if(rockA>0){ c.globalAlpha=rockA; c.fillStyle='#7a6f5d'; c.fillRect(70,160,180,125); c.globalAlpha=1; }
    c.fillStyle='#2b2f36'; c.fillRect(hx-5,170,10,95); const ch=t<800?'#e0a030':'#555'; c.fillStyle=ch; c.fillRect(hx-5,205,10,60);
    A.phase=t<800?'inisiasi':t<2300?'gelombang':t<4400?'fragmen terlepas':'mengendap';
    if(t>=0&&t<500){ c.fillStyle=`rgba(255,220,120,${.8*(1-t/500)})`; c.beginPath(); c.arc(hx,235,10+t/6,0,6.28); c.fill(); }
    if(t>600&&t<2400){ for(let k=0;k<3;k++){ const rt=t-600-k*220; if(rt<0) continue; const rad=rt*0.16; c.strokeStyle=`rgba(255,200,100,${Math.max(0,.7-rt/1800)})`; c.lineWidth=2; c.beginPath(); c.arc(hx,235,rad,0,6.28); c.stroke(); } }
    A.parts.forEach(q=>{ let p=(t-q.t0)/q.dur; const e0=p<=0?0:p>=1?1:p, e=e0*e0*(3-2*e0); const x=q.x0+(q.xf-q.x0)*e, y=q.y0+(q.yf-q.y0)*e-q.arc*Math.sin(Math.PI*e0);
      const ang=q.rot+q.spin*e*(1-e0*.3); c.save(); c.translate(x,y); c.rotate(ang); c.beginPath(); q.rr.forEach((rv,k)=>{ const th=k/q.rr.length*6.283; const px=Math.cos(th)*q.rad*rv,py=Math.sin(th)*q.rad*rv; k?c.lineTo(px,py):c.moveTo(px,py); }); c.closePath();
      c.fillStyle=q.boulder?'#c9573a':`hsl(${35+Math.round(q.size/ (A.over||1)*60)},${22+Math.round(q.size/(A.over||1)*20)}%,${52+Math.round(Math.min(1,q.size/(A.over||1))*10)}%)`; c.fill(); c.strokeStyle='rgba(0,0,0,.45)'; c.lineWidth=.8; c.stroke(); c.restore(); });
    c.fillStyle='#d8dde3'; c.font='11px monospace'; c.fillText(`Fase: ${A.phase}${A.done?' • selesai (muckpile)':''}`,12,18); c.fillText(`Sumber: ${A.src||'KUZ-RAM'} • N=${A.count} partikel representatif • boulder (≥ oversize) = ${A.boulders} • tiap partikel = 1/${A.count} massa`,12,34);
    c.fillStyle='#9aa7b4'; c.fillText('ILUSTRATIF — bukan flyrock, bukan jumlah batu aktual',12,KZ_H-8);
  }
  function kzStopAnim(){ if(KZ_UI.raf){ cancelAnimationFrame(KZ_UI.raf); KZ_UI.raf=0; } }
  function kzResetAnim(){ kzStopAnim(); KZ_UI.anim=null; kzDraw(null); const s=$('kzStale'); if(s) s.style.display='none'; }
  function kzTick(ts){ const A=KZ_UI.anim; if(!A) return; if(A.start==null) A.start=ts; A.t=Math.min(KZ_END,ts-A.start); if(A.t>=KZ_END) A.done=true; kzDraw(A); KZ_UI.raf=A.done?0:requestAnimationFrame(kzTick); }
  function kzRun(){
    const res=kzRender(); if(!res||res.blocked){ kzResetAnim(); return false; }
    kzStopAnim(); KZ_UI.anim=kzMakeAnim(res); const cv=$('kzCanvas'); Object.assign(cv.dataset,{xc:String(res.r.xc),n:String(res.r.n),x80:String(res.r.x80),count:String(KZ_N),hash:'1'});
    $('kzStale').style.display='none'; kzDraw(KZ_UI.anim); KZ_UI.raf=requestAnimationFrame(kzTick); return true;
  }
  function kzOnTabVisible(){ kzRender(); if(KZ_UI.anim) kzDraw(KZ_UI.anim); else kzDraw(null); }
  function kzHydrate(){ kzRender(); }
  function kzPersistable(){ const s=APP_STATE.kuzram; return {dv:KZ_DV,mode:s.mode,source:s.source,manual:{...s.manual},manualSrc:{...s.manualSrc},geo:{...s.geo},wip:(s.wipLegacy||[]).map(q=>[q[0],q[1]]),wipBy:Object.fromEntries(Object.entries(s.wipBy||{}).map(([k,e])=>[k,{rows:e.rows.map(q=>[q[0],q[1]]),label:e.label,t:e.t,kzX50:e.kzX50??null,kzX80:e.kzX80??null,kzN:e.kzN??null}])),simSrc:s.simSrc||'kuzram'}; }
  function kzReportLines(){ const res=KZ_UI.res||kzBuild(), r=res.r; const wcR=kzWipCurve(kzActiveWip()),wid=kzWipId(); return {model:'Kuz–Ram ('+KZ_VERSION+') • mode '+(res.mode==='excel'?'EXCEL':'KOREKSI')+' • sumber '+(res.info.srcText||res.key)+' • PSD simulasi: '+(kzEffectiveSrc()==='wipfrag'?'WIPFRAG '+(wid?wid.label:''):'KUZ-RAM'), /* REQ-04 */
    params:res.blocked?'DIBLOKIR: '+res.reasons.join(' | '):`B=${kzF(res.g.B)} m, S=${kzF(res.g.S)} m, H=${kzF(res.g.H)} m, D=${kzF(res.i.holeDiaMm,1)} mm, Q=${kzF(res.g.Q,2)} kg/lubang, PF=${kzF(res.pf,3)} kg/m³`+(res.ovKeys.length?' • OVERRIDE: '+res.ovKeys.map(k=>KZ_LABEL[k]||k).join(', '):''),
    result:r?`X50=${kzF(r.x50cm,1)} cm • X80=${kzF(r.x80*100,1)} cm • n=${kzF(r.n,3)} • passing F22=${kzPct(r.passAtTarget)} • oversize=${kzPct(r.oversize)}`+(wcR?` • Wipfrag: X50=${kzF(kzWipSizeIn(wcR,.5)==null?NaN:kzWipSizeIn(wcR,.5)*100,1)} cm, X80=${kzF(kzWipSizeIn(wcR,.8)==null?NaN:kzWipSizeIn(wcR,.8)*100,1)} cm`:''):'—'}; }
  function renderKzReport(){ if(!$('rKzModel')) return; try{ const L=kzReportLines(); $('rKzModel').textContent=L.model; $('rKzParams').textContent=L.params; $('rKzResult').textContent=L.result; }catch(e){} }
  function kzReportHtml(){
    const L=kzReportLines();
    let html=`<h2>Simulasi Fragmentasi Kuz–Ram</h2><p>${htmlEscape(L.model)}. Hasil keluaran model (bukan pengukuran lapangan); parameter manual berlabel sumber di aplikasi.</p><table><tr><th>Parameter</th><th>Value</th></tr><tr><td>Input</td><td>${htmlEscape(L.params)}</td></tr><tr><td>Hasil</td><td>${htmlEscape(L.result)}</td></tr></table>`;
    /* Phase 2: Wipfrag comparison section in export */
    try{
      const {rows,maeX50,maeX80,nX50,nX80}=kzWipCompareData();
      if(rows.length){
        const sign=v=>(v>0?'+':'')+v.toFixed(1);
        const fmt=(v)=>v!=null?v.toFixed(1)+' cm':'—';
        html+='<h2>Akurasi Model Kuz-Ram vs Wipfrag (Perbandingan Prediksi-Pengukuran)</h2>';
        html+='<p>ΔX = Wipfrag − Kuz-Ram snapshot. % = |Δ|/|Kuz-Ram|. '
             +'Kuz-Ram diambil saat Wipfrag ditempel (snapshot). '
             +'Ambang batas tampilan (≤'+KZ_DELTA_THRESHOLDS.good+'% / ≤'+KZ_DELTA_THRESHOLDS.warn+'% / >'+KZ_DELTA_THRESHOLDS.warn+'%) '
             +'adalah batas tampilan aplikasi, bukan standar teknik baku.</p>';
        html+='<table><tr><th>Blast</th><th>X50 Kuz-Ram (cm)*</th><th>X50 Wipfrag (cm)</th><th>ΔX50</th><th>%Err X50</th>'
             +'<th>X80 Kuz-Ram (cm)*</th><th>X80 Wipfrag (cm)</th><th>ΔX80</th><th>%Err X80</th></tr>';
        rows.forEach(r=>{
          html+=`<tr><td>${htmlEscape(r.label)}</td>`
              +`<td>${fmt(r.snapX50)}</td><td>${fmt(r.measX50)}</td>`
              +`<td>${r.dX50!=null?sign(r.dX50)+' cm':'—'}</td><td>${r.pctX50!=null?r.pctX50.toFixed(1)+'%':'—'}</td>`
              +`<td>${fmt(r.snapX80)}</td><td>${fmt(r.measX80)}</td>`
              +`<td>${r.dX80!=null?sign(r.dX80)+' cm':'—'}</td><td>${r.pctX80!=null?r.pctX80.toFixed(1)+'%':'—'}</td>`
              +'</tr>';
        });
        if(nX50>0||nX80>0) html+=`<tr><td><b>MAE (${Math.max(nX50,nX80)} dari ${rows.length} blast)</b></td><td colspan="2"></td><td colspan="2">${(nX50>0&&maeX50!=null)?'<b>'+maeX50.toFixed(1)+' cm</b> ('+nX50+' data)':'—'}</td><td colspan="2"></td><td colspan="2">${(nX80>0&&maeX80!=null)?'<b>'+maeX80.toFixed(1)+' cm</b> ('+nX80+' data)':'—'}</td></tr>`;
        html+='</table>';
      }
    }catch(_e){}
    return html;
  }
  function initKuzram(){
    if(KZ_UI.bound){ kzHydrate(); return; } KZ_UI.bound=true;
    const on=(id,fn)=>{const el=$(id); if(el) el.addEventListener('click',fn);};
    $('kzSource').addEventListener('change',e=>{ APP_STATE.kuzram.source=KZ_SOURCES.includes(e.target.value)?e.target.value:null; persistWorking(); kzRender(); });
    on('kzModeCorr',()=>{ APP_STATE.kuzram.mode='corrected'; persistWorking(); kzRender(); }); on('kzModeExcel',()=>{ APP_STATE.kuzram.mode='excel'; persistWorking(); kzRender(); });
    on('kzBtnRun',kzRun); on('kzBtnReset',kzResetAnim); on('kzBtnDetail',()=>{ KZ_UI.detail=!KZ_UI.detail; kzRender(); });
    on('kzBtnExample',()=>{ const s=APP_STATE.kuzram; Object.keys(KZ_EXAMPLE).forEach(k=>{ s.manual[k]=KZ_EXAMPLE[k]; s.manualSrc[k]='DEFAULT'; }); audit('Kuz-Ram default Excel BB-6',null,'DEFAULT','USER','KUZRAM DEFAULT'); persistWorking(); kzRender(); });
    on('kzBtnFollow',()=>{ const s=APP_STATE.kuzram; s.geo={}; KZ_GEO_KEYS.forEach(k=>{s.geo[k]=null;}); audit('Kuz-Ram override geometri dihapus',null,'IKUTI BLOK','USER','KUZRAM OVERRIDE'); persistWorking(); kzRender(); });
    const _ra=refreshAll; refreshAll=function(){ const out=_ra.apply(this,arguments); try{ kzRender(); }catch(_e){} return out; };
    window.KZ={compute:kzCompute,build:kzBuild,render:kzRender,run:kzRun,reset:kzResetAnim,anim:()=>KZ_UI.anim&&{hash:KZ_UI.anim.hash,xc:KZ_UI.anim.xc,n:KZ_UI.anim.n,x80:KZ_UI.anim.x80,count:KZ_UI.anim.count,boulders:KZ_UI.anim.boulders,phase:KZ_UI.anim.phase,done:KZ_UI.anim.done,raf:KZ_UI.raf,src:KZ_UI.anim.src,sizes:KZ_UI.anim.parts.map(q=>q.size)},
      finish:()=>{ const A=KZ_UI.anim; if(!A) return false; kzStopAnim(); A.t=KZ_END; A.done=true; kzDraw(A); return true; },
      seek:t=>{ const A=KZ_UI.anim; if(!A) return false; kzStopAnim(); A.t=t; kzDraw(A); return A.phase; }};
    kzHydrate(); kzDraw(KZ_UI.anim);
  }

  function persistWorking(){
    try{ localStorage.setItem(STORAGE,JSON.stringify({version:PERSIST_VERSION,project:APP_STATE.project,formation:APP_STATE.formation,material:{labWorking:APP_STATE.material.labWorking,formations:APP_STATE.material.formations,qualityKey:APP_STATE.material.qualityKey},psdConfig:APP_STATE.psdConfig,prov:APP_STATE.prov,demo:APP_STATE.demo,geometry:APP_STATE.geometry,formula:APP_STATE.formula,financial:APP_STATE.financial,optimizer:APP_STATE.optimizer,seismic:APP_STATE.seismic,psd:{sizeDefinition:APP_STATE.psd.sizeDefinition},kuzram:kzPersistable(),simulation:{...APP_STATE.simulation,animating:false,rowOverrides:APP_STATE.simulation.rowOverrides||{}},freeFace:{mode:APP_STATE.freeFace.mode,points:APP_STATE.freeFace.points,manualAzimuthDeg:APP_STATE.freeFace.manualAzimuthDeg},karst:{cavities:APP_STATE.karst.cavities,autoLevel:APP_STATE.karst.autoLevel},roi:roiPersistable()})); }catch(e){ if(e&&e.name==='QuotaExceededError'){ const m=$('kzWipMsg'); if(m) m.textContent='Penyimpanan gagal: kuota localStorage terlampaui. Data di memori tidak rusak — ekspor JSON untuk cadangan.'; } } /* REQ-01 AC-01d */
  }
  // Public, minimal hook for the optional Google Sheets backup panel.
  // The integration can force the same working-copy persistence path used by the app.
  try { window.KarstBlastForcePersist = persistWorking; } catch (_e) {}

  function restoreWorking(){
    let x=null; try{ x=migratePersistedState(JSON.parse(localStorage.getItem(STORAGE)||'null')); }catch(e){ x=null; } if(!x) return;
    try{ Object.assign(APP_STATE.project,x.project||{}); Object.assign(APP_STATE.formation,x.formation||{}); Object.assign(APP_STATE.psdConfig,normalizePSDConfig(x.psdConfig||APP_STATE.psdConfig)); Object.assign(APP_STATE.geometry,x.geometry||{}); if(x.prov&&typeof x.prov==='object'&&!Array.isArray(x.prov)) APP_STATE.prov=x.prov; if(x.demo&&typeof x.demo==='object') APP_STATE.demo=x.demo; Object.assign(APP_STATE.formula,x.formula||{}); Object.assign(APP_STATE.financial,x.financial||{}); Object.assign(APP_STATE.optimizer,x.optimizer||{}); Object.assign(APP_STATE.seismic,x.seismic||{}); APP_STATE.psd.sizeDefinition=x.psd.sizeDefinition; Object.assign(APP_STATE.simulation,x.simulation||{}); APP_STATE.simulation.animating=false; APP_STATE.simulation.rowOverrides=x.simulation?.rowOverrides||APP_STATE.simulation.rowOverrides||{}; if(x.freeFace) Object.assign(APP_STATE.freeFace,{mode:x.freeFace.mode||'front',points:x.freeFace.points||[],manualAzimuthDeg:Number.isFinite(x.freeFace.manualAzimuthDeg)?x.freeFace.manualAzimuthDeg:0}); if(x.karst) Object.assign(APP_STATE.karst,{cavities:Array.isArray(x.karst.cavities)?x.karst.cavities:[],autoLevel:x.karst.autoLevel!==false}); APP_STATE.material.labWorking=x.material?.labWorking||APP_STATE.material.labWorking; APP_STATE.material.formations=x.material?.formations||{}; APP_STATE.material.qualityKey=x.material?.qualityKey||APP_STATE.material.qualityKey; }catch(e){ /* fall through to immutable lab baseline */ }
    // Kuz-Ram dipulihkan dalam guard sendiri + sanitasi.
    try{ Object.assign(APP_STATE.kuzram,kzSanitize(x.kuzram)); }catch(e){ APP_STATE.kuzram=kzDefaultState(); }
    try{ ROI_SAVED=roiSanitizeSaved(x.roi); }catch(_e){ ROI_SAVED=null; }
    // Invariant: a derived PSD summary must never exist without its fragment dataset.
    if(!APP_STATE.fragments.length) resetDerivedPSD();
    ensureLabWorking();
    if(!APP_STATE.simulation || !APP_STATE.simulation.parameters || !Number.isFinite(Number(APP_STATE.simulation.parameters.holeCount))){ APP_STATE.simulation={ levelIndex:1, technique:'standar', animating:false, template:'group1', groupLabel:'GROUP I • J-13', activeBlastRow:1, rowOverrides:{}, parameters:{holeCount:4,anPerHoleKg:11.7,dnPerHoleKg:0.20,stemmingM:1.32,burdenM:2.5,spacingM:3.5,depthM:3.0,deckPct:0}, result:null, holePattern:[], activeView:'cross',activeBlastRow:1 }; }
    if(!APP_STATE.simulation.holePattern) APP_STATE.simulation.holePattern=[];
    APP_STATE.simulation.animating=false; /* FIX v11: flag runtime tidak boleh dipulihkan dari localStorage (mengunci tombol RUN selamanya) */
    if(!APP_STATE.simulation.activeView) APP_STATE.simulation.activeView='cross';
    const activeSavedManual=String(APP_STATE.simulation.template||'').startsWith('manual_') && Array.isArray(APP_STATE.simulation.customBlocks) && APP_STATE.simulation.customBlocks.some(g=>g&&g.key===APP_STATE.simulation.template);
    // Default template values are a convenience only; never refill intentionally blank manual-block inputs.
    if(!activeSavedManual){
      if(!Number.isFinite(Number(APP_STATE.simulation.parameters.depthM)) || Number(APP_STATE.simulation.parameters.depthM)<=0) APP_STATE.simulation.parameters.depthM=3.0;
      if(!Number.isFinite(Number(APP_STATE.simulation.parameters.spacingM)) || Number(APP_STATE.simulation.parameters.spacingM)<=0) APP_STATE.simulation.parameters.spacingM=3.5;
      if(!Number.isFinite(Number(APP_STATE.simulation.parameters.burdenM)) || Number(APP_STATE.simulation.parameters.burdenM)<=0) APP_STATE.simulation.parameters.burdenM=2.5;
    }
  }

  function downloadText(filename,textContent,mime='text/plain'){
    const blob=new Blob([String(textContent)],{type:mime+';charset=utf-8'}),a=document.createElement('a');
    a.href=URL.createObjectURL(blob);a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),0);
  }
  function exportFragments(){ downloadText('Fragment_List.csv',buildFragmentCsv().csv,'text/csv'); }
  function exportPSD(){ downloadText('PSD_Result.csv',buildPSDCsv(),'text/csv'); }
  /* HARDENING: batas ukuran file impor (kurangi risiko DoS/ReDoS pada parser). Kembali '' bila OK, pesan bila terlalu besar. */
  function kbFileTooBig(file,kind){
    const MB=1024*1024, lim={sheet:10*MB,csv:10*MB,image:25*MB,json:2*MB}[kind]||10*MB;
    if(file && Number(file.size)>lim) return 'File terlalu besar ('+(file.size/MB).toFixed(1)+' MB). Batas '+(lim/MB)+' MB untuk '+kind.toUpperCase()+'.';
    return '';
  }
  function htmlEscape(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function buildExecutiveReportHtml(){ recomputePSD();
    const k=APP_STATE.karst,html=`<!doctype html><html lang="id"><head><meta charset="utf-8"><title>Executive Report</title><style>body{font:14px 'IBM Plex Sans',Segoe UI,Arial,sans-serif;max-width:900px;margin:36px auto;padding:0 18px;color:#201c14}table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #d9d5c6;padding:8px;text-align:left}</style></head><body><h1>KarstBlast Analytics &amp; Optimizer</h1><p>Project: ${htmlEscape(APP_STATE.project.id||'--')}</p><h2>Karst / Cavity Screening</h2><table><tr><th>Metric</th><th>Value</th></tr><tr><td>Cavity count</td><td>${k.cavities?.length||0}</td></tr><tr><td>Worst severity</td><td>${k.worstSeverity||'NONE'}</td></tr><tr><td>Hole affected fraction</td><td>${((k.fractionAffected||0)*100).toFixed(1)}%</td></tr><tr><td>Weighted exposure</td><td>${(k.weightedExposure||0).toFixed(3)}</td></tr></table>${kzReportHtml()}${psdReportHtml()}<h2>Application snapshot</h2><pre>${htmlEscape(JSON.stringify({geometry:APP_STATE.geometry,psd:{...psdPhys(),oversizeThresholdCm:psdOversizeThresholdCm(),quantileMethod:PSD_QUANTILE_METHOD,unitsNote:'x50/x80/xc/oversize* are centimetres and are null unless physicalStatus is AVAILABLE; *Px fields are pixels'},seismic:APP_STATE.seismic,simulation:APP_STATE.simulation,karst:k},null,2))}</pre>



<style id="kb-ui-fix-v2">
/* UI/UX structural fix: keep the two-column Design workspace intact. */
body .kb-view{width:100%;min-width:0}
body .kb-grid{display:grid!important;grid-template-columns:minmax(300px,360px) minmax(0,1fr)!important;gap:22px!important;align-items:start!important;width:100%!important}
body .kb-grid>aside,body .kb-grid>main{display:grid!important;grid-template-columns:1fr!important;gap:22px!important;min-width:0!important;width:100%!important}
body .kb-stack{display:grid!important;grid-template-columns:1fr!important;gap:22px!important;min-width:0!important;width:100%!important}
body .kb-grid>aside .kb-panel,body .kb-grid>main .kb-panel{min-width:0!important;width:100%!important}
body .kb-grid .kb-geometry-compare-panel{width:100%!important}
/* Avoid giant vertical gaps caused by legacy floating-card title treatment. */
body .kb-grid>aside>.kb-panel,body .kb-grid>main>.kb-panel{margin-top:20px!important}
/* Comparison controls wrap cleanly instead of forcing horizontal overflow. */
body .kb-compare-actions{display:flex!important;flex-wrap:wrap!important;gap:8px!important}
body .kb-compare-actions .btn{flex:0 1 auto!important;min-width:150px}
@media(max-width:1100px){
  html body{padding-left:0!important}
  body .kb-grid{grid-template-columns:1fr!important}
  body .kb-grid>aside,body .kb-grid>main{grid-template-columns:1fr!important}
}
@media(max-width:700px){
  body .kb-grid{gap:16px!important}
  body .kb-grid>aside,body .kb-grid>main,body .kb-stack{gap:16px!important}
  body .kb-compare-actions .btn{flex:1 1 100%!important;min-width:0}
}
</style>
</body></html>`;
    return html;
  }
  function exportReport(){ downloadText('Executive_Report.html',buildExecutiveReportHtml(),'text/html'); }

  function exportBridgeText(kind){ const g=APP_STATE.geometry.result, p=psdPhys(), s=APP_STATE.seismic; const lines=[`PROJECT=${APP_STATE.project.id}`,`FORMATION=${APP_STATE.formation.label}`,`FORMULA=${APP_STATE.formula.key.toUpperCase()}`,`B_M=${g?.B??'NA'}`,`S_M=${g?.S??'NA'}`,`T_M=${g?.T??'NA'}`,`J_M=${g?.J??'NA'}`,`CHARGE_KG_PER_HOLE=${g?.chargeMass??'NA'}`,`ACTUAL_X50_CM=${p.x50??'NA'}`,`ACTUAL_X80_CM=${p.x80??'NA'}`,`OVERSIZE_THRESHOLD_CM=${psdOversizeThresholdCm()}`,`QUANTILE_METHOD=${PSD_QUANTILE_METHOD}`,`BOULDER_${psdThrTag()}_COUNT=${p.oversizeCount??'NA'}`,`RR_ESTIMATED_${psdThrTag()}=${p.rrOversizeFraction??'NA'}`,`RR_FIT_STATUS=${p.fitStatus??'NA'}`,`PPV_K=${s.K??'NA'}`,`PPV_N=${s.n??'NA'}`,`PPV=${s.ppv??'NA'}`,`SIMULATION=${APP_STATE.simulation.result?APP_STATE.simulation.result.level+'/'+APP_STATE.simulation.result.technique:'NOT RUN'}`]; return kind==='blw'?'MOCK INTEROPERABILITY BRIDGE\n'+lines.join('\n'):'MOCK INTEROPERABILITY BRIDGE\n'+lines.map(x=>x.replace('=',': ')).join('\n'); } function exportBridge(kind){ recomputePSD(); downloadText(kind==='blw'?'Mock_BLW.txt':'Mock_R3D.txt',exportBridgeText(kind)); }
  function renderBridge(){ const g=APP_STATE.geometry.result,p=psdPhys(),s=APP_STATE.seismic; const lines=[`PROJECT=${APP_STATE.project.id}`,`FORMATION=${APP_STATE.formation.label}`,`FORMULA=${APP_STATE.formula.key.toUpperCase()}`,`CHARGE_KG_PER_HOLE=${g?.chargeMass??'NA'}`,`ACTUAL_X80_CM=${p.x80??'NA'}`,`OVERSIZE_THRESHOLD_CM=${psdOversizeThresholdCm()}`,`QUANTILE_METHOD=${PSD_QUANTILE_METHOD}`,`BOULDER_${psdThrTag()}_COUNT=${p.oversizeCount??'NA'}`,`RR_ESTIMATED_${psdThrTag()}=${p.rrOversizeFraction??'NA'}`,`RR_FIT_STATUS=${p.fitStatus??'NA'}`,`PPV=${s.ppv??'NA'}`];$('blwPreview').textContent='[MOCK BLW]\n'+lines.join('\n');$('r3dPreview').textContent='[MOCK R3D]\n'+lines.map(x=>x.replace('=',': ')).join('\n'); }

  /* ===== FIX v11 • validasi, screening & status =====
     - Validasi dipisah: VISUALISASI (geometri + free face) vs SCREENING (geometri + charge + densitas).
     - Field kosong / non-angka TIDAK lagi diam-diam dianggap 0 atau ditimpa baris template.
     - Output kuantitatif dikosongkan ('--') ketika screening gagal: tidak ada angka basi/sumber tak jelas. */
  function simDomInputErrors(keys){
    const F=[['simHoleCount','holeCount','jumlah lubang'],['simANPerHole','anPerHoleKg','AN/hole'],['simDNPerHole','dnPerHoleKg','DN/hole'],['simStemming','stemmingM','stemming'],['simBurden','burdenM','burden'],['simSpacing','spacingM','spacing'],['simDepth','depthM','depth']], e=[];
    F.forEach(([id,k,label])=>{
      if(keys && keys.indexOf(k)<0) return;
      const el=$(id); if(!el) return;
      const raw=String(el.value==null?'':el.value).trim();
      if(raw==='') e.push(label+' kosong/tidak valid');
      else if(!Number.isFinite(Number(raw))) e.push(label+' bukan angka');
    });
    return e;
  }
  function simGeometryErrors(){
    const dom=simDomInputErrors(['holeCount','stemmingM','burdenM','spacingM','depthM']);
    if(dom.length) return dom;
    const p=APP_STATE.simulation.parameters||{}, e=[], bad=new Set(), n=k=>Number(p[k]);
    [['holeCount','jumlah lubang'],['stemmingM','stemming'],['burdenM','burden'],['spacingM','spacing'],['depthM','depth']].forEach(([k,l])=>{
      if(p[k]==null||p[k]===''||!Number.isFinite(n(k))||n(k)<0){e.push(l+' invalid');bad.add(k);}
    });
    if(!bad.has('holeCount')&&n('holeCount')<=0) e.push('jumlah lubang harus > 0');
    if(!bad.has('depthM')&&n('depthM')<=0) e.push('depth harus > 0');
    if(!bad.has('burdenM')&&n('burdenM')<=0) e.push('burden harus > 0');
    if(!bad.has('spacingM')&&n('spacingM')<=0) e.push('spacing harus > 0');
    if(!bad.has('stemmingM')&&!bad.has('depthM')&&n('stemmingM')>=n('depthM')) e.push('stemming harus lebih kecil dari depth');
    return e;
  }
  function simChargeErrors(){
    const dom=simDomInputErrors(['anPerHoleKg','dnPerHoleKg']);
    if(dom.length) return dom;
    const p=APP_STATE.simulation.parameters||{}, e=[];
    const an=Number(p.anPerHoleKg), dn=Number(p.dnPerHoleKg);
    if(p.anPerHoleKg==null||p.anPerHoleKg===''||!Number.isFinite(an)||an<=0) e.push('AN/hole harus > 0');
    if(p.dnPerHoleKg==null||p.dnPerHoleKg===''||!Number.isFinite(dn)||dn<0) e.push('DN/hole invalid');
    return e;
  }
  function simFreeFaceErrors(){
    const e=[], ff=APP_STATE.freeFace||{};
    if(ff.mode==='custom' && (!ff.points || ff.points.length<2)) e.push('Custom Free Face belum didefinisikan • klik 2 titik pada Plan View');
    if(ff.mode==='manual' && !Number.isFinite(Number(ff.manualAzimuthDeg))) e.push('Manual azimuth belum valid');
    if(ff.linePoints && ff.linePoints.length>=2 && vLen(vSub(ff.linePoints[1],ff.linePoints[0]))<0.5) e.push('Free face line degenerate/terlalu pendek');
    return e;
  }
  /* parameter yang WAJIB agar visualisasi masuk akal */
  function validateVisualizationInputs(){ return simGeometryErrors().concat(simFreeFaceErrors()); }
  /* parameter yang WAJIB agar screening kuantitatif sah (visualisasi + charge) */
  function validateSimulationInputs(){ return simGeometryErrors().concat(simChargeErrors(),simFreeFaceErrors()); }

  function ensureScreeningParameters(){
    /* FIX v11: hanya sinkronisasi DOM→state. Versi lama MENIMPA input pengguna yang tidak valid dengan baris template
       (menyembunyikan error dan menjalankan data yang tidak diketik pengguna). Sekarang input salah → dilaporkan. */
    if(!APP_STATE.simulation) APP_STATE.simulation={};
    if(!APP_STATE.simulation.parameters||typeof APP_STATE.simulation.parameters!=='object') APP_STATE.simulation.parameters={};
    return simRead();
  }

  function screeningSetStatus(txt,cls){
    const s=$('screeningStatus'); if(!s) return;
    s.textContent=txt; s.className='kb-badge '+cls;
  }
  /* TAHAP-1: angka screening tidak boleh tetap berlabel CALCULATED setelah baris blast atau parameter berubah.
     Nilai run terakhir dibiarkan terlihat (sejarah), tetapi badge, catatan, dan radar ditandai STALE. */
  function markScreeningStale(reason){
    try{
      const badge=$('screeningStatus'); if(!badge) return;
      if(String(badge.textContent||'').trim()!=='CALCULATED') return;
      screeningSetStatus('STALE • HITUNG ULANG','warn');
      window.__kbScreeningOK=false;
      const n=$('screeningNote');
      if(n) n.textContent=`${reason||'Input berubah'} • hasil screening di atas berasal dari run sebelumnya dan belum dihitung ulang. Klik RUN SCREENING.`;
      ['radarFlyrock','radarPpv'].forEach(id=>{const e=$(id); if(e) e.classList.remove('is-danger');});
      if($('radarFlyrockValue')) $('radarFlyrockValue').textContent='--';
      if($('radarPpvValue')) $('radarPpvValue').textContent='--';
      if($('radarFlyrockStatus')) $('radarFlyrockStatus').textContent='SCREENING BELUM TERHITUNG';
      if($('radarPpvStatus')) $('radarPpvStatus').textContent='SCREENING BELUM TERHITUNG';
    }catch(_e){}
  }
  function screeningClearOutputs(){
    ['screeningTechnique','screeningScore','screeningCharge','screeningPF'].forEach(id=>{const e=$(id); if(e) e.textContent='--';});
    try{ if(APP_STATE.geometry) APP_STATE.geometry.simulationResult=null; }catch(_e){}
    const r=APP_STATE.simulation&&APP_STATE.simulation.result;
    if(r&&r.screening===true) APP_STATE.simulation.result=null;
  }
  function screeningBlock(status,reason,fix){
    window.__kbScreeningOK=false;
    screeningSetStatus(status,'fail');
    screeningClearOutputs();
    const n=$('screeningNote');
    if(n) n.textContent=reason+(fix?' Cara memperbaiki: '+fix:'');
    return false;
  }

  function runScreeningCalculation(){
    const started=Date.now();
    try{
      screeningSetStatus('CHECKING...','warn');
      ensureLabWorking();
      ensureScreeningParameters();
      recalcFreeFace();
      const errs=validateSimulationInputs();
      if(errs.length) return screeningBlock('BLOCKED','Input simulator tidak valid: '+errs.join('; ')+'.','perbaiki field tersebut pada Charging Simulator / Blast Plan, lalu jalankan ulang. Angka screening dikosongkan.');
      const p=APP_STATE.simulation.parameters, level=simLevel().key, mat=screeningMaterial(), rho=Number(mat.Density);
      if(!Number.isFinite(rho)||rho<=0){
        const ciD=Number(APP_STATE.geometry&&APP_STATE.geometry.comparisonInputs&&APP_STATE.geometry.comparisonInputs.rockDensity);
        const lv=APP_STATE.material&&APP_STATE.material.labWorking&&APP_STATE.material.labWorking.values, labD=lv?Number(lv.Density):NaN;
        const why='Density material tidak tersedia ('+
          (APP_STATE.material&&APP_STATE.material.labSnapshot?(labD>0?'Lab aktif memiliki density':'Lab aktif tidak memiliki nilai Density valid'):'data Lab Material belum dimuat')+
          '; Rock density (SG) pada Geometry Comparison '+(ciD>0?'terisi':'kosong')+').';
        return screeningBlock('BLOCKED',why,'muat data Lab Material lalu pilih kelas HG / MG / DOL, atau isi Rock density (SG) > 0 pada panel Geometry Comparison. Teknik, skor, charge, dan PF screening dikosongkan sampai density tersedia.');
      }
      const totalAN=p.holeCount*p.anPerHoleKg, totalDN=p.holeCount*p.dnPerHoleKg;
      const volumePerHole=p.burdenM*p.spacingM*p.depthM, totalVolume=p.holeCount*volumePerHole;
      const tonnage=totalVolume*rho, pf=tonnage>0?totalAN/tonnage:null;
      const rows=Object.keys(TECH_PROFILE).map(t=>{const sc=simulationScores(level,t,p);return {t,score:Math.round(.45*sc.control+.35*sc.distribution+.20*sc.simplicity),...sc};}).sort((a,b)=>b.score-a.score);
      const best=rows[0];
      if(![totalAN,totalDN,totalVolume,tonnage].every(Number.isFinite)||!(tonnage>0)||!best||!Number.isFinite(best.score))
        return screeningBlock('BLOCKED','Hasil hitung tidak finite (NaN/∞) dari input saat ini.','periksa jumlah lubang, burden, spacing, depth, dan AN/hole.');
      window.__kbScreeningOK=true;
      APP_STATE.geometry.simulationResult={totalAN,totalDN,totalVolume,tonnage,powderFactor:pf,volumePerHole,chargePerHole:p.anPerHoleKg};
      APP_STATE.simulation.result={timestamp:now(),level,technique:best.t,score:best.score,screening:true,chargePerHole:p.anPerHoleKg,powderFactor:pf,totalAN,totalDN,totalVolume,tonnage};
      simVisual();
      screeningSetStatus('CALCULATED','ok');
      $('screeningTechnique').textContent=TECH_PROFILE[best.t].label;
      $('screeningScore').textContent=best.score+'/100';
      $('screeningCharge').textContent=fmt(p.anPerHoleKg,2)+' kg AN/hole';
      $('screeningPF').textContent=pf==null?'--':fmt(pf,3)+' kg/t';
      let warn='';
      renderSimulationDecision();
      try{ calculateFinancial(); audit('Charging screening','',''+best.t.toUpperCase(),'CALCULATED','RUN SCREENING CALCULATION'); refreshAll(); }
      catch(e2){ try{console.error(e2);}catch(_e){} warn=' PERINGATAN: pembaruan panel lain gagal ('+(e2&&e2.message||e2)+').'; }
      $('screeningNote').textContent=`[SCREENING • dihitung ${new Date().toLocaleTimeString('id-ID')}] Rongga ${level}. Kontrol ${best.control}, distribusi ${best.distribution}, operasional ${best.simplicity}. ${simGeomCheck(p).notes.join(' • ')||'Geometri tidak memiliki catatan tambahan'}. Charge ${fmt(p.anPerHoleKg,2)} kg/hole; total AN ${fmt(totalAN,1)} kg; PF ${pf==null?'--':fmt(pf,3)+' kg/t'}. Screening heuristic deterministik, bukan validasi lapangan. Density ${rho.toFixed(3)} SG • ${mat.source||'LAB'}.`+warn;
      const btn=$('btnRunScreening');
      if(btn && (Date.now()-started)>80) btn.setAttribute('data-last-run',String(Date.now()));
      return true;
    }catch(err){
      window.__kbScreeningOK=false;
      screeningSetStatus('ERROR','fail');
      screeningClearOutputs();
      $('screeningNote').textContent='Screening gagal dijalankan: '+(err?.message||String(err));
      try{console.error(err);}catch(_e){}
      return false;
    }
  }

  /* Handler tombol RUN SCREENING CALCULATION: status READY→CHECKING...→CALCULATED/BLOCKED/ERROR, tombol nonaktif selama proses
     dan DIJAMIN aktif kembali (finally), termasuk bila terjadi exception. Kalkulasi sungguhan berjalan setelah status CHECKING tergambar. */
  function screeningRunFromButton(){
    const btn=$('btnRunScreening');
    if(!btn){ runScreeningCalculation(); return; }
    if(btn.dataset.kbBusy==='1') return;
    btn.dataset.kbBusy='1';
    if(!btn.dataset.kbIdleLabel) btn.dataset.kbIdleLabel=btn.textContent.trim();
    const t0=Date.now(), badge=$('screeningStatus'), note=$('screeningNote');
    btn.disabled=true; btn.classList.add('kb-action-busy'); btn.setAttribute('aria-busy','true'); btn.textContent='MENGHITUNG…';
    screeningSetStatus('CHECKING...','warn'); if(badge) badge.classList.add('kb-status-pulse');
    if(note) note.textContent='Memeriksa input simulator, density material, lalu menghitung skor teknik…';
    let finished=false, started=false, ok=false;
    const finish=()=>{
      if(finished) return; finished=true;
      btn.disabled=false; btn.classList.remove('kb-action-busy'); btn.removeAttribute('aria-busy');
      btn.textContent=btn.dataset.kbIdleLabel||'RUN SCREENING CALCULATION'; btn.dataset.kbBusy='0';
      if(badge) badge.classList.remove('kb-status-pulse');
      if(ok){ try{ const pn=$('pdPlanActions')||$('projectDataPanel')||$('blastPlanPanel'); if(pn&&pn.scrollIntoView&&pn.isConnected) pn.scrollIntoView({behavior:'smooth',block:'center'}); }catch(_e){} }
    };
    const run=()=>{
      if(started) return; started=true;
      try{ ok=runScreeningCalculation()===true; }
      catch(err){ ok=false; screeningSetStatus('ERROR','fail'); screeningClearOutputs(); if(note) note.textContent='Screening gagal dijalankan: '+(err&&err.message||err); try{console.error(err);}catch(_e){} }
      finally{ setTimeout(finish,Math.max(0,450-(Date.now()-t0))); }
    };
    setTimeout(run,220);          /* beri waktu indikator CHECKING... tergambar sebelum kalkulasi (timer tetap jalan di tab background) */
    setTimeout(finish,4000);      /* failsafe: tombol tidak boleh terkunci */
  }

  function refreshAll(){ refreshGeometry(); refreshDesignMetrics(); calculateFinancial(); renderBridge(); updateCharts(); refreshReport(); renderImageMeta(); $('headerModelStatus').textContent=APP_STATE.fragments.length?'CV SCREENING ACTIVE':'WAITING FOR ACTUAL DATA'; renderAudit(); renderFormation(); if($('geometryComparePanel')) renderGeometryComparison(); }
  function hydrateUI(){ updateInputsFromState();$('projectId').value=APP_STATE.project.id||'';$('projectSite').value=APP_STATE.project.site||'';$('projectNotes').value=APP_STATE.project.notes||'';$('airDeckPct2').value=APP_STATE.geometry.input.airDeckPct||0;$('anfoIdrKg').value=APP_STATE.financial.anfoIdrKg??'';$('secondaryIdrUnit').value=APP_STATE.financial.secondaryIdrUnit??'';$('secondaryBaselineUnits').value=APP_STATE.financial.secondaryBaselineUnits??100;$('secondaryReductionPct').value=APP_STATE.financial.secondaryReductionPct??15;$('limestonePriceIdrTon').value=APP_STATE.financial.limestonePriceIdrTon??'';$('priceSource').value=APP_STATE.financial.priceSource||'';$('quotationDate').value=APP_STATE.financial.quotationDate||'';$('vendorRef').value=APP_STATE.financial.vendorRef||'';$('ppvK').value=APP_STATE.seismic.K??'';$('ppvN').value=APP_STATE.seismic.n??'';$('ppvD').value=APP_STATE.seismic.D??'';$('ppvW').value=APP_STATE.seismic.W??'';setFormula(APP_STATE.formula.key);geometryComparisonInputSync();if($('measurementDef'))$('measurementDef').value=APP_STATE.psd.sizeDefinition||'feret';renderFormation();renderLab();refreshAll(); }


  /* Restored charging simulator: all simulation values live in APP_STATE.simulation. */
  const SIM_LEVELS=[{key:'kecil',top:192,bottom:232,voidId:'voidSmall',tick:'tickKecil'},{key:'sedang',top:172,bottom:260,voidId:'voidMedium',tick:'tickSedang'},{key:'besar',top:140,bottom:305,voidId:'voidLarge',tick:'tickBesar'}];
  const simEls={slider:$('ronggaSlider'),techniques:qsa("input[name='technique']"),detonate:$('detonateBtn'),reset:$('resetSimBtn'),fx:$('blastFX')};
  function renderBlastPlan(){ renderBlastTemplateTable(APP_STATE.simulation.template||'group1'); }
  function renderBlastTemplateTable(key){
    const box=$('blastTemplateTableWrap'); if(!box)return; const g=BLAST_SHEET_ROWS[key]||BLAST_SHEET_ROWS.group1;
    if(!g.rows.length){box.innerHTML='<div class="kb-muted" style="padding:10px">Belum ada baris pada group ini. Untuk template kosong, pilih BUAT BLOK MANUAL lalu tambahkan data.</div>';return;}
    const f=(v,d=2,suffix='')=>v==null||v===''?'—':(Number.isFinite(Number(v))?`${Number(v).toFixed(d)}${suffix}`:'—');
    let html='<table class="blast-template-table"><thead><tr><th>No</th><th>Hole</th><th>Spacing</th><th>Burden</th><th>Depth</th><th>Depth + Sub</th><th>Unit</th><th>AN/hole</th><th>DN/hole</th><th>Charging</th><th>Stemming</th><th>DEV &gt;75%</th><th>RC &gt;1.4</th><th>BSR &gt;2.5</th><th>Volume</th><th>PF Rec.</th><th></th></tr></thead><tbody>';
    g.rows.forEach(baseRow=>{const r=getBlastRow(key,baseRow.no);const vol=r.volume==null||r.volume===''?'—':(Number.isFinite(Number(r.volume))?Number(r.volume).toLocaleString('id-ID'):'—');html+=`<tr><td>${htmlEscape(r.no)}</td><td>${f(r.holes,0)}</td><td>${f(r.spacing,2,' m')}</td><td>${f(r.burden,2,' m')}</td><td>${f(r.depth,1,' m')}</td><td>${f(r.subDepth,1,' m')}</td><td>${htmlEscape(r.unit||'—')}</td><td>${f(r.an,1)}</td><td>${f(r.dn,2)}</td><td>${f(r.charging,1,' m')}</td><td>${f(r.stemming,2,' m')}</td><td>${f(r.dev,1)}</td><td>${f(r.rc,1)}</td><td>${f(r.bsr,1)}</td><td>${vol}</td><td>${f(r.pf,3)}</td><td><button class="btn load-row" type="button" data-blast-row="${htmlEscape(r.no)}">LOAD ROW</button></td></tr>`});
    html+='</tbody></table>';box.innerHTML=html;box.querySelectorAll('[data-blast-row]').forEach(btn=>btn.addEventListener('click',()=>loadBlastSheetRow(key,Number(btn.dataset.blastRow))));
  }
  function loadBlastSheetRow__legacy(groupKey,rowNo){
    const g=BLAST_SHEET_ROWS[groupKey];const r=getBlastRow(groupKey,rowNo);if(!r)return;
    const workingDepth=r.depth==null||r.depth===''?null:Number(r.depth);
    APP_STATE.simulation.template=groupKey;APP_STATE.simulation.activeBlastRow=rowNo;if(!APP_STATE.simulation.groupLabel||Object.keys(BLAST_SHEET_ROWS).some(k=>(BLAST_SHEET_ROWS[k]?.label||'').toLowerCase()===String(APP_STATE.simulation.groupLabel).toLowerCase()))APP_STATE.simulation.groupLabel=g.label;Object.assign(APP_STATE.simulation.parameters,{holeCount:r.holes,anPerHoleKg:r.an,dnPerHoleKg:r.dn,stemmingM:r.stemming,burdenM:r.burden,spacingM:r.spacing,depthM:workingDepth,deckPct:0});
    simHydrate();renderBlastTemplateTable(groupKey);simVisual(); if(typeof geometryComparisonInputSync==='function') geometryComparisonInputSync(true); persistWorking();
    if($('screeningNote')) $('screeningNote').textContent=g?.isManual?`Blok manual • Row ${rowNo}: data diisi pengguna${workingDepth==null?' • depth belum diisi':` • depth ${workingDepth.toFixed(1)} m`}.`:(workingDepth==null?`Row template ${rowNo}: depth belum diisi.`:`Template sumber row ${rowNo} dimuat dengan depth ${workingDepth.toFixed(1)} m sesuai data template.`);
    audit('Charging template row','',`${groupKey} row ${rowNo} • source depth ${r.depth==null?'belum diisi':r.depth+' m'} • working depth ${workingDepth==null?'belum diisi':workingDepth.toFixed(1)+' m'}`,'USER INPUT',g.isManual?'LOAD MANUAL BLAST ROW':'LOAD HAND BLAST ROW');
  }
  function applySimTemplate(key){
    APP_STATE.simulation.template=key;renderBlastTemplateTable(key);const g=BLAST_SHEET_ROWS[key];if(g?.rows?.length)loadBlastSheetRow(key,g.rows[0].no);else{simVisual();persistWorking();audit('Charging template','',key,'USER INPUT','LOAD HAND BLAST GROUP');}
  }
  function simRead(){
    const p=APP_STATE.simulation.parameters|| (APP_STATE.simulation.parameters={});
    const m={simHoleCount:'holeCount',simANPerHole:'anPerHoleKg',simDNPerHole:'dnPerHoleKg',simStemming:'stemmingM',simBurden:'burdenM',simSpacing:'spacingM',simDepth:'depthM',simDeckPct:'deckPct'};
    for(const [id,k] of Object.entries(m)){
      const el=$(id); if(!el) continue;
      const raw=String(el.value??'').trim();
      if(raw==='') continue;
      const n=Number(raw);
      if(Number.isFinite(n)) p[k]=n;
    }
    if($('airDeckPct') && Number.isFinite(Number(p.deckPct))) APP_STATE.geometry.input.airDeckPct=Number(p.deckPct);
    return p;
  }
  function simHydrate(){const t=BLAST_SHEET_ROWS[APP_STATE.simulation.template]?APP_STATE.simulation.template:'group1';APP_STATE.simulation.template=t;if(!APP_STATE.simulation.groupLabel)APP_STATE.simulation.groupLabel=BLAST_SHEET_ROWS[t]?.label||t;if($('blastGroupInput'))$('blastGroupInput').value=APP_STATE.simulation.groupLabel;if($('simTemplate'))$('simTemplate').value=APP_STATE.simulation.groupLabel||BLAST_SHEET_ROWS[t]?.label||t;const p=APP_STATE.simulation.parameters,m={simHoleCount:'holeCount',simANPerHole:'anPerHoleKg',simDNPerHole:'dnPerHoleKg',simStemming:'stemmingM',simBurden:'burdenM',simSpacing:'spacingM',simDepth:'depthM',simDeckPct:'deckPct'};for(const [id,k] of Object.entries(m))if($(id))$(id).value=p[k]}
  const TECH_PROFILE={
    standar:{label:'Standar',control:[55,48,42],distribution:82,simplicity:95},
    stemrock:{label:'Deck + Stemrock',control:[72,88,94],distribution:70,simplicity:72},
    linear:{label:'Linear Decoupled',control:[70,76,62],distribution:84,simplicity:58},
    airbag:{label:'Gas Bag / Air Deck',control:[68,94,96],distribution:72,simplicity:54}
  };
  function simLevel(){
    const idx=Math.max(0,Math.min(SIM_LEVELS.length-1,Number(APP_STATE.simulation?.levelIndex)||0));
    APP_STATE.simulation.levelIndex=idx;
    return SIM_LEVELS[idx];
  }

  /* Cek geometri (heuristik screening): acuan rasio diambil dari rumus app sendiri
     (Formula Engine): T/B = 0.70; S/B = 1.15 (Konya) s/d 1.30 (Ash); PF acuan = kolom 'PF Rec.' row template aktif. Bobot penalti = ASUMSI, belum divalidasi lapangan. */
  const SIM_GEOM_REF={tbRef:0.70,sbMin:1.15,sbMax:1.30,ctrlPerUnit:40,ctrlMax:15,distPerUnit:40,distMax:12};
  function simGeomCheck(p){
    const R=SIM_GEOM_REF,B=Number(p?.burdenM),S=Number(p?.spacingM),T=Number(p?.stemmingM),notes=[];let ctrlPen=0,distPen=0,tb=null,sb=null;
    if(B>0&&Number.isFinite(T)){tb=T/B;ctrlPen=Math.min(R.ctrlMax,Math.abs(tb-R.tbRef)*R.ctrlPerUnit);notes.push(`T/B ${tb.toFixed(2)} (acuan ${R.tbRef.toFixed(2)})`+(ctrlPen>=0.5?` → kontrol −${Math.round(ctrlPen)}`:' OK'));}
    if(B>0&&S>0){sb=S/B;const out=sb<R.sbMin?R.sbMin-sb:sb>R.sbMax?sb-R.sbMax:0;distPen=Math.min(R.distMax,out*R.distPerUnit);notes.push(`S/B ${sb.toFixed(2)} (acuan ${R.sbMin.toFixed(2)}–${R.sbMax.toFixed(2)})`+(distPen>=0.5?` → distribusi −${Math.round(distPen)}`:' OK'));}
    // PF (muatan) vs PF rekomendasi row template; PF = AN/hole ÷ (B×S×depth×densitas batuan)
    let pfNow=null,pfRef=null;
    try{
      const row=getBlastRow(APP_STATE.simulation.template,Number(APP_STATE.simulation.activeBlastRow||1)),rho=Number(engineeringMaterial()?.Density),D=Number(p?.depthM),AN=Number(p?.anPerHoleKg);
      pfRef=Number(row?.pf);
      if(pfRef>0&&rho>0&&B>0&&S>0&&D>0&&Number.isFinite(AN)){
        pfNow=AN/(B*S*D*rho);const dev=Math.abs(pfNow/pfRef-1),pen=Math.min(R.ctrlMax,dev*R.ctrlPerUnit);ctrlPen+=pen;
        notes.push(`PF ${pfNow.toFixed(3)} kg/t (acuan row ${pfRef.toFixed(3)})`+(pen>=0.5?` → kontrol −${Math.round(pen)}`+(pfNow>pfRef?' (overcharge)':' (undercharge)'):' OK'));
      }
    }catch(e){}
    return {ctrlPen,distPen,tb,sb,pfNow,pfRef,notes};
  }
  function simulationScores(levelKey, technique, p){
    const levelIndex={kecil:0,sedang:1,beta:1,besar:2}[levelKey]??1; const base=TECH_PROFILE[technique]||TECH_PROFILE.standar;
    let control=base.control[levelIndex], distribution=base.distribution, simplicity=base.simplicity;
    if(technique==='airbag') control += Math.min(6,Number(p.deckPct||0)*0.15);
    if(technique==='linear') distribution += Math.min(5,Number(p.deckPct||0)*0.08);
    if(technique==='stemrock' && levelKey==='besar') control=Math.min(100,control+4);
    const gc=simGeomCheck(p); control-=gc.ctrlPen; distribution-=gc.distPen;
    const karstPenalty=Math.min(35,Number(APP_STATE.karst?.weightedExposure||0)*40);
    control=Math.max(0,control-karstPenalty);
    if(APP_STATE.karst?.worstSeverity==='CENTRAL'&&technique==='stemrock') control=Math.min(100,control+2);
    return {control:Math.round(clamp(control,0,100)),distribution:Math.round(clamp(distribution,0,100)),simplicity:Math.round(clamp(simplicity,0,100))};
  }

  function renderSimulationDecision(){
    const l=simLevel().key,p=APP_STATE.simulation.parameters, rows=[];
    Object.keys(TECH_PROFILE).forEach(t=>{const s=simulationScores(l,t,p); const score=Math.round(.45*s.control+.35*s.distribution+.20*s.simplicity); rows.push({t,s,score});});
    rows.forEach(r=>{const k=r.t;$('score-'+k+'-c').textContent=r.s.control;$('score-'+k+'-d').textContent=r.s.distribution;$('score-'+k+'-s').textContent=r.s.simplicity;});
    rows.sort((a,b)=>b.score-a.score); const best=rows[0]; const current=simulationScores(l,APP_STATE.simulation.technique,p);
    $('simRecommendation').textContent=best?TECH_PROFILE[best.t].label+' • score '+best.score+'/100':'--';
    const reason=l==='kecil'?'Rongga kecil: prioritas pada kesederhanaan dan distribusi charging.':l==='sedang'?'Rongga sedang: kontrol rongga mulai diberi bobot lebih tinggi.':'Rongga besar: teknik pemisahan/deck mendapat bobot kontrol lebih besar.';
    const gcn=simGeomCheck(p).notes.join(' • ');$('simRecommendationReason').textContent=reason+(gcn?' Cek geometri: '+gcn+'.':'')+' Teknik terpilih: '+TECH_PROFILE[APP_STATE.simulation.technique].label+'. Indeks adalah screening heuristic, bukan prediksi lapangan.';
    $('simCavityScore').textContent=current.control+'/100';$('simDistributionScore').textContent=current.distribution+'/100';$('simSimplicityScore').textContent=current.simplicity+'/100';
  }

  function simVisual(){recalcKarstInteractions(); const l=simLevel(),t=APP_STATE.simulation.technique,p=APP_STATE.simulation.parameters;SIM_LEVELS.forEach(x=>$(x.voidId).style.display=x.key===l.key?'':'none');const cy=(l.top+l.bottom)/2;$('voidLabel').setAttribute('x',236);$('voidLabel').setAttribute('y',l.bottom+16);const stem=$('segStemming'),top=$('segAnfoTop'),bot=$('segAnfoBottom'),plug=$('segPlug'),air=$('segAirbag'),lin=$('segLinearThin'),pl=$('plugLabel'),al=$('airbagLabel'),ll=$('linearLabel'),an=$('anfoLabel');stem.setAttribute('y',70);stem.setAttribute('height',40);[top,bot,plug,air,lin].forEach(e=>e.style.display='none');[pl,al,ll].forEach(e=>e.style.display='none');an.style.display='';const sr=(e,y,h)=>{e.setAttribute('y',y);e.setAttribute('height',Math.max(0,h));e.style.display=''};if(t==='standar')sr(top,110,230);else if(t==='stemrock'){sr(top,110,l.top-110);plug.setAttribute('y',l.top);plug.setAttribute('height',l.bottom-l.top);plug.style.display='';pl.style.display='';pl.setAttribute('y',cy+4);sr(bot,l.bottom,340-l.bottom)}else if(t==='airbag'){sr(top,110,l.top-110);air.setAttribute('cx',220);air.setAttribute('cy',cy);air.setAttribute('rx',13);air.setAttribute('ry',(l.bottom-l.top)/2);air.style.display='';al.style.display='';al.setAttribute('y',cy+4);sr(bot,l.bottom,340-l.bottom)}else{lin.setAttribute('x',218);lin.setAttribute('y',110);lin.setAttribute('height',230);lin.style.display='';ll.style.display='';ll.setAttribute('y',cy+4);an.style.display='none'}const totalAN=p.holeCount*p.anPerHoleKg,totalDN=p.holeCount*p.dnPerHoleKg,vol=p.holeCount*p.burdenM*p.spacingM*p.depthM,pf=vol>0?totalAN/vol:null;$('simTotalAN').textContent=Number.isFinite(totalAN)?totalAN.toLocaleString('id-ID',{maximumFractionDigits:1})+' kg':'--';$('simTotalDN').textContent=Number.isFinite(totalDN)?totalDN.toLocaleString('id-ID',{maximumFractionDigits:1})+' kg':'--';$('simVolume').textContent=Number.isFinite(vol)?vol.toLocaleString('id-ID',{maximumFractionDigits:1})+' m³':'--';$('simPF').textContent=Number.isFinite(pf)?pf.toFixed(3)+' kg/m³':'--';SIM_LEVELS.forEach((x,i)=>$(x.tick).classList.toggle('is-active',i===APP_STATE.simulation.levelIndex));simEls.techniques.forEach(i=>{i.checked=i.value===t;i.closest('.technique-option')?.classList.toggle('is-active',i.value===t)}); renderSimulationDecision(); recalcFreeFaceAndRender();}
  function simResetRadar(){for(const id of ['radarFlyrock','radarPpv'])$(id).className='radar-box';$('radarFlyrockValue').textContent='--';$('radarPpvValue').textContent='--';$('radarFlyrockStatus').textContent='STANDBY';$('radarPpvStatus').textContent='STANDBY'}
  // NOTE: direction is no longer a fixed constant • see currentBlastDir() above,
  // which derives it from APP_STATE.freeFace.normalVector (Free-Face Engine).
  const simTimers = [];
  let simRunToken = 0;
  let simRunActive = false;   /* kunci runtime (BUKAN state persisten): true hanya selama animasi di sesi halaman ini */
  let simRejectNote='';        /* pesan input ditolak Blast Plan; ditampilkan bersama notifikasi simulasi */
  function simTimeout(fn, ms){
    // V11: timer yang bisa dijeda/dilanjutkan agar Pause benar-benar menahan seluruh run
    const rec={fn:fn,remaining:ms,start:0,id:null,done:false};
    rec.arm=function(){ rec.start=performance.now(); rec.id=setTimeout(function(){ rec.done=true; fn(); },rec.remaining); };
    rec.arm(); simTimers.push(rec);
    return rec;
  }
  function clearSimTimers(){
    while(simTimers.length){ const r=simTimers.pop(); clearTimeout(r.id); }
  }
  function simPauseTimers(){ simTimers.forEach(function(r){ if(!r.done&&r.id!==null){ clearTimeout(r.id); r.id=null; r.remaining=Math.max(0,r.remaining-(performance.now()-r.start)); } }); }
  function simResumeTimers(){ simTimers.forEach(function(r){ if(!r.done&&r.id===null) r.arm(); }); }
  window.KBSim={pause:simPauseTimers,resume:simResumeTimers};
  function simFX(){
    clearSimTimers();
    simRunToken++;                 // semua timer/callback run lama menjadi basi
    simRunActive=false;
    simFxCancelPersist();
    if(simEls.fx) simEls.fx.innerHTML='';
    const n=$('simNotif'); if(n)n.className='sim-notif';
    if(APP_STATE.simulation) APP_STATE.simulation.animating=false;
    simSetBusy(false);
  }
  function simSetBusy(on){
    const d=simEls.detonate; if(!d) return;
    if(on){
      if(!d.dataset.kbIdleLabel) d.dataset.kbIdleLabel=d.textContent.trim();
      d.disabled=true; d.classList.add('kb-sim-running'); d.setAttribute('aria-busy','true'); d.textContent='SIMULASI BERJALAN…';
    }else{
      d.disabled=false; d.classList.remove('kb-sim-running'); d.removeAttribute('aria-busy');
      d.textContent=d.dataset.kbIdleLabel||'RUN SIMULATION + SCREENING';
    }
  }
  function simSetNotif(kind,text){
    const n=$('simNotif'), t=$('simNotifText');
    if(n) n.className='sim-notif'+(kind?' sim-notif--'+kind:'')+' is-visible';
    if(t) t.textContent=text;
  }
  function simMake(name, attrs){
    const e=document.createElementNS('http://www.w3.org/2000/svg',name);
    Object.entries(attrs||{}).forEach(([k,v])=>e.setAttribute(k,v));
    return e;
  }
  /* ===================================================================
     BLAST FX v2 • Web Animations API (element.animate)
     Kenapa bukan CSS @keyframes lagi: aturan global
       @media (prefers-reduced-motion: reduce){ *{animation-duration:.001ms!important} }
     membuat seluruh efek CSS langsung loncat ke frame akhir (opacity 0) sehingga ledakan
     tidak terlihat sama sekali pada perangkat dengan "reduce motion". Animasi WAAPI tidak
     terpengaruh aturan itu. Simulasi ini dipicu manual oleh pengguna (RUN SIMULATION), jadi
     diperlakukan sebagai animasi esensial. Deterministik: tidak ada Math.random.
     =================================================================== */
  function simFxCancelPersist(){
    // animasi pada elemen permanen (stemming, rongga, rumah) harus dibatalkan saat reset
    ['segStemming','houseGroup','voidSmall','voidMedium','voidLarge'].forEach(id=>{
      const e=$(id); if(e&&e.getAnimations) e.getAnimations().forEach(a=>{try{a.cancel()}catch(_e){}});
    });
  }
  function simUnitDir(){
    const d=(typeof currentBlastDir==='function'&&currentBlastDir())||{x:1,y:-.66}, n=Math.hypot(d.x,d.y)||1;
    return {x:d.x/n,y:d.y/n};
  }
  function simFxAnimate(el,frames,opts){
    try{ return el.animate(frames,Object.assign({fill:'both',easing:'ease-out'},opts||{})); }
    catch(e){ try{console.error('simFx',e)}catch(_e){} return null; }
  }
  function simFxGroup(x,y){
    const g=simMake('g',{transform:`translate(${x} ${y})`,'pointer-events':'none'});
    simEls.fx.appendChild(g); return g;
  }
  function simFxFlash(ox,oy,color,delay){
    const g=simFxGroup(ox,oy);
    const outer=simMake('circle',{cx:0,cy:0,r:20,fill:color,'fill-opacity':.55});
    const core=simMake('circle',{cx:0,cy:0,r:12,fill:'#fff3bf'});
    g.appendChild(outer); g.appendChild(core);
    simFxAnimate(outer,[{opacity:0,transform:'scale(.2)'},{opacity:.9,transform:'scale(1.5)',offset:.3},{opacity:0,transform:'scale(3.1)'}],{duration:640,delay});
    simFxAnimate(core,[{opacity:0,transform:'scale(.2)'},{opacity:1,transform:'scale(1.2)',offset:.25},{opacity:0,transform:'scale(2.1)'}],{duration:420,delay});
  }
  function simFxRing(ox,oy,color,scale,delay,duration=950){
    const g=simFxGroup(ox,oy);
    const c=simMake('circle',{cx:0,cy:0,r:10,fill:'none',stroke:color,'stroke-width':3,'vector-effect':'non-scaling-stroke'});
    g.appendChild(c);
    simFxAnimate(c,[{opacity:.95,transform:'scale(.25)'},{opacity:.6,offset:.65},{opacity:0,transform:`scale(${scale})`}],{duration,delay});
  }
  function simFxJet(ox,oy,color,distance,delay,filled){
    const dir=simUnitDir(), ang=Math.atan2(dir.y,dir.x)*180/Math.PI;
    const g=simFxGroup(ox,oy); g.setAttribute('transform',`translate(${ox} ${oy}) rotate(${ang})`);
    const p=simMake('polygon',{points:'0,0 22,-11 92,-24 120,0 92,24 22,11',fill:filled?color:'none','fill-opacity':filled?.42:0,stroke:color,'stroke-width':3,'stroke-linejoin':'round','vector-effect':'non-scaling-stroke'});
    g.appendChild(p);
    simFxAnimate(p,[{opacity:0,transform:'translate(0px,0px) scale(.25)'},{opacity:.95,offset:.2},{opacity:0,transform:`translate(${distance}px,0px) scale(1.25)`}],{duration:760,delay,easing:'cubic-bezier(.2,.75,.3,1)'});
  }
  function simFxRock(i,size,delay,travel,lift,fill){
    const dir=simUnitDir(), ox=220, oy=(simLevel().top+simLevel().bottom)/2;
    const lateral=(((i*37)%5)-2)*13, dx=dir.x*travel-dir.y*lateral, dy=dir.y*travel+dir.x*lateral*.55;
    const rot=((i*53)%240)-90, r=size/2;
    const g=simFxGroup(ox,oy);
    const p=simMake('polygon',{points:`${-r},${r*.1} ${-r*.2},${-r*.8} ${r*.9},${-r*.2} ${r*.35},${r*.75}`,fill:fill||'#78716c',stroke:'#292524','stroke-width':1.4,'stroke-linejoin':'round'});
    g.appendChild(p);
    simFxAnimate(p,[
      {opacity:0,transform:'translate(0px,0px) scale(.3) rotate(0deg)'},
      {opacity:1,offset:.12},
      {opacity:1,transform:`translate(${dx*.55}px,${dy*.55-lift}px) scale(1) rotate(${rot*.5}deg)`,offset:.55},
      {opacity:0,transform:`translate(${dx}px,${dy+lift*.9}px) scale(.85) rotate(${rot}deg)`}
    ],{duration:1150+(i%3)*90,delay,easing:'cubic-bezier(.2,.7,.4,1)'});
  }
  function simFxDust(oy,delay){
    // debu keluar dari free face (posisi x dihitung dari garis free face pada penampang)
    const faceX=520-90*((oy-70)/310);
    for(let i=0;i<3;i++){
      const g=simFxGroup(faceX+4+i*7,oy-14+i*16);
      const c=simMake('circle',{cx:0,cy:0,r:12+i*3,fill:'#a8a29e','fill-opacity':.55});
      g.appendChild(c);
      simFxAnimate(c,[{opacity:0,transform:'translate(0px,0px) scale(.4)'},{opacity:.7,offset:.3},{opacity:0,transform:`translate(${34+i*14}px,${-26-i*10}px) scale(2.6)`}],{duration:1400,delay:delay+i*110});
    }
  }
  function simFxColumnSweep(color){
    // fasa inisiasi: front detonasi merambat di sepanjang kolom isian (visual ilustratif)
    const C={x:220,top:110,bottom:340};
    const g=simFxGroup(0,0);
    const r=simMake('rect',{x:C.x-14,y:0,width:28,height:18,rx:4,fill:'#fff7c2',stroke:color,'stroke-width':2});
    g.appendChild(r);
    simFxAnimate(r,[{opacity:0,transform:`translateY(${C.bottom-18}px)`},{opacity:1,offset:.1},{opacity:1,offset:.85},{opacity:0,transform:`translateY(${C.top}px)`}],{duration:440,easing:'linear'});
  }
  function simFxPersist(el,frames,opts){
    if(!el) return null;
    return simFxAnimate(el,frames,Object.assign({fill:'none'},opts||{}));
  }
  function simDetonate(){
    if(simRunActive){
      simSetNotif('caution','SIMULASI MASIH BERJALAN • tunggu selesai, atau ubah slider/teknik/Reset Tampilan untuk membatalkan.');
      return;
    }
    /* flag lama yang basi (mis. terpulihkan dari localStorage) tidak boleh membuat klik diabaikan diam-diam */
    APP_STATE.simulation.animating=false;
    try{
      // 1) baca nilai terbaru dari UI
      const rej=simRejectNote?simRejectNote+' \u2022 ':''; simRejectNote='';
      simRead();
      recalcFreeFace();
      // 2) indikator awal terlihat
      simSetNotif('','MEMULAI SIMULASI • memeriksa input dan screening…');
      simSetBusy(true);
      // 3) screening dipisah dari kelayakan animasi
      const screeningOK=runScreeningCalculation()===true;
      // 4) validasi parameter yang memang dibutuhkan visualisasi
      const vErr=validateVisualizationInputs();
      if(vErr.length){
        simSetBusy(false);
        simSetNotif('caution',rej+'SIMULASI DIBLOKIR • '+vErr.join('; ')+' • perbaiki input lalu jalankan ulang. Animasi tidak dimulai dengan data yang tidak valid.');
        return;
      }
      const screeningWarning=screeningOK?'':(($('screeningNote')&&$('screeningNote').textContent)||'Kalkulasi screening belum tersedia.');
      // penampang harus terlihat; pada PLAN VIEW efek berjalan tapi tersembunyi
      if(APP_STATE.simulation.activeView==='plan' && typeof setSimView==='function') setSimView('cross');
      try{ $('simSvg').scrollIntoView({block:'nearest',behavior:'smooth'}); }catch(_e){}
      // 5) bersihkan animasi lama (juga membatalkan timer lama), lalu mulai run baru
      simFX();
      const token=simRunToken;
      simRunActive=true;
      APP_STATE.simulation.animating=true;
      simSetBusy(true);
      const l=simLevel(),t=APP_STATE.simulation.technique,ff=APP_STATE.freeFace;
      const color=t==='airbag'?'#0ea5e9':t==='stemrock'?'#38bdf8':t==='linear'?'#f59e0b':'#ef4444';
      const ox=220, oy=(l.top+l.bottom)/2, big=(l.key==='besar');
      const release=()=>{
        if(token!==simRunToken) return;
        simRunActive=false;
        APP_STATE.simulation.animating=false;
        simSetBusy(false);
        try{ simEls.fx.innerHTML=''; }catch(_e){}
      };
      simSetNotif(screeningOK?'safe':'caution',rej+(screeningOK
        ?`SIMULASI BERJALAN • arah visual mengikuti Free Face ${ff.mode.toUpperCase()} (azimuth ${fmt(ff.azimuthDeg,1)}°); bukan pengukuran lapangan.`
        :`VISUALISASI SAJA — SCREENING BELUM TERHITUNG • ${screeningWarning} Animasi tidak mengesahkan desain peledakan.`));
      try{
    // t=0: front detonasi naik di kolom + stemming terangkat
    simFxColumnSweep(color);
    simFxPersist($('segStemming'),[{transform:'translateY(0px)'},{transform:'translateY(-16px)',offset:.35},{transform:'translateY(0px)'}],{duration:650,delay:380});
    // t≈300ms: ledakan utama di pusat rongga/kolom
    simFxFlash(ox,oy,color,300);
    simFxRing(ox,oy,color,big&&t==='standar'?11:8,330);
    simFxRing(ox,oy,color,big&&t==='standar'?15:11,520,1100);
    simFxJet(ox,oy,color,big&&t==='standar'?230:190,340,true);
    simFxJet(ox,oy,color,big&&t==='standar'?260:210,470,false);
    // rongga merespons: gas masuk ke void
    const voidEl=$(l.voidId);
    simFxPersist(voidEl,[{fill:'#f8fafc',stroke:'#334155',strokeWidth:2},{fill:big&&t==='standar'?'#fecaca':'#fed7aa',stroke:color,strokeWidth:5,offset:.4},{fill:'#f8fafc',stroke:'#334155',strokeWidth:2}],{duration:900,delay:360});

    if(t==='stemrock'){
      const g=simFxGroup(0,0);
      const seal=simMake('rect',{x:207,y:l.top,width:26,height:Math.max(8,l.bottom-l.top),fill:'#b45309',stroke:'#5c2c08','stroke-width':1.5,rx:2});
      g.appendChild(seal);
      simFxAnimate(seal,[{opacity:0},{opacity:1,offset:.25},{opacity:1,offset:.75},{opacity:.15}],{duration:1500,delay:300});
      for(let i=0;i<6;i++) simFxRock(i,22,620+i*55,120+(i%4)*26,22);
    } else if(t==='airbag'){
      const g=simFxGroup(ox,oy);
      const bag=simMake('ellipse',{cx:0,cy:0,rx:15,ry:Math.max(14,(l.bottom-l.top)/2+4),fill:'#7dd3fc','fill-opacity':.6,stroke:'#0284c7','stroke-width':2});
      g.appendChild(bag);
      simFxAnimate(bag,[{opacity:0,transform:'scale(.35,.35)'},{opacity:.9,transform:'scale(1.25,1)',offset:.3},{opacity:.8,transform:'scale(1,1)',offset:.7},{opacity:0,transform:'scale(1.9,1.1)'}],{duration:1900,delay:300});
      simFxRing(ox,oy,'#0ea5e9',9,540);
      for(let i=0;i<8;i++) simFxRock(i,19,760+i*50,110+(i%4)*24,20);
    } else if(t==='linear'){
      for(let i=0;i<5;i++){
        const g=simFxGroup(220,170+i*25);
        const tick=simMake('rect',{x:-6,y:-2.5,width:12,height:5,fill:'#f59e0b',stroke:'#92400e','stroke-width':1});
        g.appendChild(tick);
        const dir=simUnitDir(), d=70+i*32;
        simFxAnimate(tick,[{opacity:0,transform:'translate(0px,0px)'},{opacity:1,offset:.15},{opacity:0,transform:`translate(${dir.x*d}px,${dir.y*d}px)`}],{duration:900,delay:320+i*80});
      }
      for(let i=0;i<5;i++) simFxRock(i,23,720+i*60,115+(i%4)*24,20);
    } else if(big){
      for(let i=0;i<4;i++) simFxRock(i,13,520+i*70,170+(i%4)*30,34,'#57534e');
      for(let i=0;i<2;i++) simFxRock(i+4,34,800+i*90,125+i*30,26);
      // rumah warga bergetar (hanya skenario rongga besar)
      simFxPersist($('houseGroup'),[0,-3,3,-3,3,-2,2,-1,0].map(x=>({transform:`translateX(${x}px)`})),{duration:1100,delay:820,easing:'linear'});
    } else if(l.key==='sedang'){
      for(let i=0;i<5;i++) simFxRock(i,28,650+i*55,115+(i%4)*24,22);
    } else {
      for(let i=0;i<5;i++) simFxRock(i,24,610+i*55,100+(i%4)*22,18);
    }
    simFxDust(oy,700);

      }catch(fxErr){
        try{console.error('simFx',fxErr);}catch(_e){}
        release();
        simSetNotif('caution','ANIMASI GAGAL • '+(fxErr&&fxErr.message||fxErr)+' • tombol dibebaskan, coba lagi.');
        return;
      }
      const duration=t==='airbag'?2700:2300;
      simTimeout(()=>{
        let kind='safe';
        if(!screeningOK) kind='caution';
        else if(l.key==='besar'&&t==='standar')kind='critical';
        else if((l.key==='sedang'&&t==='standar')||(l.key==='besar'&&t==='linear'))kind='caution';
        simSetNotif(kind,rej+(!screeningOK
          ?`VISUALISASI SAJA — SCREENING BELUM TERHITUNG • angka screening tetap kosong/BLOCKED: ${screeningWarning} Lengkapi data wajib sebelum memakai hasil perhitungan.`
          :kind==='critical'
          ?'SKENARIO VISUAL RISIKO TINGGI • evaluasi site, exclusion zone, stemming, dan telemetry diperlukan.'
          :kind==='caution'
          ?'SKENARIO VISUAL PERLU REVIEW • gunakan data site/telemetry sebelum keputusan lapangan.'
          :'SKENARIO VISUAL TERKONTROL • visualisasi deterministik, bukan bukti performa lapangan.'));
        const prev=APP_STATE.simulation.result, keep=(screeningOK&&prev&&prev.screening===true)?prev:null;
        APP_STATE.simulation.result=Object.assign({},keep||{},{timestamp:now(),level:l.key,technique:t,recommendedTechnique:keep?keep.technique:undefined,screeningAvailable:screeningOK,screeningStatus:screeningOK?'CALCULATED':'NOT AVAILABLE',ppv:Number.isFinite(APP_STATE.seismic.ppv)?APP_STATE.seismic.ppv:null,flyrock:null,direction:currentBlastDir(),freeFace:{mode:ff.mode,azimuthDeg:ff.azimuthDeg,distanceToHole:ff.distanceToHole,confidence:ff.confidence}});
        release();
        audit('Charging simulation','',`${l.key} / ${t}`,'USER ACTION',screeningOK?'SIMULATION RUN':'SIMULATION RUN (VISUAL ONLY)');
      },duration);
      simTimeout(release,duration+1500);   // failsafe: ikut dibersihkan oleh simFX()
    }catch(err){
      try{console.error('simDetonate',err);}catch(_e){}
      simRunActive=false; APP_STATE.simulation.animating=false; simSetBusy(false);
      simSetNotif('caution','SIMULASI ERROR • '+(err&&err.message||err)+' • tombol dibebaskan.');
    }
  }
  function populateBlastRowSelect(){const key=APP_STATE.simulation.template||'group1',rows=BLAST_SHEET_ROWS[key]?.rows||[],sel=$('blastRowSelect');if(!sel)return;sel.innerHTML='';rows.forEach(r=>{const o=document.createElement('option');o.value=r.no;o.textContent=`Row ${r.no} • ${r.holes==null?'hole —':r.holes+' hole'} • depth ${r.depth==null?'—':Number(r.depth).toFixed(1)+' m'}`;sel.appendChild(o)});if(rows.length)sel.value=String(APP_STATE.simulation.activeBlastRow||rows[0].no)}
  function initBlastPlanControls(){
    $('btnToggleBlastAdv')?.addEventListener('click',()=>{const pn=$('blastPlanPanel'),simple=pn.classList.toggle('is-simple');$('btnToggleBlastAdv').textContent=simple?'TAMPILKAN DETAIL LENGKAP':'SEMBUNYIKAN DETAIL';$('btnToggleBlastAdv').setAttribute('aria-expanded',String(!simple));});
    if($('blastGroupInput')){$('blastGroupInput').addEventListener('input',()=>{
      const raw=$('blastGroupInput').value.trim(); APP_STATE.simulation.groupLabel=raw;
      const hit=Object.entries(BLAST_SHEET_ROWS).find(([k,g])=>k.toLowerCase()===raw.toLowerCase() || String(g.label||'').toLowerCase()===raw.toLowerCase());
      if(hit){ const key=hit[0]; APP_STATE.simulation.template=key; APP_STATE.simulation.activeBlastRow=1; populateBlastRowSelect(); renderBlastTemplateTable(key); loadBlastSheetRow(key,1); }
      else { renderBlastPlan(); persistWorking(); }
    }); }
    populateBlastRowSelect();
    $('blastRowSelect')?.addEventListener('change',()=>loadBlastSheetRow(APP_STATE.simulation.template,Number($('blastRowSelect').value)));
    $('btnLoadBlastPlan')?.addEventListener('click',()=>{const ok=loadBlastSheetRow(APP_STATE.simulation.template,Number($('blastRowSelect')?.value||1));if(ok!==false)runScreeningCalculation();});
  }
  let simInitBound=false;
  /* TAHAP-1: 'input' tidak lagi menulis template='custom' (kunci palsu) ke state yang dipersist;
     simulator tetap terikat pada group/row aktif dan tulis-balik ke Plan terjadi pada 'change'. */
  function initChargingSimulation(){if(!simEls.slider)return;APP_STATE.simulation.animating=false;if(simInitBound){simHydrate();simVisual();simResetRadar();return;}simInitBound=true;simHydrate();if($('simTemplate')){$('simTemplate').value=APP_STATE.simulation.groupLabel||BLAST_SHEET_ROWS[APP_STATE.simulation.template]?.label||APP_STATE.simulation.template||'';renderBlastTemplateTable(APP_STATE.simulation.template);}simVisual();simResetRadar();simEls.slider.addEventListener('input',()=>{APP_STATE.simulation.levelIndex=Number(simEls.slider.value);simFX();simVisual();simResetRadar()});simEls.techniques.forEach(i=>i.addEventListener('change',()=>{APP_STATE.simulation.technique=i.value;simFX();simVisual();simResetRadar()}));simEls.detonate.addEventListener('click',simDetonate);simEls.reset.addEventListener('click',()=>{APP_STATE.simulation.result=null;simFX();simResetRadar();simVisual()});['simHoleCount','simANPerHole','simDNPerHole','simStemming','simBurden','simSpacing','simDepth','simDeckPct'].forEach(id=>$(id)?.addEventListener('input',()=>{simRead();if($('simTemplate'))$('simTemplate').value=APP_STATE.simulation.groupLabel||'CUSTOM / MANUAL';simVisual();persistWorking();markScreeningStale('parameter simulator diubah')}))}

  // UI events • each target has one listener in this application engine.
  qsa('.kb-tab').forEach(btn=>btn.addEventListener('click',()=>{
    qsa('.kb-tab').forEach(b=>{b.classList.remove('active');b.setAttribute('aria-selected','false')});
    qsa('.kb-view').forEach(v=>v.classList.remove('active'));
    btn.classList.add('active');btn.setAttribute('aria-selected','true');$('view-'+btn.dataset.view).classList.add('active');
    if(btn.dataset.view==='sim'){ kzOnTabVisible(); renderPPVChart(); if(typeof Plotly!=='undefined') { try{ if(chartIsActive('radarChart')) Plotly.react('radarChart',[{type:'scatterpolar',r:[psdPhys().x80?clamp(100*80/psdPhys().x80,0,100):null,psdPhys().oversizeFraction!=null?100*(1-psdPhys().oversizeFraction):null,APP_STATE.seismic.ppv?clamp(100-APP_STATE.seismic.ppv*2,0,100):0,overallConfidence()?overallConfidence()*100:0,APP_STATE.audit.entries.length?100:0],a:['Fragmentation','Oversize','Seismic','Data Quality','Traceability'],fill:'toself'}],{margin:{l:30,r:30,t:20,b:20},polar:{radialaxis:{range:[0,100],showticklabels:false}},paper_bgcolor:'#f4f2eb',font:{family:'IBM Plex Sans, Arial, sans-serif',size:10},showlegend:false}); }catch(e){} } }
    if(btn.dataset.view==='report'){ try{ refreshReport(); kzRender(); }catch(_e){} }   /* REQ-05: seluruh laporan segar saat tab dibuka */
    if(btn.dataset.view==='image' && typeof Plotly!=='undefined'){ try{renderMvpPsdChart(); renderPsdMainChart();}catch(e){} }
  }));
  $('formationPedel').addEventListener('click',()=>setupFormation('pedel'));$('formationLimestone').addEventListener('click',()=>setupFormation('limestone'));$('formulaAsh').addEventListener('click',()=>setFormula('ash'));$('formulaMae').addEventListener('click',()=>setFormula('mae'));[['xi','maeXi'],['ucs','maeUcs'],['jps','maeJps'],['jpo','maeJpo'],['cw','maeCw'],['stf','maeStf'],['sbf','maeSbf']].forEach(([k,id])=>{const el=$(id); if(el) el.addEventListener('input',()=>{ const x=parseFloat(el.value); maeState()[k]=Number.isFinite(x)?x:NaN; if(APP_STATE.formula.key==='mae'){validateAll();refreshAll();} }); });$('formulaKonya').addEventListener('click',()=>setFormula('konya'));
  ['diameterIn','benchHeight','explosiveDensity','holeCount','targetX80','airDeckPct'].forEach(id=>$(id).addEventListener('change',recalcFromFormInput));
  $('airDeckPct2').addEventListener('change',()=>{$('airDeckPct').value=$('airDeckPct2').value;recalcFromFormInput()});
  ['anfoIdrKg','secondaryIdrUnit','secondaryBaselineUnits','secondaryReductionPct','limestonePriceIdrTon','priceSource','quotationDate','vendorRef'].forEach(id=>$(id).addEventListener('change',()=>{const map={anfoIdrKg:'anfoIdrKg',secondaryIdrUnit:'secondaryIdrUnit',secondaryBaselineUnits:'secondaryBaselineUnits',secondaryReductionPct:'secondaryReductionPct',limestonePriceIdrTon:'limestonePriceIdrTon',priceSource:'priceSource',quotationDate:'quotationDate',vendorRef:'vendorRef'};const key=map[id];APP_STATE.financial[key]=(id.includes('Idr')||id==='secondaryReductionPct')?Number($(id).value):$(id).value;audit('Financial '+key,'',APP_STATE.financial[key],'USER INPUT','FINANCIAL UPDATE');refreshAll();persistWorking()}));
  $('view-design')?.addEventListener('change',e=>{
    const el=e.target.closest('[data-blast-edit]');
    if(!el) return;
    editActiveBlastRowField(el.dataset.blastEdit,el.value);
  });
  $('view-design')?.addEventListener('keydown',e=>{
    const el=e.target.closest('[data-blast-edit]');
    if(!el) return;
    if(e.key==='Enter'){ e.preventDefault(); editActiveBlastRowField(el.dataset.blastEdit,el.value); el.blur(); }
  });
  $('view-design')?.addEventListener('focus',e=>{const el=e.target.closest('[data-blast-edit]');if(el)el.closest('.kb-metric')?.setAttribute('data-edit-mode','active')},true);
  $('view-design')?.addEventListener('blur',e=>{const el=e.target.closest('[data-blast-edit]');if(el)el.closest('.kb-metric')?.removeAttribute('data-edit-mode')},true);
  $('btnAutoRecalcBlastRow')?.addEventListener('click',autoRecalcActiveBlastRow);

  $('btnImportXlsx').addEventListener('click',()=> $('labXlsxInput').click());$('labXlsxInput').addEventListener('change',e=>{const f=e.target.files?.[0];if(f)importLabXlsx(f).catch(err=>$('labImportStatus').textContent='IMPORT FAILED: '+err.message);});$('btnImportCsv').addEventListener('click',()=> $('labCsvInput').click());$('labCsvInput').addEventListener('change',e=>{const f=e.target.files?.[0];if(f)importLabCsv(f)});
  $('btnApplyLab').addEventListener('click',updateWorkingFromInputs);$('btnResetLab').addEventListener('click',()=>{ if(!APP_STATE.material.labSnapshot){$('labImportStatus').textContent='RESET UNAVAILABLE: LAB SNAPSHOT belum tersedia.';return;} const old=JSON.stringify(APP_STATE.material.labWorking?.values||{});applyLabSnapshotToWorking();audit('LAB WORKING COPY',old,JSON.stringify(APP_STATE.material.labWorking.values),'LAB SNAPSHOT','RESET TO LAB BASELINE');persistWorking();renderLab();refreshAll();});
  $('btnOpenPSDConfig')?.addEventListener('click',openPSDConfig); $('btnClosePSDConfig')?.addEventListener('click',closePSDConfig); $('psdConfigModal')?.addEventListener('click',e=>{if(e.target.id==='psdConfigModal')closePSDConfig()}); document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('psdConfigModal')?.classList.contains('is-open'))closePSDConfig()}); $('btnApplyPSDConfig')?.addEventListener('click',()=>applyPSDConfigFromUI()); $('btnResetPSDConfig')?.addEventListener('click',resetPSDConfig);
  $('btnAddPhoto').addEventListener('click',()=>$('imageInput').click());$('imageInput').addEventListener('change',e=>{const f=e.target.files?.[0];e.target.value='';if(f){try{loadImageFile(f)}catch(err){$('imageUploadStatus').textContent='IMAGE VALIDATION FAILED: '+err.message}}});$('btnResetImage').addEventListener('click',()=>{APP_STATE.image={file:null,metadata:null,sourceCanvas:null,workingCanvas:null,transform:null,displayTransform:{scaleX:1,scaleY:1,offsetX:0,offsetY:0},qc:null,mode:'auto',selectedId:null,selectedIds:[],manualMode:null,manualTrace:[],roiPolygons:[],roiDraft:[]};try{roiOnReset();}catch(_e){}APP_STATE.calibration={points:[],mode:'A',pixelDistanceSource:null,pixelDistanceWorking:null,metersPerSourcePixel:null,centimetersPerSourcePixel:null,metersPerWorkingPixel:null,centimetersPerWorkingPixel:null,status:'NOT CALIBRATED',quality:'POOR',perspectiveWarning:true};APP_STATE.fragments=[];APP_STATE.fragmentLineage=[];APP_STATE.psd={x50:null,x80:null,oversizeCount:null,oversizeFraction:null,xc:null,n:null,rrOversizeFraction:null,r2:null,fitStatus:'INSUFFICIENT SAMPLE',sizeDefinition:'feret'};drawCanvas();renderFragments();$('imageUploadStatus').textContent='WAITING FOR ACTUAL FIELD IMAGE';syncPSDConfigControls(); syncMvpPsdControls(); refreshAll();persistWorking()});$('btnCalPointA')?.addEventListener('click',()=>setCalibrationMode('A'));$('btnCalPointB')?.addEventListener('click',()=>setCalibrationMode('B'));$('btnCalCancel')?.addEventListener('click',()=>setCalibrationMode('CANCEL'));$('btnApplyScale').addEventListener('click',applyScale);$('btnClearCalibration').addEventListener('click',()=>{APP_STATE.calibration={points:[],mode:'A',pixelDistanceSource:null,pixelDistanceWorking:null,metersPerSourcePixel:null,centimetersPerSourcePixel:null,metersPerWorkingPixel:null,centimetersPerWorkingPixel:null,status:'NOT CALIBRATED',quality:'POOR',perspectiveWarning:true};setCalibrationMode('A');syncMvpPsdControls();recomputeFragmentMeasurements();drawCanvas();refreshAll()});
  window.addEventListener('resize',updateDisplayTransform);
  const traceCanvas=$('muckpileCanvas'); let tracePointerDown=false;
  traceCanvas.addEventListener('pointerdown',e=>{
    if(APP_STATE.image.manualMode!=='trace')return;
    e.preventDefault(); tracePointerDown=true; traceCanvas.setPointerCapture?.(e.pointerId);
    APP_STATE.image.manualTrace=[canvasPoint(e)]; drawCanvas();
  });
  traceCanvas.addEventListener('pointermove',e=>{
    if(!tracePointerDown||APP_STATE.image.manualMode!=='trace')return;
    e.preventDefault(); const pt=canvasPoint(e),arr=APP_STATE.image.manualTrace,last=arr[arr.length-1];
    if(!last||Math.hypot(pt.x-last.x,pt.y-last.y)>=3){arr.push(pt);drawCanvas();}
  });
  function endTracePointer(e){
    if(!tracePointerDown)return; tracePointerDown=false;
    try{traceCanvas.releasePointerCapture?.(e.pointerId)}catch(_){ }
    if(APP_STATE.image.manualMode==='trace')finalizeManualTrace();
  }
  traceCanvas.addEventListener('pointerup',endTracePointer); traceCanvas.addEventListener('pointercancel',endTracePointer);
  traceCanvas.addEventListener('click',e=>{
    if(APP_STATE.image.manualMode==='trace'||APP_STATE.image.manualMode==='roi')return;
    if(!APP_STATE.image.workingCanvas)return;
    const pt=canvasPoint(e),calMode=APP_STATE.calibration.mode;
    if(calMode==='A'||calMode==='B'){
      if(calMode==='A'){APP_STATE.calibration.points=[pt];setCalibrationMode('B');$('canvasHint').textContent='Point A set • now POINT B.';}
      else{APP_STATE.calibration.points=[APP_STATE.calibration.points[0],pt];setCalibrationMode('CANCEL');$('canvasHint').textContent='Two calibration points set • click APPLY SCALE.';}
      drawCanvas(); return;
    }
    if(APP_STATE.image.manualMode==='add'){addObjectAtPoint(pt);return;}
    if(APP_STATE.image.manualMode==='split'){splitClick(pt);return;}
    if(APP_STATE.image.manualMode==='delete'){const hit=hitFragmentAtPoint(pt);if(hit){toggleSelectedFragment(hit.id);$('scanStatus').textContent=`DELETE MODE • ${selectedIdList().length} object selected.`;}return;}
    if(!APP_STATE.image.manualMode){const hit=hitFragmentAtPoint(pt);if(hit){selectSingleOrMulti(hit.id,e.shiftKey||e.ctrlKey||e.metaKey);return;}}
    if(APP_STATE.image.manualMode==='merge'){
      const target=APP_STATE.fragments.slice().reverse().find(f=>Array.isArray(f.boundary)&&f.boundary.length>=3?pointInPolygon(pt,f.boundary):pt.x>=f.minx&&pt.x<=f.maxx&&pt.y>=f.miny&&pt.y<=f.maxy);
      const src=APP_STATE.fragments.find(f=>f.id===APP_STATE.image.selectedId);
      if(target&&src&&target.id!==src.id){
        const mr=applyMerge(src.id,target.id); APP_STATE.image.manualMode=null; $('scanStatus').textContent=mr.ok?('MERGE ESTIMATE #'+mr.fragment.id+': convex hull, gap '+Math.round(mr.fragment.hullGapAreaPx)+' px², dikeluarkan dari PSD sampai APPROVE ESTIMATE.'):('MERGE DIBATALKAN: '+mr.reason); recomputeFragmentMeasurements(); syncSelectionState();
      }
      return;
    }
    const hit=[...APP_STATE.fragments].reverse().find(f=>Array.isArray(f.boundary)&&f.boundary.length>=3?pointInPolygon(pt,f.boundary):pt.x>=f.minx&&pt.x<=f.maxx&&pt.y>=f.miny&&pt.y<=f.maxy);
    if(hit)selectFragment(hit.id);
  });
  ['mvpThreshold','mvpMinArea','mvpEdgeSensitivity','mvpWatershed','mvpScaleCmPx','mvpPolarity'].forEach(id=>$(id)?.addEventListener('input',scheduleMvpRescan));
  $('mvpPolarity')?.addEventListener('change',scheduleMvpRescan);
  $('btnApplyMvpPsd')?.addEventListener('click',()=>applyMvpPsdControls('BUTTON APPLY'));
  $('btnMvpRescan')?.addEventListener('click',()=>applyMvpPsdControls('BUTTON RESCAN'));
  syncMvpPsdControls();
  $('btnScanMuckpile').addEventListener('click',scanActualPhoto);$('btnRescan').addEventListener('click',scanActualPhoto);$('measurementDef').addEventListener('change',()=>{APP_STATE.psd.sizeDefinition=$('measurementDef').value;recomputeFragmentMeasurements();persistWorking()});['scanMode','thresholdPct','minArea','maxArea','smoothRadius','edgeSensitivity','separationSensitivity'].forEach(id=>$(id).addEventListener('change',()=>{APP_STATE.image.mode=$('scanMode').value; const c=getPSDConfig(); if(['thresholdPct','minArea','maxArea','smoothRadius','edgeSensitivity','separationSensitivity'].includes(id)){c[id]=normalizePSDConfig({...c,[id]:$(id).value})[id]; APP_STATE.psdConfig=c; syncPSDConfigControls(); persistWorking(); if(APP_STATE.fragments.length) recomputeFragmentMeasurements();}}));
  $('btnRoiDraw')?.addEventListener('click',roiStart);$('btnRoiFinish')?.addEventListener('click',roiFinish);$('btnRoiClear')?.addEventListener('click',roiClear);
  $('muckpileCanvas').addEventListener('click',e=>{ if(APP_STATE.image.manualMode!=='roi')return; const cm=APP_STATE.calibration.mode; if(cm==='A'||cm==='B'){ roiExit(); return; } e.stopImmediatePropagation(); e.preventDefault(); roiClick(e); },true);
  document.addEventListener('keydown',e=>{ if(e.key==='Escape'&&APP_STATE.image.manualMode==='roi')roiCancel(); });
  $('btnTraceObject').addEventListener('click',startTrace);$('btnFinishTrace').addEventListener('click',finalizeManualTrace);$('btnCancelTrace').addEventListener('click',cancelTrace);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&APP_STATE.image.manualMode==='trace')cancelTrace();});$('btnAddObject').addEventListener('click',()=>{cancelTrace();APP_STATE.image.manualMode='add';$('scanStatus').textContent='ADD OBJECT: click the image at object center.'});$('btnRemoveObject').addEventListener('click',removeSelected);$('btnMergeObject').addEventListener('click',mergeSelected);$('btnSplitObject').addEventListener('click',splitSelected);$('btnApproveEstimate').addEventListener('click',approveSelectedEstimate);$('btnClearOverride').addEventListener('click',clearSelectedOverride);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&APP_STATE.image.manualMode==='split')splitCancel('SPLIT dibatalkan; object induk dipertahankan.');});$('knownDistance').addEventListener('input',scaleInputDirty);$('btnEditSize').addEventListener('click',editSize);
  window.addEventListener('load',()=>{try{syncSelectionState();}catch(_e){}});
  $('btnApplyPPV').addEventListener('click',()=>{audit('PPV inputs','','updated','USER INPUT','PPV UPDATE');updateSeismic()});$('btnFitSeismicTemplate')?.addEventListener('click',fitSeismicTemplate);$('btnApplySeismicRef')?.addEventListener('click',applySeismicRef);$('btnDownloadSeismicTemplate')?.addEventListener('click',downloadSeismicTemplate);$('btnImportSeismic').addEventListener('click',()=>$('seismicCsvInput').click());$('seismicCsvInput').addEventListener('change',e=>{const f=e.target.files?.[0];if(f)fitSeismicCsv(f)});['ppvD','ppvW'].forEach(id=>$(id).addEventListener('change',updateSeismic));renderPPVTemplateTable();
  $('btnResetWorkspace').addEventListener('click',()=>{ if(confirm('Reset parameter kerja ke demo/baseline?\n\nPERINGATAN: Seluruh data Wipfrag semua blast akan dihapus. Disarankan EKSPOR JSON terlebih dahulu.\n\nLAB SNAPSHOT tidak dihapus.')) resetWorkspace(); }); /* REQ-03 */$('btnRunScreening').addEventListener('click',screeningRunFromButton);
  $('btnExportFragments').addEventListener('click',exportFragments);$('btnExportPSD').addEventListener('click',exportPSD);$('btnExportReport').addEventListener('click',exportReport);$('btnExportBLW').addEventListener('click',()=>exportBridge('blw'));$('btnExportR3D').addEventListener('click',()=>exportBridge('r3d'));$('btnRunTests').addEventListener('click',runTests);
  ['projectId','projectSite','projectNotes'].forEach(id=>$(id).addEventListener('change',()=>{const key=id==='projectId'?'id':id==='projectSite'?'site':'notes';const old=APP_STATE.project[key];APP_STATE.project[key]=$(id).value;audit('Project '+key,old,APP_STATE.project[key],'USER INPUT','PROJECT UPDATE');$('projectBadge').textContent='PROJECT: '+(APP_STATE.project.id||'UNTITLED');persistWorking();refreshReport();}));

  // Keep source-of-truth status separate from DOM and never fabricate lab data.
  // Convert the embedded workbook rows into the same normalized structure used by imports.
  if(!APP_STATE.material.labSnapshot || !APP_STATE.material.labSnapshot.groups){
    try{
      APP_STATE.material.labSnapshot=buildLabSnapshot(EMBEDDED_LAB_SOURCE.rows,EMBEDDED_LAB_SOURCE.fileName,EMBEDDED_LAB_SOURCE.sheet);
      APP_STATE.material.labSnapshot.fileName=EMBEDDED_LAB_SOURCE.fileName;
    }catch(e){
      APP_STATE.material.labSnapshot=null;
    }
  }
  restoreWorking();
  registerManualBlastGroups();
  /* TAHAP-1: wadah tabel multi-blast pernah dibiarkan kosong sehingga tampak seperti fitur yang aktif.
     Mesin PROJECT-BLASTS (Blast Terpilih / Rata-rata Terbobot / Batch) belum punya konsumen: satu baris aktif
     pada bagian 1 di bawah adalah sumber tunggal perhitungan. Ditampilkan apa adanya, tanpa menanam 10 baris
     CONTOH/BAWAAN sebagai data proyek. */
  try{
    const wrap=$('projectBlastsTableWrap');
    if(wrap && !wrap.children.length){
      wrap.innerHTML='<div class="kb-muted" style="padding:10px;border:1px dashed var(--border-hairline,#c4cfd4);border-radius:8px">'+
        '<b>MODE SATU BARIS AKTIF — perhitungan multi-blast belum aktif.</b><br>'+
        'Mesin Blast Terpilih / Rata-rata Terbobot / Batch tersedia di kode tetapi belum dihubungkan ke Kuz-Ram, Screening, Simulator, atau laporan. '+
        'Daftar contoh bawaan (10 blast berlabel CONTOH) sengaja tidak ditampilkan supaya tidak disalahpahami sebagai data proyek. '+
        'Sumber blast tunggal yang dipakai semua perhitungan: <b>Group / Row aktif</b> pada bagian 1 - SUMBER DATA dan BARIS di bawah.</div>';
    }
  }catch(_e){}
  /* TAHAP-1: payload lama dapat menyimpan template 'custom' (tulis sementara dari field simulator) atau
     groupLabel skenario yang tidak lagi cocok dengan kunci group. Kembalikan ke group/row yang benar-benar ada
     supaya pemilih baris tidak kosong dan edit baris tidak ditolak, tanpa mengubah data lain. */
  try{
    const sim=APP_STATE.simulation||{}, label=String(sim.groupLabel||'').trim().toLowerCase();
    let key=String(sim.template||'');
    if(!BLAST_SHEET_ROWS[key]){
      const hit=Object.keys(BLAST_SHEET_ROWS).find(k=>k.toLowerCase()===label||String(BLAST_SHEET_ROWS[k]?.label||'').trim().toLowerCase()===label);
      key=hit||(BLAST_SHEET_ROWS.group1?'group1':Object.keys(BLAST_SHEET_ROWS)[0])||'group1';
      sim.template=key;
      if(!hit) sim.groupLabel=String(BLAST_SHEET_ROWS[key]?.label||key); /* label menggantung (skenario/custom) → ikuti group yang dipakai */
    }
    const rows=(BLAST_SHEET_ROWS[sim.template]&&BLAST_SHEET_ROWS[sim.template].rows)||[];
    if(rows.length){ const want=Number(sim.activeBlastRow); if(!rows.some(r=>Number(r.no)===want)) sim.activeBlastRow=rows[0].no; }
    else sim.activeBlastRow=1;
  }catch(_e){}
  if(!APP_STATE.material.labSnapshot) APP_STATE.material.labSnapshot=buildLabSnapshot(EMBEDDED_LAB_SOURCE.rows,EMBEDDED_LAB_SOURCE.fileName,EMBEDDED_LAB_SOURCE.sheet);
  ensureLabWorking();
  APP_STATE.psdConfig=normalizePSDConfig(APP_STATE.psdConfig||PSD_CONFIG_DEFAULTS); syncPSDConfigControls();
  if(!APP_STATE.karst) APP_STATE.karst={cavities:[],autoLevel:true,placementMode:false,counts:{none:0,near:0,intersect:0,central:0},worstSeverity:'NONE',fractionAffected:0,weightedExposure:0,holeSeverity:{}};

/*AUTOTRACE_CORE_BEGIN*/
const AutoTrace=(function(){
  const clampA=(v,a,b)=>Math.max(a,Math.min(b,v));
  function polyArea(p){let a=0;for(let i=0;i<p.length;i++){const j=(i+1)%p.length;a+=p[i].x*p[j].y-p[j].x*p[i].y;}return Math.abs(a)/2;}
  function polyPerim(p){let s=0;for(let i=0;i<p.length;i++){const j=(i+1)%p.length;s+=Math.hypot(p[j].x-p[i].x,p[j].y-p[i].y);}return s;}
  function hullArea(p){const q=p.map(t=>[t.x,t.y]).sort((a,b)=>a[0]-b[0]||a[1]-b[1]);if(q.length<3)return 0;const cr=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);const lo=[],up=[];for(const t of q){while(lo.length>=2&&cr(lo[lo.length-2],lo[lo.length-1],t)<=0)lo.pop();lo.push(t);}for(let i=q.length-1;i>=0;i--){const t=q[i];while(up.length>=2&&cr(up[up.length-2],up[up.length-1],t)<=0)up.pop();up.push(t);}lo.pop();up.pop();return polyArea(lo.concat(up).map(t=>({x:t[0],y:t[1]})));}
  function segX(a,b,c,d){const o=(p,q,r)=>Math.sign((q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x));return o(a,b,c)!==o(a,b,d)&&o(c,d,a)!==o(c,d,b);}
  function selfIntersects(p){const n=p.length;for(let i=0;i<n;i++)for(let j=i+2;j<n;j++){if(i===0&&j===n-1)continue;if(segX(p[i],p[(i+1)%n],p[j],p[(j+1)%n]))return true;}return false;}
  function rdpOpen(p,eps){if(p.length<3)return p.slice();let dm=0,ix=0;const a=p[0],b=p[p.length-1],dx=b.x-a.x,dy=b.y-a.y,L=Math.hypot(dx,dy)||1e-9;for(let i=1;i<p.length-1;i++){const d=Math.abs(dy*p[i].x-dx*p[i].y+b.x*a.y-b.y*a.x)/L;if(d>dm){dm=d;ix=i;}}if(dm<=eps)return[a,b];const l=rdpOpen(p.slice(0,ix+1),eps),r=rdpOpen(p.slice(ix),eps);return l.slice(0,-1).concat(r);}
  function rdpClosed(p,eps){if(p.length<4)return p.slice();let k=0,best=-1;for(let i=0;i<p.length;i++){const d=Math.hypot(p[i].x-p[0].x,p[i].y-p[0].y);if(d>best){best=d;k=i;}}const A=rdpOpen(p.slice(0,k+1),eps),B=rdpOpen(p.slice(k).concat([p[0]]),eps);return A.slice(0,-1).concat(B.slice(0,-1));}
  function erode(m,w,h){const o=new Uint8Array(w*h),at=(x,y)=>x<0||y<0||x>=w||y>=h?1:m[y*w+x];for(let y=0;y<h;y++)for(let x=0;x<w;x++){if(m[y*w+x]&&at(x-1,y)&&at(x+1,y)&&at(x,y-1)&&at(x,y+1)&&at(x-1,y-1)&&at(x+1,y-1)&&at(x-1,y+1)&&at(x+1,y+1))o[y*w+x]=1;}return o;}
  function dilate(m,w,h){const o=new Uint8Array(w*h);for(let y=0;y<h;y++)for(let x=0;x<w;x++){let v=0;for(let dy=-1;dy<=1&&!v;dy++)for(let dx=-1;dx<=1;dx++){const xx=x+dx,yy=y+dy;if(xx>=0&&yy>=0&&xx<w&&yy<h&&m[yy*w+xx]){v=1;break;}}o[y*w+x]=v;}return o;}
  function fillHoles(m,w,h){const out=new Uint8Array(w*h),st=[];const push=i=>{if(!m[i]&&!out[i]){out[i]=2;st.push(i);}};for(let x=0;x<w;x++){push(x);push((h-1)*w+x);}for(let y=0;y<h;y++){push(y*w);push(y*w+w-1);}while(st.length){const i=st.pop(),x=i%w,y=(i/w)|0;if(x>0)push(i-1);if(x<w-1)push(i+1);if(y>0)push(i-w);if(y<h-1)push(i+w);}const r=new Uint8Array(w*h);for(let i=0;i<w*h;i++)r[i]=out[i]===2?0:1;for(let i=0;i<w*h;i++)if(m[i])r[i]=1;return r;}
  function seedComponent(m,w,h,sx,sy){let s=sy*w+sx;if(!m[s]){let bd=1e9;for(let i=0;i<w*h;i++)if(m[i]){const d=Math.hypot(i%w-sx,((i/w)|0)-sy);if(d<bd){bd=d;s=i;}}if(bd>=1e9)return null;}const o=new Uint8Array(w*h),st=[s];o[s]=1;while(st.length){const i=st.pop(),x=i%w,y=(i/w)|0;for(const j of[x>0?i-1:-1,x<w-1?i+1:-1,y>0?i-w:-1,y<h-1?i+w:-1])if(j>=0&&m[j]&&!o[j]){o[j]=1;st.push(j);}}return o;}
  // Moore-neighbour boundary tracing (8-connected), Jacob stopping criterion
  function mooreTrace(m,w,h){let sx=-1,sy=-1;outer:for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(m[y*w+x]){sx=x;sy=y;break outer;}if(sx<0)return[];const D=[[1,0],[1,1],[0,1],[-1,1],[-1,0],[-1,-1],[0,-1],[1,-1]];const at=(x,y)=>x>=0&&y>=0&&x<w&&y<h&&m[y*w+x];const pts=[{x:sx,y:sy}];let cx=sx,cy=sy,dir=6,guard=0,first=true;while(guard++<w*h*4){let found=false;for(let k=0;k<8;k++){const d=(dir+k+ (first?0:0))%8,nx=cx+D[d][0],ny=cy+D[d][1];if(at(nx,ny)){cx=nx;cy=ny;dir=(d+6)%8;found=true;break;}}if(!found)break;if(cx===sx&&cy===sy&&pts.length>2)break;pts.push({x:cx,y:cy});first=false;}return pts;}
  function grayBlurSobel(g,W,x0,y0,rw,rh){const b=new Float32Array(rw*rh);for(let y=0;y<rh;y++)for(let x=0;x<rw;x++){let s=0,c=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const xx=x+dx,yy=y+dy;if(xx>=0&&yy>=0&&xx<rw&&yy<rh){s+=g[(y0+yy)*W+x0+xx];c++;}}b[y*rw+x]=s/c;}const m=new Float32Array(rw*rh);for(let y=1;y<rh-1;y++)for(let x=1;x<rw-1;x++){const i=y*rw+x,gx=-b[i-rw-1]-2*b[i-1]-b[i+rw-1]+b[i-rw+1]+2*b[i+1]+b[i+rw+1],gy=-b[i-rw-1]-2*b[i-rw]-b[i-rw+1]+b[i+rw-1]+2*b[i+rw]+b[i+rw+1];m[i]=Math.hypot(gx,gy)/4;}m.blur=b;return m;}
  // minimax (bottleneck) gradient cost from seed via bucket queue
  function bottleneck(q,rw,rh,sx,sy){const B=new Uint8Array(rw*rh).fill(255),vis=new Uint8Array(rw*rh),bk=Array.from({length:256},()=>[]);const s=sy*rw+sx;bk[0].push(s);B[s]=0;for(let l=0;l<256;l++){const a=bk[l];while(a.length){const i=a.pop();if(vis[i])continue;vis[i]=1;B[i]=l;const x=i%rw,y=(i/rw)|0;for(const j of[x>0?i-1:-1,x<rw-1?i+1:-1,y>0?i-rw:-1,y<rh-1?i+rw:-1]){if(j<0||vis[j])continue;const c=Math.max(l,q[j]);bk[c].push(j);}}}return B;}

  function run(g,W,H,seed,R,opt){
    const x0=Math.max(0,seed.x-R),y0=Math.max(0,seed.y-R),x1=Math.min(W,seed.x+R+1),y1=Math.min(H,seed.y+R+1),rw=x1-x0,rh=y1-y0,sx=seed.x-x0,sy=seed.y-y0;
    const mag=grayBlurSobel(g,W,x0,y0,rw,rh),srt=Float32Array.from(mag).sort(),p95=Math.max(2,srt[Math.floor(srt.length*.95)]);
    const q=new Uint8Array(rw*rh);for(let i=0;i<q.length;i++)q[i]=Math.min(255,Math.round(mag[i]/p95*100));
    const B=bottleneck(q,rw,rh,sx,sy),cnt=new Float64Array(257);for(let i=0;i<B.length;i++)cnt[B[i]]++;const A=new Float64Array(257);let c=0;for(let t=0;t<256;t++){c+=cnt[t];A[t]=c;}
    // ROI edges that are NOT image borders: region reaching them means ROI too small
    let minEdge=255;const chk=i=>{if(B[i]<minEdge)minEdge=B[i];};if(x0>0)for(let y=0;y<rh;y++)chk(y*rw);if(x1<W)for(let y=0;y<rh;y++)chk(y*rw+rw-1);if(y0>0)for(let x=0;x<rw;x++)chk(x);if(y1<H)for(let x=0;x<rw;x++)chk((rh-1)*rw+x);
    const tmax=minEdge-1,s=4,maxA=opt.maxArea,ref=Math.min(A[Math.max(0,Math.min(tmax,250))],maxA),floorA=Math.max(opt.minArea,0.25*ref);let bestT=-1,bestS=9;const sc=new Float64Array(256).fill(9);
    for(let t=s;t<=Math.min(tmax,250);t++){if(A[t]<floorA||A[t]>maxA)continue;sc[t]=(A[Math.min(255,t+s)]-A[t-s])/A[t];if(sc[t]<bestS){bestS=sc[t];bestT=t;}}
    if(bestT<0)return{fail:'NO_CLOSED_PLATEAU',needBigger:tmax<250&&A[Math.max(0,tmax)]>=opt.minArea*0.5};
    let t=bestT;while(t+1<=tmax&&sc[t+1]<=bestS*1.25+0.01)t++;
    let m=new Uint8Array(rw*rh);for(let i=0;i<m.length;i++)m[i]=B[i]<=t?1:0;
    m=fillHoles(m,rw,rh);const area0=m.reduce((a,b)=>a+b,0),k=clampA(Math.round(0.03*Math.sqrt(area0)),1,3);let o=m;for(let i=0;i<k;i++)o=erode(o,rw,rh);for(let i=0;i<k;i++)o=dilate(o,rw,rh);for(let i=0;i<rw*rh;i++)o[i]=o[i]&&m[i]?1:0;const gr=opt.edgeGrowPx??2;for(let i=0;i<gr;i++)o=dilate(o,rw,rh);
    const comp=seedComponent(o,rw,rh,sx,sy);if(!comp)return{fail:'SEED_LOST'};
    const raw=mooreTrace(comp,rw,rh).map(p=>({x:p.x+x0,y:p.y+y0}));if(raw.length<8)return{fail:'CONTOUR_TOO_SHORT'};
    let area=0,mx=0,my=0,sxx=0,syy=0,sxy=0,bsum=0,bn=0;for(let i=0;i<comp.length;i++)if(comp[i]){area++;const x=i%rw,y=(i/rw)|0;mx+=x;my+=y;sxx+=x*x;syy+=y*y;sxy+=x*y;const xx=x,yy=y;if(!(xx>0&&yy>0&&xx<rw-1&&yy<rh-1&&comp[i-1]&&comp[i+1]&&comp[i-rw]&&comp[i+rw])){bsum+=q[i];bn++;}}
    const cx=mx/area,cy=my/area,vxx=sxx/area-cx*cx,vyy=syy/area-cy*cy,vxy=sxy/area-cx*cy,tr=vxx+vyy,dt=Math.sqrt(Math.max(0,(vxx-vyy)**2/4+vxy*vxy)),l1=tr/2+dt,l2=Math.max(1e-6,tr/2-dt);
    return{raw,area,x0,y0,rw,rh,tPlateau:t,stability:bestS,boundaryStrength:bn?bsum/bn:0,elongation:Math.sqrt(l1/l2),touchesImageEdge:raw.some(p=>p.x<=0||p.y<=0||p.x>=W-1||p.y>=H-1)};
  }

  function trace(g,W,H,seedIn,userOpt){
    const opt=Object.assign({minArea:30,maxAreaFrac:.35},userOpt||{});opt.maxArea=opt.maxArea||W*H*opt.maxAreaFrac;
    const seed={x:clampA(Math.round(seedIn.x),0,W-1),y:clampA(Math.round(seedIn.y),0,H-1)};let r=null,used=0;
    for(const R of[45,90,170,320]){used=R;r=run(g,W,H,seed,R,opt);if(!r.fail)break;if(r.fail!=='NO_CLOSED_PLATEAU')break;}
    if(!r||r.fail)return{ok:false,level:'LOW',confidence:0,reasons:[r?r.fail:'NO_RESULT'],seed};
    const eq=2*Math.sqrt(r.area/Math.PI);let eps=clampA(0.012*eq,1,4),poly=null,tries=0,areaB=polyArea(r.raw);
    while(tries++<4){poly=rdpClosed(r.raw,eps);const a=polyArea(poly);if(poly.length>=4&&Math.abs(a-areaB)/Math.max(1,areaB)<=0.05)break;eps/=2;}
    const areaA=polyArea(poly),perB=polyPerim(r.raw),perA=polyPerim(poly),reasons=[];
    if(!poly.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)))reasons.push('NON_FINITE');
    if(poly.length<4)reasons.push('TOO_FEW_POINTS');
    if(selfIntersects(poly))reasons.push('SELF_INTERSECTION');
    let spikes=0;for(let i=0;i<poly.length;i++){const a=poly[(i+poly.length-1)%poly.length],b=poly[i],c=poly[(i+1)%poly.length],v1=[a.x-b.x,a.y-b.y],v2=[c.x-b.x,c.y-b.y],cs=(v1[0]*v2[0]+v1[1]*v2[1])/((Math.hypot(...v1)*Math.hypot(...v2))||1e-9);if(cs>0.966)spikes++;}
    if(spikes>2)reasons.push('SPIKES:'+spikes);
    const solidity=areaA/Math.max(1,hullArea(poly));if(solidity<0.7)reasons.push('LOW_SOLIDITY');
    if(r.elongation>6)reasons.push('EXTREME_ELONGATION');
    if(used>=320&&r.area>opt.maxArea*.5)reasons.push('VERY_LARGE_REGION');
    const stab=clampA(1-r.stability/0.25,0,1),bs=clampA(r.boundaryStrength/60,0,1),shape=clampA((solidity-0.6)/0.3,0,1)*clampA(1-(r.elongation-3)/6,0,1);
    let conf=0.4*stab+0.35*bs+0.25*shape;if(reasons.length)conf=Math.min(conf,0.45);
    const level=conf>=0.7?'HIGH':conf>=0.5?'MEDIUM':'LOW';
    return{ok:!reasons.some(x=>/NON_FINITE|TOO_FEW|SELF_INT/.test(x)),polygon:poly,seed,confidence:conf,level,reasons,
      metrics:{rawPoints:r.raw.length,simplifiedPoints:poly.length,areaBefore:areaB,areaAfter:areaA,perimeterBefore:perB,perimeterAfter:perA,eps,roiRadius:used,plateauLevel:r.tPlateau,stabilityScore:r.stability,boundaryStrength:r.boundaryStrength,solidity,elongation:r.elongation,touchesImageEdge:r.touchesImageEdge,eqDiameterPx:2*Math.sqrt(areaA/Math.PI)}};
  }

  // ================= MULTI-CANDIDATE ENGINE (v2) =================
  function rasterGrid(poly,gx,gy,gw,gh,st){const m=new Uint8Array(gw*gh);for(let j=0;j<gh;j++){const y=gy+j*st;for(let i=0;i<gw;i++){const x=gx+i*st;let ins=false;for(let a=0,b=poly.length-1;a<poly.length;b=a++){const p=poly[a],q=poly[b];if((p.y>y)!==(q.y>y)&&x<(q.x-p.x)*(y-p.y)/(q.y-p.y)+p.x)ins=!ins;}m[j*gw+i]=ins?1:0;}}return m;}
  function polyRel(a,b){const bb=p=>{let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const t of p){x0=Math.min(x0,t.x);x1=Math.max(x1,t.x);y0=Math.min(y0,t.y);y1=Math.max(y1,t.y);}return[x0,y0,x1,y1];};const A=bb(a),B=bb(b);if(A[2]<B[0]||B[2]<A[0]||A[3]<B[1]||B[3]<A[1])return{iou:0,aInB:0,bInA:0};const x0=Math.min(A[0],B[0]),y0=Math.min(A[1],B[1]),x1=Math.max(A[2],B[2]),y1=Math.max(A[3],B[3]),st=Math.max(1,Math.floor(Math.max(x1-x0,y1-y0)/80)),gw=Math.ceil((x1-x0)/st)+1,gh=Math.ceil((y1-y0)/st)+1,ma=rasterGrid(a,x0,y0,gw,gh,st),mb=rasterGrid(b,x0,y0,gw,gh,st);let i=0,ua=0,ub=0;for(let k=0;k<ma.length;k++){ua+=ma[k];ub+=mb[k];if(ma[k]&&mb[k])i++;}return{iou:i/Math.max(1,ua+ub-i),aInB:i/Math.max(1,ua),bInA:i/Math.max(1,ub)};}
  function finishCand(m,rw,rh,x0,y0,sx,sy,q,Ib,sd,W,H,meta){
    m=fillHoles(m,rw,rh);const a0=m.reduce((a,b)=>a+b,0),k=clampA(Math.round(0.03*Math.sqrt(a0)),1,3);let o=m;for(let i=0;i<k;i++)o=erode(o,rw,rh);for(let i=0;i<k;i++)o=dilate(o,rw,rh);for(let i=0;i<rw*rh;i++)o[i]=o[i]&&m[i]?1:0;if(!meta.noGrow){o=dilate(o,rw,rh);o=dilate(o,rw,rh);}
    const comp=seedComponent(o,rw,rh,sx,sy);if(!comp)return null;const raw=mooreTrace(comp,rw,rh).map(p=>({x:p.x+x0,y:p.y+y0}));if(raw.length<8)return null;
    let area=0,mx=0,my=0,sxx=0,syy=0,sxy=0,sIn=0,sIn2=0,bs=0,bn=0,ec=0;const bnd=[];const at=(i)=>comp[i];
    for(let i=0;i<comp.length;i++)if(comp[i]){area++;const x=i%rw,y=(i/rw)|0;mx+=x;my+=y;sxx+=x*x;syy+=y*y;sxy+=x*y;sIn+=Ib[i];sIn2+=Ib[i]*Ib[i];if(!(x>0&&y>0&&x<rw-1&&y<rh-1&&comp[i-1]&&comp[i+1]&&comp[i-rw]&&comp[i+rw]))bnd.push(i);}
    for(const i of bnd){bs+=q[i];bn++;let mxq=q[i];const x=i%rw,y=(i/rw)|0;for(const j of[x>0?i-1:i,x<rw-1?i+1:i,y>0?i-rw:i,y<rh-1?i+rw:i])if(q[j]>mxq)mxq=q[j];if(mxq>=25)ec++;}
    let d=comp;for(let i=0;i<3;i++)d=dilate(d,rw,rh);let rs=0,rn=0;for(let i=0;i<d.length;i++)if(d[i]&&!comp[i]){rs+=Ib[i];rn++;}
    const mIn=sIn/area,sdIn=Math.sqrt(Math.max(0,sIn2/area-mIn*mIn)),ring=rn?rs/rn:mIn,cx=mx/area,cy=my/area,vxx=sxx/area-cx*cx,vyy=syy/area-cy*cy,vxy=sxy/area-cx*cy,tr=vxx+vyy,dt=Math.sqrt(Math.max(0,(vxx-vyy)**2/4+vxy*vxy)),elong=Math.sqrt((tr/2+dt)/Math.max(1e-6,tr/2-dt));
    const eq=2*Math.sqrt(area/Math.PI);let eps=clampA(0.012*eq,1,4),poly=null,tries=0;const areaB=polyArea(raw);while(tries++<4){poly=rdpClosed(raw,eps);if(poly.length>=4&&Math.abs(polyArea(poly)-areaB)/Math.max(1,areaB)<=0.05)break;eps/=2;}
    const areaA=polyArea(poly),reasons=[];if(!poly.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y))||poly.length<4)return null;if(selfIntersects(poly))return null;
    let spikes=0;for(let i=0;i<poly.length;i++){const a=poly[(i+poly.length-1)%poly.length],b=poly[i],c=poly[(i+1)%poly.length],v1=[a.x-b.x,a.y-b.y],v2=[c.x-b.x,c.y-b.y];if((v1[0]*v2[0]+v1[1]*v2[1])/((Math.hypot(...v1)*Math.hypot(...v2))||1e-9)>0.966)spikes++;}
    const solidity=areaA/Math.max(1,hullArea(poly)),sdist=Math.min(...poly.map(p=>Math.hypot(p.x-(sx+x0),p.y-(sy+y0))));
    return{polygon:poly,area:areaA,eq:2*Math.sqrt(areaA/Math.PI),solidity,elong,spikes,bStrength:bn?bs/bn:0,edgeCov:bn?ec/bn:0,contrast:Math.abs(mIn-ring)/Math.max(6,sdIn),homog:clampA(1-sdIn/Math.max(8,sd*1.2),0,1),seedRel:sdist/Math.max(1,2*Math.sqrt(areaA/Math.PI)/2),touchesImageEdge:raw.some(p=>p.x<=0||p.y<=0||p.x>=W-1||p.y>=H-1),
      rawPoints:raw.length,perimB:polyPerim(raw),perimA:polyPerim(poly),areaB,eps,scales:new Set([meta.R]),fields:new Set([meta.f]),growth:meta.g};}
  function candsAtScale(g,W,H,seed,R,opt){
    const x0=Math.max(0,seed.x-R),y0=Math.max(0,seed.y-R),x1=Math.min(W,seed.x+R+1),y1=Math.min(H,seed.y+R+1),rw=x1-x0,rh=y1-y0,sx=seed.x-x0,sy=seed.y-y0,n=rw*rh;
    const mag=grayBlurSobel(g,W,x0,y0,rw,rh),Ib=mag.blur,srt=Float32Array.from(mag).sort(),p95=Math.max(2,srt[Math.floor(n*.95)]);
    let mI=0;for(let i=0;i<n;i++)mI+=Ib[i];mI/=n;let v=0;for(let i=0;i<n;i++)v+=(Ib[i]-mI)**2;const sd=Math.max(4,Math.sqrt(v/n));let mu=0,c=0;for(let dy=-3;dy<=3;dy++)for(let dx=-3;dx<=3;dx++){const xx=sx+dx,yy=sy+dy;if(xx>=0&&yy>=0&&xx<rw&&yy<rh){mu+=Ib[yy*rw+xx];c++;}}mu/=c;
    const q=new Uint8Array(n),qi=new Uint8Array(n),qc=new Uint8Array(n);for(let i=0;i<n;i++){q[i]=Math.min(255,Math.round(mag[i]/p95*100));qi[i]=Math.min(255,Math.round(Math.abs(Ib[i]-mu)/sd*60));qc[i]=Math.max(q[i],Math.round(qi[i]*.7));}
    const out=[];
    for(const[f,F]of[['grad',q],['int',qi],['comb',qc]]){
      const B=bottleneck(F,rw,rh,sx,sy),cnt=new Float64Array(257);for(let i=0;i<n;i++)cnt[B[i]]++;const A=new Float64Array(257);let cc=0;for(let t=0;t<256;t++){cc+=cnt[t];A[t]=cc;}
      let minEdge=255;const chk=i=>{if(B[i]<minEdge)minEdge=B[i];};if(x0>0)for(let y=0;y<rh;y++)chk(y*rw);if(x1<W)for(let y=0;y<rh;y++)chk(y*rw+rw-1);if(y0>0)for(let x=0;x<rw;x++)chk(x);if(y1<H)for(let x=0;x<rw;x++)chk((rh-1)*rw+x);
      const tmax=Math.min(250,minEdge-1),s=4,sc=new Float64Array(258).fill(9);for(let t=s;t<=tmax;t++)if(A[t]>=opt.minArea&&A[t]<=opt.maxArea)sc[t]=(A[Math.min(255,t+s)]-A[t-s])/A[t];
      const mins=[];for(let t=s;t<=tmax;t++)if(sc[t]<0.6&&sc[t]<=sc[t-1]&&sc[t]<=sc[t+1])mins.push(t);mins.sort((a,b)=>sc[a]-sc[b]);const pick=[];for(const t of mins){if(pick.every(u=>Math.max(A[t],A[u])/Math.min(A[t],A[u])>=1.35))pick.push(t);if(pick.length>=3)break;}
      for(let t of pick){const b0=sc[t];while(t+1<=tmax&&sc[t+1]<=b0*1.25+0.01)t++;const m=new Uint8Array(n);for(let i=0;i<n;i++)m[i]=B[i]<=t?1:0;const cd=finishCand(m,rw,rh,x0,y0,sx,sy,q,Ib,sd,W,H,{R,f,g:b0});if(cd&&cd.area>=opt.minArea)out.push(cd);}
    }
    return out;
  }
  const ramp=(v,a,b)=>clampA((v-a)/(b-a),0,1);
  function traceMulti(g,W,H,seedIn,userOpt){
    const opt=Object.assign({minArea:30,maxAreaFrac:.3,scales:[60,130,260]},userOpt||{});opt.maxArea=opt.maxArea||W*H*opt.maxAreaFrac;const seed={x:clampA(Math.round(seedIn.x),0,W-1),y:clampA(Math.round(seedIn.y),0,H-1)};
    let all=[];for(const R of opt.scales)all=all.concat(candsAtScale(g,W,H,seed,R,opt));
    const u=[];for(const c of all){let hit=null;for(const d of u){const r=polyRel(c.polygon,d.polygon);if(r.iou>=0.8){hit=d;break;}}if(hit){c.scales.forEach(x=>hit.scales.add(x));c.fields.forEach(x=>hit.fields.add(x));if(c.growth<hit.growth){c.scales=hit.scales;c.fields=hit.fields;u[u.indexOf(hit)]=c;}}else u.push(c);}
    for(const c of u){const rad=c.eq/2,elig=opt.scales.filter(R=>R>=1.25*rad).length,stab=clampA(c.scales.size/Math.max(2,elig),0,1);
      c.sc={boundary:0.5*ramp(c.bStrength,15,70)+0.5*ramp(c.contrast,0.3,1.8),edgeCoverage:ramp(c.edgeCov,0.35,0.85),geometry:ramp(c.solidity,0.6,0.9)*clampA(1-(c.elong-2.5)/5,0,1)*(c.spikes>2?.5:1),region:c.homog,stability:stab,seed:c.seedRel>=0.15?1:0.4};
      c.raw=.25*c.sc.boundary+.2*c.sc.edgeCoverage+.2*c.sc.geometry+.15*c.sc.stability+.1*c.sc.region+.1*c.sc.seed;c.pen=0;c.flags=[];}
    for(const a of u)for(const b of u){if(a===b||b.area<1.3*a.area||b.area>5*a.area)continue;const r=polyRel(a.polygon,b.polygon);if(r.aInB>=0.85&&b.raw>=a.raw-0.12&&b.solidity>=0.78){a.pen+=0.2;a.flags.push('POSSIBLE_PARTIAL_FACE(larger plausible candidate exists)');b.pen+=0.05;b.flags.push('MAY_INCLUDE_NEIGHBOR');}}
    for(const c of u){if(c.solidity<0.7)c.flags.push('LOW_SOLIDITY');if(c.elong>5)c.flags.push('ELONGATED');if(c.scales.size<2&&opt.scales.filter(R=>R>=1.25*c.eq/2).length>=2)c.flags.push('SINGLE_SCALE_ONLY');if(c.spikes>2)c.flags.push('SPIKES');if(c.area>opt.maxArea*.5)c.flags.push('VERY_LARGE');c.conf=clampA(c.raw-c.pen,0,1);}
    u.sort((a,b)=>b.conf-a.conf);const cands=u.slice(0,4);
    if(cands.length>1){const d=cands[0],e=cands.slice(1).find(x=>Math.max(x.area,d.area)/Math.min(x.area,d.area)>1.3&&d.conf-x.conf<0.06);if(e){d.flags.push('AMBIGUOUS_ALTERNATIVE');d.conf=Math.min(d.conf,0.69);e.conf=Math.min(e.conf,0.69);}}
    cands.forEach((c,i)=>{const hard=c.flags.some(f=>/LOW_SOLIDITY|SPIKES|ELONGATED|VERY_LARGE/.test(f));/* HIGH intentionally disabled: real-photo test (BB_7/GG_10) showed HIGH on merged/partial contours; re-enable only after calibration against a manual reference set */c.level=(c.conf>=0.5&&!hard)?'MEDIUM':'LOW';c.label='ABCD'[i];
      c.ok=true;c.reasons=c.flags;c.confidence=c.conf;c.metrics={areaBefore:c.areaB,areaAfter:c.area,rawPoints:c.rawPoints,simplifiedPoints:c.polygon.length,perimeterBefore:c.perimB,perimeterAfter:c.perimA,eqDiameterPx:c.eq,solidity:c.solidity,elongation:c.elong,boundaryStrength:c.bStrength,scaleSupport:[...c.scales],fields:[...c.fields]};c.scores=c.sc;});
    return{ok:cands.length>0,seed,candidates:cands,nRaw:all.length,nUnique:u.length};
  }

  // ================= V3: REGION-GRAPH ROCK BOUNDARY ENGINE =================
  function superpixels(q,rw,rh,step){const lab=new Int32Array(rw*rh).fill(-1),bk=Array.from({length:256},()=>[]);let n=0;for(let gy=step>>1;gy<rh;gy+=step)for(let gx=step>>1;gx<rw;gx+=step){let bi=gy*rw+gx,bv=q[bi];for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){const x=gx+dx,y=gy+dy;if(x>=0&&y>=0&&x<rw&&y<rh&&q[y*rw+x]<bv){bv=q[y*rw+x];bi=y*rw+x;}}if(lab[bi]<0){lab[bi]=n++;bk[q[bi]].push(bi);}}
    for(let l=0;l<256;l++){const a=bk[l];while(a.length){const i=a.pop(),x=i%rw,y=(i/rw)|0;for(const j of[x>0?i-1:-1,x<rw-1?i+1:-1,y>0?i-rw:-1,y<rh-1?i+rw:-1])if(j>=0&&lab[j]<0){lab[j]=lab[i];bk[Math.max(l,q[j])].push(j);}}}return{lab,n};}
  function buildPartition(g,W,H,seed,R,step){
    const x0=Math.max(0,seed.x-R),y0=Math.max(0,seed.y-R),x1=Math.min(W,seed.x+R+1),y1=Math.min(H,seed.y+R+1),rw=x1-x0,rh=y1-y0,sx=seed.x-x0,sy=seed.y-y0,N=rw*rh;
    const mag=grayBlurSobel(g,W,x0,y0,rw,rh),Ib=mag.blur,srt=Float32Array.from(mag).sort(),p95=Math.max(2,srt[Math.floor(N*.95)]),q=new Uint8Array(N);for(let i=0;i<N;i++)q[i]=Math.min(255,Math.round(mag[i]/p95*100));
    const{lab,n}=superpixels(q,rw,rh,step),area=new Float64Array(n),sI=new Float64Array(n),sQ=new Float64Array(n),touch=new Uint8Array(n),adj=Array.from({length:n},()=>new Map());
    const edgeOK=(x,y)=>(x===0&&x0>0)||(y===0&&y0>0)||(x===rw-1&&x1<W)||(y===rh-1&&y1<H);
    for(let y=0;y<rh;y++)for(let x=0;x<rw;x++){const i=y*rw+x,a=lab[i];area[a]++;sI[a]+=Ib[i];sQ[a]+=q[i];if(edgeOK(x,y))touch[a]=1;for(const j of[x<rw-1?i+1:-1,y<rh-1?i+rw:-1]){if(j<0)continue;const b=lab[j];if(a===b)continue;const e=Math.max(q[i],q[j]);for(const[u,v]of[[a,b],[b,a]]){let t=adj[u].get(v);if(!t){t={s:0,c:0};adj[u].set(v,t);}t.s+=e;t.c++;}}}
    const mI=new Float64Array(n),tex=new Float64Array(n);for(let a=0;a<n;a++){mI[a]=sI[a]/area[a];tex[a]=sQ[a]/area[a];}
    let mm=0;for(let i=0;i<N;i++)mm+=Ib[i];mm/=N;let vv=0;for(let i=0;i<N;i++)vv+=(Ib[i]-mm)**2;const sdI=Math.max(6,Math.sqrt(vv/N));let mt=0;for(let a=0;a<n;a++)mt+=tex[a];mt/=n;let vt=0;for(let a=0;a<n;a++)vt+=(tex[a]-mt)**2;const sdT=Math.max(15,Math.sqrt(vt/n));const lk=[];for(let a=0;a<n;a++)for(const[b,e]of adj[a])if(b>a)lk.push(e.s/e.c);lk.sort((u,v)=>u-v);const medB=lk.length?lk[lk.length>>1]:20,p90B=lk.length?lk[Math.floor(lk.length*.9)]:60,spanB=Math.max(25,p90B-medB);
    return{x0,y0,rw,rh,sx,sy,q,Ib,lab,n,area,mI,tex,adj,touch,sdI,sdT,medB,spanB,seedR:lab[sy*rw+sx],R};}
  const METHODS=[{label:'A',name:'region-first',wI:1,wT:1,wB:.4,tau:1.0},{label:'B',name:'region+edge',wI:.6,wT:.6,wB:1.2,tau:.9},{label:'C',name:'shadow-aware',wI:.25,wT:1,wB:.8,tau:.9},{label:'D',name:'conservative',wI:1,wT:1,wB:1,tau:.55}];
  function growSeq(P,m,maxA){const inSet=new Uint8Array(P.n),fs=new Map(),seq=[];let A=P.area[P.seedR],sI=P.mI[P.seedR]*A,sT=P.tex[P.seedR]*A,intC=0,intS=0,roiHit=false;inSet[P.seedR]=1;
    const front=a=>{for(const[b,e]of P.adj[a]){if(inSet[b])continue;let f=fs.get(b);if(!f){f={s:0,c:0};fs.set(b,f);}f.s+=e.s;f.c+=e.c;}};front(P.seedR);const tauR=m.tau*1.5;
    while(fs.size){const mS=sI/A,tS=sT/A;let best=-1,bc=1e9,bb=0;for(const[r,f]of fs){const bs=f.s/f.c,c=m.wI*Math.abs(P.mI[r]-mS)/P.sdI+m.wT*Math.abs(P.tex[r]-tS)/P.sdT+m.wB*Math.max(0,bs-P.medB)/P.spanB;if(c<bc){bc=c;best=r;bb=bs;}}
      if(bc>tauR||A+P.area[best]>maxA)break;if(P.touch[best]&&bc<=m.tau){roiHit=true;break;}const f=fs.get(best);intC+=f.c;if(f.s/f.c-P.medB>=0.6*P.spanB)intS+=f.c;
      seq.push({r:best,cost:bc,bs:bb,a:A+P.area[best],iC:intC,iS:intS,fsz:f.c});inSet[best]=1;A+=P.area[best];sI+=P.mI[best]*P.area[best];sT+=P.tex[best]*P.area[best];fs.delete(best);front(best);}
    return{seq,roiHit,fs};}
  function maskFrom(P,regs){const inS=new Uint8Array(P.n);regs.forEach(r=>inS[r]=1);const m=new Uint8Array(P.rw*P.rh);for(let i=0;i<m.length;i++)m[i]=inS[P.lab[i]];return m;}
  function chamfer(m,w,h){const d=new Float32Array(w*h);for(let i=0;i<d.length;i++)d[i]=m[i]?1e9:0;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x;if(!m[i])continue;let v=d[i];if(x>0)v=Math.min(v,d[i-1]+1);if(y>0){v=Math.min(v,d[i-w]+1);if(x>0)v=Math.min(v,d[i-w-1]+1.414);if(x<w-1)v=Math.min(v,d[i-w+1]+1.414);}d[i]=v;}for(let y=h-1;y>=0;y--)for(let x=w-1;x>=0;x--){const i=y*w+x;if(!m[i])continue;let v=d[i];if(x<w-1)v=Math.min(v,d[i+1]+1);if(y<h-1){v=Math.min(v,d[i+w]+1);if(x<w-1)v=Math.min(v,d[i+w+1]+1.414);if(x>0)v=Math.min(v,d[i+w-1]+1.414);}d[i]=v;}return d;}
  function necks(m,w,h){const d=chamfer(m,w,h);let mx=0,A=0;for(let i=0;i<d.length;i++){if(m[i])A++;if(d[i]>mx)mx=d[i];}const T=0.5*mx,seen=new Uint8Array(w*h);let comps=0;for(let s=0;s<d.length;s++){if(seen[s]||!m[s]||d[s]<=T)continue;let a=0;const st=[s];seen[s]=1;while(st.length){const i=st.pop();a++;const x=i%w,y=(i/w)|0;for(const j of[x>0?i-1:-1,x<w-1?i+1:-1,y>0?i-w:-1,y<h-1?i+w:-1])if(j>=0&&!seen[j]&&m[j]&&d[j]>T){seen[j]=1;st.push(j);}}if(a>=0.05*A)comps++;}return comps;}
  function candFrom(P,regs,meta,W,H,opt,sq){const m=maskFrom(P,regs),c=finishCand(m,P.rw,P.rh,P.x0,P.y0,P.sx,P.sy,P.q,P.Ib,P.sdI,W,H,{R:P.R,f:meta.name,g:0,noGrow:true});if(!c||c.area<opt.minArea)return null;c.necks=necks(m,P.rw,P.rh);return c;}
  // ================= V3: SUPERPIXEL REGION-GRAPH ENGINE =================
  function slicLite(Ib,T,rw,rh,S,sdI,tM){const gx=Math.ceil(rw/S),gy=Math.ceil(rh/S),K=gx*gy,cI=new Float32Array(K),cT=new Float32Array(K),cX=new Float32Array(K),cY=new Float32Array(K),lab=new Int32Array(rw*rh),dist=new Float32Array(rw*rh),S2=S*S;
    for(let j=0;j<gy;j++)for(let i=0;i<gx;i++){const k=j*gx+i,x=Math.min(rw-1,Math.floor((i+.5)*S)),y=Math.min(rh-1,Math.floor((j+.5)*S));cX[k]=x;cY[k]=y;cI[k]=Ib[y*rw+x];cT[k]=T[y*rw+x];}
    for(let it=0;it<4;it++){dist.fill(1e9);for(let k=0;k<K;k++){const xa=Math.max(0,Math.floor(cX[k]-S)),xb=Math.min(rw-1,Math.ceil(cX[k]+S)),ya=Math.max(0,Math.floor(cY[k]-S)),yb=Math.min(rh-1,Math.ceil(cY[k]+S));for(let y=ya;y<=yb;y++)for(let x=xa;x<=xb;x++){const i=y*rw+x,di=(Ib[i]-cI[k])/sdI,dt=(T[i]-cT[k])/tM,d=4*di*di+.5*dt*dt+((x-cX[k])**2+(y-cY[k])**2)/S2;if(d<dist[i]){dist[i]=d;lab[i]=k;}}}
      const a=new Float64Array(K*5);for(let i=0;i<lab.length;i++){const k=lab[i]*5;a[k]+=Ib[i];a[k+1]+=T[i];a[k+2]+=i%rw;a[k+3]+=(i/rw)|0;a[k+4]++;}for(let k=0;k<K;k++){const n=a[k*5+4];if(n){cI[k]=a[k*5]/n;cT[k]=a[k*5+1]/n;cX[k]=a[k*5+2]/n;cY[k]=a[k*5+3]/n;}}}
    return{lab,K};}
  function v3Scale(g,W,H,seed,R,opt){
    const x0=Math.max(0,seed.x-R),y0=Math.max(0,seed.y-R),x1=Math.min(W,seed.x+R+1),y1=Math.min(H,seed.y+R+1),rw=x1-x0,rh=y1-y0,sx=seed.x-x0,sy=seed.y-y0,n=rw*rh;
    const mag=grayBlurSobel(g,W,x0,y0,rw,rh),Ib=mag.blur,srt=Float32Array.from(mag).sort(),p95=Math.max(2,srt[Math.floor(n*.95)]),q=new Uint8Array(n);for(let i=0;i<n;i++)q[i]=Math.min(255,Math.round(mag[i]/p95*100));
    const T=new Float32Array(n),cl=(v,m)=>v<0?0:v>m?m:v;for(let y=0;y<rh;y++)for(let x=0;x<rw;x++){let s1=0,s2=0;for(let dy=-2;dy<=2;dy+=2)for(let dx=-2;dx<=2;dx+=2){const v=Ib[cl(y+dy,rh-1)*rw+cl(x+dx,rw-1)];s1+=v;s2+=v*v;}T[y*rw+x]=Math.sqrt(Math.max(0,s2/9-(s1/9)**2));}
    let mI=0,tM=0;for(let i=0;i<n;i++){mI+=Ib[i];tM+=T[i];}mI/=n;tM=tM/n+1e-3;let vv=0;for(let i=0;i<n;i++)vv+=(Ib[i]-mI)**2;const sdI=Math.max(4,Math.sqrt(vv/n));
    const{lab,K}=slicLite(Ib,T,rw,rh,R<=120?8:12,sdI,tM),N=new Float64Array(K),sI=new Float64Array(K),sT=new Float64Array(K),sX=new Float64Array(K),sY=new Float64Array(K),sXX=new Float64Array(K),sYY=new Float64Array(K),sXY=new Float64Array(K),touch=new Uint8Array(K),E=new Map();
    for(let i=0;i<n;i++){const k=lab[i],x=i%rw,y=(i/rw)|0;N[k]++;sI[k]+=Ib[i];sT[k]+=T[i];sX[k]+=x;sY[k]+=y;sXX[k]+=x*x;sYY[k]+=y*y;sXY[k]+=x*y;if((x===0&&x0>0)||(x===rw-1&&x1<W)||(y===0&&y0>0)||(y===rh-1&&y1<H))touch[k]=1;}
    const add=(i,j)=>{const a=lab[i],b=lab[j];if(a===b)return;const key=a<b?a*K+b:b*K+a;let e=E.get(key);if(!e){e={a:Math.min(a,b),b:Math.max(a,b),s:0,c:0};E.set(key,e);}e.s+=(q[i]+q[j])/2;e.c++;};
    for(let y=0;y<rh;y++)for(let x=0;x<rw;x++){const i=y*rw+x;if(x<rw-1)add(i,i+1);if(y<rh-1)add(i,i+rw);}
    const adj=Array.from({length:K},()=>[]);for(const e of E.values()){adj[e.a].push(e);adj[e.b].push(e);}const oth=(e,v)=>e.a===v?e.b:e.a,s0=lab[sy*rw+sx];
    function grow(mode){const inR=new Uint8Array(K),rank=new Int32Array(K).fill(1e9),order=[s0],fr=new Set(),steps=[];inR[s0]=1;rank[s0]=0;let A=N[s0],cI=sI[s0],cT=sT[s0],mx=sX[s0],my=sY[s0],mxx=sXX[s0],myy=sYY[s0],mxy=sXY[s0],oS=0,oC=0,iS=0,iC=0,tc=touch[s0];for(const e of adj[s0]){oS+=e.s;oC+=e.c;fr.add(oth(e,s0));}
      for(let it=0;it<500;it++){const cx=mx/A,cy=my/A,vxx=mxx/A-cx*cx,vyy=myy/A-cy*cy,vxy=mxy/A-cx*cy,tr=vxx+vyy,dt=Math.sqrt(Math.max(0,(vxx-vyy)**2/4+vxy*vxy)),l1=tr/2+dt,l2=Math.max(1e-6,tr/2-dt);steps.push({k:order.length,A,out:oC?oS/oC:0,inn:iC?iS/iC:0,fill:A/(4*Math.PI*Math.sqrt(l1*l2)),elong:Math.sqrt(l1/l2),touch:tc});if(tc||A>opt.maxArea||!fr.size)break;
        let best=-1,bc=1e9;const aI=cI/A,aT=cT/A;for(const u of fr){let es=0,ec=0;for(const e of adj[u])if(inR[oth(e,u)]){es+=e.s;ec+=e.c;}const st=ec?es/ec:0,cost=mode==='A'?.3*Math.abs(aI-sI[u]/N[u])/sdI+.2*Math.abs(aT-sT[u]/N[u])/tM+.5*st/60:st/60;if(cost<bc){bc=cost;best=u;}}
        const v=best;fr.delete(v);inR[v]=1;rank[v]=order.length;order.push(v);A+=N[v];cI+=sI[v];cT+=sT[v];mx+=sX[v];my+=sY[v];mxx+=sXX[v];myy+=sYY[v];mxy+=sXY[v];tc=tc||touch[v];for(const e of adj[v]){const u=oth(e,v);if(inR[u]){oS-=e.s;oC-=e.c;iS+=e.s;iC+=e.c;}else{oS+=e.s;oC+=e.c;fr.add(u);}}}
      return{steps,rank};}
    const shape=st=>st.touch||st.A<opt.minArea?0:st.out*ramp(st.fill,.55,.9)*clampA(1-(st.elong-3)/6,0,1);
    function peaks(G){const sc=G.steps.map(shape),P=[];for(let i=0;i<sc.length;i++){if(sc[i]<=0)continue;let ok=true;for(let d=-4;d<=4;d++)if(sc[i+d]!==undefined&&sc[i+d]>sc[i]){ok=false;break;}if(ok)P.push(i);}P.sort((a,b)=>sc[b]-sc[a]);const out=[];for(const i of P){if(out.every(j=>Math.max(G.steps[i].A,G.steps[j].A)/Math.min(G.steps[i].A,G.steps[j].A)>=1.3))out.push(i);if(out.length>=2)break;}return{idx:out,sc};}
    const maskAt=(G,k)=>{const m=new Uint8Array(n);for(let i=0;i<n;i++)m[i]=G.rank[lab[i]]<k?1:0;return m;};
    const mk=(m,method,st)=>{const c=finishCand(m,rw,rh,x0,y0,sx,sy,q,Ib,sdI,W,H,{R,f:method,g:0});if(c&&c.area>=opt.minArea){c.methods=new Set([method]);c.stepOut=st.out;c.stepIn=st.inn;return c;}return null;};
    const out=[],GA=grow('A'),GB=grow('B'),pA=peaks(GA),pB=peaks(GB);
    pA.idx.forEach((i,r)=>{const c=mk(maskAt(GA,GA.steps[i].k),'region-first',GA.steps[i]);if(c)out.push(c);});
    pB.idx.forEach(i=>{const c=mk(maskAt(GB,GB.steps[i].k),'edge-constrained',GB.steps[i]);if(c)out.push(c);});
    if(pA.idx.length){const bestS=pA.sc[pA.idx[0]],cons=pA.idx.filter(i=>pA.sc[i]>=.8*bestS).sort((a,b)=>GA.steps[a].A-GA.steps[b].A)[0];const c=mk(maskAt(GA,GA.steps[cons].k),'conservative',GA.steps[cons]);if(c)out.push(c);
      // watershed-assisted: erosion markers (ultimate-erosion style) on the best region-first mask; only if a neck splits it
      const M=maskAt(GA,GA.steps[pA.idx[0]].k);let e=M;for(let k=1;k<=18;k++){e=erode(e,rw,rh);const L=new Int32Array(n),sz=[0];let nl=0;for(let i=0;i<n;i++)if(e[i]&&!L[i]){nl++;let c2=0;const st=[i];L[i]=nl;while(st.length){const j=st.pop();c2++;const x=j%rw,y=(j/rw)|0;for(const u of[x>0?j-1:-1,x<rw-1?j+1:-1,y>0?j-rw:-1,y<rh-1?j+rw:-1])if(u>=0&&e[u]&&!L[u]){L[u]=nl;st.push(u);}}sz[nl]=c2;}
        const mx2=Math.max(...sz),big=[];for(let l=1;l<=nl;l++)if(sz[l]>=Math.max(12,.2*mx2))big.push(l);
        if(big.length>=2&&k>=2){const own=new Int32Array(n),q2=[];for(let i=0;i<n;i++)if(big.includes(L[i])){own[i]=L[i];q2.push(i);}let h=0;while(h<q2.length){const j=q2[h++],x=j%rw,y=(j/rw)|0;for(const u of[x>0?j-1:-1,x<rw-1?j+1:-1,y>0?j-rw:-1,y<rh-1?j+rw:-1])if(u>=0&&M[u]&&!own[u]){own[u]=own[j];q2.push(u);}}
          let sl=own[sy*rw+sx];if(!sl){let bd=1e9;for(const j of q2){const d=Math.hypot(j%rw-sx,((j/rw)|0)-sy);if(d<bd&&L[j]){bd=d;sl=own[j];}}}const m3=new Uint8Array(n);for(let i=0;i<n;i++)m3[i]=own[i]===sl?1:0;const c=mk(m3,'watershed-neck',GA.steps[pA.idx[0]]);if(c){c.necked=true;out.push(c);}break;}}}
    out.ctx={x0,y0,rw,rh,sx,sy,q,Ib,sdI,R};return out;}
  function traceV3Legacy(g,W,H,seedIn,userOpt){
    const opt=Object.assign({minArea:30,maxAreaFrac:.3,scales:[110,240]},userOpt||{});opt.maxArea=opt.maxArea||W*H*opt.maxAreaFrac;const seed={x:clampA(Math.round(seedIn.x),0,W-1),y:clampA(Math.round(seedIn.y),0,H-1)};
    let all=[];for(const R of opt.scales)all=all.concat(v3Scale(g,W,H,seed,R,opt));
    const u=[];for(const c of all){let hit=null;for(const d of u)if(polyRel(c.polygon,d.polygon).iou>=.85){hit=d;break;}if(hit){c.scales.forEach(x=>hit.scales.add(x));c.methods.forEach(x=>hit.methods.add(x));if(c.necked)hit.necked=true;}else u.push(c);}
    for(const c of u){const elig=opt.scales.filter(R=>R>=1.25*c.eq/2).length,stab=clampA(c.scales.size/Math.max(2,elig),0,1),leak=(c.solidity<.75?.15:0)+(c.elong>5?.15:0)+(c.stepIn>.9*c.stepOut?.1:0)+(c.touchesImageEdge?0:0);
      c.sc={boundary:.5*ramp(c.bStrength,15,70)+.5*ramp(c.contrast,.3,1.8),neighborSep:ramp(c.stepOut,20,70),edgeCoverage:ramp(c.edgeCov,.35,.85),geometry:ramp(c.solidity,.6,.9)*clampA(1-(c.elong-2.5)/5,0,1)*(c.spikes>2?.5:1),region:c.homog,stability:stab,seed:c.seedRel>=.15?1:.4};c.leak=leak;
      c.raw=.2*c.sc.boundary+.15*c.sc.neighborSep+.15*c.sc.edgeCoverage+.2*c.sc.geometry+.15*c.sc.stability+.1*c.sc.region+.05*c.sc.seed;c.pen=0;c.flags=[];if(c.stepIn>.9*c.stepOut)c.flags.push('INTERNAL_EDGES_AS_STRONG_AS_BOUNDARY');if(leak>=.25)c.flags.push('POSSIBLE_LEAKAGE');}
    for(const a of u)for(const b of u){if(a===b||b.area<1.3*a.area||b.area>5*a.area)continue;const r=polyRel(a.polygon,b.polygon);if(r.aInB>=.85&&b.raw>=a.raw-.12&&b.solidity>=.78){a.pen+=.2;a.flags.push('POSSIBLE_PARTIAL_FACE(larger plausible candidate exists)');b.pen+=.05;b.flags.push('MAY_INCLUDE_NEIGHBOR');}}
    for(const c of u){if(c.solidity<.7)c.flags.push('LOW_SOLIDITY');if(c.elong>5)c.flags.push('ELONGATED');if(c.spikes>2)c.flags.push('SPIKES');if(c.necked)c.flags.push('NECK_SPLIT_APPLIED');c.conf=clampA(c.raw-c.pen-c.leak,0,1);c.sc.leakagePenalty=c.leak+c.pen;}
    u.sort((a,b)=>b.conf-a.conf);const cands=u.slice(0,4);if(cands.length>1){const d=cands[0],e=cands.slice(1).find(x=>Math.max(x.area,d.area)/Math.min(x.area,d.area)>1.3&&d.conf-x.conf<.06);if(e){d.flags.push('AMBIGUOUS_ALTERNATIVE');d.conf=Math.min(d.conf,.69);e.conf=Math.min(e.conf,.69);}}
    cands.forEach((c,i)=>{const hard=c.flags.some(f=>/LOW_SOLIDITY|SPIKES|ELONGATED|LEAKAGE/.test(f));c.level=(c.conf>=.5&&!hard)?'MEDIUM':'LOW'/* MAX=MEDIUM until reference validation */;c.label='ABCD'[i];c.ok=true;c.reasons=c.flags;c.confidence=c.conf;c.metrics={areaBefore:c.areaB,areaAfter:c.area,rawPoints:c.rawPoints,simplifiedPoints:c.polygon.length,perimeterBefore:c.perimB,perimeterAfter:c.perimA,areaChangePct:100*(c.area-c.areaB)/Math.max(1,c.areaB),perimChangePct:100*(c.perimA-c.perimB)/Math.max(1,c.perimB),eqDiameterPx:c.eq,solidity:c.solidity,elongation:c.elong,boundaryStrength:c.bStrength,scaleSupport:[...c.scales],methods:[...c.methods]};c.scores=c.sc;});
    return{ok:cands.length>0,seed,candidates:cands,nRaw:all.length,nUnique:u.length};}
    // ================= V4: MULTI-OBJECT-AWARE RANKING + DT-PERSISTENCE SPLIT =================
  // Evidence is derived ONLY from the candidate mask + image edge map (q). Ground truth is never an input.
  // dtPartition: marker-controlled watershed on the distance transform. A DT maximum becomes its own core when its
  // persistence 1 - saddle/peak >= tau (and its peak >= minPeak). All other maxima are absorbed (noise / bumps).
  function dtPartition(m,w,h,Q,o){
    const d=chamfer(m,w,h),n=w*h;let mx=0,A=0;for(let i=0;i<n;i++)if(m[i]){A++;if(d[i]>mx)mx=d[i];}
    if(!A)return{cores:0,neck:0,mx:0,lab:null,roots:[],seamQ:0,seamN:0};
    const minPk=Math.max(o.minPeakPx??3,(o.minPeakFrac??.3)*mx),tau=o.tau??.2,idx=[];for(let i=0;i<n;i++)if(m[i])idx.push(i);idx.sort((a,b)=>d[b]-d[a]||a-b);
    const par=new Int32Array(n).fill(-1),pk=new Float32Array(n),find=x=>{while(par[x]!==x){par[x]=par[par[x]];x=par[x];}return x;};let neck=0,neckAt=-1;const fp=new Map(); // fp: persistence at FIRST encounter (= true saddle) per surviving core
    for(const i of idx){const x=i%w,y=(i/w)|0,rs=[];
      for(const j of[x>0?i-1:-1,x<w-1?i+1:-1,y>0?i-w:-1,y<h-1?i+w:-1,x>0&&y>0?i-w-1:-1,x<w-1&&y>0?i-w+1:-1,x>0&&y<h-1?i+w-1:-1,x<w-1&&y<h-1?i+w+1:-1]){if(j<0||par[j]<0)continue;const r=find(j);if(!rs.includes(r))rs.push(r);}
      if(!rs.length){par[i]=i;pk[i]=d[i];continue;}
      rs.sort((a,b)=>pk[b]-pk[a]||a-b);const p=rs[0];par[i]=p;
      for(let k=1;k<rs.length;k++){const r=rs[k],prom=1-d[i]/pk[r];if(pk[r]>=minPk&&prom>=tau){if(!fp.has(r)){fp.set(r,prom);if(prom>neck){neck=prom;neckAt=i;}}}else par[r]=p;}}
    const rootsAll=[];for(let i=0;i<n;i++)if(m[i]&&par[i]===i&&pk[i]>=minPk)rootsAll.push(i);rootsAll.sort((a,b)=>pk[b]-pk[a]||a-b);
    const id=new Map();rootsAll.forEach((r,k)=>id.set(r,k+1));const lab=new Int32Array(n),area=new Array(rootsAll.length+1).fill(0);
    for(let i=0;i<n;i++)if(m[i]){const r=find(i),l=id.get(r)||0;lab[i]=l;if(l)area[l]++;}
    let sq=0,sn=0;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x;if(!lab[i])continue;for(const j of[x<w-1?i+1:-1,y<h-1?i+w:-1]){if(j<0||!lab[j]||lab[j]===lab[i])continue;sq+=Math.max(Q[i],Q[j]);sn++;}}
    return{cores:rootsAll.length,neck:rootsAll.length>=2?neck:0,mx,lab,roots:rootsAll.map((r,k)=>({peak:pk[r],area:area[k+1],i:r})),neckAt:rootsAll.length>=2?neckAt:-1,seamQ:sn?sq/sn:0,seamN:sn};}
  function v4Evidence(c,opt){const X=c.ctx,m=rasterGrid(c.polygon,X.x0,X.y0,X.rw,X.rh,1),part=dtPartition(m,X.rw,X.rh,X.q,opt);c.mask=m;c.part=part;c.cores=part.cores;c.neck=part.neck;
    c.seamSup=part.seamN?ramp(part.seamQ/Math.max(20,c.bStrength),.2,.6):0;c.E=part.cores>=2?part.neck*(.6+.4*c.seamSup):0;c.seedIn=m[X.sy*X.rw+X.sx]===1;c.multi=c.E>=opt.tauSplit;}
  function v4Children(p,W,H,opt){const X=p.ctx,out=[];if(!p.part||p.part.cores<2)return out;
    for(let l=1;l<=p.part.cores;l++){const m=new Uint8Array(X.rw*X.rh);for(let i=0;i<m.length;i++)m[i]=p.part.lab[i]===l?1:0;
      const c=finishCand(m,X.rw,X.rh,X.x0,X.y0,X.sx,X.sy,X.q,X.Ib,X.sdI,W,H,{R:X.R,f:'dt-split',g:0,noGrow:true});
      if(!c||c.area<opt.minArea)continue;c.methods=new Set(['dt-split']);c.scales=new Set(p.scales);c.stepOut=p.stepOut;c.stepIn=p.stepIn;c.ctx=X;c.necked=true;c.parentOf=p;out.push(c);}
    return out;}
  function traceV4(g,W,H,seedIn,userOpt){
    const opt=Object.assign({minArea:30,maxAreaFrac:.3,scales:[110,240],split:true,gate:true,pfCond:true,seedGate:true,tauSplit:.2,tau:.2,childFloor:.5,splitMargin:.05,pfMaxRatio:8},userOpt||{});opt.maxArea=opt.maxArea||W*H*opt.maxAreaFrac;
    const seed={x:clampA(Math.round(seedIn.x),0,W-1),y:clampA(Math.round(seedIn.y),0,H-1)};
    let all=[];if(opt.pre)all=opt.pre;else for(const R of opt.scales){const o=v3Scale(g,W,H,seed,R,opt);o.forEach(c=>c.ctx=o.ctx);all=all.concat(o);}
    const u=[];const merge=c=>{let hit=null;for(const d of u)if(polyRel(c.polygon,d.polygon).iou>=.85){hit=d;break;}if(hit){c.scales.forEach(x=>hit.scales.add(x));c.methods.forEach(x=>hit.methods.add(x));if(c.necked)hit.necked=true;return hit;}u.push(c);return c;};
    for(const c of all)merge(c);
    for(const c of u)v4Evidence(c,opt);
    const scoreBase=c=>{const elig=opt.scales.filter(R=>R>=1.25*c.eq/2).length,stab=clampA(c.scales.size/Math.max(2,elig),0,1),leak=(c.solidity<.75?.15:0)+(c.elong>5?.15:0)+(c.stepIn>.9*c.stepOut?.1:0);
      c.sc={boundary:.5*ramp(c.bStrength,15,70)+.5*ramp(c.contrast,.3,1.8),neighborSep:ramp(c.stepOut,20,70),edgeCoverage:ramp(c.edgeCov,.35,.85),geometry:ramp(c.solidity,.6,.9)*clampA(1-(c.elong-2.5)/5,0,1)*(c.spikes>2?.5:1),region:c.homog,stability:stab,seed:c.seedRel>=.15?1:.4};c.leak=leak;
      c.raw=.2*c.sc.boundary+.15*c.sc.neighborSep+.15*c.sc.edgeCoverage+.2*c.sc.geometry+.15*c.sc.stability+.1*c.sc.region+.05*c.sc.seed;c.pen=0;c.flags=[];c.rejected=false;
      if(c.stepIn>.9*c.stepOut)c.flags.push('INTERNAL_EDGES_AS_STRONG_AS_BOUNDARY');if(leak>=.25)c.flags.push('POSSIBLE_LEAKAGE');};
    for(const c of u)scoreBase(c);
    if(opt.split){const single=u.filter(c=>!c.multi&&c.seedIn),rStar=single.length?Math.max(...single.map(c=>c.raw-c.leak)):-1;
      // split is a FALLBACK: only a multi-object candidate that would still win the base ranking is worth splitting
      for(const p of u.slice()){if(!p.multi||!p.seedIn||p.raw-p.leak<=rStar-opt.splitMargin)continue;for(const ch of v4Children(p,W,H,opt)){const k=merge(ch);if(k===ch){v4Evidence(ch,opt);scoreBase(ch);}}}}
    // V3 partial-face rule, made conditional: a larger candidate that is itself multi-object is NOT evidence of a partial face.
    for(const a of u)for(const b of u){if(a===b||b.area<1.3*a.area||b.area>opt.pfMaxRatio*a.area)continue;if(opt.pfCond&&b.multi)continue;const r=polyRel(a.polygon,b.polygon);if(r.aInB>=.85&&b.raw>=a.raw-.12&&b.solidity>=.78){a.pen+=.2;a.flags.push('POSSIBLE_PARTIAL_FACE(larger plausible candidate exists)');b.pen+=.05;b.flags.push('MAY_INCLUDE_NEIGHBOR');}}
    // Parent rejection: multi-object evidence AND a valid sub-candidate that lies inside it, is itself
    // single-object, AND beats the parent on the evidence score. The d.raw>p.raw condition is the fix for
    // the single-object regression (fused/narrow-waist single rocks): dtPartition legitimately finds 2
    // cores in a waisted single rock (E barely above tauSplit) and a lobe scores raw~0.95 because a lobe
    // is itself a clean convex blob; the old unconditional rejection then buried the correct full-rock
    // contour (highest raw in the pool) below every other candidate and usually cut it from the top-4 the
    // user is shown. Now the parent is rejected only when the split explanation is strictly BETTER on the
    // evidence terms; on a tie the single-object reading wins (this tool is human-in-the-loop; the parent
    // stays visible, flagged MULTI_OBJECT_PARENT_REJECTED). Rejection is also no longer lexicographic in
    // the sort: a rejected parent keeps its conf and is ranked by evidence, not buried below noise.
    if(opt.gate)for(const p of u){if(!p.multi)continue;for(const d of u){if(d===p||d.multi||!d.seedIn||d.area>.8*p.area)continue;if(polyRel(d.polygon,p.polygon).aInB<.85)continue;if(d.raw<opt.childFloor)continue;if(!(d.raw>p.raw))continue;p.rejected=true;p.flags.push('MULTI_OBJECT_PARENT_REJECTED');break;}}
    for(const c of u){if(c.solidity<.7)c.flags.push('LOW_SOLIDITY');if(c.elong>5)c.flags.push('ELONGATED');if(c.spikes>2)c.flags.push('SPIKES');if(c.necked)c.flags.push('NECK_SPLIT_APPLIED');if(c.multi)c.flags.push('MULTI_OBJECT_EVIDENCE');
      c.conf=clampA(c.raw-c.pen-c.leak,0,1);c.sc.leakagePenalty=c.leak+c.pen;if(opt.seedGate&&!c.seedIn){c.conf=0;c.flags.push('SEED_OUTSIDE');}}
    const toXY=(X,i)=>i<0?null:{x:X.x0+i%X.rw,y:X.y0+((i/X.rw)|0)};
    for(const c of u){const X=c.ctx,P=c.part;c.dbg={cores:c.cores,neck:c.neck,E:c.E,multi:!!c.multi,rejected:!!c.rejected,seedIn:!!c.seedIn,child:c.methods.has('dt-split'),roots:P&&P.roots?P.roots.map(r=>Object.assign(toXY(X,r.i),{peak:r.peak,area:r.area})):[],saddle:P&&P.neckAt>=0?toXY(X,P.neckAt):null};}
    u.sort((a,b)=>(b.conf-a.conf));const cands=u.slice(0,4);
    if(cands.length>1){const d=cands[0],e=cands.slice(1).find(x=>Math.max(x.area,d.area)/Math.min(x.area,d.area)>1.3&&d.conf-x.conf<.06&&!x.rejected);if(e){d.flags.push('AMBIGUOUS_ALTERNATIVE');d.conf=Math.min(d.conf,.69);e.conf=Math.min(e.conf,.69);}}
    cands.forEach((c,i)=>{const hard=c.flags.some(f=>/LOW_SOLIDITY|SPIKES|ELONGATED|LEAKAGE/.test(f));c.level=(c.conf>=.5&&!hard&&!c.rejected)?'MEDIUM':'LOW';c.label='ABCD'[i];c.ok=true;c.reasons=c.flags;c.confidence=c.conf;c.scores=c.sc;c.metrics={areaBefore:c.areaB,areaAfter:c.area,rawPoints:c.rawPoints,simplifiedPoints:c.polygon.length,perimeterBefore:c.perimB,perimeterAfter:c.perimA,areaChangePct:100*(c.area-c.areaB)/Math.max(1,c.areaB),perimChangePct:100*(c.perimA-c.perimB)/Math.max(1,c.perimB),eqDiameterPx:c.eq,solidity:c.solidity,elongation:c.elong,boundaryStrength:c.bStrength,scaleSupport:[...c.scales],methods:[...c.methods]};});
    for(const c of u){delete c.mask;if(c.part)delete c.part.lab;}
    return{ok:cands.length>0,seed,candidates:cands,all:u,nRaw:all.length,nUnique:u.length,engine:'V4'};}

  /* API-stable entry point used by the UI: single active implementation = V4. traceV3Legacy is kept ONLY for A/B regression tests (never called by the UI). */
  const traceV3=(g,W,H,s,o)=>traceV4(g,W,H,s,o);
  return{traceV3,traceV4,traceV3Legacy,dtPartition,trace,traceMulti,rasterGrid,polyArea,selfIntersects,rdpClosed,polyRel,v3Scale,finishCand,necks,chamfer,erode,dilate,fillHoles,clampA,ramp,hullArea,polyPerim};
})();
/*AUTOTRACE_CORE_END*/

  // ===== AUTO TRACE ROCK v2: multi-candidate, multi-scale, human-in-the-loop =====
  const AT={debug:false,pending:null,gray:null,grayFor:null,seq:0,stats:{accepted:0,acceptedLow:0,manualFallback:0,cancelled:0,failed:0,altChosen:0}};
  const AT_COL={A:'#22d3ee',B:'#facc15',C:'#c084fc',D:'#fb7185'};
  function atGray(){const c=APP_STATE.image.workingCanvas;if(!c)return null;if(AT.grayFor===c&&AT.gray)return AT.gray;const w=c.width,h=c.height,d=c.getContext('2d').getImageData(0,0,w,h).data,g=new Float32Array(w*h);for(let i=0;i<w*h;i++){const o=i*4;g[i]=.299*d[o]+.587*d[o+1]+.114*d[o+2];}AT.gray=g;AT.grayFor=c;return g;}
  const atCur=()=>AT.pending&&AT.pending.candidates&&AT.pending.candidates[AT.pending.sel];
  function atPanel(){const p=$('autoTracePanel');if(!p)return;const P=AT.pending;if(!P){p.hidden=true;return;}p.hidden=false;const sc=APP_STATE.calibration.centimetersPerWorkingPixel;$('atCands').innerHTML=(P.candidates||[]).map((c,i)=>`<button class="btn ${i===P.sel?'btn--accent':''}" data-at="${i}" type="button" style="border-left:4px solid ${AT_COL[c.label]}">${c.label} • ${c.level} ${(c.confidence*100).toFixed(0)}%</button>`).join(' ');const c=atCur();if(!c){$('atInfo').innerHTML='<span style="color:#a86a00">Tidak ada kandidat yang lolos validasi → gunakan MANUAL TRACE.</span>';$('atAccept').disabled=true;return;}const m=c.metrics,s=c.scores;
    const pc=v=>Number.isFinite(v)?(v*100).toFixed(0):'--',sc2=Object.entries(s).map(([k,v])=>k+' '+pc(v)).join(' • ');$('atInfo').innerHTML=`Seed (${P.seed.x},${P.seed.y}) • Candidate <b>${c.label}</b> [${[...(c.methods||[])].join('+')}] • Confidence <b>${c.level}</b> (${(c.confidence*100).toFixed(0)}%)<br>Area ${Math.round(m.areaAfter)} px² • ED ${m.eqDiameterPx.toFixed(1)} px${sc?' = '+(m.eqDiameterPx*sc).toFixed(1)+' cm':' (belum kalibrasi)'}<br>${sc2}<br>pts ${m.rawPoints}→${m.simplifiedPoints} • Δarea ${(m.areaChangePct??0).toFixed(1)}% • Δperim ${(m.perimChangePct??m.perimeterChangePct??0).toFixed(1)}%`+(c.reasons.length?`<br><span style="color:#a86a00">Flags: ${c.reasons.join('; ')}</span>`:'')+(AT.debug?atDbgInfo(P,c):'');$('atAccept').disabled=false;}
  function atDrawPreview(ctx){try{refDraw(ctx);}catch(_e){}const P=AT.pending;if(!P)return;ctx.save();(P.candidates||[]).forEach((c,i)=>{const sel=i===P.sel;ctx.strokeStyle=AT_COL[c.label];ctx.lineWidth=sel?3:1.5;ctx.setLineDash(sel?[]:[6,4]);ctx.fillStyle=sel?'rgba(34,211,238,.12)':'transparent';ctx.beginPath();c.polygon.forEach((p,k)=>k?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();if(sel)ctx.fill();ctx.stroke();});ctx.setLineDash([]);ctx.fillStyle='#fff';ctx.strokeStyle='#000';ctx.beginPath();ctx.arc(P.seed.x,P.seed.y,4,0,7);ctx.fill();ctx.stroke();if(AT.debug)atDrawDebug(ctx,P);ctx.restore();}
  // ---- V4 debug overlay: parent / rejected parent / child split / core markers / saddle (selected + reference are drawn by the normal preview) ----
  function atDrawDebug(ctx,P){const all=P.all||[];ctx.save();
    all.forEach(c=>{const d=c.dbg;if(!d||!c.polygon)return;let col=null,w=1.5,dash=[3,3];if(d.child){col='#34d399';dash=[2,2];}else if(d.rejected){col='#ef4444';w=3;dash=[8,4];}else if(d.multi){col='#fb923c';w=2.5;dash=[8,4];}if(!col)return;ctx.strokeStyle=col;ctx.lineWidth=w;ctx.setLineDash(dash);ctx.beginPath();c.polygon.forEach((p,k)=>k?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.stroke();});
    ctx.setLineDash([]);
    all.forEach(c=>{const d=c.dbg;if(!d||!d.multi)return;d.roots.forEach((r,k)=>{ctx.fillStyle='#fde047';ctx.strokeStyle='#000';ctx.lineWidth=1;ctx.beginPath();ctx.arc(r.x,r.y,5,0,7);ctx.fill();ctx.stroke();ctx.fillStyle='#fff';ctx.font='11px sans-serif';ctx.fillText('C'+(k+1),r.x+7,r.y-6);});if(d.saddle){const s=d.saddle;ctx.strokeStyle='#e879f9';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(s.x-7,s.y-7);ctx.lineTo(s.x+7,s.y+7);ctx.moveTo(s.x+7,s.y-7);ctx.lineTo(s.x-7,s.y+7);ctx.stroke();}});
    ctx.restore();}
  function atDbgInfo(P,c){const all=P.all||[],par=all.filter(x=>x.dbg&&x.dbg.multi).length,rej=all.filter(x=>x.dbg&&x.dbg.rejected).length,ch=all.filter(x=>x.dbg&&x.dbg.child&&x.methods&&x.methods.size===1).length,d=c.dbg||{};return `<br><span style=\"color:#a5b4fc\">DEBUG • selected: cores ${d.cores} • neck ${(d.neck||0).toFixed(2)} • E ${(d.E||0).toFixed(2)} • multi ${!!d.multi} • pool ${all.length} • multi-parents ${par} • rejected ${rej} • DT-children ${ch}<br><span style=\"color:#fb923c\">▭ orange dashed = multi-object parent</span> • <span style=\"color:#ef4444\">red dashed = rejected parent</span> • <span style=\"color:#34d399\">green dotted = child split</span> • <span style=\"color:#fde047\">● C# = core</span> • <span style=\"color:#e879f9\">✕ = saddle/neck</span> • solid colour = selected • orange solid = reference</span>`;}
  function atStart(){if(!APP_STATE.image.workingCanvas){$('scanStatus').textContent='AUTO TRACE: upload foto terlebih dahulu.';return;}cancelTrace();APP_STATE.image.manualMode='autotrace';AT.pending=null;atPanel();$('muckpileCanvas').style.cursor='crosshair';$('canvasHint').textContent='AUTO TRACE ROCK • klik di dalam SATU batu. Beberapa kandidat (A/B/C) akan ditampilkan.';$('scanStatus').textContent='AUTO TRACE aktif. Hasil BUKAN ground truth: pilih kandidat yang benar, atau MANUAL TRACE.';}
  function atStop(){if(APP_STATE.image.manualMode==='autotrace')APP_STATE.image.manualMode=null;AT.pending=null;atPanel();$('muckpileCanvas').style.cursor='';drawCanvas();}
  function atRun(pt){const g=atGray(),c=APP_STATE.image.workingCanvas;if(!g)return;const t0=performance.now();let r;try{r=AutoTrace.traceV3(g,c.width,c.height,pt,{minArea:Math.max(30,Number(getPSDConfig().minArea)||30)});}catch(e){console.error('AutoTrace error',e);r={ok:false,seed:pt,candidates:[],error:e.message};}r.ms=performance.now()-t0;r.sel=0;AT.pending=r;if(!r.ok)AT.stats.failed++;atPanel();drawCanvas();const b=r.candidates[0];$('scanStatus').textContent=`AUTO TRACE ${r.candidates.length} kandidat (${r.ms.toFixed(0)} ms)`+(b?` • terbaik ${b.label}: ${b.level}`:' • tidak ada kandidat valid');}
  function polygonPerimeterPx(xy){let s=0;for(let i=0;i<xy.length;i++){const j=(i+1)%xy.length;s+=Math.hypot(xy[j][0]-xy[i][0],xy[j][1]-xy[i][1]);}return s;}
  function atAccept(){const r=atCur();if(!r||!r.ok)return;const xy=r.polygon.map(p=>[p.x,p.y]),area=polygonArea(r.polygon),b=bboxFromPoints(r.polygon),feret=maxFeretFromXY(xy),ed=eqDiam({area}),bb=Math.max(b.maxx-b.minx,b.maxy-b.miny),sc=APP_STATE.calibration.centimetersPerWorkingPixel,pxDef=APP_STATE.psd.sizeDefinition==='feret'?feret:APP_STATE.psd.sizeDefinition==='eqdiam'?ed:bb,measured=sc?pxDef*sc:null,id=APP_STATE.fragments.length?Math.max(...APP_STATE.fragments.map(f=>Number(f.id)||0))+1:1,hull=convexHull(xy),P=AT.pending;
    const f={id,area,minx:b.minx,maxx:b.maxx,miny:b.miny,maxy:b.maxy,eqDiameterPx:ed,feretPx:feret,bboxMaxPx:bb,boundary:xy,measuredSizeCm:measured,confidence:r.confidence,circularity:(4*Math.PI*area)/Math.max(1,polygonPerimeterPx(xy)**2),aspect:Math.max((b.maxx-b.minx+1)/(b.maxy-b.miny+1),(b.maxy-b.miny+1)/(b.maxx-b.minx+1)),solidity:hull.length>=3?area/Math.max(1,polygonArea(hull.map(p=>({x:p[0],y:p[1]})))):1,status:psdStatusFromSize(measured),manual:false,autoTrace:true,exactPolygon:true,source:'AUTO_TRACE',operation:'TRACE',parentIDs:[],createdBy:'AUTO_TRACE V4 cand '+r.label+(P.sel>0?' (alt chosen)':''),createdAt:now(),traceLevel:r.level,traceScores:r.scores,traceMetrics:r.metrics,review:r.level!=='HIGH',reviewReason:'AUTO TRACE '+r.level};
    APP_STATE.fragments.push(f);AT.stats.accepted++;if(P.sel>0)AT.stats.altChosen++;if(r.level==='LOW')AT.stats.acceptedLow++;audit('Fragment '+id,'NONE','ADDED','AUTO TRACE',`ACCEPT cand ${r.label}/${P.candidates.length} ${r.level} conf=${r.confidence.toFixed(2)} flags=[${r.reasons.join('|')}] ${JSON.stringify(r.metrics,(k,v)=>typeof v==='number'?+v.toFixed(2):v)}`);AT.pending=null;atPanel();APP_STATE.image.selectedId=id;$('selectedObjectId').value=String(id);$('selectedLabel').textContent=`Selected #${id} • AUTO_TRACE ${r.level}`;recomputePSD();renderFragments();drawCanvas();$('scanStatus').textContent=`AUTO TRACE #${id} diterima (${r.level}). Klik batu berikutnya atau STOP.`;}
  $('btnAutoTrace')?.addEventListener('click',atStart);$('atAccept')?.addEventListener('click',atAccept);$('atStop')?.addEventListener('click',atStop);
  $('atNext')?.addEventListener('click',()=>{const P=AT.pending;if(!P||!P.candidates.length)return;P.sel=(P.sel+1)%P.candidates.length;atPanel();drawCanvas();});
  $('atCands')?.addEventListener('click',e=>{const b=e.target.closest('[data-at]');if(!b||!AT.pending)return;AT.pending.sel=+b.dataset.at;atPanel();drawCanvas();});
  $('atCancel')?.addEventListener('click',()=>{AT.stats.cancelled++;AT.pending=null;atPanel();drawCanvas();});
  $('atRedraw')?.addEventListener('click',()=>{AT.stats.manualFallback++;audit('AutoTrace','PREVIEW','MANUAL TRACE','AUTO TRACE','USER REJECTED ALL CANDIDATES');AT.pending=null;atPanel();$('muckpileCanvas').style.cursor='';startTrace();});
  $('muckpileCanvas').addEventListener('click',e=>{if(APP_STATE.image.manualMode!=='autotrace')return;e.stopImmediatePropagation();e.preventDefault();atRun(canvasPoint(e));},true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&APP_STATE.image.manualMode==='autotrace')atStop();});
  window.__AutoTraceDebug={AT,run:atRun,accept:atAccept,start:atStart,gray:atGray,core:AutoTrace,setDebug:v=>{AT.debug=!!v;const e=$('atDebug');if(e)e.checked=!!v;atPanel();drawCanvas();}};
  $('atDebug')?.addEventListener('change',e=>{AT.debug=e.target.checked;atPanel();drawCanvas();});

  // ===== REFERENCE SET (manual ground-truth polygons for validation; source=MANUAL_REFERENCE, never enters PSD dataset) =====
  const REF={list:[],cur:null,pts:[],down:false};
  const refKey=()=>((APP_STATE.image.metadata&&APP_STATE.image.metadata.name)||'img')+'|'+(APP_STATE.image.workingCanvas?APP_STATE.image.workingCanvas.width+'x'+APP_STATE.image.workingCanvas.height:'');
  const refOut=t=>{const e=$('refOut');if(e)e.textContent=t;};
  function refStart(){if(!APP_STATE.image.workingCanvas){refOut('Upload foto dulu.');return;}cancelTrace();AT.pending=null;atPanel();APP_STATE.image.manualMode='reference';REF.cur=null;$('muckpileCanvas').style.cursor='crosshair';refOut(`REFERENCE MODE • tahan mouse dan gambar outline SATU batu, lepas → ACCEPT REF. Tersimpan: ${REF.list.filter(r=>r.image===refKey()).length}`);}
  function refPoly(p){const xy=p.map(t=>[t.x,t.y]);let a=0,per=0;for(let i=0;i<p.length;i++){const j=(i+1)%p.length;a+=p[i].x*p[j].y-p[j].x*p[i].y;per+=Math.hypot(p[j].x-p[i].x,p[j].y-p[i].y);}return{area:Math.abs(a)/2,perimeter:per};}
  function refAccept(){if(!REF.cur)return;const m=refPoly(REF.cur),n=REF.list.length+1;REF.list.push({id:'REF-'+String(n).padStart(3,'0'),image:refKey(),polygon:REF.cur.map(p=>({x:+p.x.toFixed(1),y:+p.y.toFixed(1)})),area:m.area,perimeter:m.perimeter,eqDiameterPx:2*Math.sqrt(m.area/Math.PI),source:'MANUAL_REFERENCE',createdAt:now()});REF.cur=null;refOut(`REF-${String(n).padStart(3,'0')} disimpan (${REF.list.filter(r=>r.image===refKey()).length} untuk gambar ini). Gambar batu berikutnya.`);drawCanvas();}
  function refUndo(){if(REF.cur)REF.cur=null;else REF.list.pop();refOut(`Reference: ${REF.list.length}`);drawCanvas();}
  function refExport(){downloadText('reference_set.json',JSON.stringify(REF.list,null,1),'application/json');}
  function distSeg(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,L=dx*dx+dy*dy||1e-9,t=clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/L,0,1);return Math.hypot(p.x-a.x-t*dx,p.y-a.y-t*dy);}
  function distPoly(p,poly){let d=1e9;for(let i=0;i<poly.length;i++)d=Math.min(d,distSeg(p,poly[i],poly[(i+1)%poly.length]));return d;}
  function refSeed(poly){let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;poly.forEach(p=>{x0=Math.min(x0,p.x);x1=Math.max(x1,p.x);y0=Math.min(y0,p.y);y1=Math.max(y1,p.y);});let best=null,bd=-1;for(let i=0;i<=20;i++)for(let j=0;j<=20;j++){const p={x:x0+(x1-x0)*i/20,y:y0+(y1-y0)*j/20};if(!pointInPolygon(p,poly.map(t=>[t.x,t.y])))continue; /* FIX: pointInPolygon expects [x,y] pairs; with {x,y} it was always false and refSeed returned poly[0] (a boundary vertex) */const d=distPoly(p,poly);if(d>bd){bd=d;best=p;}}return best||poly[0];}
  function refScore(){const g=atGray(),c=APP_STATE.image.workingCanvas,rows=[];for(const r of REF.list.filter(x=>x.image===refKey())){const t=AutoTrace.traceV3(g,c.width,c.height,refSeed(r.polygon),{minArea:30}),cs=t.candidates,a=cs[0],io=cs.map(k=>AutoTrace.polyRel(k.polygon,r.polygon,250).iou);let bdev=null;if(a){const d1=a.polygon.reduce((s,p)=>s+distPoly(p,r.polygon),0)/a.polygon.length,d2=r.polygon.reduce((s,p)=>s+distPoly(p,a.polygon),0)/r.polygon.length;bdev=(d1+d2)/2;}
    const ratio=a?a.area/r.area:0,iou=a?io[0]:0;rows.push({id:r.id,refArea:Math.round(r.area),autoArea:a?Math.round(a.area):null,iou:+iou.toFixed(3),bestOfCandidatesIoU:+Math.max(0,...io).toFixed(3),areaErrPct:a?+((ratio-1)*100).toFixed(1):null,diamErrPct:a?+((a.eq/r.eqDiameterPx-1)*100).toFixed(1):null,boundaryDevPx:bdev==null?null:+bdev.toFixed(1),level:a?a.level:'NONE',failureMode:!a?'MISSED':iou>=0.8?'OK':ratio>1.5?'LEAKAGE_OR_MERGED':ratio<0.6?'PARTIAL':'MISALIGNED',flags:a?a.reasons.join('|'):'',legacyV3IoU:AT.debug?(()=>{try{const l=AutoTrace.traceV3Legacy(g,c.width,c.height,refSeed(r.polygon),{minArea:30}).candidates[0];return l?+AutoTrace.polyRel(l.polygon,r.polygon,250).iou.toFixed(3):0;}catch(_e){return null;}})():undefined});}
    if(!rows.length){refOut('Belum ada reference untuk gambar ini.');return null;}const ious=rows.map(r=>r.iou).sort((x,y)=>x-y),mean=a=>a.reduce((x,y)=>x+y,0)/a.length,ae=rows.filter(r=>r.areaErrPct!=null).map(r=>Math.abs(r.areaErrPct)),de=rows.filter(r=>r.diamErrPct!=null).map(r=>Math.abs(r.diamErrPct));
    const sum={n:rows.length,meanIoU:+mean(ious).toFixed(3),medianIoU:ious[Math.floor(ious.length/2)],meanAbsAreaErrPct:+mean(ae).toFixed(1),meanAbsDiamErrPct:+mean(de).toFixed(1),modes:rows.reduce((o,r)=>(o[r.failureMode]=(o[r.failureMode]||0)+1,o),{})};REF.lastScore={summary:sum,rows};refOut(JSON.stringify(sum)+'\n'+rows.map(r=>`${r.id} IoU ${r.iou} (best ${r.bestOfCandidatesIoU}) area ${r.refArea}→${r.autoArea} ${r.failureMode} ${r.level}${r.legacyV3IoU!=null?' | V3legacy IoU '+r.legacyV3IoU:''}`).join('\n'));audit('Reference validation',REF.list.length,'IoU mean '+sum.meanIoU,'AUTO TRACE','SCORE vs MANUAL_REFERENCE');return REF.lastScore;}
  const cv=$('muckpileCanvas');
  cv.addEventListener('pointerdown',e=>{if(APP_STATE.image.manualMode!=='reference')return;e.preventDefault();REF.down=true;REF.cur=null;REF.pts=[canvasPoint(e)];cv.setPointerCapture?.(e.pointerId);},true);
  cv.addEventListener('pointermove',e=>{if(!REF.down||APP_STATE.image.manualMode!=='reference')return;const p=canvasPoint(e),l=REF.pts[REF.pts.length-1];if(Math.hypot(p.x-l.x,p.y-l.y)>2){REF.pts.push(p);drawCanvas();}},true);
  cv.addEventListener('pointerup',e=>{if(!REF.down)return;REF.down=false;const s=REF.pts.length>=12?simplifyTrace(REF.pts,1.5):[];if(s.length>=4&&refPoly(s).area>=30){REF.cur=s;refOut('Outline siap. ACCEPT REF untuk menyimpan, atau UNDO REF.');}else refOut('Outline terlalu pendek, ulangi.');REF.pts=[];drawCanvas();},true);
  cv.addEventListener('click',e=>{if(APP_STATE.image.manualMode==='reference'){e.stopImmediatePropagation();e.preventDefault();}},true);
  $('refNew')?.addEventListener('click',refStart);$('refAccept')?.addEventListener('click',refAccept);$('refNext')?.addEventListener('click',()=>{REF.cur=null;drawCanvas();refStart();});$('refUndo')?.addEventListener('click',refUndo);$('refExport')?.addEventListener('click',refExport);$('refScore')?.addEventListener('click',refScore);
  $('refImport')?.addEventListener('change',ev=>{const f=ev.target.files?.[0];ev.target.value='';if(!f)return;{const big=kbFileTooBig(f,'json');if(big){refOut(big);return;}}f.text().then(t=>{try{const a=JSON.parse(t);if(Array.isArray(a)){REF.list=a;refOut('Import '+a.length+' reference.');drawCanvas();}}catch(err){refOut('JSON tidak valid.');}});});
  function refDraw(ctx){ctx.save();ctx.lineWidth=2;REF.list.filter(r=>r.image===refKey()).forEach(r=>{ctx.strokeStyle='#fb923c';ctx.beginPath();r.polygon.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.stroke();ctx.fillStyle='#fb923c';ctx.font='11px "IBM Plex Mono", Consolas, monospace';ctx.fillText(r.id,r.polygon[0].x+3,r.polygon[0].y-3);});const pl=REF.cur||(REF.pts.length>1?REF.pts:null);if(pl){ctx.strokeStyle='#f97316';ctx.setLineDash([5,3]);ctx.beginPath();pl.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));if(REF.cur)ctx.closePath();ctx.stroke();}ctx.restore();}
  window.__AutoTraceDebug.REF=REF;window.__AutoTraceDebug.refScore=refScore;window.__AutoTraceDebug.refAccept=refAccept;

  wireGeometryComparison();

  // Kuz-Ram: single init point (state already restored above). Idempotent.
  initKuzram();

  $('projectBadge').textContent='PROJECT: '+(APP_STATE.project.id||'UNTITLED'); ensureLabWorking(); hydrateUI(); renderLab(); drawCanvas(); computeImageQC(); renderFragments(); renderAudit(); updateSeismic(); initBlastPlanControls(); refreshAll(); initChargingSimulation(); initFreeFace(); initKarst(); setCalibrationMode('A'); recalcKarstInteractions(); renderPlanView(); runScreeningCalculation();
  /* ===== EDIT OUTLINE: geser / tambah / hapus titik garis hasil otomatis; ukuran & PSD dihitung ulang ===== */
  const EDIT={drag:null,undo:[]},edCv=$('muckpileCanvas');
  const edPoly=f=>f.exactPolygon&&Array.isArray(f.boundary)?f.boundary:convexHull(f.boundary||[]);
  const edK=()=>{updateDisplayTransform();return((APP_STATE.image.displayTransform||{}).scaleX)||1;};
  const edFrag=()=>APP_STATE.fragments.find(f=>f.id===APP_STATE.image.selectedId)||null;
  const edOn=()=>APP_STATE.image.manualMode==='edit';
  const EDK=['area','minx','maxx','miny','maxy','eqDiameterPx','feretPx','bboxMaxPx','circularity','aspect','solidity','measuredSizeCm','status','exactPolygon','edited','review','reviewReason','estimate','geometryBasis','reviewStatus','sizeOverride','sizeSource'];
  function edPush(f){EDIT.undo.push({id:f.id,boundary:(f.boundary||[]).map(p=>[p[0],p[1]]),k:EDK.reduce((o,k)=>(o[k]=f[k],o),{})});if(EDIT.undo.length>60)EDIT.undo.shift();}
  function edExact(f){if(!f.exactPolygon){f.boundary=convexHull(f.boundary||[]).map(p=>[p[0],p[1]]);f.exactPolygon=true;}}
  function edRefit(f){const pts=f.boundary.map(p=>({x:p[0],y:p[1]}));if(pts.length<3)return;const area=polygonArea(pts),b=bboxFromPoints(pts),feret=maxFeretFromXY(f.boundary),ed=eqDiam({area}),bb=Math.max(b.maxx-b.minx,b.maxy-b.miny),hull=convexHull(f.boundary),
    px=APP_STATE.psd.sizeDefinition==='feret'?feret:APP_STATE.psd.sizeDefinition==='eqdiam'?ed:bb,sc=APP_STATE.calibration.centimetersPerWorkingPixel,m=sc?px*sc:null;
    Object.assign(f,{area,minx:b.minx,maxx:b.maxx,miny:b.miny,maxy:b.maxy,eqDiameterPx:ed,feretPx:feret,bboxMaxPx:bb,circularity:(4*Math.PI*area)/Math.max(1,(feret*Math.PI)**2),
    aspect:Math.max((b.maxx-b.minx+1)/(b.maxy-b.miny+1),(b.maxy-b.miny+1)/(b.maxx-b.minx+1)),solidity:hull.length>=3?Math.min(1,area/Math.max(1,polygonArea(hull.map(p=>({x:p[0],y:p[1]}))))):1,measuredSizeCm:m,status:psdStatusFromSize(m),edited:true,review:false,reviewReason:'OUTLINE DIEDIT',estimate:false,geometryBasis:'USER_EDITED_POLYGON',reviewStatus:'USER EDITED'});if(f.sizeOverride){delete f.sizeOverride;f.sizeSource='GEOMETRY';try{audit('Fragment '+f.id,'SIZE OVERRIDE','CLEARED','MANUAL QC','OUTLINE EDIT INVALIDATES SIZE OVERRIDE');}catch(_e){}}}
  function edCommit(f){edRefit(f);recomputePSD();renderFragments();drawCanvas();try{audit('Fragment '+f.id,'OUTLINE','EDITED','MANUAL QC','EDIT OUTLINE');}catch(_e){}}
  function edSelect(c){APP_STATE.image.selectedId=c.id;try{$('selectedObjectId').value=String(c.id);$('selectedLabel').textContent='Selected #'+c.id+' • EDIT OUTLINE';}catch(_e){}}
  function edHit(f,p){const poly=edPoly(f),R=11*edK();for(let i=0;i<poly.length;i++)if(Math.hypot(poly[i][0]-p.x,poly[i][1]-p.y)<=R)return{t:'v',i};
    for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length];if(Math.hypot((a[0]+b[0])/2-p.x,(a[1]+b[1])/2-p.y)<=R*.9)return{t:'m',i,x:(a[0]+b[0])/2,y:(a[1]+b[1])/2};}
    return pointInPolygon(p,poly)?{t:'in'}:null;}
  const edSmallest=p=>APP_STATE.fragments.filter(g=>g.boundary&&g.boundary.length>=3&&pointInPolygon(p,edPoly(g))).sort((a,b)=>a.area-b.area)[0];
  function edToggle(on){const m=on===undefined?!edOn():on;APP_STATE.image.manualMode=m?'edit':null;edCv.style.touchAction=m?'none':'';
    try{$('canvasHint').textContent=m?'EDIT OUTLINE: klik objek • seret titik putih = geser • seret titik kecil di tengah sisi = tambah titik • klik-kanan / dobel-klik titik = hapus • seret di dalam = geser seluruh garis • Ctrl+Z = undo • Esc = selesai':'Edit outline selesai.';}catch(_e){}drawCanvas();}
  function edUndo(){const s=EDIT.undo.pop();if(!s)return;const f=APP_STATE.fragments.find(x=>x.id===s.id);if(!f)return;f.boundary=s.boundary;Object.assign(f,s.k);recomputePSD();renderFragments();drawCanvas();}
  edCv.addEventListener('pointerdown',e=>{if(!edOn()||e.button!==0)return;e.preventDefault();e.stopImmediatePropagation();const p=canvasPoint(e);let f=edFrag(),h=f?edHit(f,p):null;
    const sm=(!h||h.t==='in')?edSmallest(p):null;if(sm&&(!f||sm.id!==f.id)){edSelect(sm);drawCanvas();return;}if(!f||!h){drawCanvas();return;}
    edPush(f);edExact(f);let idx=h.i;if(h.t==='m'){f.boundary.splice(h.i+1,0,[h.x,h.y]);idx=h.i+1;}
    EDIT.drag={f,t:h.t==='in'?'move':'v',idx,sx:p.x,sy:p.y,orig:f.boundary.map(q=>[q[0],q[1]]),moved:false};edCv.setPointerCapture?.(e.pointerId);drawCanvas();},true);
  edCv.addEventListener('pointermove',e=>{const d=EDIT.drag;if(!d||!edOn())return;e.preventDefault();const p=canvasPoint(e),W=edCv.width,H=edCv.height;d.moved=true;
    if(d.t==='v')d.f.boundary[d.idx]=[Math.max(0,Math.min(W,p.x)),Math.max(0,Math.min(H,p.y))];else{const dx=p.x-d.sx,dy=p.y-d.sy;d.f.boundary=d.orig.map(q=>[Math.max(0,Math.min(W,q[0]+dx)),Math.max(0,Math.min(H,q[1]+dy))]);}drawCanvas();},true);
  edCv.addEventListener('pointerup',e=>{const d=EDIT.drag;if(!d)return;EDIT.drag=null;try{edCv.releasePointerCapture?.(e.pointerId);}catch(_e){}if(d.moved)edCommit(d.f);else{EDIT.undo.pop();drawCanvas();}},true);
  function edDel(e){if(!edOn())return false;const f=edFrag();if(!f)return false;const p=canvasPoint(e),h=edHit(f,p);if(!h||h.t!=='v')return false;e.preventDefault();e.stopImmediatePropagation();
    if(edPoly(f).length<=3){try{$('canvasHint').textContent='Minimal 3 titik.';}catch(_e){}return true;}edPush(f);edExact(f);f.boundary.splice(h.i,1);edCommit(f);return true;}
  edCv.addEventListener('contextmenu',e=>{if(edOn()){edDel(e);e.preventDefault();}},true);
  edCv.addEventListener('dblclick',e=>{edDel(e);},true);
  edCv.addEventListener('click',e=>{if(edOn())e.stopImmediatePropagation();},true);
  document.addEventListener('keydown',e=>{if(!edOn()||/INPUT|TEXTAREA|SELECT/.test((e.target||{}).tagName||''))return;if(e.key==='Escape')edToggle(false);else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();edUndo();}});
  function editDraw(ctx){const b=$('btnEditOutline');if(b){b.textContent=edOn()?'✔ SELESAI EDIT':'EDIT OUTLINE';b.classList.toggle('btn--accent',edOn());}if(!edOn())return;const f=edFrag();if(!f)return;const poly=edPoly(f),k=edK();if(poly.length<3)return;
    ctx.save();ctx.lineJoin='round';ctx.beginPath();poly.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1]));ctx.closePath();ctx.fillStyle='rgba(26,115,232,.12)';ctx.fill();ctx.strokeStyle='#fff';ctx.lineWidth=5*k;ctx.stroke();ctx.strokeStyle='#1a73e8';ctx.lineWidth=2.5*k;ctx.stroke();
    poly.forEach((q,i)=>{const n=poly[(i+1)%poly.length];ctx.fillStyle='rgba(26,115,232,.55)';ctx.beginPath();ctx.arc((q[0]+n[0])/2,(q[1]+n[1])/2,3.5*k,0,7);ctx.fill();});
    poly.forEach(q=>{ctx.fillStyle='#fff';ctx.strokeStyle='#1a73e8';ctx.lineWidth=2.5*k;ctx.beginPath();ctx.arc(q[0],q[1],6.5*k,0,7);ctx.fill();ctx.stroke();});ctx.restore();}
  $('btnEditOutline')?.addEventListener('click',()=>edToggle());$('btnUndoOutline')?.addEventListener('click',edUndo);
  /* ===== Blast Plan = sumber tunggal. Simulator selalu mengikuti baris aktif (termasuk override); edit di simulator ditulis balik ke Plan.
     Akar masalah lama: mengetik di field simulator mengubah template jadi 'custom' sehingga terlepas dari Plan, lalu setelah reload angkanya tidak cocok. ===== */
  (function(){const map={simHoleCount:'holes',simANPerHole:'an',simDNPerHole:'dn',simStemming:'stemming',simBurden:'burden',simSpacing:'spacing',simDepth:'depth'};
    let KEY=Object.keys(BLAST_SHEET_ROWS).find(k=>BLAST_SHEET_ROWS[k].label===APP_STATE.simulation.groupLabel)||'group1';
    const key=()=>{const t=APP_STATE.simulation.template;if(BLAST_SHEET_ROWS[t])KEY=t;return KEY;};
    function planToSim(){try{key();APP_STATE.simulation.template=KEY;const r=getBlastRow(KEY,Number(APP_STATE.simulation.activeBlastRow||1));if(!r)return;syncActiveBlastInputsToSimulation(r);simHydrate();renderBlastTemplateTable(KEY);populateBlastRowSelect();try{refreshGeometry();}catch(_e){}simVisual();renderPlanView();try{calculateFinancial();}catch(_e){}try{runScreeningCalculation();}catch(_e){}persistWorking();}catch(_e){}}
    Object.entries(map).forEach(([id,field])=>{const el=$(id);if(!el)return;el.addEventListener('focus',key);
      el.addEventListener('change',()=>{APP_STATE.simulation.template=key();let ok=false;try{ok=editActiveBlastRowField(field,el.value);}catch(_e){}if(!ok){const bad=el.value;planToSim();simRejectNote='INPUT DITOLAK \u2022 nilai \u201c'+bad+'\u201d tidak valid untuk '+id+' (angka; burden/spacing > 0); dikembalikan ke Blast Plan aktif.';try{simSetNotif('caution','INPUT DITOLAK • nilai \u201c'+bad+'\u201d tidak valid untuk '+id+' (harus angka; burden/spacing > 0). Nilai dikembalikan ke Blast Plan aktif.');}catch(_e){}}});});
    planToSim();
  })();
  /* ===== PHASE A fix: density screening dari Lab aktif, material HG/MG/DOL (tanpa PEDEL), nama blok bisa diganti ===== */
  function screeningMaterial(){const m=engineeringMaterial();if(m&&Number(m.Density)>0)return m;try{ensureLabWorking();}catch(_e){}
    const q=activeLabQualityKey(),v=APP_STATE.material.labWorking&&APP_STATE.material.labWorking.values,d=v?Number(v.Density):NaN;
    return d>0?{Density:d,source:`LAB kelas ${q} aktif (rata-rata ${v.sampleCount||'?'} sampel)`}:{};}
  function syncFormationPick(){const g=(APP_STATE.material.labSnapshot&&APP_STATE.material.labSnapshot.groups)||{},q=activeLabQualityKey();
    [['formationHG','HG'],['formationMG','MG'],['formationDOL','DOL']].forEach(([id,k])=>{const e=$(id);if(e){e.classList.toggle('btn--accent',q===k);e.disabled=!g[k];e.title=g[k]?'':'Kelas '+k+' tidak ada di data Lab';}});}
  (function(){
    [['formationHG','HG'],['formationMG','MG'],['formationDOL','DOL']].forEach(([id,q])=>$(id)?.addEventListener('click',()=>{if(APP_STATE.formation.key!=='limestone')setupFormation('limestone');setLabQuality(q,'USER ACTION');renderFormation();}));
    /* data tersimpan lama: buang PEDEL */
    try{if(APP_STATE.formation.key==='pedel')APP_STATE.formation={key:'limestone',label:'Gamping / Dolomit'};
      const g=(APP_STATE.material.labSnapshot&&APP_STATE.material.labSnapshot.groups)||{};
      if((APP_STATE.material.qualityKey==='PEDEL'||(APP_STATE.material.labWorking&&APP_STATE.material.labWorking.qualityKey==='PEDEL'))&&g.HG){APP_STATE.material.qualityKey='HG';applyLabSnapshotToWorking('HG');}}catch(_e){}
    /* nama blok: terapkan override tersimpan */
    const ov=APP_STATE.simulation.labelOverrides=APP_STATE.simulation.labelOverrides||{};
    Object.entries(ov).forEach(([k,v])=>{const g=BLAST_SHEET_ROWS[k];if(g&&v){if(g.origLabel===undefined)g.origLabel=g.label;g.label=v;}});
    const inp=$('blastGroupInput');
    if(inp){
      const oldRenameHint=$('blastRenameHint');if(oldRenameHint)oldRenameHint.remove();
      inp.addEventListener('change',()=>{const raw=inp.value.trim().replace(/\s+/g,' ').slice(0,80),key=APP_STATE.simulation.template,g=BLAST_SHEET_ROWS[key];if(!g||!raw||g.label===raw)return;
        if(Object.entries(BLAST_SHEET_ROWS).some(([k,x])=>k!==key&&(k.toLowerCase()===raw.toLowerCase()||String(x.label||'').toLowerCase()===raw.toLowerCase())))return;
        const old=g.label;if(g.origLabel===undefined)g.origLabel=old;g.label=raw;ov[key]=raw;APP_STATE.simulation.groupLabel=raw;
        const ci=APP_STATE.geometry.comparisonInputs;if(ci&&typeof ci.source==='string')ci.source=ci.source.split(old).join(raw);
        const dl=$('blastGroupSuggestions');if(dl)[...dl.options].forEach(o=>{if(o.value===old)o.value=raw;});
        try{if($('simTemplate'))$('simTemplate').value=raw;if($('geometrySource'))$('geometrySource').textContent=`Source: ${raw} • Row ${APP_STATE.simulation.activeBlastRow||1}. Data mengikuti template handak.`;renderBlastTemplateTable(key);populateBlastRowSelect();}catch(_e){}
        /* TAHAP-1: update wipBy labels on rename so Kuz-Ram Wipfrag display stays current */
        try{const wb=APP_STATE.kuzram.wipBy;if(wb)Object.entries(wb).forEach(([wk,we])=>{if(wk.startsWith(key+'|')&&we&&we.label===old)we.label=raw;});}catch(_e){}
        try{audit('Nama blok',old,raw,'USER ACTION','BLOCK RENAME');}catch(_e){}persistWorking();try{refreshAll();}catch(_e){}});
    }
    try{syncFormationPick();renderFormation();renderBlastTemplateTable(APP_STATE.simulation.template||'group1');if(inp&&APP_STATE.simulation.groupLabel)inp.value=APP_STATE.simulation.groupLabel;}catch(_e){}
    if(Object.keys(ov).length){try{const key=APP_STATE.simulation.template,g=BLAST_SHEET_ROWS[key],ci=APP_STATE.geometry.comparisonInputs;if(g&&g.origLabel&&ci&&typeof ci.source==='string')ci.source=ci.source.split(g.origLabel).join(g.label);if($('geometrySource')&&g)$('geometrySource').textContent=`Source: ${g.label} • Row ${APP_STATE.simulation.activeBlastRow||1}. Data mengikuti template handak.`;refreshAll();}catch(_e){}}
  })();
  /* FIX v10: later <script> patches reference these as bare globals but they live inside this IIFE (ReferenceError otherwise) */
  try{ window.__kbP02={fitRR,psdQuantile,psdQuantileLegacyFloor,splitPolygonByLine,applySplit,applyMerge,applySizeOverride,clearSizeOverride,approveEstimates,measurePolygon,validateFragmentGeometry,recomputePSD,buildPSDCsv,buildFragmentCsv,exportBridgeText,buildExecutiveReportHtml,splitClick}; }catch(_e){} try{ const X={scanActualPhoto,startTrace,cancelTrace,atStart,atStop,toggleDeleteMode,deleteSelectedBatch,clearSelection,syncSelectionState,showScanComplete}; Object.keys(X).forEach(k=>{ if(typeof X[k]==='function') window[k]=X[k]; }); }catch(_e){ console.error('photo API export failed',_e); }
  /* Expose test entry-points for headless/browser console validation */
  try{ window.runTests=runTests; }catch(_e){} try{ window.__kbRoi={roiRasterize,roiMaskCount,roiFilterByCenter,roiGetMask,roiStart,roiFinish,roiCancel,roiClear}; }catch(_e){}
  try{ window.runPhase0Tests=runPhase0Tests; }catch(_e){}
})();
