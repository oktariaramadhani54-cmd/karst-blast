/* KarstBlast — patches.js
   Skrip tambahan (patch UI/behavior) dari file monolit asli, urutan eksekusi TIDAK diubah.
   Masing-masing dibungkus try/catch agar satu patch yang error tidak menghentikan patch berikutnya
   (perilaku isolasi yang sama dengan <script> terpisah di file asli). */

/* ===== PATCH [tanpa-id]  (asal: baris 7845) ===== */
try{
(function(){
  function arrangeDesignWorkspace(){
    try{
      const panel=document.getElementById('geometryComparePanel');
      const main=document.querySelector('#view-design > .kb-grid > main.kb-stack');
      if(panel && main && panel.parentElement!==main){
        const blast=document.getElementById('blastPlanPanel');
        main.insertBefore(panel, blast || main.firstElementChild || null);
      }
    }catch(e){}
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',arrangeDesignWorkspace,{once:true});
  else arrangeDesignWorkspace();
})();
}catch(e){console.error("[KarstBlast patch 7845]",e);}

/* ===== PATCH [kb-final-behavior-fix]  (asal: baris 7912) ===== */
try{
(function(){
  function $(id){return document.getElementById(id)}
  const qcp=$('manualQcPanel'),toggle=$('btnToggleManualQC'),focus=$('btnFocusActualPhoto'),photoPanel=document.querySelector('#view-image .kb-canvas-wrap');
  if(qcp&&toggle){
    toggle.addEventListener('click',()=>{
      const collapsed=qcp.classList.toggle('is-collapsed');
      toggle.setAttribute('aria-expanded',String(!collapsed));
      toggle.textContent=collapsed?'＋ TAMPILKAN':'− RINGKAS';
    });
  }
  if(focus){focus.addEventListener('click',()=>{
    const target=document.getElementById('muckpileCanvas')?.closest('.kb-panel')||photoPanel;
    if(target){target.scrollIntoView({behavior:'smooth',block:'center'});setTimeout(()=>{try{document.getElementById('muckpileCanvas')?.focus({preventScroll:true})}catch(_e){}},450)}
  });}
  /* FIX v11: scroll-ke-plan setelah screening sukses dipindah ke screeningRunFromButton() (tanpa race 60 ms). */
})();
}catch(e){console.error("[KarstBlast patch kb-final-behavior-fix]",e);}

/* ===== PATCH [kb-manualqc-scroll-behavior]  (asal: baris 7931) ===== */
try{
(function(){
  function init(){
    const qcp=document.getElementById('manualQcPanel');
    const view=document.getElementById('view-image');
    if(!qcp||!view)return;
    let lastY=window.scrollY||window.pageYOffset||0;
    let ticking=false;
    let docked=false;

    function release(){
      if(!docked)return;
      docked=false;
      qcp.classList.remove('is-scroll-near-photo');
      qcp.removeAttribute('data-scroll-docked');
    }

    function update(){
      ticking=false;
      const y=window.scrollY||window.pageYOffset||0;
      const delta=y-lastY;
      const dir=delta < -2 ? 'up' : delta > 2 ? 'down' : 'still';
      const rect=qcp.getBoundingClientRect();
      const viewActive=view.classList.contains('active');
      const desktop=window.innerWidth>1100;

      if(!viewActive||!desktop){
        release();
        lastY=y;
        return;
      }

      // Activate only when the Manual QC card is entering the upper viewport while
      // moving upward. This makes it feel magnetized toward the photo without
      // permanently changing the document flow.
      const entering=rect.top < 170 && rect.bottom > 80;
      if(dir==='up' && entering){
        if(!docked){
          docked=true;
          qcp.classList.add('is-scroll-near-photo');
          qcp.setAttribute('data-scroll-docked','true');
        }
      }else if(dir==='down'){
        release();
      }
      lastY=y;
    }

    function onScroll(){
      if(ticking)return;
      ticking=true;
      requestAnimationFrame(update);
    }
    window.addEventListener('scroll',onScroll,{passive:true});
    window.addEventListener('resize',onScroll,{passive:true});
    document.querySelectorAll('.kb-tab[data-view="image"]').forEach(btn=>btn.addEventListener('click',()=>{release();requestAnimationFrame(update);}));
    update();
  }
  window.__kbPhotoApi={
    scanActualPhoto, startTrace, cancelTrace, atStart, atStop,
    toggleDeleteMode, deleteSelectedBatch, clearSelection, syncSelectionState,
    showScanComplete
  };

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();
}catch(e){console.error("[KarstBlast patch kb-manualqc-scroll-behavior]",e);}

/* ===== PATCH [kb-flyrock-radar-patch]  (asal: baris 8000) ===== */
try{
/* Engine tambahan: kalkulasi Flyrock (Lundborg) + PPV real-time dan update
   indikator radar (#radarFlyrock / #radarPpv) setiap simulasi dijalankan. */
(function(){
  const $=id=>document.getElementById(id);
  const num=v=>{const n=Number(v);return Number.isFinite(n)?n:null;};
  const fmt=(x,d)=>x==null?'--':Number(x).toFixed(d);
  function state(){ return (typeof APP_STATE!=='undefined'&&APP_STATE&&APP_STATE.simulation)?APP_STATE:null; }
  function computeFlyrock(){
    const st=state(); if(!st) return null;
    const p=st.simulation.parameters||{};
    const B=num(p.burdenM)||num($('geoB')&&$('geoB').value)||2.5;
    let Din=num(st.geometry&&st.geometry.input&&st.geometry.input.diameterIn);
    if(!Din){const el=$('cmpDiameterIn'); if(el) Din=num(el.value);}
    if(!Din) Din=3.0; // fallback 3 in (~76 mm) bila diameter belum di-set
    return 15.6*Math.pow(Din*25.4,0.6)/Math.sqrt(B); // Lundborg empirical model
  }
  function computePPV(){
    const st=state(); if(!st) return null;
    if(st.seismic&&Number.isFinite(st.seismic.ppv)) return st.seismic.ppv;
    const p=st.simulation.parameters||{};
    const W=(num(p.anPerHoleKg)||0)+(num(p.dnPerHoleKg)||0)||1; // kg per delay (per hole)
    const SD=150/Math.sqrt(W); // PPV @ 150 m
    return 1140*Math.pow(SD,-1.6); // K=1140, n=1.6
  }
  function updateRadar(){
    if(!state()) return;
    /* FIX v11: bila screening tidak terhitung, jangan tampilkan angka radar dari konstanta fallback */
    if(window.__kbScreeningOK===false){
      ['radarFlyrock','radarPpv'].forEach(id=>{const e=$(id); if(e) e.classList.remove('is-danger');});
      if($('radarFlyrockValue')) $('radarFlyrockValue').textContent='--';
      if($('radarPpvValue')) $('radarPpvValue').textContent='--';
      if($('radarFlyrockStatus')) $('radarFlyrockStatus').textContent='SCREENING BELUM TERHITUNG';
      if($('radarPpvStatus')) $('radarPpvStatus').textContent='SCREENING BELUM TERHITUNG';
      return;
    }
    const fly=computeFlyrock(), ppv=computePPV();
    if(APP_STATE.simulation.result) APP_STATE.simulation.result.flyrock=fly;
    const fr=$('radarFlyrock'), pv=$('radarPpv');
    if(fr&&fly!=null){
      fr.classList.toggle('is-danger',fly>200);
      $('radarFlyrockValue').textContent=fmt(fly,0);
      $('radarFlyrockStatus').textContent=fly>200?'DANGER > 200 m':'SAFE';
    }
    if(pv&&ppv!=null){
      pv.classList.toggle('is-danger',ppv>5);
      $('radarPpvValue').textContent=fmt(ppv,2);
      $('radarPpvStatus').textContent=ppv>5?'DANGER > 5 mm/s':'SAFE';
    }
  }
  const btn=$('detonateBtn');
  if(btn) btn.addEventListener('click',()=>setTimeout(updateRadar,80));
})();
}catch(e){console.error("[KarstBlast patch kb-flyrock-radar-patch]",e);}

/* ===== PATCH [kb-photo-workspace-runtime-v2]  (asal: baris 8057) ===== */
try{
(function(){
  function $(id){return document.getElementById(id)}
  function relocateScanPanel(){
    const view=$('view-image'),seg=$('segmentationControlPanel');
    const main=view?.querySelector(':scope > .kb-grid > main.kb-stack');
    const photo=main?.querySelector(':scope > .kb-panel');
    if(seg&&main&&photo&&seg.parentElement!==main){
      main.insertBefore(seg,photo.nextElementSibling);
      seg.classList.add('kb-photo-scan-dock');
    }
  }
  function bindQuickTools(){
    $('btnQuickScan')?.addEventListener('click',()=>window.__kbPhotoApi?.scanActualPhoto?.());
    $('btnQuickRescan')?.addEventListener('click',()=>window.__kbPhotoApi?.scanActualPhoto?.());
    $('btnQuickTrace')?.addEventListener('click',()=>{
      if(APP_STATE.image.manualMode==='trace') window.__kbPhotoApi?.cancelTrace?.();
      else window.__kbPhotoApi?.startTrace?.();
      syncSelectionState();
    });
    $('btnQuickAutoTrace')?.addEventListener('click',()=>{
      if(APP_STATE.image.manualMode==='autotrace') window.__kbPhotoApi?.atStop?.(); else window.__kbPhotoApi?.atStart?.();
      syncSelectionState();
    });
    $('btnDeleteMode')?.addEventListener('click',()=>window.__kbPhotoApi?.toggleDeleteMode?.());
    $('btnDeleteSelected')?.addEventListener('click',()=>window.__kbPhotoApi?.deleteSelectedBatch?.());
    $('btnClearSelection')?.addEventListener('click',()=>window.__kbPhotoApi?.clearSelection?.());
    $('btnScanTraceRock')?.addEventListener('click',()=>window.__kbPhotoApi?.startTrace?.());
    $('btnScanAutoTraceRock')?.addEventListener('click',()=>{ if(APP_STATE.image.manualMode==='autotrace')window.__kbPhotoApi?.atStop?.(); else window.__kbPhotoApi?.atStart?.(); });
  }
  relocateScanPanel();
  bindQuickTools();
  setTimeout(relocateScanPanel,0);
  syncSelectionState();
  window.__photoUiuxV2={relocateScanPanel,bindQuickTools};
})();
}catch(e){console.error("[KarstBlast patch kb-photo-workspace-runtime-v2]",e);}

/* ===== PATCH [kb-redsun-nav]  (asal: baris 8298) ===== */
try{
(function(){var t=document.querySelector('.kb-tabs'),h=document.querySelector('header.app-header');
if(t&&h&&h.parentNode){h.parentNode.insertBefore(t,h)}
document.addEventListener('click',function(e){var g=e.target.closest('[data-goto]');if(!g)return;
var tab=document.querySelector('.kb-tab[data-view="'+g.getAttribute('data-goto')+'"]');if(tab){tab.click();
var a=document.querySelector('.kb-toolbar');if(a)window.scrollTo({top:a.getBoundingClientRect().top+scrollY-70,behavior:'smooth'})}})})();
}catch(e){console.error("[KarstBlast patch kb-redsun-nav]",e);}

/* ===== PATCH [kb-boom]  (asal: baris 8306) ===== */
try{
(function(){var h=document.querySelector('header.app-header');if(!h)return;
var C=['#f7f9f9','#c4cfd4','#8b9ba4','#5a6c76','#33454f'];
function build(){var b=document.createElement('div');b.className='kb-boom';b.setAttribute('aria-hidden','true');var H='<b></b><s></s>';
for(var i=0;i<34;i++){var k=i%4===0,a=(-170+Math.random()*160)*Math.PI/180,d=(k?260:140)+Math.random()*(k?420:300),x=Math.cos(a)*d*1.25,y=Math.sin(a)*d,s=k?3+Math.random()*3:6+Math.random()*13;
H+='<i class="'+(k?'k':'')+'" style="--x:'+x.toFixed(0)+'px;--y:'+y.toFixed(0)+'px;--r:'+((Math.random()-.5)*900).toFixed(0)+'deg;--s:'+s.toFixed(1)+'px;--c:'+(k?'#ffb340':C[i%5])+';--t:'+(1.1+Math.random()*.9).toFixed(2)+'s;--d:'+(.28+Math.random()*.12).toFixed(2)+'s"></i>';}
[-240,-80,90,250].forEach(function(x,i){H+='<u style="--x:'+x+'px;--d:'+(.35+i*.06).toFixed(2)+'s"></u>';});b.innerHTML=H;return b;}
function boom(){var o=h.querySelector('.kb-boom');if(o)o.remove();h.classList.remove('is-boom');void h.offsetWidth;h.appendChild(build());h.classList.add('is-boom');}
boom();
var vis=true;if('IntersectionObserver' in window)new IntersectionObserver(function(e){vis=e[0].isIntersecting;}).observe(h);
if(!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches))setInterval(function(){if(vis&&!document.hidden)boom();},6000);
h.addEventListener('click',function(e){if(!e.target.closest('button,a,input,select,textarea,label'))boom();});})();
}catch(e){console.error("[KarstBlast patch kb-boom]",e);}

/* ===== PATCH [kb-run-screening-feedback-runtime]  (asal: baris 8336) ===== */
try{
(function(){
  'use strict';
  /* FIX v11: umpan balik palsu berbasis timer 900 ms untuk btnRunScreening dihapus; status nyata ditangani screeningRunFromButton(). */
  const detonate=document.getElementById('detonateBtn');
  if(detonate){
    detonate.addEventListener('click',function(){
      detonate.classList.remove('kb-press-feedback');
      void detonate.offsetWidth;
      detonate.classList.add('kb-press-feedback');
      setTimeout(()=>detonate.classList.remove('kb-press-feedback'),320);
    },true);
  }
})();
}catch(e){console.error("[KarstBlast patch kb-run-screening-feedback-runtime]",e);}

/* V11: cermin status sidebar dari badge nyata aplikasi (tanpa nilai buatan). */
(function(){
  var map=[['projectBadge','kbSideProject'],['sourceBadge','kbSideSource'],['gsSummaryStatus','kbSideSheets']];
  function sync(){map.forEach(function(m){var a=document.getElementById(m[0]),b=document.getElementById(m[1]);if(a&&b){var t=(a.textContent||'').replace(/^PROJECT:\s*/i,'').replace(/^LAB BASELINE[:\s•]*/i,'').trim();b.textContent=t||'—';}});}
  function init(){sync();map.forEach(function(m){var a=document.getElementById(m[0]);if(a&&window.MutationObserver)new MutationObserver(sync).observe(a,{childList:true,characterData:true,subtree:true});});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

/* V11: kontrol animasi simulasi (WAAPI + timer yang dapat dijeda). Status mengikuti kondisi sebenarnya. */
(function(){
  function init(){
    var svg=document.getElementById('simSvg'),$=function(i){return document.getElementById(i)};
    if(!svg||!$('kbSimBar'))return;
    var st=$('kbSimStatus'),fill=$('kbSimFill'),time=$('kbSimTime'),bPlay=$('kbSimPlay'),bPause=$('kbSimPause'),bRe=$('kbSimReplay'),bRs=$('kbSimReset'),det=$('detonateBtn'),rst=$('resetSimBtn');
    var paused=false,seen=false,maxT=0;
    function anims(){return document.getAnimations().filter(function(a){var t=a.effect&&a.effect.target;return t&&svg.contains(t);});}
    function setStatus(txt,cls){st.textContent=txt;st.className='kb-badge '+(cls||'');}
    function tick(){
      var A=anims(),busy=det&&det.classList.contains('kb-sim-running'),notif=$('simNotif'),txt=($('simNotifText')||{}).textContent||'';
      var err=notif&&/is-visible/.test(notif.className)&&/DIBLOKIR|GAGAL/.test(txt);
      if(busy||A.length)seen=true;
      var cur=0,end=0;A.forEach(function(a){var ct=Number(a.currentTime)||0,e=a.effect.getComputedTiming().endTime;cur=Math.max(cur,ct);end=Math.max(end,Number.isFinite(e)?e:0);});
      if(end>maxT)maxT=end;
      if(err&&!busy)setStatus('ERROR','warn');
      else if(paused&&busy)setStatus('PAUSED','warn');
      else if(busy)setStatus('RUNNING','ok');
      else if(seen){setStatus('COMPLETED','ok');if(!A.length)cur=maxT;}
      else setStatus('READY','');
      fill.style.width=(maxT>0?Math.min(100,cur/maxT*100):0)+'%';
      time.textContent='t = '+Math.round(cur)+' ms'+(maxT>0?' / '+Math.round(maxT)+' ms':'');
      bPause.disabled=!(busy&&!paused);bPlay.disabled=busy&&!paused;
      requestAnimationFrame(tick);
    }
    function pause(){if(!(det&&det.classList.contains('kb-sim-running')))return;paused=true;anims().forEach(function(a){a.pause();});if(window.KBSim)window.KBSim.pause();}
    function resume(){paused=false;anims().forEach(function(a){a.play();});if(window.KBSim)window.KBSim.resume();}
    function start(){if(det&&!det.disabled)det.click();}
    bPause.addEventListener('click',pause);
    bPlay.addEventListener('click',function(){if(paused&&det.classList.contains('kb-sim-running'))resume();else start();});
    bRe.addEventListener('click',function(){paused=false;if(rst)rst.click();setTimeout(start,60);});
    bRs.addEventListener('click',function(){paused=false;if(rst)rst.click();});
    if(rst)rst.addEventListener('click',function(){paused=false;seen=false;maxT=0;});
    requestAnimationFrame(tick);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
