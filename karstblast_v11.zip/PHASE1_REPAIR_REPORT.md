# Laporan Audit dan Perbaikan Tahap 1 — KarstBlast

**Tanggal:** 19 Oktober 2026  
**Kesimpulan:** perbaikan kontrol Tahap 1 yang diminta sudah diterapkan pada project aktual dan jalur utama yang disebutkan telah diuji. Ini bukan sertifikasi penuh atau bukti siap-produksi; batas uji dicatat di `PHASE1_TEST_RESULTS.md`.

## Temuan, perubahan, dan bukti

| Area | Kondisi saat diaudit | Perbaikan Tahap 1 | Verifikasi aktual |
|---|---|---|---|
| Modal impor | Panel lama tidak memberi alur modal khusus; preview inline | Modal impor CSV/XLSX dengan buka, tutup, Escape, backdrop, preview, validasi, dan status | Lulus di Chromium; open/close/reopen dan Escape diuji |
| Mapping kolom | Pemetaan otomatis; kolom tak dikenal tidak bisa dipetakan manual | Kontrol map field dan jenis Rencana/Aktual; perubahan memicu validasi ulang file yang sama | CSV fixture; `Bench H` dipetakan ke `depth`, tampil di preview dan masuk ke blok |
| CSV/XLSX | Pengujian file belum termasuk laporan lama | Stage → preview → apply; data masuk ke blok manual, template sumber tidak ditimpa | CSV dan XLSX masing-masing 2 row; lulus |
| Input manual blast | Handler buat blok/baris sudah tersedia | Dipertahankan dan diverifikasi | Buat blok kosong + tambah baris; lulus |
| Penghapusan data | `KOSONGKAN AKTUAL` memakai konfirmasi dua klik; belum ada kontrol hapus blok manual | Clear Actual dipertahankan; tambah HAPUS BLOK MANUAL dengan konfirmasi dan pembersihan record/override/Wipfrag | Kedua jalur lulus; template `group1` tetap tersedia |
| Mode Kuz–Ram | Tombol mode dan Run terhubung ke handler | Tidak mengganti rumus; cek wiring dan keluaran | EXCEL ↔ KOREKSI dan Run menghasilkan KPI; lulus |
| Pemilihan blast/row | Select row dan Load sudah tersedia | Dipertahankan | Row 2 memperbarui state aktif; lulus |
| Kalibrasi | POINT A/B/CANCEL berupa `<span role="status">`, tidak bisa ditekan seperti kontrol | Kembali menjadi tombol aktif, `aria-pressed` disinkronkan, Clear Points mengembalikan POINT A | Upload fixture gambar, dua titik, Apply Scale menghasilkan skala positif; lulus |
| Screening | Handler tersedia, namun perlu dibuktikan sampai status dan output | Tidak mengubah perhitungan; verifikasi transisi busy/status/output | `CALCULATED`, skor hasil tampil, tombol kembali aktif; lulus |
| Simulasi | Handler tersedia, namun perlu dibuktikan saat tombol ditekan | Tidak mengubah persamaan; verifikasi run/feedback | Animasi mulai dan status `SIMULASI BERJALAN`; lulus |
| Event listener/state/ID | Risiko UI-state tidak sinkron, serta ID vendor dinamis | Modal listener terhubung pada init data; mapping tidak kehilangan override saat parse ulang; audit ID setelah mutasi | Tidak ada error JS. 0 duplikat ID milik aplikasi. ID `symbol` ganda berasal dari ikon SVG Plotly dan merupakan pengecualian vendor yang diketahui |

## Hasil aktual

- Built-in tests: **322/322 PASS** (lihat catatan koreksi jumlah di bawah).
- Browser interaction suite: jalur interaksinya diverifikasi ulang lewat event DOM asli di Chromium; runner Python/Playwright lama tidak dapat dijalankan di environment ini.
- `node --check`: `js/app.js`, `js/patches.js`, `js/a11y.js` semuanya PASS.
- Tab Design, Simulator, Report, Image, dan Audit dibuka pada Chromium tanpa uncaught browser error.
- Konsol bersih: 0 error, 0 warning (sebelumnya 18 warning karena `value="--"` pada input metrik rencana).

## Putaran hardening akhir Tahap 1

Angka lama "332/332" tidak dapat direproduksi dari `js/app.js` project ini; suite berisi 313 assertion sebelum hardening dan 322 sesudah. Laporan memakai hasil run nyata.

| Temuan saat audit | Perbaikan | Verifikasi |
|---|---|---|
| Panel "Daftar Blast Proyek & Pemetaan Geometri" tampil aktif tetapi tidak dipakai sama sekali (mesin `PROJECT-BLASTS-ENGINE` tanpa konsumen) | Isi tabel diganti keterangan `MODE SATU BARIS AKTIF — perhitungan multi-blast belum aktif` dan teks section menyebutkan Group/Row bagian 1 sebagai satu-satunya sumber blast; `projectBlasts` yang tersimpan disanitasi (`sanitizeProjectBlasts`) dan dipaksa `runMode:'single'` | Lulus; assertion baru memeriksa tabel, sanitasi payload, dan fallback |
| Payload lama bertemplate `'custom'` membuat `#blastRowSelect` kosong dan blast aktif menggantung | Boot menormalkan template (selesai via `groupLabel`, lalu `group1`, lalu grup pertama), memperbaiki `groupLabel` yang menggantung, dan menjepit `activeBlastRow` ke baris yang ada; `planToSim()` memanggil `populateBlastRowSelect()` | Reload payload legacy → dropdown terisi, baris aktif valid |
| Badge screening tetap `CALCULATED` setelah baris blast/parameter/rencana diubah (hasil basi terlihat hidup) | `markScreeningStale(reason)` dipasang pada `loadBlastSheetRow`, `editActiveBlastRowField`, `autoRecalcActiveBlastRow`, dan input simulator: badge → `STALE • HITUNG ULANG`, catatan diperbarui, radar flyrock/PPV menjadi `--` dengan status `SCREENING BELUM TERHITUNG` | Ganti Row 1 → 2 menghasilkan STALE + radar kosong; kembali setelah RUN SCREENING |
| Field rencana kosong menampilkan `0`/`NaN` | `simHydrate` menulis string kosong untuk nilai kosong (`num()` menolak non-finfinite) | Panel Blank → input kosong, bukan `0` |
| Tidak ada kontrol hapus baris manual (hanya hapus blok) | `deleteManualBlastRow()` + tombol `HAPUS BARIS MANUAL`: hanya blok manual, menolak baris terakhir, konfirmasi, dan ikut membersihkan `actualRecord`, `rowOverrides`, `wipBy` baris itu | Lulus lewat UI; baris bawaan ditolak |
| Input metrik rencana memakai `value="--"` (18 warning konsol, dan nilai itu bisa terbaca sebagai data) | Diganti `placeholder="--"` (CSS sudah menata placeholder) | Konsol 0 warning |
| Wiring simulator menyimpan template palsu saat input diubah | Handler input simulator tidak lagi menulis `'CUSTOM / MANUAL'` ke `#simTemplate` selain label grup aktif yang benar | Lulus; assertion "no bogus template key" |
| Suite bawaan gagal bila pengguna punya data aktual/override nyata (315/322) — tes mengasumsikan baris rencana murni | Isolasi tes: `runStage3Tests` dan `runStage4Tests` menetralkan `actualRecord` + `rowOverrides` di awal (blok `finally` yang sudah ada mengembalikan data pengguna), dan tes ukuran fisik PSD mengunci `sizeDefinition='feret'` lalu memulihkannya | 322/322 pada state bersih **dan** pada state berisi data nyata; working copy tetap identik sebelum/sesudah menekan tombol tes |

## Tidak diubah

- Tidak ada perubahan pada rumus teknik Kuz–Ram, Ash, Konya, MAE, atau persamaan simulator.
- Tidak dilakukan redesign besar. Perubahan UI dibatasi pada modal impor/mapping, kontrol kalibrasi, dan hapus blok manual.

## Batas yang masih harus ditandai

- **Multi-blast belum diimplementasikan.** `BLAST TERPILIH`, `RATA-RATA TERBOBOT`, dan `BATCH` tidak punya jalur ke perhitungan. Mesinnya ada (`computeWeightedAverageBlast`, `parsePastedBlastTable`) dengan 10 blast contoh `isExample`, tetapi nol konsumen; menghubungkannya membutuhkan perubahan arsitektur sumber data blast (Tahap 2). Yang dilakukan Tahap 1 hanya membuat UI menyatakan kondisi sebenarnya, tanpa mengarang data.
- **Header CSV/XLSX tertentu butuh mapping manual:** `Hole`, `AN/hole`, `DN/hole` tidak termasuk alias otomatis dan harus dipetakan di modal impor.
- **Screening sengaja tetap STALE** sampai `RUN SCREENING` ditekan; aplikasi tidak menghitung ulang otomatis setelah perubahan blast/parameter.
- ~~Persistensi setelah reload penuh belum diverifikasi~~ — **sudah disertifikasi** pada origin HTTP nyata dengan storage asli browser (tanpa shim); lihat `PHASE1_QA_REPORT.md`. Foto, hasil kalibrasi, fragmen, dan PSD turunan memang hanya bertahan satu sesi sesuai desain; yang bertahan adalah pengaturan, data aktual, override, dan parameter.
- Pengujian memakai fixture sintetik, bukan CSV/XLSX atau foto lapangan pengguna. Harness Python/Playwright (`qa/runtime_audit.py`, `qa/run_phase1_targeted_audit.py`, `qa/cr-kb-004.spec.mjs`) belum dijalankan ulang karena Python dan Playwright tidak tersedia di environment ini.
- Screening dan animasi hanya diuji sebagai kontrol/alur aplikasi, bukan sebagai penilaian kelayakan teknis atau izin peledakan.
