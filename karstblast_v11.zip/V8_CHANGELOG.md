# V8 — 25 Okt 2026
- Baru: `flatFrac` / UI "Buang lantai/pasir polos otomatis" (default 0.5). Area dengan energi tepi rendah (lantai pasir polos) dikeluarkan sebelum segmentasi, jadi tidak jadi "fragmen" raksasa walau ROI belum digambar.
- Diukur TANPA ROI di 6 foto vs outline WipFrag: luas fragmen di luar area WipFrag 36% -> 21%; mean|D80| 45% -> 36%; EE-4 62% -> 31%. mean|D50| tidak membaik (23% -> 24%).
- Sebagian "kebocoran" tersisa memang batu di luar area yang dioutline operator (mis. lereng atas), bukan selalu salah.
- Tetap berlaku: V5 tidak menyamai net WipFrag manual (IoU ~0.33). Pakai ROI poligon + rapikan manual. Test suite browser belum dijalankan ulang.

## Presentation correction — restore opening blast animation
- Restored the original V8 HTML and CSS so the animated blast/boom hero, original brand treatment, and existing page motion remain intact.
- Kept only a targeted responsive layout change: the geometry comparison panel spans the full workspace width on desktop, removing the empty left area below the input column.
- No application JavaScript or calculation logic changed.
