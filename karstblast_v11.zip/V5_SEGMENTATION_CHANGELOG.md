# Perubahan segmentasi foto (V5) — 25 Okt 2026

## Masalah (terukur, foto HH-8, dibanding outline WipFrag)
- Engine lama memakai threshold terang/gelap. Pada batu berwarna pasir, langit, tanggul, dan lantai pasir punya kecerahan sama dengan batu,
  sehingga jadi "fragmen" raksasa. Error D50 berbasis luas: **+328%**, D80: **+266%**.
- X50/X80 dihitung berdasarkan JUMLAH fragmen (setiap fragmen bernilai 1), sedangkan WipFrag berbasis luas. Ratusan serpihan kecil menarik D50 ke bawah.
- Poligon di canvas "Hasil segmentasi" digambar dari piksel tepi urutan raster, sehingga muncul garis zig-zag panjang.

## Perbaikan (`js/app.js`, `index.html`)
1. `segmentRocksV5`: peta edge + lembah gelap yang dinormalisasi pencahayaan -> watershed bermarker -> merge region (batas terlemah dulu,
   dibatasi ukuran dan elongasi supaya tidak menggumpal). Langit otomatis dikeluarkan. Engine lama tetap ada (pilihan LEGACY).
2. Kontrol baru: pilihan engine, batas atas/bawah area analisis (% tinggi foto).
3. D50/D80 **berbasis luas (ala WipFrag)** ditambahkan; D50/D80 berbasis jumlah tetap ditampilkan.
4. Outline gambar memakai kontur berurutan (`rkTraceOutline`); metrik tetap dari piksel, tidak berubah.

## Hasil di app asli (foto uji, fragmen di dalam area yang di-outline WipFrag)
| | eq D50 | eq D80 | Feret D50 | Feret D80 |
|---|---|---|---|---|
| Lama | +328% | +266% | +422% | +279% |
| V5   | 0% | +4% | +6% | +20% |
Tanpa membatasi area (seluruh foto termasuk pasir depan & tanggul): V5 +21% / +39% (eq D50 / D80).

## Batasan
Dikalibrasi dan diuji pada SATU foto. Pembanding berasal dari outline WipFrag di screenshot, bukan angka D50/D80 WipFrag.
Test suite bawaan: 350/354 sebelum dan sesudah perubahan (hasil identik).
