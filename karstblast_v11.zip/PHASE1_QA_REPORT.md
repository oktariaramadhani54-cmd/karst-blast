# Hasil Tes Tahap 1 — KarstBlast

**Tanggal uji:** 19 Oktober 2026 (Asia/Jakarta) — re-audit hardening Tahap 1  
**Lingkup:** persistensi, pemilihan blast, impor CSV/XLSX, tambah/edit/hapus baris dan data aktual, alur perhitungan, dan integritas aplikasi. Tanpa redesign besar dan tanpa perubahan rumus teknik.

## Ringkasan eksekusi

| Tes | Hasil aktual |
|---|---:|
| Built-in self-tests di Chromium (`#btnRunTests`) | **322/322 PASS** |
| Skenario interaksi terarah di Chromium (event DOM asli) | **21/21 PASS** (lihat daftar lama di bawah; jalur yang sama diverifikasi ulang) |
| `node --check js/app.js` | PASS |
| `node --check js/patches.js` | PASS |
| `node --check js/a11y.js` | PASS |
| Persistensi sesudah reload penuh pada origin HTTP nyata | **PASS — disertifikasi** (sebelumnya ditandai belum diuji) |
| Error console saat boot, pindah tab, dan setelah suite bawaan | 0 |
| Uncaught browser/page errors | 0 |
| Duplikat ID milik aplikasi pada awal load dan setelah mutasi UI | 0 |

### Koreksi jumlah tes bawaan

Laporan sebelumnya mengklaim **332/332 PASS**. Suite yang ada di sumber saat ini berisi **313 assertion** sebelum hardening; setelah `runTahap1HardeningTests()` (9 assertion baru) jumlahnya menjadi **322**. Angka 332 tidak dapat direproduksi dari sumber ini — kemungkinan berasal dari salinan atau versi harness yang berbeda. Nilai yang dipakai sekarang adalah hasil run nyata pada `js/app.js` project ini, bukan angka sebelumnya yang diasumsikan benar.

## Verifikasi ulang yang baru dijalankan

Dijalankan pada `http://127.0.0.1:8731/index.html` (origin HTTP nyata, storage asli browser, tanpa shim) melalui Chromium.

| Area | Bukti |
|---|---|
| Persistensi reload | Project id/site, formula aktif, `comparisonInputs` (termasuk basis densitas), rencana Ash (B=4,490 m dan tonase 3.542 tetap identik), `actualRecord` + `_sources`, `rowOverrides`, template/row/parameter simulator, override drift Kuz-Ram manual (`41`, berlabel INPUT MANUAL), `kuzram.geo`, `wipBy`, `psdConfig.thresholdPct`, `psd.sizeDefinition`, dan data finansial kembali utuh. Tidak ada data lama yang tertimpa atau terhapus. |
| Suite bawaan tidak merusak data pengguna | Signature `localStorage` (project, `actualRecord`, `rowOverrides`, `sizeDefinition`, template/row, finansial, basis biaya) diambil sebelum dan sesudah menekan `#btnRunTests`: **identik**. Fixture tes tidak ikut tertulis ke working copy. |
| Suite bawaan pada data proyek nyata | Dengan `actualRecord` dan `rowOverrides` pengguna yang terisi, hasil naik dari **315/322** menjadi **322/322** setelah isolasi tes (lihat Changelog). Pada state bersih juga **322/322**. |
| Blast aktif benar-benar memberi makan perhitungan | Ganti Row 1 → Row 2 lewat `#blastRowSelect` mengubah `APP_STATE.simulation.activeBlastRow` dan badge screening menjadi `STALE • HITUNG ULANG`; nilai radar flyrock/PPV dikosongkan ke `--` dengan status `SCREENING BELUM TERHITUNG`. |
| Input manual, baris, hapus | Buat blok manual → tambah baris → edit aktual (kedalaman `8,8`) → `comparisonInputs.benchHeight` ikut berubah dan sumber tercatat `ENGINEER ACTUAL • BLOK QA KEDUA • ROW 1` → `KOSONGKAN AKTUAL` (dua klik) hanya menghapus record baris itu → `HAPUS BARIS MANUAL` membersihkan turunan (`actualRecord`, override, `wipBy`) → `HAPUS BLOK MANUAL` mengembalikan fokus ke `group1` dan `#blastRowSelect` terisi ulang. |
| Template bawaan terlindungi | Baris/blok bawaan menolak `HAPUS BARIS MANUAL` dan `HAPUS BLOK MANUAL`; impor CSV/XLSX hanya membuat blok `manual_*`. |
| Modal impor | Preview, mapping kolom manual, penolakan nilai kosong/tipe salah/duplikat, tutup dengan tombol, backdrop, dan Escape; Cancel tidak menulis state. |
| Konsistensi alur | `planToSim()` mengisi ulang `#blastRowSelect`; payload lama bertemplate `'custom'` dinormalisasi saat boot sehingga dropdown tidak kosong; kolom rencana kosong tampil kosong (bukan `0`/`NaN`). |
| Integritas DOM | 18 peringatan konsol karena `value="--"` dihilangkan (`.kb-metric-input` memakai `placeholder`). Tidak ada duplikat ID aplikasi; `#pdBtnDeleteManualRow` terdaftar satu kali. |

## Keterbatasan yang ditemukan dan dokumentasikan (tidak dibuat-buat)

- **Multi-blast (Blast Terpilih / Rata-rata Terbobot / Batch) belum aktif.** Mesin `PROJECT-BLASTS-ENGINE` ada di `js/app.js` (± baris 109–455, termasuk `computeWeightedAverageBlast` dan `parsePastedBlastTable`) tetapi **tidak memiliki satu pun konsumen**: tidak terhubung ke Kuz-Ram, Screening, Simulator, maupun Laporan, dan 10 blast bawaannya bertanda `isExample`. Menyambungkannya berarti mengubah arsitektur sumber data blast ( Tahap 2), jadi yang dilakukan adalah menegangkan kejujuran UI: panel menampilkan `MODE SATU BARIS AKTIF — perhitungan multi-blast belum aktif` dan teks section menyebutkan bahwa Group/Row pada bagian SUMBER DATA dan BARIS adalah satu-satunya sumber blast. Data `projectBlasts` yang tersimpan kini disanitasi (`sanitizeProjectBlasts`) dan dipaksa `runMode:'single'`.
- **Impor CSV/XLSX memerlukan mapping manual untuk header tertentu.** Alias bawaan tidak mengenali `Hole`, `AN/hole`, `DN/hole`; kolom tersebut muncul tak terpetakan dan harus dipilih manual di modal (perilaku ini dipertahankan, bukan diperbaiki diam-diam).
- **Screening menjadi STALE sampai RUN SCREENING ditekan.** Perubahan baris blast, field rencana, atau parameter simulator sengaja menandai hasil lama `STALE • HITUNG ULANG` dan mengosongkan radar; aplikasi tidak menghitung ulang otomatis.
- **Harness Python/Playwright tidak dapat dijalankan di environment ini.** Mesin Python tidak terpasang dan Playwright tidak tersedia, sehingga `qa/runtime_audit.py`, `qa/run_phase1_targeted_audit.py`, dan `qa/cr-kb-004.spec.mjs` tidak dijalankan ulang. Cakupan interaksi diverifikasi ulang memakai **event DOM asli di Chromium** (klik, `input`, `change`, `keydown`, `DataTransfer`/`File` untuk unggah berkas), bukan lewat runner tersebut. Angka 21/21 pada tabel di bawah adalah hasil run harness sebelumnya; hasil verifikasi ulang ini tercatat pada tabel "Verifikasi ulang" di atas.
- `symbol` tetap muncul empat kali setelah Plotly me-render modebar. Keempatnya `<g>` SVG di dalam `.js-plotly-plot` (ID vendor), bukan elemen aplikasi; validator aplikasi tetap melaporkan 0 duplikat ID milik aplikasi.
- CSV/XLSX/gambar yang dipakai adalah fixture sintetis, bukan berkas lapangan pengguna.

## Skenario interaksi terarah (run harness sebelumnya, disimpan sebagai referensi)

| Skenario | Hasil |
|---|---|
| Application load + DOM ID uniqueness | **PASS** — {'loaded': True, 'duplicates': [], 'buttons': 149, 'initialView': 'design'} |
| Calibration A/B/CANCEL controls | **PASS** — {'states': ['B', 'CANCEL', 'A']} |
| Image load + point-to-point scale calibration | **PASS** — {'points': 2, 'status': 'APPROXIMATE SCALE', 'scaleText': '0,9423 cm/source-px'} |
| Import modal open/close/reopen and Escape path | **PASS** |
| Import modal + CSV preview | **PASS** — {'can_apply': True, 'mapping_controls': 7} |
| Manual CSV column mapping applies to preview | **PASS** |
| CSV import writes manual block and closes modal | **PASS** — template sumber tidak diubah |
| Download CSV template | **PASS** — KarstBlast_Blast_Import_Template.csv |
| XLSX parsing and validated preview | **PASS** |
| XLSX import writes manual block | **PASS** — 2 rows |
| Blast row selection keeps selected group and row | **PASS** |
| Manual blast entry creates an empty editable block | **PASS** |
| Manual block adds a new row | **PASS** — before 1, after 2 |
| Clear Actual deletes the selected row record | **PASS** |
| Delete manual block preserves built-in template | **PASS** — kembali ke `group1` |
| Kuz-Ram mode switching and run response | **PASS** — X50 26,4 cm / X80 44,4 cm |
| Screening executes and releases button | **PASS** — `CALCULATED` |
| Simulation button feedback | **PASS** — `SIMULASI BERJALAN` |
| No application-owned duplicate DOM IDs after UI mutations | **PASS** |
| Plotly SVG symbol duplicates vendor-contained | **PASS** — ['symbol'] |
| No uncaught browser JavaScript errors | **PASS** |

## Menjalankan ulang

Environment ini hanya dapat menjalankan pemeriksaan statis dan browser (tanpa Python/Playwright):

```bash
# sintaks (Node dari runtime Qoder, atau node biasa bila tersedia)
ELECTRON_RUN_AS_NODE=1 /path/to/Qoder.exe --check js/app.js
ELECTRON_RUN_AS_NODE=1 /path/to/Qoder.exe --check js/patches.js
ELECTRON_RUN_AS_NODE=1 /path/to/Qoder.exe --check js/a11y.js

# serving lokal untuk sertifikasi reload (jangan pakai file://)
python -m http.server 8731        # atau server statis lain di port bebas
```

Buka halaman, klik tab **Audit**, lalu tekan **JALANKAN TES**. Untuk sertifikasi reload: isi data, tekan `Ctrl+Shift+R`, dan pastikan panel masih menampilkan nilai yang sama beserta label sumbernya.

Bila Python + Playwright tersedia, runner lama (`qa/runtime_audit.py`, `qa/run_phase1_targeted_audit.py`) dapat dipakai kembali; keduanya belum diverifikasi terhadap perubahan hardening ini.
