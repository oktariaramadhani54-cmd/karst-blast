import json,re,urllib.parse
from playwright.sync_api import sync_playwright
EP="https://script.google.com/macros/s/AKMOCKTESTID123/exec"; TOKEN="mock-token-1234567890"
store={}; mode={"v":"ok"}
def handler(route,req):
    u=req.url
    if "BADENDPOINT" in u: return route.fulfill(status=404,body="not found")
    q=urllib.parse.parse_qs(urllib.parse.urlparse(u).query)
    if req.method=="POST":
        f=urllib.parse.parse_qs(req.post_data or "")
        if f.get("token",[""])[0]==TOKEN and mode["v"]=="ok": store.update(id=f["snapshotId"][0],payload=f["payload"][0],proj=f["projectId"][0],at=f["savedAt"][0])
        return route.fulfill(status=200,content_type="text/html",body="<html>ok</html>")
    cb=q.get("callback",["cb"])[0]; act=q.get("action",[""])[0]
    def js(o): route.fulfill(status=200,content_type="application/javascript",body=f"{cb}({json.dumps(o)});")
    if q.get("token",[""])[0]!=TOKEN: return js({"ok":False,"error":"Token tidak valid."})
    if act=="health": return js({"ok":True,"spreadsheet":"MOCK SHEET","saves":1 if store else 0})
    if act=="latest":
        if not store: return js({"ok":True,"found":False})
        return js({"ok":True,"found":True,"snapshotId":store["id"],"projectId":store["proj"],"savedAt":store["at"],"payloadChars":len(store["payload"]),"chunkCount":1})
    if act=="chunk": return js({"ok":True,"index":0,"total":1,"data":store["payload"]})
    js({"ok":False,"error":"aksi tidak dikenal"})
R=[]
def rec(n,ok,d): R.append((n,ok)); print("PASS" if ok else "FAIL",n,"|",d)
with sync_playwright() as p:
    b=p.chromium.launch(args=["--no-sandbox","--disable-gpu"])
    ctx=b.new_context(viewport={"width":1366,"height":768}); pg=ctx.new_page(); errs=[]
    pg.on("pageerror",lambda e:errs.append(str(e)[:150]))
    ctx.route("**/script.google.com/**",handler); ctx.route("**/script.googleusercontent.com/**",handler)
    pg.goto("file://__PROJECT_DIR__/index.html",wait_until="load"); pg.wait_for_timeout(1200)
    ST=lambda:pg.inner_text("#gsSyncStatus")
    def fill(ep,tok): pg.fill("#gsEndpoint",ep); pg.fill("#gsToken",tok)
    fill("https://example.com/x","short"); pg.click("#gsTestConnection"); pg.wait_for_timeout(300)
    rec("URL tidak valid ditolak",re.search("URL belum valid",ST()) is not None,ST()[:70])
    fill(EP,"pendek"); pg.click("#gsTestConnection"); pg.wait_for_timeout(300)
    rec("Token pendek ditolak",re.search("Token minimal",ST()) is not None,ST()[:70])
    fill(EP,"salah-token-123456789"); pg.click("#gsTestConnection"); pg.wait_for_timeout(800)
    rec("Token salah -> error dari endpoint",re.search("Koneksi gagal",ST()) is not None and "Token" in ST(),ST()[:90])
    fill("https://script.google.com/macros/s/BADENDPOINT/exec",TOKEN); pg.click("#gsTestConnection"); pg.wait_for_timeout(1500)
    rec("Endpoint salah (404) -> error jelas",re.search("Koneksi gagal",ST()) is not None,ST()[:100])
    fill(EP,TOKEN); pg.click("#gsTestConnection"); pg.wait_for_timeout(800)
    rec("Tes koneksi valid",re.search("Terhubung ke",ST()) is not None,ST()[:80])
    # ubah data lalu simpan
    pg.fill("#projectSite","SITE-UJI-A"); pg.dispatch_event("#projectSite","change"); pg.wait_for_timeout(300)
    pg.click("#gsSaveWorkspace"); pg.wait_for_timeout(4500)
    rec("Simpan snapshot terverifikasi",re.search("terverifikasi",ST()) is not None and bool(store),ST()[:100])
    rec("Snapshot berisi data terbaru",'SITE-UJI-A' in store.get("payload",""),f"payload {len(store.get('payload',''))} chars")
    # ubah lokal lalu restore
    pg.fill("#projectSite","SITE-LOKAL-B"); pg.dispatch_event("#projectSite","change"); pg.wait_for_timeout(300)
    pg.evaluate("window.KarstBlastForcePersist&&window.KarstBlastForcePersist()")
    pg.once("dialog",lambda d:d.accept())
    pg.click("#gsLoadWorkspace"); pg.wait_for_timeout(2500)
    cur=pg.evaluate("localStorage.getItem('karstblast_working_copy_v9')"); bk=pg.evaluate("localStorage.getItem('karstblast_working_copy_v9:before-restore')")
    rec("Restore mengubah state (SITE-UJI-A kembali)",'SITE-UJI-A' in (cur or ""),"")
    rec("Data lama diamankan sebelum restore",bool(bk) and 'SITE-LOKAL-B' in bk,f"backup {len(bk or '')} chars")
    pg.wait_for_timeout(500)
    rec("UI setelah reload menampilkan data restore",pg.input_value("#projectSite")=="SITE-UJI-A",pg.input_value("#projectSite"))
    rec("Tanpa pageerror",not errs,str(errs[:2]))
    b.close()
print(sum(1 for _,o in R if o),"/",len(R),"PASS")
