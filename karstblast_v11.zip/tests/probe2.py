import json,sys
from playwright.sync_api import sync_playwright
URL="file://__PROJECT_DIR__/index.html"
with sync_playwright() as p:
    b=p.chromium.launch(args=["--no-sandbox","--disable-gpu"])
    pg=b.new_page(viewport={"width":1366,"height":768})
    errs=[]
    pg.on("pageerror",lambda e:errs.append("PAGEERR "+str(e)[:250]))
    pg.goto(URL,wait_until="load"); pg.wait_for_timeout(1500)
    for v in ["design","image","sim","report","audit"]:
        pg.click(f"#tab-{v}"); pg.wait_for_timeout(300)
        vis=pg.evaluate(f"(()=>{{const e=document.getElementById('view-{v}');return e?{{hidden:e.hidden,disp:getComputedStyle(e).display,h:e.getBoundingClientRect().height}}:null}})()")
        print("TAB",v,vis)
    pg.click("#tab-sim"); pg.wait_for_timeout(300)
    pg.evaluate("document.getElementById('kzCanvas').scrollIntoView({block:'center'})")
    def sig():
        return pg.evaluate("(()=>{const c=document.getElementById('kzCanvas');const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let s=0;for(let i=0;i<d.length;i+=97)s=(s*31+d[i])%1000003;return {s,w:c.width,h:c.height,cw:c.clientWidth,ch:c.clientHeight}})()")
    print("kz before",sig())
    pg.screenshot(path="/home/claude/before_sim_kz_idle.png")
    pg.click("#kzBtnRun"); 
    for t in (150,600,1500,3500):
        pg.wait_for_timeout(t if t==150 else 600); print("kz after run",t,sig())
    pg.screenshot(path="/home/claude/before_sim_kz_running.png")
    # simSvg
    pg.evaluate("document.getElementById('simSvg').scrollIntoView({block:'center'})")
    bb=pg.evaluate("(()=>{const e=document.getElementById('simSvg');const r=e.getBoundingClientRect();return [r.width,r.height,e.innerHTML.length]})()")
    print("simSvg bbox/inner",bb)
    h0=pg.evaluate("document.getElementById('simSvg').innerHTML.length")
    pg.click("#detonateBtn"); pg.wait_for_timeout(800)
    h1=pg.evaluate("document.getElementById('simSvg').innerHTML.length")
    print("simSvg inner len before/after detonate",h0,h1)
    pg.screenshot(path="/home/claude/before_sim_detonate.png")
    # screening
    pg.click("#tab-design"); pg.wait_for_timeout(300)
    pg.evaluate("document.getElementById('btnRunScreening').scrollIntoView({block:'center'})")
    pre=pg.evaluate("document.body.innerText.length")
    pg.click("#btnRunScreening"); pg.wait_for_timeout(800)
    print("screening body len delta",pg.evaluate("document.body.innerText.length")-pre)
    print("ERRS",errs[:10])
    b.close()
