from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=["--no-sandbox","--disable-gpu"])
    pg=b.new_page(viewport={"width":1366,"height":768})
    pg.goto("file://__PROJECT_DIR__/index.html",wait_until="load"); pg.wait_for_timeout(1500)
    for v in ["design","sim","audit"]:
        pg.click(f"#tab-{v}"); pg.wait_for_timeout(300)
        print(v,pg.evaluate("""()=>['design','image','sim','report','audit'].map(x=>{const e=document.getElementById('view-'+x);return x+':'+(e.offsetParent!==null?'VISIBLE':'hidden')+':'+e.className}).join(' | ')"""))
    pg.click("#tab-design"); pg.wait_for_timeout(300)
    print("screening-related ids:",pg.evaluate("""()=>[...document.querySelectorAll('[id*=creen]')].map(e=>e.id+':'+(e.innerText||'').slice(0,60).replace(/\\n/g,' ')).slice(0,12)"""))
    pg.evaluate("document.getElementById('btnRunScreening').scrollIntoView({block:'center'})")
    snap=lambda:pg.evaluate("""()=>[...document.querySelectorAll('[id*=creen]')].map(e=>e.innerText).join('|')""")
    a=snap(); pg.click("#btnRunScreening"); pg.wait_for_timeout(1000); c=snap()
    print("screening output changed:",a!=c, "| len",len(a),len(c))
    pg.click("#tab-sim"); pg.wait_for_timeout(300)
    pg.evaluate("document.getElementById('simSvg').scrollIntoView({block:'start'})"); pg.wait_for_timeout(200)
    pg.screenshot(path="/home/claude/before_sim_top.png")
    b.close()
