from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=["--no-sandbox","--disable-gpu"])
    for w,h in [(390,844),(768,1024),(1366,768),(1920,1080)]:
        pg=b.new_page(viewport={"width":w,"height":h}); errs=[]
        pg.on("pageerror",lambda e:errs.append(str(e)[:120]))
        pg.goto("file://__PROJECT_DIR__/index.html",wait_until="load"); pg.wait_for_timeout(900)
        row=[]
        for v in ["design","image","sim","report","audit"]:
            pg.evaluate(f"document.getElementById('tab-{v}').click()"); pg.wait_for_timeout(250)
            over=pg.evaluate("""()=>{const W=document.documentElement.clientWidth;const bad=[...document.querySelectorAll('#main *')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.right>W+2&&e.offsetParent!==null&&!e.closest('[style*="overflow"],.kb-table-wrap,table,pre')}).slice(0,2).map(e=>e.tagName+'#'+e.id+'.'+String(e.className).slice(0,30));return [document.documentElement.scrollWidth>W+1,bad]}""")
            row.append(f"{v}:{'OVERFLOW '+str(over[1]) if over[0] else 'ok'}")
        print(w,"|"," ".join(row),"| errs",errs)
        if w==390:
            pg.evaluate("document.getElementById('tab-sim').click()"); pg.wait_for_timeout(300); pg.evaluate("scrollTo(0,0)"); pg.screenshot(path="/home/claude/after_390_sim.png")
        pg.close()
    b.close()
