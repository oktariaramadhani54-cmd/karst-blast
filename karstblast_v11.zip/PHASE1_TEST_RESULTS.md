# Hasil Tes Tahap 1 — KarstBlast (ringkasan angka)

**Tanggal:** 19 Oktober 2026 (Asia/Jakarta)  
Narasi lengkap, bukti reload, dan daftar keterbatasan ada di `PHASE1_QA_REPORT.md`; perubahan kodenya ada di `PHASE1_CHANGELOG.md`.

## Angka hasil run nyata

| Tes | Sebelum hardening | Sesudah hardening |
|---|---:|---:|
| Assertion di `js/app.js` (`runTests()`) | 313 | **322** |
| Built-in self-tests, Chromium, state bersih | tidak diukur terpisah (313 assertion yang sudah ada lulus semua sebelum 9 assertion baru ditambahkan) | **322/322 PASS** |
| Built-in self-tests dengan data proyek nyata di `localStorage` | 306/313 — angka ini diperoleh dari 315/322 hasil run sesudah hardening dikurangi 9 assertion baru yang lulus; 7 kegagalan berasal dari tes lama yang tidak terisolasi dari data aktual/override pengguna | **322/322 PASS** |
| Klaim laporan lama | "332/332" — tidak dapat direproduksi dari sumber ini | dikoreksi ke 322/322 |
| `node --check` (`app.js`, `patches.js`, `a11y.js`) | PASS | PASS |
| Persistensi sesudah reload penuh | **belum disertifikasi** | **PASS**, origin HTTP nyata, storage asli |
| Efek menekan `#btnRunTests` terhadap working copy | tidak diukur | **tidak ada** — signature storage identik sebelum/sesudah |
| Error console / uncaught page errors | 0 | 0 |
| Duplikat ID milik aplikasi (load dan setelah mutasi UI) | 0 | 0 |
| Peringatan konsol karena `value="--"` di `.kb-metric-input` | 18 | 0 |

## Rincian cakupan verifikasi ulang

- **Persistensi:** project id/site, formula, `comparisonInputs` + basis densitas, rencana Ash (B 4,490 m; tonase 3.542), `actualRecord` + `_sources`, `rowOverrides`, simulator (template/row/parameter), override Kuz-Ram manual + `kuzram.geo` + `wipBy`, `psdConfig`, `psd.sizeDefinition`, finansial — kembali identik setelah reload; tidak ada data lama yang tertimpa.
- **Pemilihan blast:** `#blastRowSelect` dan panel Blast Plan memakai baris yang sama; `planToSim()` mengisi ulang dropdown; payload lama bertemplate `'custom'` dinormalisasi saat boot.
- **Alur perhitungan:** perubahan baris/parameter → badge screening `STALE • HITUNG ULANG`, radar flyrock/PPV menjadi `--`; laporan Kuz-Ram mengikuti sumber PSD blast aktif (KUZ-RAM vs WIPFRAG per baris).
- **Impor + manual:** preview, mapping manual, validasi kosong/salah tipe/duplikat, Cancel/tutup/Escape tidak menulis state; buat blok → tambah baris → edit aktual → kosongkan aktual → hapus baris → hapus blok, dengan template bawaan tetap terlindungi.
- **Interaksi:** dijalankan lewat event DOM asli di Chromium (klik, `input`, `change`, `keydown`, `DataTransfer`/`File`). Harness Python/Playwright (`qa/*.py`, `qa/cr-kb-004.spec.mjs`) **tidak dapat dijalankan** di environment ini — Python dan Playwright tidak tersedia.

## Bukan merupakan

Sertifikasi kelayakan teknik atau desain peledakan. Rumus Kuz-Ram, Ash, Konya, MAE, PSD, dan persamaan simulator tidak diubah.
