# V10 — Hasil pengujian integrasi Google Spreadsheet

## Pemeriksaan yang lulus

- `js/app.js` dan `js/google-sheets-sync.js` lolos `node --check` (validasi sintaks JavaScript).
- `google-apps-script/Code.gs` lolos validasi sintaks JavaScript menggunakan Node parser.
- HTML diperiksa: tidak ditemukan ID duplikat dan semua referensi aset lokal yang diperiksa tersedia.
- Logika Apps Script diuji dengan mock SpreadsheetApp: penyimpanan menghasilkan `Log_Penyimpanan`, `Ringkasan_Blast`, dan `Arsip_Workspace`; metadata snapshot dapat dibaca; snapshot multi-bagian dapat dirangkai kembali; kolom arsip memakai awalan teks agar payload tidak ditafsirkan sebagai formula.

## Belum diuji secara langsung

- Belum terhubung ke Google Spreadsheet sungguhan, karena spreadsheet, token, dan deployment Web App milik pengguna belum dikonfigurasi.
- Pengujian browser Chromium headless pada lingkungan ini mengalami timeout, sehingga tidak dilaporkan sebagai uji UI end-to-end yang lulus.
- Karena itu, setelah mengatur Apps Script, lakukan uji nyata: **TES KONEKSI → SIMPAN KE SHEETS → refresh → MUAT BACKUP TERAKHIR** menggunakan data percobaan terlebih dahulu.

## Batasan yang tetap berlaku

- Snapshot hanya menyimpan state yang sudah dipersistensikan oleh KarstBlast. Foto, kalibrasi foto, canvas, dan dataset fragmen PSD per sesi tidak termasuk.
- Integrasi ini adalah simpan/muat snapshot manual, bukan sinkronisasi dua arah langsung untuk setiap edit.
- Deploy Apps Script dengan akses `Anyone` dan token bersama bukan autentikasi pengguna penuh; jangan gunakan untuk data perusahaan yang rahasia tanpa backend terautentikasi dan kontrol akses yang sesuai.
