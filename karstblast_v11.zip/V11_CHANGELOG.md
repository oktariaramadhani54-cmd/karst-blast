# V11 (parsial) — perubahan
- Sidebar: akar masalah CSS (`.kb-tabs::before` transform/width lama) diperbaiki; ikon ditampilkan; grup menu; kotak status dari badge nyata (js/patches.js).
- Tombol RUN SIMULATION + SCREENING tidak lagi menimpa teks panel.
- Simulasi ledakan: panel kontrol (status READY/RUNNING/PAUSED/COMPLETED/ERROR, Play, Pause, Replay, Reset, timeline ms). Timer internal simulasi (`simTimeout` di js/app.js) dibuat dapat dijeda; animasi dijeda lewat Web Animations API. Diberi label "ilustratif/konseptual".
- Google Sheets: sebelum restore, working copy lokal disimpan ke `karstblast_working_copy_v9:before-restore`.
- Rumus & mesin perhitungan TIDAK diubah.
