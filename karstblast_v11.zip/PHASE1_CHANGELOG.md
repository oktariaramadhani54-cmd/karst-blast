# Changelog Tahap 1 — KarstBlast

**Tanggal:** 19 Oktober 2026  
**Lingkup:** perbaikan kontrol dan konsistensi data; tidak mengubah rumus teknik maupun melakukan redesign besar.

## Perubahan yang dikerjakan

- Menambahkan **modal impor CSV/XLSX** dengan tombol buka/tutup, dukungan tutup via Escape/backdrop, preview, validasi sebelum apply, dan status setelah modal ditutup.
- Menambahkan **pemetaan kolom manual**. Kolom yang tidak dikenal dapat dipetakan ke field aplikasi, dengan tipe Rencana/Aktual yang dapat dipilih. Impor tetap membuat blok manual dan tidak menimpa template sumber bawaan.
- Menguji jalur **CSV dan XLSX** melalui file chooser asli di Chromium, mengubah satu mapping manual, mengimpor dua row, dan memverifikasi data masuk ke state.
- Mengembalikan **POINT A, POINT B, CANCEL kalibrasi** menjadi tombol aktif. Status `aria-pressed` sinkron dengan mode, dan `CLEAR POINTS` kembali ke mode POINT A.
- Menambahkan **HAPUS BLOK MANUAL** dengan konfirmasi. Blok manual beserta catatan aktual, row override, dan Wipfrag terkait dihapus; template bawaan dilindungi dan aplikasi kembali ke `group1`.
- Mempertahankan input manual, penambahan baris, penghapusan Aktual dua-klik, pilihan blast/row, mode Kuz–Ram, Screening, dan Simulasi; jalurnya diuji tanpa mengubah perhitungan teknik.
- Tidak membuat perubahan pada rumus teknik Kuz–Ram, Ash, Konya, MAE, atau simulator.

## Perubahan hardening akhir Tahap 1

`js/app.js`

- **Persistensi diverifikasi, bukan sekadar diklaim.** Sertifikasi reload penuh dijalankan pada origin HTTP nyata (storage asli browser): id/situs proyek, formula, `comparisonInputs` + basis densitas, rencana Ash, `actualRecord` + `_sources`, `rowOverrides`, template/row/parameter simulator, override Kuz-Ram manual + `kuzram.geo` + `wipBy`, `psdConfig`, `psd.sizeDefinition`, dan data finansial kembali identik; tidak ada penimpaan data lama.
- **Normalisasi payload lama saat boot** (setelah `registerManualBlastGroups()`): `simulation.template` yang tidak valid/di-resolve lewat `groupLabel` → `group1` → grup pertama, `groupLabel` yang menggantung diganti label grup hasil resolve, dan `activeBlastRow` dijepit ke baris yang benar-benar ada. Mencegah `#blastRowSelect` kosong dan blast aktif menggantung.
- **`planToSim()`** kini memanggil `populateBlastRowSelect()` setelah render tabel template, sehingga dropdown baris selalu mengikuti blast aktif.
- **`markScreeningStale(reason)`** (baru). Dipanggil dari `loadBlastSheetRow`, `editActiveBlastRowField`, `autoRecalcActiveBlastRow`, dan handler input simulator. Hanya bila badge masih `CALCULATED`: ubah ke `STALE • HITUNG ULANG`, tulis alasan di `#screeningNote`, set `window.__kbScreeningOK=false`, dan kosongkan `#radarFlyrockValue`/`#radarPpvValue` menjadi `--` dengan status `SCREENING BELUM TERHITUNG`. Perhitungan screening itu sendiri tidak diubah.
- **`deleteManualBlastRow(groupKey,rowNo)` + tombol `HAPUS BARIS MANUAL`** (baru). Menolak baris/blok bawaan dan baris terakhir, meminta konfirmasi, lalu ikut menghapus `actualRecord`, `rowOverrides`, dan `kuzram.wipBy` milik baris tersebut; baris berikutnya diaktifkan dan tabel/dropdown dirender ulang.
- **`sanitizeProjectBlasts(payload)`** (baru) dipakai `migratePersistedState`: whitelist key, hanya angka finite, string ≤ 120 karakter, id fallback `BLAST-i`, `activeId` wajib ada, `runMode` dipaksa `'single'`. Payload rusak atau berisi `__proto__` tidak dapat mencemari state.
- **Keterangan jujur untuk panel multi-blast**: tabel kosong diganti pesan `MODE SATU BARIS AKTIF — perhitungan multi-blast belum aktif` beserta sumber blast tunggalnya.
- **`simHydrate`**: field rencana yang kosong ditulis sebagai string kosong (bukan `0`/`NaN`); konverter `num()` menolak nilai non-finite.
- **Handler input simulator** tidak lagi menulis template palsu ke `#simTemplate`.
- **Isolasi tes**: `runStage3Tests` dan `runStage4Tests` menetralkan `APP_STATE.geometry.actualRecord` dan `APP_STATE.simulation.rowOverrides` di awal blok `try` (blok `finally` yang sudah ada mengembalikan data pengguna), dan tes ukuran fisik PSD mengunci `psd.sizeDefinition='feret'` lalu memulihkannya di `finally`. Suite tidak lagi bergantung pada apakah pengguna sudah mencatat data aktual.
- **`runTahap1HardeningTests(pass)`** (baru, 9 assertion): dropdown sinkron dengan baris aktif, tidak ada template palsu saat input simulator berubah, screening menjadi STALE + radar kosong setelah baris berubah, hapus baris manual membersihkan turunannya, baris bawaan terlindungi, tombol hapus eksak satu, sanitasi dan fallback `projectBlasts`, serta proteksi prototype lewat `migratePersistedState`.

`index.html`

- 19 input `.kb-metric-input` memakai `placeholder="--"` sebagai ganti `value="--"` (menghapus 18 peringatan konsol dan mencegah `--` terbaca sebagai data).
- Tombol `HAPUS BARIS MANUAL` ditambahkan di samping TAMBAH BARIS MANUAL.
- Teks bagian "DAFTAR BLAST PROYEK & PEMETAAN GEOMETRI" ditulis ulang: daftar multi-blast **belum aktif**; Group/Row pada bagian SUMBER DATA dan BARIS adalah sumber tunggal.

## Status

Jumlah assertion suite: **313 → 322** setelah 9 tes hardening ditambahkan. Hasil run nyata: **322/322 PASS** pada state bersih dan pada state berisi data pengguna; konsol bersih; menekan tombol tes tidak mengubah working copy. Klaim lama "332/332" tidak dapat direproduksi dari sumber ini dan telah dikoreksi di laporan.


Lihat `PHASE1_TEST_RESULTS.md` untuk hasil pengujian aktual dan batasan environment. Semua tes yang tercantum di sana dijalankan pada salinan kode project ini.
