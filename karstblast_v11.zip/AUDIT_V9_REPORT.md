# KarstBlast V9 — audit & repair report

**Scope:** static code audit, deploy configuration, and conservative presentation redesign. **Not a certification of blast-engineering calculations or a complete browser regression pass.**

## Verdict

**Suitable to deploy to Vercel as a presentation/demo site, conditionally. Not yet ready to be represented as production-certified operational engineering software.** Deploy the preview first, run a browser test on desktop and mobile, and only then promote the site to Production.

## Improvements applied in V9

- Replaced the final dark/neon-green presentation layer with a light, high-contrast workspace; kept a restrained slate navigation rail and safety-orange primary actions.
- Removed the oversized explosion hero/particles from the presentation header. The actual simulator and calculation logic are unchanged by the visual change.
- Normalized header sizing, card spacing, typography, field backgrounds, table colours, metric cards, buttons, and chart labels. Removed gradients and glow/shadow treatment that made the page look like a generic AI dashboard.
- Changed all seven external classic script tags to `defer` while keeping their source order, reducing parser-blocking downloads from the bundled libraries.
- Added explicit accessible names to the 19 editable geometry metric fields; static review found no remaining visible form fields without an explicit accessible name.
- Fixed a layout override conflict: a late desktop rule had added `padding-right: 220px` to the fixed navigation, leaving too little space for its labels. V9 explicitly resets that padding.
- Localized the page title, description, header tagline, and primary tab labels to Indonesian.
- Added `vercel.json` for static deployment and baseline response headers, plus this deployment guide.

## Strengths

- Single-page static architecture: no server, build step, or package installation required for deployment.
- Vendor dependencies (Plotly, PapaParse, SheetJS) are bundled locally rather than required from a third-party script CDN.
- The project contains data-source/provenance indicators, export/report functions, validation steps for import, and warnings that outputs need engineering review.
- Existing source reports describe tests around persistence, CSV/XLSX import, manual rows, screening, simulator feedback and duplicate DOM IDs.
- Existing CSP restricts script execution to same-origin sources and disallows objects; no API secret is needed for the current static flow.

## Material limitations and risks

| Area | Finding | Consequence / action |
|---|---|---|
| Multi-blast analysis | Project QA notes say weighted-average and batch modes have no connected calculation consumer. | Do not present multi-blast output as implemented. |
| Photo PSD | `V8_CHANGELOG.md` reports mean IoU around 0.33 against manual WipFrag outlines and explicitly says manual ROI/boundary correction may be needed. | Label automatic segmentations as draft; validate with field photos and operator outlines. |
| Calculation validity | No independent technical reproduction of all Kuz-Ram, Ash, Konya, MAE, PPV and karst-screening formulas was part of this visual/deploy pass. | Have a blasting engineer review methods, units, assumptions, and representative cases before operational use. |
| Persistence | Data is browser-local (`localStorage`), with no backend/database. | A QR shares the page URL, not the current user's project data. Back up/export data; do not assume cross-device sync. |
| Access control | App source and client-side datasets are public after deployment; no login is configured. | Never store credentials, access tokens, or confidential site data in the public app. |
| Browser validation | Static checks completed. The headless Chromium smoke run did not finish in this environment, so V9's interaction paths could not be re-certified here. | Complete the preview checklist manually before production promotion. |
| Stylesheet maintainability | `style.css` contains layered historical theme overrides. V9 applies one explicit final theme layer to avoid a risky rewrite of application selectors. | Future development should consolidate CSS in a dedicated refactor after browser regression tests. |

## Checks performed on this bundle

- `node --check` passes for `js/app.js`, `js/patches.js`, `js/lab-data.js`, and `js/a11y.js`.
- Static HTML inspection found 694 IDs with no duplicates, 8 local file references with no missing targets, 0 inline script blocks, and all visible form fields with an explicit accessible name.
- CSS parser reported 0 syntax errors (1,406 top-level rules/blocks); braces are balanced. `vercel.json` parses as JSON.
- All seven external classic scripts use `defer` and remain in their original document order.
- Not performed: successful headless browser smoke test (Chromium did not terminate in this environment, including on `about:blank`), cross-browser certification, production Vercel deployment, exhaustive tests of every button, real-site field-data validation, formula certification, and physical mobile-device tests.

## Pre-production checklist

1. Open the preview URL on desktop and mobile; verify all 5 tabs navigate and no content is obscured by the navigation.
2. Import one test CSV and XLSX, add/edit/delete a manual row, and confirm validation errors are understandable.
3. Test the active blast row → geometry comparison → simulator → Run Screening → report/export chain with known sample values.
4. Upload a representative photo, calibrate it with a known scale, compare detected fragments with a manual reference, and inspect D50/D80 and units.
5. Refresh the page and verify what persists; export a backup. Confirm the user-facing notice makes clear that the QR does not package saved browser data.
6. Only after these checks, promote the Vercel preview to Production and generate the QR from the final Production URL.
