# KarstBlast V10 — Integrasi Google Spreadsheet

Integrasi ini menambahkan fitur **TES KONEKSI**, **SIMPAN KE SHEETS**, dan **MUAT BACKUP TERAKHIR**. Simpanan terdiri dari snapshot working copy untuk pemulihan serta ringkasan yang lebih mudah dibaca. Foto PSD, nilai kalibrasi foto, canvas, dan dataset fragmen PSD memang tidak termasuk working copy permanen pada aplikasi saat ini.

## A. Buat Google Spreadsheet dan Apps Script

1. Buat Google Spreadsheet baru, misalnya `KarstBlast - Data Proyek`.
2. Dari spreadsheet tersebut, pilih **Extensions / Ekstensi → Apps Script**.
3. Hapus kode contoh lalu salin isi file `google-apps-script/Code.gs` ke editor Apps Script. Simpan proyek.
4. Buka **Project Settings / Setelan project → Script Properties → Add script property**. Buat properti:
   - Property: `KARSTBLAST_SYNC_KEY`
   - Value: buat token acak minimal 16 karakter, lebih panjang lebih baik. Contoh format: `KB-` diikuti rangkaian acak panjang. Jangan gunakan contoh token publik atau kata sandi akun Google.
5. Pilih **Deploy → New deployment → Web app**.
   - **Execute as:** Me
   - **Who has access:** Anyone
   - Deploy dan setujui izin Google yang diminta.
6. Salin URL Web App yang berakhir dengan `/exec`. Jika mengubah kode Apps Script setelah deploy, buat versi deployment baru atau perbarui deployment yang ada.

## B. Hubungkan KarstBlast

1. Buka website KarstBlast melalui HTTPS (alamat deployment Vercel).
2. Buka panel **Google Spreadsheet**.
3. Tempel URL Web App `/exec` dan masukkan `KARSTBLAST_SYNC_KEY` yang sama persis dengan Script Properties.
4. Klik **SIMPAN KONFIGURASI**, lalu **TES KONEKSI**. Status harus menunjukkan nama spreadsheet.
5. Klik **SIMPAN KE SHEETS**. Tunggu sampai status menampilkan bahwa snapshot berhasil diverifikasi. Jangan menutup tab sebelum status akhir muncul.
6. Apps Script membuat tiga tab: `Log_Penyimpanan`, `Ringkasan_Blast`, dan `Arsip_Workspace`.
7. Untuk mengambil snapshot terbaru di browser ini, klik **MUAT BACKUP TERAKHIR** dan konfirmasi. Working copy lokal akan diganti lalu halaman dimuat ulang.

## C. Isi ketiga tab

- **Ringkasan_Blast**: waktu simpan, ID proyek, lokasi, material, group/row aktif, dan sebagian parameter utama.
- **Log_Penyimpanan**: histori snapshot, versi aplikasi, ukuran payload, dan jumlah bagian.
- **Arsip_Workspace**: snapshot JSON dibagi ke beberapa baris agar sel tetap di bawah batas ukuran; bagian payload diberi awalan teknis `KBJSON:` untuk mencegah isi snapshot ditafsirkan sebagai formula spreadsheet. Jangan edit nilai di tab ini secara manual; perubahan pada arsip bisa membuat pemulihan gagal.

## Batasan yang perlu diketahui

- Integrasi menyimpan **working copy yang memang diserialisasi oleh KarstBlast**, bukan seluruh isi browser. Foto yang diunggah, kalibrasi yang terkait foto, canvas, dan dataset fragmentasi PSD sesi tidak tersimpan dalam snapshot versi ini. Arsip foto harus disimpan terpisah di Google Drive.
- Konfigurasi URL dan token disimpan di `localStorage` browser pengguna. Konfigurasi perlu diisi pada setiap browser/perangkat yang akan menyimpan atau memuat data.
- Deployment Apps Script dengan akses `Anyone` tetap merupakan endpoint publik; token di aplikasi adalah perlindungan tambahan, bukan pengganti autentikasi pengguna. Siapa pun yang mendapatkan URL **dan** token dapat membaca/mengubah data lewat endpoint. Gunakan token kuat, batasi distribusi, rotasi token jika terekspos, dan **jangan gunakan untuk data rahasia atau data sensitif perusahaan**.
- Untuk penggunaan perusahaan atau kolaborasi banyak pengguna, rekomendasi produksi adalah Google OAuth / pembatasan pengguna dan backend terautentikasi (mis. Vercel serverless + Google Sheets API), dengan hak akses dan audit yang benar.
- Setiap klik simpan membuat snapshot baru; spreadsheet menjadi arsip snapshot, bukan lembar input live yang otomatis tersinkron dua arah. Mengedit sel ringkasan tidak mengubah working copy di website.

## Cek cepat

- URL berakhir `/exec`, bukan `/dev`.
- Script Property `KARSTBLAST_SYNC_KEY` berisi token minimal 16 karakter.
- Web App sudah di-deploy dan izin akses sesuai konfigurasi.
- Status `TES KONEKSI` berhasil sebelum menyimpan data proyek.
- Uji **SIMPAN KE SHEETS → refresh browser → MUAT BACKUP TERAKHIR** dengan data uji terlebih dahulu.
