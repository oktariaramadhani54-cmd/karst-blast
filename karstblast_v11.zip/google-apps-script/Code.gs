/**
 * KarstBlast Google Sheets Sync
 * Pasang pada Extensions > Apps Script dari Google Spreadsheet tujuan.
 * Simpan token di Project Settings > Script properties:
 *   KARSTBLAST_SYNC_KEY = token rahasia pilihan pemilik
 * Deploy sebagai Web app (Execute as: Me; Who has access: Anyone).
 */
const KB_SYNC = {
  ARCHIVE_SHEET: 'Arsip_Workspace',
  LOG_SHEET: 'Log_Penyimpanan',
  SUMMARY_SHEET: 'Ringkasan_Blast',
  CHUNK_SIZE: 30000,
  ARCHIVE_HEADERS: ['Waktu Simpan', 'Snapshot ID', 'Project ID', 'Indeks Bagian', 'Total Bagian', 'Potongan JSON'],
  LOG_HEADERS: ['Waktu Simpan', 'Snapshot ID', 'Project ID', 'Lokasi', 'Versi Aplikasi', 'Ukuran JSON (karakter)', 'Jumlah Bagian'],
  SUMMARY_HEADERS: ['Waktu Simpan', 'Snapshot ID', 'Project ID', 'Lokasi', 'Material', 'Group Aktif', 'Row Aktif', 'Burden (m)', 'Spacing (m)', 'Kedalaman (m)', 'Jumlah Lubang', 'AN per Lubang (kg)', 'Ukuran JSON (karakter)', 'Jumlah Bagian']
};

function doGet(e) {
  const p = (e && e.parameter) || {};
  const callback = String(p.callback || '');
  let result;
  try {
    assertAuthorized_(p.token);
    const action = String(p.action || 'health');
    if (action === 'health') result = health_();
    else if (action === 'latest') result = latest_();
    else if (action === 'chunk') result = chunk_(String(p.snapshotId || ''), Number(p.index));
    else if (action === 'history') result = history_();
    else result = { ok: false, error: 'Aksi tidak dikenal.' };
  } catch (err) {
    result = { ok: false, error: safeMessage_(err) };
  }
  const json = JSON.stringify(result).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');
  if (callback && /^[A-Za-z_$][0-9A-Za-z_$]*$/.test(callback)) {
    return ContentService.createTextOutput(callback + '(' + json + ');').setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    const p = (e && e.parameter) || {};
    assertAuthorized_(p.token);
    if (String(p.action || '') !== 'save') throw new Error('Aksi simpan tidak dikenal.');
    const snapshotId = String(p.snapshotId || '').slice(0, 120);
    const raw = String(p.payload || '');
    if (!snapshotId || !raw) throw new Error('Snapshot ID atau payload kosong.');
    if (raw.length > 5000000) throw new Error('Snapshot lebih dari 5 MB; kecilkan data atau ekspor foto secara terpisah.');
    const state = JSON.parse(raw);
    if (!state || typeof state !== 'object' || Array.isArray(state) || !Number.isFinite(Number(state.version)) || Number(state.version) < 11) throw new Error('Format working copy KarstBlast tidak dikenali.');

    const lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try {
      const ss = SpreadsheetApp.getActiveSpreadsheet();
      if (!ss) throw new Error('Spreadsheet tujuan tidak ditemukan. Buat Apps Script dari dalam Google Spreadsheet.');
      const archive = sheetWithHeader_(ss, KB_SYNC.ARCHIVE_SHEET, KB_SYNC.ARCHIVE_HEADERS);
      const log = sheetWithHeader_(ss, KB_SYNC.LOG_SHEET, KB_SYNC.LOG_HEADERS);
      const summary = sheetWithHeader_(ss, KB_SYNC.SUMMARY_SHEET, KB_SYNC.SUMMARY_HEADERS);
      const savedAt = new Date();
      const project = state.project || {};
      const sim = state.simulation || {};
      const params = sim.parameters || {};
      const projectId = sheetSafeText_(project.id || p.projectId || 'KarstBlast_Project', 120);
      const site = sheetSafeText_(project.site || p.site || '', 160);
      const chunks = [];
      for (let i = 0; i < raw.length; i += KB_SYNC.CHUNK_SIZE) chunks.push(raw.slice(i, i + KB_SYNC.CHUNK_SIZE));
      const archiveRows = chunks.map((chunk, i) => [savedAt, snapshotId, sheetSafeText_(projectId, 120), i, chunks.length, 'KBJSON:' + chunk]);
      if (archiveRows.length) archive.getRange(archive.getLastRow() + 1, 1, archiveRows.length, KB_SYNC.ARCHIVE_HEADERS.length).setValues(archiveRows);
      log.appendRow([savedAt, snapshotId, projectId, site, Number(state.version) || 11, raw.length, chunks.length]);
      summary.appendRow([
        savedAt, snapshotId, projectId, site,
        sheetSafeText_(state.formation && (state.formation.label || state.formation.key) || '', 100),
        sheetSafeText_(sim.groupLabel || sim.template || '', 160),
        Number(sim.activeBlastRow) || '',
        numberOrBlank_(params.burdenM), numberOrBlank_(params.spacingM), numberOrBlank_(params.depthM),
        numberOrBlank_(params.holeCount), numberOrBlank_(params.anPerHoleKg), raw.length, chunks.length
      ]);
      return jsonOutput_({ ok: true, snapshotId: snapshotId, chunks: chunks.length, savedAt: savedAt.toISOString() });
    } finally {
      lock.releaseLock();
    }
  } catch (err) {
    return jsonOutput_({ ok: false, error: safeMessage_(err) });
  }
}

function assertAuthorized_(provided) {
  const expected = PropertiesService.getScriptProperties().getProperty('KARSTBLAST_SYNC_KEY');
  if (!expected || expected.length < 16) throw new Error('Pemilik belum mengatur KARSTBLAST_SYNC_KEY (minimal 16 karakter) di Script Properties.');
  if (String(provided || '') !== expected) throw new Error('Token tidak cocok. Periksa token KarstBlast dan Script Properties.');
}

function health_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Spreadsheet tujuan tidak ditemukan.');
  const log = ss.getSheetByName(KB_SYNC.LOG_SHEET);
  return { ok: true, spreadsheet: ss.getName(), hasSavedData: !!(log && log.getLastRow() > 1), saves: log ? Math.max(0, log.getLastRow() - 1) : 0 };
}

function latest_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss && ss.getSheetByName(KB_SYNC.LOG_SHEET);
  if (!sh || sh.getLastRow() < 2) return { ok: true, found: false, message: 'Belum ada snapshot tersimpan.' };
  const row = sh.getRange(sh.getLastRow(), 1, 1, KB_SYNC.LOG_HEADERS.length).getValues()[0];
  return { ok: true, found: true, savedAt: iso_(row[0]), snapshotId: String(row[1]), projectId: String(row[2]), site: String(row[3] || ''), appVersion: Number(row[4]) || 11, payloadChars: Number(row[5]) || 0, chunkCount: Number(row[6]) || 0 };
}

function chunk_(snapshotId, index) {
  if (!snapshotId || !Number.isInteger(index) || index < 0) throw new Error('Permintaan potongan snapshot tidak valid.');
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss && ss.getSheetByName(KB_SYNC.ARCHIVE_SHEET);
  if (!sh || sh.getLastRow() < 2) throw new Error('Arsip snapshot masih kosong.');
  const data = sh.getRange(2, 1, sh.getLastRow() - 1, KB_SYNC.ARCHIVE_HEADERS.length).getValues();
  for (let i = data.length - 1; i >= 0; i--) {
    if (String(data[i][1]) === snapshotId && Number(data[i][3]) === index) {
      const stored = String(data[i][5] || '');
      if (!stored.startsWith('KBJSON:')) throw new Error('Format potongan arsip tidak valid.');
      return { ok: true, snapshotId: snapshotId, index: index, total: Number(data[i][4]), data: stored.slice(7) };
    }
  }
  throw new Error('Potongan snapshot tidak ditemukan.');
}

function history_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss && ss.getSheetByName(KB_SYNC.LOG_SHEET);
  if (!sh || sh.getLastRow() < 2) return { ok: true, items: [] };
  const first = Math.max(2, sh.getLastRow() - 9);
  const rows = sh.getRange(first, 1, sh.getLastRow() - first + 1, KB_SYNC.LOG_HEADERS.length).getValues().reverse();
  return { ok: true, items: rows.map(r => ({ savedAt: iso_(r[0]), snapshotId: String(r[1]), projectId: String(r[2]), site: String(r[3] || ''), payloadChars: Number(r[5]) || 0 })) };
}

function sheetWithHeader_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#dbe7ef');
  }
  return sh;
}
function jsonOutput_(obj) { return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON); }
function text_(v, max) { return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').slice(0, max); }
function sheetSafeText_(v, max) { const s = text_(v, max); return /^[\s]*[=+\-@]/.test(s) ? "'" + s : s; }
function numberOrBlank_(v) { const n = Number(v); return v !== null && v !== '' && Number.isFinite(n) ? n : ''; }
function iso_(v) { return v instanceof Date ? v.toISOString() : String(v || ''); }
function safeMessage_(err) { return text_(err && err.message ? err.message : 'Kesalahan tidak diketahui.', 350); }
