# V7 — 25 Okt 2026
Diukur terhadap outline WipFrag manual di 6 foto (HH-8, EE-4, HH-13, GG-10, CC-7, BB-6), ROI = area yang dioutline WipFrag.
- Tambah `baseSigma` (smoothing dasar V5, UI: "Smoothing tekstur", default 2.5; sebelumnya tetap 1.2) dan `minRegion` (gabung paksa region kecil, default 0 = mati).
- IoU rata-rata terhadap WipFrag: 0.312 -> 0.331. Perbaikan KECIL.
## Batasan (penting)
- V5 TIDAK menyamai net WipFrag manual: IoU ~0.33, error D50 berubah-ubah -39%..+40% antar foto. Tuning parameter (37+12 kombinasi, leave-one-out) tidak mengubah itu.
- Pakai ROI poligon hanya di area batu; hasil auto = DRAFT, rapikan dengan merge/split/trace.
- Foto JJ 13-14 belum terukur (screenshot pembanding tidak bisa dipasang ke foto asli).
- Test suite browser TIDAK dijalankan ulang; engine diverifikasi di Node (default tanpa opsi = identik dengan V6).
